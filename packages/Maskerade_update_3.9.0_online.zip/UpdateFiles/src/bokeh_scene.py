"""Automatic table-scene preservation using local SAM2 and face anchors.

No per-file coordinates: prompts come from the existing person mask. Ambiguous
scenes return None so the conservative legacy table detector remains available.
"""
from collections import OrderedDict
from contextlib import nullcontext
from pathlib import Path
import hashlib
import logging
import threading
import cv2
import numpy as np

_LOCK = threading.RLock()
_CACHE = OrderedDict()
_FRONT_FACE_CACHE = OrderedDict()
_FACE = None
_MODELS = None
_LOG = logging.getLogger(__name__)


def _face_detector():
    global _FACE
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision
    root = Path(__file__).resolve().parents[1]
    if _FACE is None:
        _FACE = vision.FaceDetector.create_from_options(vision.FaceDetectorOptions(
            base_options=python.BaseOptions(model_asset_path=str(root/'models/MediaPipe/blaze_face_full_range.tflite')),
            min_detection_confidence=.3, min_suppression_threshold=.3))
    return _FACE


def _models():
    global _MODELS
    import torch
    detector = _face_detector()
    root = Path(__file__).resolve().parents[1]
    if _MODELS is None:
        from sam2.build_sam import build_sam2
        from sam2.sam2_image_predictor import SAM2ImagePredictor
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        original = torch.jit.script
        try:
            torch.jit.script = lambda value: value
            model = build_sam2('configs/sam2.1/sam2.1_hiera_t.yaml',
                              str(root/'models/SAM2/sam2.1_hiera_tiny.pt'), device=device)
            predictor = SAM2ImagePredictor(model)
        finally:
            torch.jit.script = original
        _MODELS = predictor, device
    return detector, _MODELS


def _face_anchors(rgb, alpha, detector):
    import mediapipe as mp
    h, w = alpha.shape
    faces = []
    confidence = []
    # Rotated passes recover tilted heads and small children; size alone never
    # excludes a diner. Existing mask support rejects background false positives.
    for angle in (0, 30, -30):
        matrix = cv2.getRotationMatrix2D((w/2, h/2), angle, 1)
        rotated = cv2.warpAffine(rgb, matrix, (w, h)) if angle else rgb
        inverse = cv2.invertAffineTransform(matrix)
        detections = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,
                                     data=np.ascontiguousarray(rotated))).detections
        for detection in detections:
            score = detection.categories[0].score
            if score < .35:
                continue
            b = detection.bounding_box
            cx, cy = inverse @ np.array([b.origin_x+b.width/2, b.origin_y+b.height/2, 1])
            size = max(b.width, b.height)
            x, y = int(cx-size/2), int(cy-size/2)
            patch = alpha[max(0,y):min(h,y+size), max(0,x):min(w,x+size)]
            support = float(patch.mean()) if patch.size else 0.0
            if support < .04 or (score < (.4 if angle else .45) and support < .3):
                continue
            if any(np.hypot(cx-f[0], cy-f[1]) < max(size,f[2])*.65 for f in faces):
                continue
            faces.append((float(cx), float(cy), float(size)))
            confidence.append(float(score))
    confirmed=[]
    for face,score in zip(faces,confidence):
        cx,cy,size=face
        # A weak, small detection immediately above a larger confirmed face
        # can be glasses or a hair accessory. Check the local image at higher
        # resolution before treating it as an additional person. Genuine small
        # heads still qualify when confirmed in the crop, including tilted ones.
        above_head=any(other_score>=.65 and size<other_size*.45
                       and abs(cx-ox)<other_size*.6
                       and other_size*.55<oy-cy<other_size*1.45
                       for (ox,oy,other_size),other_score in zip(faces,confidence))
        if score<.65 and above_head and not _confirm_local_face(rgb,face,detector):
            _LOG.info('Unconfirmed small detection above supported head: score %.2f at (%d,%d); ignoring accessory candidate',score,cx,cy)
            continue
        confirmed.append(face)
    return confirmed


def _confirm_local_face(rgb, face, detector):
    """Recheck a possible head accessory without changing the main threshold."""
    import mediapipe as mp
    cx,cy,side=face
    h,w=rgb.shape[:2]
    x0,y0=max(0,int(cx-side*1.5)),max(0,int(cy-side*1.5))
    x1,y1=min(w,int(cx+side*1.5)),min(h,int(cy+side*1.5))
    crop=rgb[y0:y1,x0:x1]
    ch,cw=crop.shape[:2]
    if min(ch,cw)<16:
        return True
    for angle in (0,30,-30):
        matrix=cv2.getRotationMatrix2D((cw/2,ch/2),angle,1)
        frame=cv2.warpAffine(crop,matrix,(cw,ch)) if angle else crop
        inverse=cv2.invertAffineTransform(matrix)
        detections=detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,
                                    data=np.ascontiguousarray(frame))).detections
        for detection in detections:
            if detection.categories[0].score<.35:
                continue
            b=detection.bounding_box
            px,py=inverse@np.array([b.origin_x+b.width/2,b.origin_y+b.height/2,1])
            if (.5*side<max(b.width,b.height)<side*1.8
                    and np.hypot(px+x0-cx,py+y0-cy)<side*.4):
                return True
    return False


def _gap_bounds(alpha):
    h, w = alpha.shape
    rows = []
    for y in range(int(h*.60), int(h*.82)):
        xs = np.flatnonzero(alpha[y] > .7)
        left, right = xs[xs<w*.45], xs[xs>w*.55]
        if len(left) and len(right) and right[0]-left[-1] > w*.15:
            rows.append((left[-1], right[0]))
    if len(rows) < h*.08:
        return None
    return np.median(rows, axis=0)


def has_possible_table_layout(people):
    """Cheap, color-independent warning for table-like group geometry.

    This is deliberately broader than a confirmed table. It prevents an
    uncertain tabletop from entering the ordinary person-only blur path.
    """
    h, w = people.shape
    if h < 320 or w < 320 or not np.isfinite(people).all():
        return False
    scale = min(1., 1100 / w)
    alpha = cv2.resize(people, (round(w * scale), round(h * scale)),
                       interpolation=cv2.INTER_AREA)
    if _gap_bounds(alpha) is not None:
        return True
    if w <= h:
        return False
    sh, sw = alpha.shape
    near_people = alpha[int(sh * .55):int(sh * .65)]
    foreground = alpha[int(sh * .78):int(sh * .92)]
    return (np.mean(near_people > .7) >= .55
            and np.mean(foreground < .3) >= .72
            and np.mean(foreground[:, int(sw * .30):int(sw * .70)] < .3) >= .8)


def _table_gap_fallback(alpha, faces):
    """Protect a table between seated rows when SAM2 misses its dark surface.

    A valid gap widens toward the camera and is bordered by at least two
    detected diners on each side. Portraits do not qualify.
    """
    h, w = alpha.shape
    if (len(faces) < 4 or sum(x < w*.45 for x, _, _ in faces) < 2
            or sum(x > w*.55 for x, _, _ in faces) < 2):
        return None
    left = np.full(h, np.nan, np.float32)
    right = np.full(h, np.nan, np.float32)
    for y in range(int(h*.4), int(h*.97)):
        xs = np.flatnonzero(alpha[y] > .7)
        l, r = xs[xs < w*.45], xs[xs > w*.55]
        if len(l) and len(r) and .095*w < r[0]-l[-1] < .65*w:
            left[y], right[y] = l[-1], r[0]
    width = right-left
    if np.count_nonzero(np.isfinite(width)) < h*.23:
        return None
    start = None
    for y in range(int(h*.42), int(h*.68)):
        if not np.isfinite(width[y]) or width[y] < w*.13:
            continue
        later = width[min(h-1, y+int(h*.16)):min(h, y+int(h*.23))]
        later = later[np.isfinite(later)]
        if ((len(later) > h*.025 and np.median(later) > width[y]*1.18)
                or (y >= h*.52 and width[y] > w*.23)):
            start = y
            break
    if start is None:
        return None
    tail = width[start:int(h*.97)]
    finite = tail[np.isfinite(tail)]
    if (len(finite) < h*.20 or
            np.quantile(finite, .85) < max(w*.20, width[start]*1.12)):
        return None
    peak = float(np.quantile(finite, .9))
    end = int(h*.97)
    for y in range(max(int(h*.75), start+int(h*.2)), end-int(h*.025)):
        sample = width[y:y+max(3,int(h*.025))]
        sample = sample[np.isfinite(sample)]
        if len(sample) > h*.015 and np.median(sample) < peak*.58:
            end = y
            break
    valid = np.flatnonzero(np.isfinite(width[start:end]))+start
    if len(valid) < h*.18:
        return None
    rows = np.arange(start,end)
    l = np.interp(rows, valid, left[valid]).astype(int)+2
    r = np.interp(rows, valid, right[valid]).astype(int)-2
    table = np.zeros((h,w), np.uint8)
    for y, x0, x1 in zip(rows,l,r):
        if x1 > x0:
            table[y,x0:x1+1] = 1
    return table


def is_long_table_scene(source, people):
    """Conservatively identify a long table before running SAM2 or blurring.

    A light cloth has its own continuous-surface evidence. Dark tables need
    the widening gap between at least two supported diners on each side.
    """
    h, w = people.shape
    if h < 320 or w < 320 or not np.isfinite(people).all():
        return False
    scale = min(1., 1100 / w)
    size = (round(w*scale), round(h*scale))
    alpha = cv2.resize(people, size, interpolation=cv2.INTER_AREA)
    if _gap_bounds(alpha) is None:
        return False
    from .bokeh_table import table_foreground
    cloth = table_foreground(np.asarray(source, np.float32), people)
    if np.count_nonzero(cloth > .5) > cloth.size * .08:
        _LOG.info('Long table with cloth: selecting complete surface')
        return True
    rgb = cv2.resize(np.asarray(source, np.uint8), size, interpolation=cv2.INTER_AREA)
    try:
        faces = _face_anchors(rgb, alpha, _face_detector())
    except Exception:
        _LOG.exception('Long-table face detection unavailable')
        return False
    if _table_gap_fallback(alpha, faces) is not None:
        _LOG.info('Long table without cloth: selecting complete surface')
        return True
    return False


def has_possible_front_table_layout(people):
    """Notice even a thin or diagonal unmasked near-camera surface.

    This is a risk gate, not semantic table recognition. Color cannot tell a
    black tabletop from the background. A bottom-connected gap below a broad
    group also protects dishes, cups and cloth of any color.
    """
    h, w = people.shape
    # Near-camera tables also occur in portrait couples and square crops.
    # Keep the same minimum resolution without using orientation as a veto.
    if min(h, w) < 320 or max(h, w) < 480 or not np.isfinite(people).all():
        return False
    scale = min(1., 640 / max(h, w))
    alpha = cv2.resize(people, (round(w * scale), round(h * scale)),
                       interpolation=cv2.INTER_AREA)
    sh, sw = alpha.shape
    if np.mean(alpha[int(sh * .45):int(sh * .75)] > .7) < .30:
        return False
    gaps = (alpha[int(sh * .60):] < .65).astype(np.uint8)
    _, labels = cv2.connectedComponents(gaps, 8)
    bottom_labels = np.unique(labels[-1])
    bottom_labels = bottom_labels[bottom_labels != 0]
    if not len(bottom_labels):
        return False
    connected = np.isin(labels, bottom_labels)
    # A small visible strip is enough; do not require the table at 78..92%.
    broad_rows = connected.sum(axis=1) >= sw * .22
    return bool(np.count_nonzero(broad_rows) >= max(3, round(sh * .018)))


def _front_table_faces(source, people):
    h, w = people.shape
    scale = min(1., 1100 / w)
    size = (round(w * scale), round(h * scale))
    alpha = cv2.resize(people, size, interpolation=cv2.INTER_AREA)
    rgb = cv2.resize(np.asarray(source, np.uint8), size, interpolation=cv2.INTER_AREA)
    key = hashlib.sha256(rgb.tobytes() + np.rint(alpha * 255).astype(np.uint8).tobytes()).digest()
    with _LOCK:
        if key not in _FRONT_FACE_CACHE:
            try:
                _FRONT_FACE_CACHE[key] = _face_anchors(rgb, alpha, _face_detector())
            except Exception:
                _LOG.exception('Front-table face detection unavailable; returning original')
                _FRONT_FACE_CACHE[key] = []
            while len(_FRONT_FACE_CACHE) > 4:
                _FRONT_FACE_CACHE.popitem(last=False)
        _FRONT_FACE_CACHE.move_to_end(key)
        return alpha, _FRONT_FACE_CACHE[key]


def is_front_table_scene(source, people):
    """Confirm a group above a plausible near-camera foreground surface.

    This uses person-mask geometry, not surface color, so dark and covered
    tables follow the same conservative rule. A plausible standing group can
    also receive the foreground guard rather than risk an unrecognized table.
    """
    if not has_possible_front_table_layout(people):
        return False
    alpha, faces = _front_table_faces(source, people)
    faces = _front_diner_faces(alpha, faces)
    sh, _ = alpha.shape
    supported = [(x, y) for x, y, _ in faces if y < sh * .68]
    # Adjacent/embracing faces and single close portraits are valid foregrounds.
    # The surface geometry already triggers the lower guard; face separation
    # does not measure whether the mask can safely preserve the subject.
    if not supported:
        return False
    _LOG.info('Near-camera surface below group: selecting its contour')
    return True


def _front_diner_faces(alpha, faces):
    """Do not let a smaller, unmasked rear face veto a close portrait.

    Retain comparable heads and lower small heads (children/babies). Only a
    smaller face at/above the main heads with an empty core is a rear candidate.
    Long-table validation deliberately continues to inspect all diners.
    """
    if not faces:
        return []
    h, w = alpha.shape
    cores = []
    for cx, cy, side in faces:
        patch = alpha[max(0, int(cy-side*.32)):min(h, int(cy+side*.32)),
                      max(0, int(cx-side*.32)):min(w, int(cx+side*.32))]
        cores.append(float(patch.mean()) if patch.size else 0.)
    supported = [f for f, coverage in zip(faces, cores) if coverage >= .65]
    if not supported:
        return faces
    largest = max(f[2] for f in supported)
    head_row = min(f[1] for f in supported if f[2] >= largest * .65)
    return [f for f, coverage in zip(faces, cores)
            if not (coverage < .15 and f[2] < largest * .65
                    and f[1] < head_row + largest * .35)]


def _face_interior_supported(alpha, cx, cy, side):
    """Allow a profile's exterior edge, but never an interior mask hole."""
    h,w=alpha.shape
    left,right=max(0,int(cx-side*.32)),min(w,int(cx+side*.32))
    top,bottom=max(0,int(cy-side*.32)),min(h,int(cy+side*.32))
    patch=alpha[top:bottom,left:right]
    if not patch.size:
        return False,0.
    yy,xx=np.ogrid[top:bottom,left:right]
    core=((xx-cx)/(side*.32))**2+((yy-cy)/(side*.32))**2<=1
    covered=patch>=.95
    coverage=float(np.mean(covered[core])) if core.any() else 0.
    if coverage>=.97:
        return True,coverage
    # A turned face can leave an exterior wedge in the detector's round box.
    # Its central facial region must still be opaque, and every missing piece
    # in the larger core must connect to the outside of the checked patch.
    inner=((xx-cx)/(side*.22))**2+((yy-cy)/(side*.22))**2<=1
    if coverage<.85 or not inner.any() or np.mean(covered[inner])<.97:
        return False,coverage
    _,labels=cv2.connectedComponents((~covered).astype(np.uint8),8)
    boundary=np.unique(np.concatenate((labels[0],labels[-1],labels[:,0],labels[:,-1])))
    missing=np.unique(labels[core & ~covered])
    return bool(np.isin(missing,boundary[boundary>0]).all()),coverage


def front_table_mask_safe(source, people, *, include_rear_faces=False):
    """Validate face interiors before the lower foreground guard hides holes.

    Close portraits use a round core: square corners can extend beyond tilted
    cheeks/beards and wrongly count background as a missing part of the face.
    Long tables inspect every diner, using the same round interior. A table's
    length does not make the corners of a tilted face box part of the face.
    """
    alpha, faces = _front_table_faces(source, people)
    if not include_rear_faces:
        faces = _front_diner_faces(alpha, faces)
    if not faces:
        return False
    for cx, cy, side in faces:
        safe,coverage=_face_interior_supported(alpha,cx,cy,side)
        if not safe:
            _LOG.warning('Uncertain diner mask near foreground table: face interior %.2f%% at (%d,%d); returning original',
                         coverage * 100, cx, cy)
            return False
        if coverage<.97:
            _LOG.info('Face exterior contour accepted: coverage %.2f%% at (%d,%d); central face remains protected',
                      coverage*100,cx,cy)
    return True


def _table_candidate(mask, score, alpha):
    h, w = alpha.shape
    m = mask.astype(np.uint8)
    if score < .5 or not .045 < m.mean() < .40:
        return None
    ys, xs = np.nonzero(m)
    if ys.mean() < h*.58 or ys.max() < h*.78 or xs.max()-xs.min() < w*.20:
        return None
    if (alpha[m>0]>.7).mean() > .16:
        return None
    # Retain the largest connected surface and fill enclosed objects; do not
    # take a convex hull through people or arbitrary background components.
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5,5),np.uint8))
    contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    contour = max(contours, key=cv2.contourArea)
    filled = np.zeros_like(m)
    cv2.drawContours(filled, [contour], -1, 1, cv2.FILLED)
    for y in range(int(h*.4), h):
        xx = np.flatnonzero(filled[y])
        if len(xx) and xx[-1]-xx[0] > w*.12:
            filled[y,xx[0]:xx[-1]+1] = 1
    if not .06 < filled.mean() < .42:
        return None
    return filled


def _front_surface_seeds(rgb, alpha):
    """Interior prompts on visible near-camera surfaces, not a height mask."""
    h, w = alpha.shape
    free = (alpha < .35).astype(np.uint8)
    free[:round(h*.72)] = 0
    free[round(h*.985):] = 0
    free[:, :2] = free[:, -2:] = 0
    seeds = []
    # Dark tabletops and light dishes/cloth need separate prompts. Prefer
    # neutral interiors so a small glass or a coloured chair is not the sole seed.
    neutral = np.ptp(rgb.astype(np.int16), axis=2) < 35
    for region in (free * (neutral & (rgb.mean(axis=2)<110)),
                   free * (neutral & (rgb.mean(axis=2)>=110)), free):
        count, labels, stats, _ = cv2.connectedComponentsWithStats(region.astype(np.uint8))
        for label in sorted(range(1,count), key=lambda n:stats[n,cv2.CC_STAT_AREA], reverse=True)[:3]:
            if stats[label,cv2.CC_STAT_AREA] < h*w*.001:
                continue
            distance = cv2.distanceTransform((labels==label).astype(np.uint8),cv2.DIST_L2,5)
            y,x = np.unravel_index(distance.argmax(),distance.shape)
            if distance[y,x] >= 3 and all(np.hypot(x-px,y-py)>min(h,w)*.06 for px,py in seeds):
                seeds.append((x,y))
    return seeds


def _front_surface_candidate(mask, score, alpha):
    h,w=alpha.shape
    m=mask.astype(np.uint8)
    if score < .30 or not .007 < m.mean() < .50:
        return None
    ys,xs=np.nonzero(m)
    if ys.mean()<h*.76 or ys.min()<h*.60 or ys.max()<h*.96:
        return None
    if (alpha[m>0]>.7).mean()>.16 or np.count_nonzero(m[round(h*.97):])<w*.02:
        return None
    contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    filled=np.zeros_like(m)
    cv2.drawContours(filled,contours,-1,1,cv2.FILLED)
    # A cropped plate can have an open ring: hole filling alone leaves its food
    # exposed. Close the compact near-camera surface across those interruptions.
    points=np.concatenate(contours)
    near_bottom=xs[ys>=h*.90]
    if len(near_bottom):
        # Continue a surface cropped by the frame underneath its dishes; an
        # open plate rim must not leave a triangular blurred hole in the food.
        points=np.concatenate((points,np.array([[[int(near_bottom.min()),h-1]],
                                                [[int(near_bottom.max()),h-1]]],np.int32)))
    hull=cv2.convexHull(points)
    if cv2.contourArea(hull)<min(h*w*.25,m.sum()*8):
        cv2.drawContours(filled,[hull],-1,1,cv2.FILLED)
    return filled


def _detect(rgb, alpha):
    bounds = _gap_bounds(alpha)
    if bounds is None and not has_possible_front_table_layout(alpha):
        return None
    detector, (predictor, device) = _models()
    faces = _face_anchors(rgb, alpha, detector)
    h, w = alpha.shape
    if not faces:
        return None
    import torch
    context = torch.autocast('cuda', dtype=torch.bfloat16) if device=='cuda' else nullcontext()
    with torch.inference_mode(), context:
        predictor.set_image(rgb)
        candidates = []
        from .bokeh_table import table_foreground
        confirmed_cloth=table_foreground(rgb.astype(np.float32),alpha)
        # A short table can have just one diner on each side. Keep the SAM2
        # surface checks; the four-diner geometric fallback remains separate.
        paired_table = (bounds is not None and len(faces)==2
                        and min(x for x,_,_ in faces)<np.mean(bounds)
                        <max(x for x,_,_ in faces)
                        and np.mean(confirmed_cloth>.5)<.08)
        if bounds is not None and (len(faces)>=3 or paired_table):
            left,right=bounds
            for margin, top, bottom in ((.06,.45,.99),(.10,.35,.99),(.08,.35,.87)):
                box = np.array([max(0,left-w*margin),h*top,min(w-1,right+w*margin),h*bottom],np.float32)
                masks, scores, _ = predictor.predict(box=box, multimask_output=True)
                for mask, score in zip(masks,scores):
                    table = _table_candidate(mask,score,alpha)
                    if table is not None:
                        candidates.append((float(score)+table.mean()*1.2, table))
        front_candidates=[]
        front_objects=[]
        for x,y in _front_surface_seeds(rgb,alpha):
            masks,scores,_=predictor.predict(point_coords=np.array([[x,y]],np.float32),
                point_labels=np.array([1]),multimask_output=True)
            for mask, score in zip(masks,scores):
                table = _front_surface_candidate(mask,score,alpha)
                if table is not None:
                    front_candidates.append(table)
                m=mask.astype(np.uint8)
                if score>=.7 and .0005<m.mean()<.08:
                    yy,xx=np.nonzero(m)
                    if yy.min()>=h*.60 and yy.mean()>h*.73 and (alpha[m>0]>.7).mean()<.16:
                        front_objects.append(m)
        table_gap = _table_gap_fallback(alpha, faces)
        if candidates:
            table = max(candidates,key=lambda item:item[0])[1]
            # Complementary table proposals can recover the far end hidden by dishes.
            for quality, proposal in candidates:
                if quality >= .72 and (proposal & table).sum() > min(proposal.sum(),table.sum())*.55:
                    table = np.maximum(table,proposal)
            if table_gap is not None:
                table = np.maximum(table,table_gap)
        else:
            table = table_gap
            if table is None and not front_candidates:
                return None
            if table is None:
                table=np.zeros_like(alpha,np.uint8)
        for proposal in front_candidates:
            table=np.maximum(table,proposal)
        table=np.maximum(table,(confirmed_cloth>.5).astype(np.uint8))
        # Rescue diners supported by the original mask. Reject predictions that
        # also cover another diner face to avoid swallowing the group.
        preserved = alpha.copy()
        for cx, cy, size in faces:
            x,y=int(cx-size/2),int(cy-size/2)
            patch=alpha[max(0,int(cy-size*.3)):min(h,int(cy+size*.3)),
                        max(0,int(cx-size*.3)):min(w,int(cx+size*.3))]
            if patch.mean() > .97 or bounds is None:
                continue
            points=[[cx,cy]]
            masks,scores,_=predictor.predict(point_coords=np.array(points,np.float32),
                point_labels=np.array([1]+[0]*(len(points)-1)),multimask_output=True)
            valid=[]
            for m,score in zip(masks,scores):
                if score<.25 or not size*size*.45<m.sum()<h*w*.25:
                    continue
                if score<.7 and (alpha[m.astype(bool)]>.1).mean()<.30:
                    continue
                if any(m[max(0,int(fy-fs*.18)):min(h,int(fy+fs*.18)),max(0,int(fx-fs*.18)):min(w,int(fx+fs*.18))].any() for fx,fy,fs in faces if np.hypot(fx-cx,fy-cy)>max(size,fs)*.8):
                    continue
                valid.append((float(score),m))
            if valid:
                for _, person_mask in valid:
                    preserved=np.maximum(preserved,person_mask)
        # Objects that intersect the confirmed tabletop are foreground too.
        # Sample its bounding region, then require contact and no face overlap.
        ys,xs=np.nonzero(table)
        x0,x1=int(xs.min()),int(xs.max());y0=int(ys.min());y1=int(ys.max())
        contact=cv2.dilate(table,np.ones((max(15,round(h*.07))|1,)*2,np.uint8))
        objects=table.copy()
        for proposal in front_objects:
            if (proposal & contact).sum()>proposal.sum()*.06:
                contours,_=cv2.findContours(proposal,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(proposal,contours,-1,1,cv2.FILLED)
                objects=np.maximum(objects,proposal)
        # Small objects at the far end of a short table can fall entirely
        # between coarse prompts (or behind a cup at the nearest prompt).
        # Sample these confirmed two-diner tables more closely; keep all the
        # existing object confidence, contact and face-overlap checks.
        rows,columns=(20,24) if paired_table else (10,12)
        for py in np.linspace(max(h*.35,y0-h*.07),min(h*.93,y1),rows):
            if bounds is None:
                # Near-camera surfaces already include enclosed dishes. An
                # unconstrained point sweep beside a close portrait can select
                # the adjacent wall as an "object" touching the table.
                break
            for px in np.linspace(x0+w*.03,x1-w*.03,columns):
                # One object prediction can cover a fragment of the object
                # behind it. Do not let that fragment suppress every remaining
                # prompt on a bottle/cup in the short-table sweep.
                occupied=table if paired_table else objects
                if alpha[int(py),int(px)]>.7 or occupied[int(py),int(px)]:
                    continue
                masks,scores,_=predictor.predict(point_coords=np.array([[px,py]],np.float32),
                    point_labels=np.array([1]),multimask_output=True)
                for m,score in zip(masks,scores):
                    m=m.astype(np.uint8);area=int(m.sum())
                    if score<.45 or not h*w*.0007<area<h*w*.08:
                        continue
                    if rgb[m>0].mean()<35:
                        continue
                    if (alpha[m>0]>.7).mean()>.18 or (m & contact).sum()<area*.06:
                        continue
                    if any(m[max(0,int(fy-fs*.3)):min(h,int(fy+fs*.3)),max(0,int(fx-fs*.3)):min(w,int(fx+fs*.3))].any() for fx,fy,fs in faces):
                        continue
                    contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                    for contour in contours:
                        hull=cv2.convexHull(contour)
                        if cv2.contourArea(hull)<area*1.8:
                            cv2.drawContours(m,[hull],-1,1,cv2.FILLED)
                    objects=np.maximum(objects,m)
        preserved=np.maximum(preserved,objects)
    _LOG.info('Automatic table scene: faces=%d table_pixels=%d',len(faces),np.count_nonzero(table))
    return preserved.astype(np.float32), len(faces)


def preserve_table_scene(source, people, *, include_group_size=False):
    h,w=people.shape
    # Very small images do not contain enough detail for reliable face anchors.
    if min(h,w)<320 or max(h,w)<480 or not np.isfinite(people).all():
        return (None, 0) if include_group_size else None
    scale=min(1.,1100/max(h,w));size=(round(w*scale),round(h*scale))
    rgb=cv2.resize(np.asarray(source,np.uint8),size,interpolation=cv2.INTER_AREA)
    alpha=cv2.resize(people,size,interpolation=cv2.INTER_AREA)
    key=hashlib.sha256(rgb.tobytes()+np.rint(alpha*255).astype(np.uint8).tobytes()).digest()
    with _LOCK:
        if key in _CACHE:
            result=_CACHE[key];_CACHE.move_to_end(key)
        else:
            try:
                result=_detect(rgb,alpha)
            except Exception:
                _LOG.exception('Automatic table selection unavailable; using legacy table mask')
                result=None
            _CACHE[key]=result
            while len(_CACHE)>4:
                _CACHE.popitem(last=False)
        if result is None:
            return (None, 0) if include_group_size else None
        scene, group_size = result if isinstance(result, tuple) else (result, 0)
        # Never erode the incoming full-resolution foreground during resizing.
        output = np.maximum(people,cv2.resize(scene,(w,h),interpolation=cv2.INTER_LINEAR))
        return (output, group_size) if include_group_size else output


def _face_core_mask(shape, boxes):
    """Soft interior of a detected face; never its hair or background edge."""
    h, w = shape
    core = np.zeros((h,w),np.float32)
    for x, y, size in boxes:
        center = (round(x+size*.5), round(y+size*.5))
        radii = (max(1,round(size*.38)), max(1,round(size*.38)))
        cv2.ellipse(core, center, radii, 0, 0, 360, 1., -1)
    if boxes:
        core=cv2.GaussianBlur(core,(0,0),max(1.,min(h,w)*.002))
    return core

def protect_supported_face_cores(source, original, alpha):
    """Retain original RGB inside confident, already-supported faces."""
    h,w=alpha.shape
    if h<320 or w<320:
        return alpha
    scale=min(1.,1100/w);size=(round(w*scale),round(h*scale))
    rgb=cv2.resize(np.asarray(source,np.uint8),size,interpolation=cv2.INTER_AREA)
    support=cv2.resize(original,size,interpolation=cv2.INTER_AREA)
    try:
        import mediapipe as mp
        with _LOCK:
            detector=_face_detector()
            found=detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB,
                                          data=np.ascontiguousarray(rgb))).detections
    except Exception:
        _LOG.exception('Face-core protection unavailable; retaining original mask')
        return alpha
    boxes=[]
    for d in found:
        if d.categories[0].score<.65:
            continue
        b=d.bounding_box
        x,y,side=int(b.origin_x),int(b.origin_y),int(max(b.width,b.height))
        patch=support[max(0,y):min(size[1],y+side),max(0,x):min(size[0],x+side)]
        if patch.size and patch.mean()>=.65:
            boxes.append((x,y,side))
    if not boxes:
        return alpha
    core=_face_core_mask((size[1],size[0]),boxes)
    return np.maximum(alpha,cv2.resize(core,(w,h),interpolation=cv2.INTER_LINEAR))


def dense_group_mask_safe(source, alpha):
    """Reject a table portrait if a likely diner face would be half blurred."""
    h,w=alpha.shape
    scale=min(1.,1100/w);size=(round(w*scale),round(h*scale))
    rgb=cv2.resize(np.asarray(source,np.uint8),size,interpolation=cv2.INTER_AREA)
    mask=cv2.resize(alpha,size,interpolation=cv2.INTER_AREA)
    gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
    cascade=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    direct=cascade.detectMultiScale(gray,scaleFactor=1.08,minNeighbors=4,minSize=(25,25))
    mirrored=cascade.detectMultiScale(cv2.flip(gray,1),scaleFactor=1.08,minNeighbors=4,minSize=(25,25))
    mirrored=[(size[0]-int(x)-int(fw),int(y),int(fw),int(fh)) for x,y,fw,fh in mirrored]
    inspected=0
    for x,y,fw,fh in direct:
        x,y,fw,fh=map(int,(x,y,fw,fh))
        cx=x+fw*.5
        if not (y>size[1]*.15 and (cx<size[0]*.46 or cx>size[0]*.54)):
            continue
        if not any(_face_box_iou((x,y,fw,fh),box)>.6 for box in mirrored):
            continue
        inspected+=1
        patch=mask[y:y+fh,x:x+fw]
        if not patch.size or float(patch.mean())<.65:
            _LOG.warning('Ambiguous full-table group: face coverage %.2f at (%d,%d); returning original',
                         float(patch.mean()) if patch.size else 0.,x,y)
            return False
    # A bright table is a continuous foreground surface. A missing stretch at
    # its far end is as visible as a blurred face; keep the camera original.
    y0,y1=round(size[1]*.25),round(size[1]*.5)
    x0,x1=round(size[0]*.38),round(size[0]*.62)
    patch=rgb[y0:y1,x0:x1]
    coverage=mask[y0:y1,x0:x1]
    white=(patch.min(axis=2)>130)&(patch.max(axis=2)-patch.min(axis=2)<65)
    if white.mean()>.12 and float((white & (coverage<.65)).sum()/white.sum())>.12:
        _LOG.warning('Ambiguous full-table group: bright tabletop partly unprotected; returning original')
        return False
    # A failed detector is not evidence that every diner was preserved.
    return inspected>=4

def _face_box_iou(a,b):
    x,y,w,h=a;u,v,s,t=b
    overlap=max(0,min(x+w,u+s)-max(x,u))*max(0,min(y+h,v+t)-max(y,v))
    return overlap/max(1,w*h+s*t-overlap)
