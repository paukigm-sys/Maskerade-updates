from __future__ import annotations

import os
import shutil
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


ACTIVE_STATES = {
    "detected",
    "waiting",
    "backed_up",
    "processing",
    "retry",
    "restored",
}
TERMINAL_STATES = {"processed", "failed", "skipped", "missing"}


@dataclass(frozen=True)
class LedgerSummary:
    detected: int = 0
    pending: int = 0
    processed: int = 0
    failed: int = 0
    missing: int = 0
    skipped: int = 0

    @property
    def complete(self) -> bool:
        return self.pending == 0 and self.failed == 0 and self.missing == 0


@dataclass(frozen=True)
class BatchManifest:
    id: int
    source_batch_name: str
    input_batch_name: str | None
    source_path: Path
    expected_total: int
    state: str


@dataclass(frozen=True)
class BatchReconciliation:
    expected: int = 0
    detected: int = 0
    pending: int = 0
    processed: int = 0
    failed: int = 0
    missing: int = 0
    skipped: int = 0
    extra: int = 0
    manifest_count: int = 0
    finalized: bool = False

    @property
    def complete(self) -> bool:
        return (
            self.manifest_count > 0
            and self.finalized
            and self.processed == self.expected
            and self.pending == 0
            and self.failed == 0
            and self.missing == 0
            and self.skipped == 0
            and self.extra == 0
        )


class HotfolderLedger:
    """Durable inventory and recovery spool for every file observed in IN."""

    def __init__(
        self,
        database_path: Path,
        recovery_root: Path,
        input_root: Path,
        park_name: str,
    ) -> None:
        self.database_path = Path(database_path)
        self.recovery_root = Path(recovery_root)
        self.input_root = Path(input_root).resolve()
        self.park_name = str(park_name)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self.recovery_root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._connection = sqlite3.connect(
            self.database_path,
            timeout=5.0,
            check_same_thread=False,
        )
        self._connection.row_factory = sqlite3.Row
        self._configure()
        self._create_schema()

    def close(self) -> None:
        with self._lock:
            self._connection.close()

    def _configure(self) -> None:
        with self._connection:
            self._connection.execute("PRAGMA journal_mode=WAL")
            self._connection.execute("PRAGMA synchronous=FULL")
            self._connection.execute("PRAGMA foreign_keys=ON")
            self._connection.execute("PRAGMA busy_timeout=5000")

    def _create_schema(self) -> None:
        with self._connection:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS hotfolder_batches (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    park TEXT NOT NULL,
                    source_root TEXT NOT NULL,
                    source_path TEXT NOT NULL,
                    source_batch_name TEXT NOT NULL,
                    input_batch_name TEXT,
                    expected_total INTEGER NOT NULL DEFAULT 0,
                    state TEXT NOT NULL,
                    first_seen_utc TEXT NOT NULL,
                    updated_utc TEXT NOT NULL,
                    finalized_utc TEXT
                );

                CREATE INDEX IF NOT EXISTS idx_hotfolder_batches_source
                    ON hotfolder_batches(park, source_path, state, id);

                CREATE INDEX IF NOT EXISTS idx_hotfolder_batches_input
                    ON hotfolder_batches(park, input_batch_name, id);

                CREATE TABLE IF NOT EXISTS hotfolder_files (
                    source_path TEXT PRIMARY KEY,
                    park TEXT NOT NULL,
                    batch_name TEXT NOT NULL,
                    manifest_id INTEGER,
                    file_name TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL DEFAULT 0,
                    mtime_ns INTEGER NOT NULL DEFAULT 0,
                    ctime_ns INTEGER NOT NULL DEFAULT 0,
                    state TEXT NOT NULL,
                    first_seen_utc TEXT NOT NULL,
                    updated_utc TEXT NOT NULL,
                    backup_path TEXT,
                    output_path TEXT,
                    final_path TEXT,
                    error TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS idx_hotfolder_files_batch
                    ON hotfolder_files(park, batch_name, state);

                CREATE TABLE IF NOT EXISTS hotfolder_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    occurred_utc TEXT NOT NULL,
                    source_path TEXT NOT NULL,
                    park TEXT NOT NULL,
                    batch_name TEXT NOT NULL,
                    event TEXT NOT NULL,
                    detail TEXT
                );
                """
            )
            columns = {
                str(row[1])
                for row in self._connection.execute("PRAGMA table_info(hotfolder_files)")
            }
            if "manifest_id" not in columns:
                self._connection.execute(
                    "ALTER TABLE hotfolder_files ADD COLUMN manifest_id INTEGER"
                )
            self._connection.execute(
                "CREATE INDEX IF NOT EXISTS idx_hotfolder_files_manifest "
                "ON hotfolder_files(park, manifest_id, state)"
            )

    def observe_source_batch(
        self,
        source_root: Path,
        source_path: Path,
        expected_total: int,
    ) -> BatchManifest:
        root = str(Path(source_root).resolve())
        source = Path(source_path).resolve()
        count = max(0, int(expected_total))
        now = _utc_now()
        with self._lock, self._connection:
            row = self._connection.execute(
                """
                SELECT * FROM hotfolder_batches
                 WHERE park = ? AND source_path = ? AND state = 'observing'
                 ORDER BY id DESC LIMIT 1
                """,
                (self.park_name, str(source)),
            ).fetchone()
            if row is None:
                cursor = self._connection.execute(
                    """
                    INSERT INTO hotfolder_batches (
                        park, source_root, source_path, source_batch_name,
                        expected_total, state, first_seen_utc, updated_utc
                    ) VALUES (?, ?, ?, ?, ?, 'observing', ?, ?)
                    """,
                    (
                        self.park_name,
                        root,
                        str(source),
                        source.name,
                        count,
                        now,
                        now,
                    ),
                )
                row = self._connection.execute(
                    "SELECT * FROM hotfolder_batches WHERE id = ?",
                    (int(cursor.lastrowid),),
                ).fetchone()
            elif count > int(row["expected_total"]):
                self._connection.execute(
                    """
                    UPDATE hotfolder_batches
                       SET expected_total = ?, updated_utc = ?
                     WHERE id = ?
                    """,
                    (count, now, int(row["id"])),
                )
                row = self._connection.execute(
                    "SELECT * FROM hotfolder_batches WHERE id = ?",
                    (int(row["id"]),),
                ).fetchone()
        return self._manifest_from_row(row)

    def finalize_source_batches(
        self,
        source_root: Path,
        observed_source_paths: Iterable[Path],
    ) -> list[BatchManifest]:
        root = str(Path(source_root).resolve())
        observed = {str(Path(path).resolve()) for path in observed_source_paths}
        now = _utc_now()
        finalized: list[BatchManifest] = []
        with self._lock, self._connection:
            rows = self._connection.execute(
                """
                SELECT * FROM hotfolder_batches
                 WHERE park = ? AND source_root = ? AND state = 'observing'
                """,
                (self.park_name, root),
            ).fetchall()
            for row in rows:
                if str(row["source_path"]) in observed:
                    continue
                self._connection.execute(
                    """
                    UPDATE hotfolder_batches
                       SET state = 'finalized', finalized_utc = ?, updated_utc = ?
                     WHERE id = ?
                    """,
                    (now, now, int(row["id"])),
                )
                finalized.append(
                    BatchManifest(
                        id=int(row["id"]),
                        source_batch_name=str(row["source_batch_name"]),
                        input_batch_name=(
                            str(row["input_batch_name"])
                            if row["input_batch_name"]
                            else None
                        ),
                        source_path=Path(str(row["source_path"])),
                        expected_total=int(row["expected_total"]),
                        state="finalized",
                    )
                )
        return finalized

    def manifest_for_input_batch(self, batch_name: str) -> BatchManifest | None:
        batch = str(batch_name).strip()
        if not batch or batch == "_root":
            return None
        source_names = [batch]
        base, separator, suffix = batch.rpartition("_")
        if separator and base and suffix.isdigit():
            source_names.append(base)
        placeholders = ",".join("?" for _ in source_names)
        parameters: list[object] = [self.park_name, batch, *source_names]
        with self._lock, self._connection:
            row = self._connection.execute(
                f"""
                SELECT * FROM hotfolder_batches
                 WHERE park = ?
                   AND (
                       input_batch_name = ?
                       OR (input_batch_name IS NULL AND source_batch_name IN ({placeholders}))
                   )
                 ORDER BY
                       id DESC,
                       CASE WHEN input_batch_name = ? THEN 0
                            WHEN source_batch_name = ? THEN 1 ELSE 2 END
                 LIMIT 1
                """,
                (*parameters, batch, batch),
            ).fetchone()
            if row is None:
                return None
            if not row["input_batch_name"]:
                self._connection.execute(
                    "UPDATE hotfolder_batches SET input_batch_name = ?, updated_utc = ? WHERE id = ?",
                    (batch, _utc_now(), int(row["id"])),
                )
                row = self._connection.execute(
                    "SELECT * FROM hotfolder_batches WHERE id = ?",
                    (int(row["id"]),),
                ).fetchone()
        return self._manifest_from_row(row)

    def reconcile_batches(self, batches: Iterable[str]) -> BatchReconciliation:
        manifests: dict[int, BatchManifest] = {}
        for batch in sorted(set(batches)):
            manifest = self.manifest_for_input_batch(batch)
            if manifest is not None:
                manifests[manifest.id] = manifest
        if not manifests:
            return BatchReconciliation()

        manifest_ids = sorted(manifests)
        placeholders = ",".join("?" for _ in manifest_ids)
        with self._lock:
            rows = self._connection.execute(
                f"""
                SELECT manifest_id, state, COUNT(*) AS count
                  FROM hotfolder_files
                 WHERE park = ? AND manifest_id IN ({placeholders})
                 GROUP BY manifest_id, state
                """,
                (self.park_name, *manifest_ids),
            ).fetchall()
        counts: dict[str, int] = {}
        for row in rows:
            state = str(row["state"])
            counts[state] = counts.get(state, 0) + int(row["count"])
        detected = sum(counts.values())
        expected = sum(manifest.expected_total for manifest in manifests.values())
        finalized = all(manifest.state == "finalized" for manifest in manifests.values())
        unseen = max(0, expected - detected)
        pending = sum(counts.get(state, 0) for state in ACTIVE_STATES)
        missing = counts.get("missing", 0)
        if finalized:
            missing += unseen
        else:
            pending += unseen
        return BatchReconciliation(
            expected=expected,
            detected=detected,
            pending=pending,
            processed=counts.get("processed", 0),
            failed=counts.get("failed", 0),
            missing=missing,
            skipped=counts.get("skipped", 0),
            extra=max(0, detected - expected),
            manifest_count=len(manifests),
            finalized=finalized,
        )

    def observe_many(self, paths: Iterable[Path]) -> None:
        for path in paths:
            self.observe(path)

    def observe(self, path: Path) -> None:
        path = Path(path).resolve()
        try:
            stat = path.stat()
        except FileNotFoundError:
            return
        now = _utc_now()
        source = str(path)
        batch = self._batch_name(path)
        signature = (int(stat.st_size), int(stat.st_mtime_ns), int(stat.st_ctime_ns))
        with self._lock, self._connection:
            manifest = self.manifest_for_input_batch(batch)
            manifest_id = manifest.id if manifest is not None else None
            row = self._connection.execute(
                "SELECT size_bytes, mtime_ns, ctime_ns, state, manifest_id "
                "FROM hotfolder_files WHERE source_path = ?",
                (source,),
            ).fetchone()
            if row is None:
                self._connection.execute(
                    """
                    INSERT INTO hotfolder_files (
                        source_path, park, batch_name, manifest_id, file_name, size_bytes,
                        mtime_ns, ctime_ns, state, first_seen_utc, updated_utc
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'detected', ?, ?)
                    """,
                    (
                        source,
                        self.park_name,
                        batch,
                        manifest_id,
                        path.name,
                        *signature,
                        now,
                        now,
                    ),
                )
                self._event_locked(path, batch, "detected", f"size={signature[0]}")
                return

            old_signature = (
                int(row["size_bytes"]),
                int(row["mtime_ns"]),
                int(row["ctime_ns"]),
            )
            state = str(row["state"])
            old_manifest_id = int(row["manifest_id"]) if row["manifest_id"] is not None else None
            # Seeing a path again after it was declared missing is itself a
            # replacement signal. A move out of and back into IN can preserve
            # every NTFS timestamp, especially for zero-byte placeholders, so
            # signature comparison alone would leave the live file stuck in
            # the terminal ``missing`` state until the watcher restarted.
            replacement = state in TERMINAL_STATES and (
                state == "missing"
                or signature != old_signature
                or (manifest_id is not None and manifest_id != old_manifest_id)
            )
            next_state = "detected" if replacement else state
            next_manifest_id = manifest_id if manifest_id is not None else old_manifest_id
            self._connection.execute(
                """
                UPDATE hotfolder_files
                   SET size_bytes = ?, mtime_ns = ?, ctime_ns = ?, state = ?,
                       manifest_id = ?, batch_name = ?,
                       updated_utc = ?, error = CASE WHEN ? THEN NULL ELSE error END,
                       output_path = CASE WHEN ? THEN NULL ELSE output_path END,
                       final_path = CASE WHEN ? THEN NULL ELSE final_path END,
                       attempts = CASE WHEN ? THEN 0 ELSE attempts END
                 WHERE source_path = ?
                """,
                (
                    *signature,
                    next_state,
                    next_manifest_id,
                    batch,
                    now,
                    replacement,
                    replacement,
                    replacement,
                    replacement,
                    source,
                ),
            )
            if replacement:
                self._event_locked(path, batch, "replaced", f"size={signature[0]}")

    def ensure_backup(self, path: Path) -> Path:
        path = Path(path).resolve()
        stat = path.stat()
        if stat.st_size <= 0:
            raise ValueError(f"Cannot back up empty input: {path}")
        self.observe(path)
        target = self._backup_target(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.{uuid.uuid4().hex}.part")
        try:
            with path.open("rb") as source, temporary.open("xb") as destination:
                shutil.copyfileobj(source, destination, length=1024 * 1024)
                destination.flush()
                os.fsync(destination.fileno())
            if temporary.stat().st_size != stat.st_size:
                raise OSError(
                    f"Recovery copy size mismatch for {path}: "
                    f"{temporary.stat().st_size} != {stat.st_size}"
                )
            current_stat = path.stat()
            if (
                int(current_stat.st_size) != int(stat.st_size)
                or int(current_stat.st_mtime_ns) != int(stat.st_mtime_ns)
            ):
                raise OSError(f"Input changed while its recovery copy was being created: {path}")
            shutil.copystat(path, temporary)
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        self._transition(path, "backed_up", backup_path=target)
        return target

    def mark_processing(self, path: Path) -> None:
        self._transition(path, "processing", increment_attempts=True)

    def mark_retry(self, path: Path, error: str | None = None) -> None:
        self._transition(path, "retry", error=error)

    def mark_processed(
        self,
        path: Path,
        output_path: Path | None,
        final_path: Path | None,
    ) -> None:
        self._transition(
            path,
            "processed",
            output_path=output_path,
            final_path=final_path,
        )
        if (final_path is not None and Path(final_path).exists()) or Path(path).exists():
            self.discard_backup(path)

    def mark_failed(self, path: Path, failed_path: Path | None, reason: str) -> None:
        self._transition(path, "failed", final_path=failed_path, error=reason)
        if failed_path is not None and Path(failed_path).exists():
            self.discard_backup(path)

    def mark_skipped(self, path: Path, reason: str | None = None) -> None:
        self._transition(path, "skipped", error=reason)

    def mark_missing(self, path: Path, reason: str) -> None:
        self._transition(path, "missing", error=reason)

    def restore(self, path: Path) -> bool:
        path = Path(path).resolve()
        with self._lock:
            row = self._connection.execute(
                "SELECT backup_path FROM hotfolder_files WHERE source_path = ?",
                (str(path),),
            ).fetchone()
        if row is None or not row["backup_path"]:
            return False
        backup = Path(str(row["backup_path"]))
        if not backup.exists() or backup.stat().st_size <= 0:
            return False
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.restore")
        try:
            with backup.open("rb") as source, temporary.open("xb") as destination:
                shutil.copyfileobj(source, destination, length=1024 * 1024)
                destination.flush()
                os.fsync(destination.fileno())
            if temporary.stat().st_size != backup.stat().st_size:
                raise OSError(f"Restored input size mismatch: {path}")
            shutil.copystat(backup, temporary)
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
        self._transition(path, "restored", error="Restored from safety copy")
        return True

    def recover_interrupted(self, restore: bool = False) -> tuple[list[Path], list[Path]]:
        restored: list[Path] = []
        missing: list[Path] = []
        with self._lock:
            rows = self._connection.execute(
                "SELECT source_path FROM hotfolder_files WHERE state IN (%s)"
                % ",".join("?" for _ in ACTIVE_STATES),
                tuple(sorted(ACTIVE_STATES)),
            ).fetchall()
        for row in rows:
            path = Path(str(row["source_path"]))
            if path.exists():
                continue
            if restore and self.restore(path):
                restored.append(path)
            else:
                self.mark_missing(
                    path,
                    "Observed input disappeared; safety copy retained for manual recovery",
                )
                missing.append(path)
        return restored, missing

    def active_batch_names(self) -> set[str]:
        """Return batches that were unfinished when this ledger was opened."""
        placeholders = ",".join("?" for _ in ACTIVE_STATES)
        with self._lock:
            rows = self._connection.execute(
                f"""
                SELECT DISTINCT batch_name
                  FROM hotfolder_files
                 WHERE park = ? AND state IN ({placeholders})
                """,
                (self.park_name, *sorted(ACTIVE_STATES)),
            ).fetchall()
        return {str(row["batch_name"]) for row in rows}

    def discard_backup(self, path: Path) -> None:
        path = Path(path).resolve()
        with self._lock:
            row = self._connection.execute(
                "SELECT backup_path FROM hotfolder_files WHERE source_path = ?",
                (str(path),),
            ).fetchone()
            if row is None or not row["backup_path"]:
                return
            backup = Path(str(row["backup_path"]))
            backup.unlink(missing_ok=True)
            with self._connection:
                self._connection.execute(
                    "UPDATE hotfolder_files SET backup_path = NULL, updated_utc = ? WHERE source_path = ?",
                    (_utc_now(), str(path)),
                )
        self._remove_empty_recovery_parents(backup.parent)

    def summary(
        self,
        batches: Iterable[str] | None = None,
        paths: Iterable[Path] | None = None,
    ) -> LedgerSummary:
        parameters: list[str] = [self.park_name]
        clause = "park = ?"
        selected_batches = sorted(set(batches or ()))
        if selected_batches:
            clause += " AND batch_name IN (%s)" % ",".join("?" for _ in selected_batches)
            parameters.extend(selected_batches)
        selected_paths = sorted({str(Path(path).resolve()) for path in (paths or ())})
        if selected_paths:
            clause += " AND source_path IN (%s)" % ",".join("?" for _ in selected_paths)
            parameters.extend(selected_paths)
        with self._lock:
            rows = self._connection.execute(
                f"SELECT state, COUNT(*) AS count FROM hotfolder_files WHERE {clause} GROUP BY state",
                parameters,
            ).fetchall()
        counts = {str(row["state"]): int(row["count"]) for row in rows}
        return LedgerSummary(
            detected=sum(counts.values()),
            pending=sum(counts.get(state, 0) for state in ACTIVE_STATES),
            processed=counts.get("processed", 0),
            failed=counts.get("failed", 0),
            missing=counts.get("missing", 0),
            skipped=counts.get("skipped", 0),
        )

    def _transition(
        self,
        path: Path,
        state: str,
        *,
        backup_path: Path | None = None,
        output_path: Path | None = None,
        final_path: Path | None = None,
        error: str | None = None,
        increment_attempts: bool = False,
    ) -> None:
        path = Path(path).resolve()
        self.observe(path)
        now = _utc_now()
        batch = self._batch_name(path)
        with self._lock, self._connection:
            self._connection.execute(
                """
                UPDATE hotfolder_files
                   SET state = ?, updated_utc = ?,
                       backup_path = COALESCE(?, backup_path),
                       output_path = COALESCE(?, output_path),
                       final_path = COALESCE(?, final_path),
                       error = ?,
                       attempts = attempts + ?
                 WHERE source_path = ?
                """,
                (
                    state,
                    now,
                    str(backup_path) if backup_path else None,
                    str(output_path) if output_path else None,
                    str(final_path) if final_path else None,
                    error,
                    1 if increment_attempts else 0,
                    str(path),
                ),
            )
            self._event_locked(path, batch, state, error)

    def _event_locked(
        self,
        path: Path,
        batch: str,
        event: str,
        detail: str | None,
    ) -> None:
        self._connection.execute(
            """
            INSERT INTO hotfolder_events (
                occurred_utc, source_path, park, batch_name, event, detail
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (_utc_now(), str(path), self.park_name, batch, event, detail),
        )

    @staticmethod
    def _manifest_from_row(row: sqlite3.Row) -> BatchManifest:
        return BatchManifest(
            id=int(row["id"]),
            source_batch_name=str(row["source_batch_name"]),
            input_batch_name=(str(row["input_batch_name"]) if row["input_batch_name"] else None),
            source_path=Path(str(row["source_path"])),
            expected_total=int(row["expected_total"]),
            state=str(row["state"]),
        )

    def _batch_name(self, path: Path) -> str:
        try:
            relative = path.resolve().relative_to(self.input_root)
        except ValueError:
            return "_external"
        return relative.parts[0] if len(relative.parts) > 1 else "_root"

    def _backup_target(self, path: Path) -> Path:
        try:
            relative = path.resolve().relative_to(self.input_root)
        except ValueError:
            relative = Path("_external") / path.name
        return self.recovery_root / self.park_name / relative

    def _remove_empty_recovery_parents(self, directory: Path) -> None:
        root = (self.recovery_root / self.park_name).resolve()
        current = directory.resolve()
        while current != root and root in current.parents:
            try:
                current.rmdir()
            except OSError:
                break
            current = current.parent


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")
