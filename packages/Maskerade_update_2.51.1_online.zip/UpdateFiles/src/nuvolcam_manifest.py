from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .config import SUPPORTED_IMAGE_EXTENSIONS


NUVOLCAM_CONFIG_RELATIVE_PATH = Path("nuvolcam-desktop") / "config.json"


@dataclass(frozen=True)
class NuvolcamBatchSnapshot:
    path: Path
    expected_total: int


def discover_download_root(
    input_dir: Path,
    *,
    environment: Mapping[str, str] | None = None,
    config_path: Path | None = None,
) -> Path | None:
    """Read only Nuvolcam's two folder fields and validate the shared IN path."""
    if config_path is None:
        variables = environment if environment is not None else os.environ
        appdata = str(variables.get("APPDATA", "")).strip()
        if not appdata:
            return None
        config_path = Path(appdata) / NUVOLCAM_CONFIG_RELATIVE_PATH

    try:
        raw = json.loads(Path(config_path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(raw, dict):
        return None

    download_value = raw.get("downloadPath")
    nuvolcam_input_value = raw.get("inDirectory")
    if not isinstance(download_value, str) or not download_value.strip():
        return None
    if not isinstance(nuvolcam_input_value, str) or not nuvolcam_input_value.strip():
        return None
    if not _same_path(Path(nuvolcam_input_value), Path(input_dir)):
        return None

    download_root = Path(download_value).expanduser()
    try:
        resolved = download_root.resolve()
    except OSError:
        return None
    if _same_path(resolved, Path(input_dir)):
        return None
    return resolved


def scan_download_batches(download_root: Path) -> list[NuvolcamBatchSnapshot]:
    """Count JPG directory entries, including empty/incomplete placeholders."""
    root = Path(download_root)
    directories = sorted(
        (entry for entry in root.iterdir() if entry.is_dir()),
        key=lambda entry: entry.name.casefold(),
    )

    snapshots: list[NuvolcamBatchSnapshot] = []
    for directory in directories:
        try:
            count = sum(
                1
                for entry in directory.iterdir()
                if entry.is_file() and entry.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
            )
        except OSError:
            count = -1
        snapshots.append(
            NuvolcamBatchSnapshot(path=directory.resolve(), expected_total=count)
        )
    return snapshots


def _same_path(left: Path, right: Path) -> bool:
    try:
        left_text = os.path.normcase(os.path.abspath(os.path.normpath(str(left))))
        right_text = os.path.normcase(os.path.abspath(os.path.normpath(str(right))))
    except (OSError, ValueError):
        return False
    return left_text == right_text
