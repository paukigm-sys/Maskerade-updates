from __future__ import annotations

import logging
import json
import re
import time
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

try:
    import cv2
except Exception:  # pragma: no cover - optional runtime fallback
    cv2 = None

if TYPE_CHECKING:
    from .config import PhotoEnhanceSettings


QENHANCER_CUEVAS_ENGINES = {
    "qenhancer",
    "qenhancer_cuevas",
    "cuevas_qenhancer",
    "cuevas_i2e",
    "i2e_cuevas",
}

LEGACY_ENHANCER2_ENGINES = {
    "enhancer2",
    "qenhance_auto_v2",
    "auto_v2",
    "v2",
    "autotune",
    "autopilot",
    "auto_tune",
}

QENHANCER_PRESET_DIR = Path("config/qenhancer_presets")
QENHANCER_DEFAULT_PRESET_NAME = "C_Channel 1.qes"
QENHANCER_DEFAULT_PRESET = {
    "LSE": 8,
    "COH": 20,
    "MCE": 60,
    "DesatShadows": 18,
    "ACE": 60,
    "R": 5,
    "G": -2,
    "ABE": 80,
    "SAT": 12,
    "SHEH": 40,
    "CO": 20,
    "SHES": 80,
    "LNRStrength": 55,
    "SharpenLimit": 16,
    "SharpenFactor": 22,
    "SharpenThreshold": 5,
}


def enhance_photo(
    image: Image.Image,
    settings: "PhotoEnhanceSettings",
    logger: logging.Logger | None = None,
) -> Image.Image:
    """Apply local QEnhancer-style finishing to the final composited photo."""

    if not bool(getattr(settings, "enabled", True)):
        return image

    engine = str(getattr(settings, "engine", "qenhancer_cuevas") or "qenhancer_cuevas").strip().lower()
    if engine in LEGACY_ENHANCER2_ENGINES:
        engine = "qenhancer_cuevas"
    if engine == "classic":
        engine = "qenhancer_cuevas"
    if engine in {"none", "off", "disabled"}:
        return image
    if engine in QENHANCER_CUEVAS_ENGINES:
        started = time.perf_counter()
        strength = _qenhancer_strength(settings)
        preset_name = str(getattr(settings, "preset", QENHANCER_DEFAULT_PRESET_NAME) or QENHANCER_DEFAULT_PRESET_NAME)
        preset_values = _load_qenhancer_preset(preset_name, logger=logger)
        result = _enhance_qenhancer_cuevas(image, strength, preset_values=preset_values, logger=logger)
        result = _apply_manual_photo_controls(result, settings)
        result.info["_photo_enhance_report"] = {
            "engine": "qenhancer_cuevas",
            "engine_label": "Retoque fotografico",
            "status": "ok",
            "preset": preset_name,
            "requested_strength": round(strength, 4),
            "manual_controls": _manual_photo_controls_report(settings),
            "source_preset": preset_values,
            "processing_ms": int(round((time.perf_counter() - started) * 1000)),
        }
        return result

    return _enhance_classic(image, settings, 1.0, logger=logger)


def _enhance_classic(
    image: Image.Image,
    settings: "PhotoEnhanceSettings",
    strength: float,
    logger: logging.Logger | None = None,
) -> Image.Image:
    if _classic_is_noop(settings) or strength <= 0.0001:
        return image
    try:
        if cv2 is None:
            return _enhance_pillow(image, settings, strength)
        return _enhance_cv(image, settings, strength)
    except Exception as exc:
        if logger is not None:
            logger.warning("Photo enhancer skipped: %s", exc)
        return image


def _enhance_pillow(image: Image.Image, settings: "PhotoEnhanceSettings", strength: float) -> Image.Image:
    result = image.convert("RGB")
    result = ImageOps.autocontrast(result, cutoff=max(0, min(3, int(2 * strength))))
    brightness = float(settings.brightness) / 100.0 * strength
    result = ImageEnhance.Brightness(result).enhance(max(0.12, 1.0 + 0.95 * brightness))
    result = ImageEnhance.Color(result).enhance(max(0.0, 1.0 + (float(settings.saturation) / 100.0) * 1.05 * strength))
    result = ImageEnhance.Contrast(result).enhance(max(0.12, 1.0 + (float(settings.shadow_contrast + settings.highlight_contrast) / 260.0) * strength))
    result = ImageEnhance.Sharpness(result).enhance(max(0.0, 1.0 + (float(settings.global_sharpen + settings.local_sharpen) / 140.0) * strength))
    return result


def _qenhancer_strength(settings: "PhotoEnhanceSettings") -> float:
    try:
        strength = float(getattr(settings, "strength", 1.0) or 1.0)
    except (TypeError, ValueError):
        strength = 1.0
    return float(np.clip(strength, 0.0, 1.4))


def _load_qenhancer_preset(
    preset_name: str,
    logger: logging.Logger | None = None,
) -> dict[str, float]:
    values = dict(QENHANCER_DEFAULT_PRESET)
    name = (preset_name or QENHANCER_DEFAULT_PRESET_NAME).strip()
    if not name or name.lower() == QENHANCER_DEFAULT_PRESET_NAME.lower():
        return values

    candidate = _qenhancer_preset_path(name)
    if candidate is None:
        if logger is not None:
            logger.warning("QEnhancer preset not found, using default: %s", name)
        return values

    try:
        parsed = _parse_qenhancer_preset(candidate.read_text(encoding="utf-8", errors="ignore"))
        values.update(parsed)
    except Exception as exc:
        if logger is not None:
            logger.warning("QEnhancer preset could not be parsed, using default: %s (%s)", name, exc)
    return values


def _qenhancer_preset_path(name: str) -> Path | None:
    preset_dir = Path.cwd() / QENHANCER_PRESET_DIR
    raw = Path(name)
    candidates = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        candidates.append(preset_dir / raw.name)
        if raw.suffix.lower() != ".qes":
            candidates.append(preset_dir / f"{raw.name}.qes")
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate
    if preset_dir.exists():
        wanted = raw.name.lower()
        wanted_stem = raw.stem.lower()
        for candidate in preset_dir.glob("*.qes"):
            if candidate.name.lower() == wanted or candidate.stem.lower() == wanted_stem:
                return candidate
    return None


def _parse_qenhancer_preset(text: str) -> dict[str, float]:
    parsed: dict[str, float] = {}
    try:
        payload = json.loads(text)
        if isinstance(payload, dict):
            _collect_numeric_preset_values(payload, parsed)
            return parsed
    except Exception:
        pass

    patterns = (
        r"([A-Za-z][A-Za-z0-9_]{0,36})\s*=\s*['\"]?(-?\d+(?:\.\d+)?)",
        r"([A-Za-z][A-Za-z0-9_]{0,36})\s*:\s*['\"]?(-?\d+(?:\.\d+)?)",
        r"<([A-Za-z][A-Za-z0-9_]{0,36})>\s*(-?\d+(?:\.\d+)?)\s*</\1>",
    )
    for pattern in patterns:
        for key, value in re.findall(pattern, text):
            if _is_qenhancer_preset_key(key):
                parsed[_canonical_qenhancer_key(key)] = float(value)
    return parsed


def _collect_numeric_preset_values(payload: dict, parsed: dict[str, float]) -> None:
    for key, value in payload.items():
        if isinstance(value, dict):
            _collect_numeric_preset_values(value, parsed)
        elif _is_qenhancer_preset_key(str(key)):
            try:
                parsed[_canonical_qenhancer_key(str(key))] = float(value)
            except (TypeError, ValueError):
                continue


def _is_qenhancer_preset_key(key: str) -> bool:
    return _canonical_qenhancer_key(key) in QENHANCER_DEFAULT_PRESET


def _canonical_qenhancer_key(key: str) -> str:
    compact = re.sub(r"[^a-z0-9]", "", str(key).lower())
    aliases = {
        "desatshadows": "DesatShadows",
        "lnrstrength": "LNRStrength",
        "sharpenlimit": "SharpenLimit",
        "sharpenfactor": "SharpenFactor",
        "sharpenthreshold": "SharpenThreshold",
    }
    for preset_key in QENHANCER_DEFAULT_PRESET:
        aliases.setdefault(re.sub(r"[^a-z0-9]", "", preset_key.lower()), preset_key)
    return aliases.get(compact, key)


def _enhance_qenhancer_cuevas(
    image: Image.Image,
    strength: float = 1.0,
    preset_values: dict[str, float] | None = None,
    logger: logging.Logger | None = None,
) -> Image.Image:
    if strength <= 0.0001:
        return ImageOps.exif_transpose(image).convert("RGB")
    if cv2 is None:
        result = ImageOps.autocontrast(ImageOps.exif_transpose(image).convert("RGB"), cutoff=1)
        result = ImageEnhance.Contrast(result).enhance(1.08)
        result = ImageEnhance.Color(result).enhance(1.03)
        result = ImageEnhance.Sharpness(result).enhance(1.22)
        return result

    try:
        preset_values = dict(QENHANCER_DEFAULT_PRESET if preset_values is None else preset_values)
        preset_scale = lambda key, default: float(preset_values.get(key, default)) / max(1.0, float(default))
        rgb = np.asarray(ImageOps.exif_transpose(image).convert("RGB")).astype(np.float32)
        amount = float(np.clip(strength, 0.0, 1.4))
        sat_scale = np.clip(preset_scale("SAT", 12), 0.25, 3.2)
        ace_scale = np.clip(preset_scale("ACE", 60), 0.25, 2.4)
        abe_scale = np.clip(preset_scale("ABE", 80), 0.35, 2.2)
        contrast_scale = np.clip(preset_scale("CO", 20), 0.35, 2.6)
        sharpen_scale = np.clip(preset_scale("SharpenFactor", 22), 0.2, 3.0)
        red_value = np.clip(float(preset_values.get("R", 5)), -40.0, 40.0)
        green_value = np.clip(float(preset_values.get("G", -2)), -40.0, 40.0)

        rgb[..., 0] *= 1.0 + (0.0012 * red_value) * amount
        rgb[..., 1] *= 1.0 - (0.004 * green_value) * amount
        rgb[..., 2] *= 1.0 - (0.018 + 0.0006 * (red_value - 5.0)) * amount
        rgb = np.clip(rgb, 0, 255)

        lab = cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
        l_channel = lab[..., 0]
        source_l_mean = float(np.mean(l_channel))
        low, high = np.percentile(l_channel, [0.8, 99.2])
        if high > low + 8:
            stretched = np.clip((l_channel - low) * 255.0 / (high - low), 0, 255)
            blend = 0.10 * amount * ace_scale
            l_channel = l_channel * (1.0 - blend) + stretched * blend

        gamma = max(0.68, 1.0 - 0.20 * amount * abe_scale)
        gamma_lut = np.array(
            [
                min(255.0, max(0.0, 255.0 * ((value / 255.0) ** gamma)))
                for value in range(256)
            ],
            dtype=np.float32,
        )
        curved = gamma_lut[np.clip(l_channel, 0, 255).astype(np.uint8)]
        midtones = _smoothstep(18.0, 92.0, l_channel) * (1.0 - _smoothstep(226.0, 255.0, l_channel))
        curve_blend = 0.62 * amount * abe_scale * midtones
        l_channel = l_channel * (1.0 - curve_blend) + curved * curve_blend

        upper_mids = _smoothstep(110.0, 220.0, l_channel) * (1.0 - _smoothstep(238.0, 255.0, l_channel))
        l_channel += 4.6 * amount * contrast_scale * upper_mids
        lift = np.clip(10.5 - (source_l_mean - 62.0) * 0.10, 5.5, 10.5)
        lift += 3.0
        l_channel += lift * amount * abe_scale * (1.0 - _smoothstep(218.0, 255.0, l_channel))

        deep_shadows = 1.0 - _smoothstep(10.0, 58.0, l_channel)
        l_channel -= 2.5 * amount * deep_shadows
        l_uint8 = np.clip(l_channel, 0, 255).astype(np.uint8)

        clahe = cv2.createCLAHE(clipLimit=1.45 + 0.22 * amount * ace_scale, tileGridSize=(8, 8))
        local_l = clahe.apply(l_uint8)
        l_uint8 = cv2.addWeighted(l_uint8, 1.0 - 0.07 * amount * ace_scale, local_l, 0.07 * amount * ace_scale, 0)
        lab[..., 0] = l_uint8.astype(np.float32)
        rgb = cv2.cvtColor(np.clip(lab, 0, 255).astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)

        hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
        hue = hsv[..., 0]
        saturation = hsv[..., 1]
        value = hsv[..., 2]
        shadow = 1.0 - _smoothstep(42.0, 150.0, value)
        saturation *= 1.0 - 0.04 * amount * shadow
        saturation *= 1.0 + 0.40 * amount * sat_scale
        green = ((hue > 32.0) & (hue < 92.0) & (saturation > 35.0)).astype(np.float32)
        saturation *= 1.0 + 0.12 * amount * sat_scale * green
        value += 1.6 * amount * green
        hsv[..., 1] = np.clip(saturation, 0, 255)
        hsv[..., 2] = np.clip(value, 0, 255)
        rgb = cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)

        blur = cv2.GaussianBlur(rgb, (0, 0), 0.85)
        detail = np.clip(rgb - blur, -17.0, 17.0)
        edge = np.maximum(0.0, np.abs(detail).mean(axis=2) - 4.7) / 21.5
        edge = np.clip(edge, 0.0, 1.0)
        sharpen_amount = 0.74 * amount * sharpen_scale
        rgb = np.clip(rgb + detail * (sharpen_amount * edge[..., None]), 0, 255)
        return Image.fromarray(rgb.astype(np.uint8), "RGB")
    except Exception as exc:
        if logger is not None:
            logger.warning("QEnhancer Cuevas clone skipped: %s", exc)
        return ImageOps.exif_transpose(image).convert("RGB")


def _manual_photo_controls_report(settings: "PhotoEnhanceSettings") -> dict[str, int]:
    return {
        "exposure": int(getattr(settings, "manual_exposure", 0) or 0),
        "contrast": int(getattr(settings, "manual_contrast", 0) or 0),
        "fill_light": int(getattr(settings, "manual_fill_light", 0) or 0),
        "highlights": int(getattr(settings, "manual_highlights", 0) or 0),
        "black_point": int(getattr(settings, "manual_black_point", 0) or 0),
        "sharpness": int(getattr(settings, "manual_sharpness", 0) or 0),
        "saturation": int(getattr(settings, "manual_saturation", 0) or 0),
        "temperature": int(getattr(settings, "manual_temperature", 0) or 0),
        "vibrance": int(getattr(settings, "manual_vibrance", 0) or 0),
        "red": int(getattr(settings, "manual_red", 0) or 0),
        "green": int(getattr(settings, "manual_green", 0) or 0),
        "blue": int(getattr(settings, "manual_blue", 0) or 0),
    }


def _manual_controls_are_noop(settings: "PhotoEnhanceSettings") -> bool:
    return all(value == 0 for value in _manual_photo_controls_report(settings).values())


def _apply_manual_photo_controls(image: Image.Image, settings: "PhotoEnhanceSettings") -> Image.Image:
    if _manual_controls_are_noop(settings):
        return image

    rgb = np.asarray(ImageOps.exif_transpose(image).convert("RGB")).astype(np.float32)

    exposure = np.clip(float(getattr(settings, "manual_exposure", 0) or 0) / 100.0, -1.0, 1.0)
    contrast = np.clip(float(getattr(settings, "manual_contrast", 0) or 0) / 100.0, -1.0, 1.0)
    fill_light = np.clip(float(getattr(settings, "manual_fill_light", 0) or 0) / 100.0, -1.5, 1.5)
    highlights = np.clip(float(getattr(settings, "manual_highlights", 0) or 0) / 100.0, -1.5, 1.5)
    black_point = np.clip(float(getattr(settings, "manual_black_point", 0) or 0) / 100.0, -1.5, 1.5)
    sharpness = np.clip(float(getattr(settings, "manual_sharpness", 0) or 0) / 100.0, 0.0, 1.5)
    saturation = np.clip(float(getattr(settings, "manual_saturation", 0) or 0) / 100.0, -1.0, 1.0)
    temperature = np.clip(float(getattr(settings, "manual_temperature", 0) or 0) / 100.0, -1.0, 1.0)
    vibrance = np.clip(float(getattr(settings, "manual_vibrance", 0) or 0) / 100.0, -1.0, 1.0)

    if abs(exposure) > 0.0001:
        rgb *= np.power(2.0, 1.15 * exposure)

    if abs(fill_light) > 0.0001:
        lum = _luminance(np.clip(rgb, 0, 255))
        shadows = 1.0 - _smoothstep(42.0, 188.0, lum)
        mids = _smoothstep(32.0, 150.0, lum) * (1.0 - _smoothstep(198.0, 255.0, lum))
        rgb += (72.0 * fill_light * shadows + 24.0 * fill_light * mids)[..., None]

    if abs(highlights) > 0.0001 or abs(black_point) > 0.0001:
        lum = _luminance(np.clip(rgb, 0, 255))
        if abs(highlights) > 0.0001:
            highs = _smoothstep(168.0, 250.0, lum)
            rgb -= (58.0 * highlights * highs)[..., None]

        if abs(black_point) > 0.0001:
            shadows = 1.0 - _smoothstep(24.0, 108.0, lum)
            rgb -= (46.0 * black_point * shadows)[..., None]

    if abs(contrast) > 0.0001:
        pivot = 122.0
        factor = np.clip(1.0 + 0.82 * contrast, 0.18, 2.1)
        rgb = (rgb - pivot) * factor + pivot

    controls = np.array(
        [
            np.clip(float(getattr(settings, "manual_red", 0) or 0) / 100.0, -1.0, 1.0),
            np.clip(float(getattr(settings, "manual_green", 0) or 0) / 100.0, -1.0, 1.0),
            np.clip(float(getattr(settings, "manual_blue", 0) or 0) / 100.0, -1.0, 1.0),
        ],
        dtype=np.float32,
    )
    if np.any(np.abs(controls) > 0.0001):
        rgb = rgb * (1.0 + controls[None, None, :] * 0.18) + controls[None, None, :] * 34.0

    if abs(temperature) > 0.0001:
        temperature_shift = np.array([32.0, 5.0, -32.0], dtype=np.float32) * temperature
        rgb += temperature_shift[None, None, :]

    if abs(saturation) > 0.0001:
        gray = _luminance(np.clip(rgb, 0, 255))[..., None]
        rgb = gray + (rgb - gray) * np.clip(1.0 + 1.15 * saturation, 0.0, 2.2)

    if abs(vibrance) > 0.0001:
        clipped = np.clip(rgb, 0, 255)
        gray = _luminance(clipped)[..., None]
        channel_range = clipped.max(axis=2, keepdims=True) - clipped.min(axis=2, keepdims=True)
        existing_saturation = np.clip(channel_range / 128.0, 0.0, 1.0)
        protection = 1.0 - (0.72 * existing_saturation)
        vibrance_factor = np.clip(1.0 + 1.35 * vibrance * protection, 0.0, 2.25)
        rgb = gray + (rgb - gray) * vibrance_factor

    if sharpness > 0.0001:
        if cv2 is not None:
            blur = cv2.GaussianBlur(rgb, (0, 0), 0.9)
        else:
            blur = np.asarray(Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB").filter(ImageFilter.GaussianBlur(0.9))).astype(np.float32)
        detail = np.clip(rgb - blur, -24.0, 24.0)
        edge = np.clip((np.abs(detail).mean(axis=2) - 3.0) / 18.0, 0.0, 1.0)
        rgb = rgb + detail * (1.15 * sharpness * edge[..., None])

    return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB")


def _enhance_cv(image: Image.Image, settings: "PhotoEnhanceSettings", strength: float) -> Image.Image:
    src = np.asarray(image.convert("RGB")).astype(np.float32)
    original = src.copy()

    luminance = _luminance(src)
    black_preserve = _smoothstep(0.0, 34.0, luminance)
    highlight_preserve = 1.0 - _smoothstep(210.0, 252.0, luminance)
    editable = (0.25 + 0.75 * black_preserve) * (0.35 + 0.65 * highlight_preserve)

    src = _auto_brightness(src, settings, strength, editable)
    src = _qenhancer_tone(src, settings, strength, editable)
    src = _shadow_highlight_balance(src, settings, strength, editable)
    src = _clahe_luminance(src, settings, strength)
    src = _gray_world(src, settings, strength)
    src = _channel_balance(src, settings, strength)
    src = _rotate_hue_and_saturate(src, settings, strength)
    src = _desaturate_shadows(src, settings, strength)
    src = _denoise(src, settings, strength)
    src = _sharpen(src, settings, strength)

    # Preserve deep blacks and hot whites from the input so the correction feels
    # like photo finishing, not a gray wash.
    lum = _luminance(original)
    keep_black = 1.0 - _smoothstep(15.0, 54.0, lum)
    positive_brightness = max(0.0, float(settings.brightness) / 100.0) * strength
    keep_white = _smoothstep(226.0, 252.0, lum) * max(0.08, 0.45 - 0.37 * positive_brightness)
    keep = np.clip(keep_black * 0.58 + keep_white, 0.0, 0.78)[..., None]
    src = src * (1.0 - keep) + original * keep

    return Image.fromarray(np.clip(src, 0, 255).astype(np.uint8), "RGB")


def _auto_brightness(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    amount = max(0.0, float(settings.auto_brightness)) / 100.0 * strength
    if amount <= 0:
        return rgb
    lum = _luminance(rgb)
    p1, p99 = np.percentile(lum, [1.0, 99.0])
    if p99 <= p1 + 1:
        return rgb
    stretched = (rgb - p1) * (255.0 / (p99 - p1))
    stretched = np.clip(stretched, 0, 255)
    blend = np.clip(0.42 * amount, 0, 0.78) * editable[..., None]
    return rgb * (1.0 - blend) + stretched * blend


def _qenhancer_tone(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    amount = max(0.0, float(settings.auto_brightness)) / 100.0 * strength
    if amount <= 0.001:
        return rgb

    lum = _luminance(rgb)
    median = float(np.percentile(lum, 50.0))
    p95 = float(np.percentile(lum, 95.0))
    lift_need = float(np.clip((105.0 - median) / 78.0, 0.0, 1.0))
    bright_scene = float(np.clip((median - 92.0) / 70.0, 0.0, 1.0))

    # Dark no-flash photos need midtones and upper mids lifted, while daylight
    # photos mostly need cleaner blacks. This curve gives that QEnhancer-like
    # bite without washing out already bright files.
    gamma = max(0.58, 1.0 - 0.30 * min(1.6, amount) * lift_need)
    curved = np.clip(255.0 * np.power(np.clip(rgb / 255.0, 0.0, 1.0), gamma), 0, 255)
    lift_blend = np.clip((0.18 + 0.24 * lift_need) * amount, 0.0, 0.55) * editable[..., None]
    out = rgb * (1.0 - lift_blend) + curved * lift_blend

    upper_mids = _smoothstep(96.0, 220.0, lum) * (1.0 - _smoothstep(242.0, 255.0, lum))
    out += (8.0 * lift_need * min(1.6, amount)) * upper_mids[..., None] * editable[..., None]

    out_lum = _luminance(out)
    deep_shadow = 1.0 - _smoothstep(18.0, 74.0, out_lum)
    black_push = 5.0 + 6.0 * bright_scene + 4.0 * lift_need
    out -= black_push * min(1.45, amount) * deep_shadow[..., None]

    if p95 < 220.0:
        highlight_push = _smoothstep(150.0, 235.0, out_lum) * (1.0 - _smoothstep(238.0, 255.0, out_lum))
        out += (5.0 * lift_need * min(1.6, amount)) * highlight_push[..., None]

    return np.clip(out, 0, 255)


def _shadow_highlight_balance(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    lum = _luminance(rgb)
    shadows = 1.0 - _smoothstep(42.0, 160.0, lum)
    mids = _smoothstep(25.0, 118.0, lum) * (1.0 - _smoothstep(190.0, 246.0, lum))
    highs = _smoothstep(150.0, 245.0, lum)

    shadow_lift = _positive_control(settings.shadows, strength, min_step=0.006)
    highlight_hold = _positive_control(settings.lights, strength, min_step=0.004)
    shadow_contrast = _signed_control(settings.shadow_contrast, strength, min_step=0.006)
    highlight_contrast = _signed_control(settings.highlight_contrast, strength, min_step=0.006)
    brightness = _signed_control(settings.brightness, strength, min_step=0.004)

    out = rgb.copy()
    exposure_gain = np.power(2.0, np.clip(0.95 * brightness, -1.4, 1.4))
    out = out * exposure_gain
    out += (92.0 * shadow_lift + 24.0 * brightness) * shadows[..., None] * editable[..., None]
    out += (18.0 * brightness) * mids[..., None] * editable[..., None]
    out += (12.0 * brightness) * highs[..., None] * editable[..., None]
    out -= (52.0 * highlight_hold) * highs[..., None]
    out -= (34.0 * shadow_contrast) * shadows[..., None] * editable[..., None]
    out += (58.0 * highlight_contrast) * highs[..., None] * editable[..., None]

    mean = np.maximum(1.0, _luminance(out))[..., None]
    contrast_gain = 1.0 + (0.48 * shadow_contrast * shadows + 0.44 * highlight_contrast * highs)[..., None]
    contrast_gain = np.clip(contrast_gain, 0.35, 2.1)
    out = mean + (out - mean) * contrast_gain
    return np.clip(out, 0, 255)


def _clahe_luminance(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.memory_color)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    lab = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    clip = 1.2 + 2.0 * min(1.4, amount)
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(8, 8))
    enhanced_l = clahe.apply(l_channel)
    blend = min(0.48, 0.25 * amount)
    l_channel = cv2.addWeighted(l_channel, 1.0 - blend, enhanced_l, blend, 0)
    merged = cv2.merge([l_channel, a_channel, b_channel])
    return cv2.cvtColor(merged, cv2.COLOR_LAB2RGB).astype(np.float32)


def _gray_world(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.auto_color)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    means = np.mean(np.clip(rgb, 1, 255), axis=(0, 1))
    gray = float(np.mean(means))
    gains = np.clip(gray / np.maximum(means, 1.0), 0.65, 1.45)
    blend = min(0.62, 0.32 * amount)
    corrected = np.clip(rgb * gains[None, None, :], 0, 255)
    return rgb * (1.0 - blend) + corrected * blend


def _channel_balance(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    red = _signed_control(settings.red, strength)
    green = _signed_control(settings.green, strength)
    blue = _signed_control(settings.blue, strength)
    controls = np.array([red, green, blue], dtype=np.float32)
    offsets = controls * 58.0
    gains = 1.0 + controls * 0.28
    return np.clip(rgb * gains[None, None, :] + offsets[None, None, :], 0, 255)


def _rotate_hue_and_saturate(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    saturation = _signed_control(settings.saturation, strength)
    hue = float(settings.hue_rotation) * strength
    if abs(saturation) <= 0.0001 and abs(hue) <= 0.0001:
        return rgb
    hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv[..., 0] = (hsv[..., 0] + hue * 0.75) % 180.0
    sat_gain = 1.0 + saturation * 1.35
    hsv[..., 1] = np.clip(hsv[..., 1] * sat_gain, 0, 255)
    return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)


def _desaturate_shadows(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = _positive_control(settings.desaturate_shadows, strength)
    if amount <= 0.001:
        return rgb
    hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    shadow = 1.0 - _smoothstep(55.0, 175.0, hsv[..., 2])
    hsv[..., 1] *= 1.0 - np.clip(1.1 * amount * shadow, 0, 0.72)
    return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)


def _denoise(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = _positive_control(settings.denoise, strength)
    if amount <= 0.001:
        return rgb
    h = max(1, int(round(2 + 9 * min(1.4, amount))))
    denoised = cv2.fastNlMeansDenoisingColored(np.clip(rgb, 0, 255).astype(np.uint8), None, h, h, 5, 15)
    blend = min(0.62, 0.34 * amount)
    return rgb * (1.0 - blend) + denoised.astype(np.float32) * blend


def _sharpen(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = _positive_control(settings.global_sharpen + settings.local_sharpen, strength)
    if amount <= 0.001:
        return rgb
    blur = cv2.GaussianBlur(rgb, (0, 0), 1.15)
    sharpened = np.clip(rgb + (rgb - blur) * (1.25 * amount), 0, 255)
    return sharpened


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _classic_is_noop(settings: "PhotoEnhanceSettings") -> bool:
    fields = (
        "brightness",
        "shadow_contrast",
        "highlight_contrast",
        "saturation",
        "red",
        "green",
        "blue",
        "auto_brightness",
        "auto_color",
        "memory_color",
        "shadows",
        "lights",
        "global_sharpen",
        "local_sharpen",
        "denoise",
        "desaturate_shadows",
        "hue_rotation",
    )
    return all(abs(float(getattr(settings, field, 0) or 0)) <= 0.0001 for field in fields)


def _signed_control(value: float, strength: float, divisor: float = 100.0, min_step: float = 0.006) -> float:
    amount = float(value) / divisor * strength
    if abs(amount) <= 0.0001:
        return 0.0
    return float(np.sign(amount) * (abs(amount) + min_step * max(0.2, strength)))


def _positive_control(value: float, strength: float, divisor: float = 100.0, min_step: float = 0.006) -> float:
    amount = max(0.0, float(value)) / divisor * strength
    if amount <= 0.0001:
        return 0.0
    return amount + min_step * max(0.2, strength)


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)
