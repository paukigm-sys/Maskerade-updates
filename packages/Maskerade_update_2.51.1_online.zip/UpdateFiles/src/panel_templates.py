PANEL_HTML = """<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Maskerade</title>
  <link rel="stylesheet" href="/panel.css">
</head>
<body>
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">M</div>
        <div>
          <h1>Maskerade</h1>
          <p>Editor local de fotos</p>
        </div>
      </div>
      <div id="runtime-summary" class="runtime-summary"></div>
      <div id="operation-panel" class="runtime-summary operation-panel"></div>
      <div class="sidebar-actions">
        <button id="refresh-btn" class="secondary" type="button">Actualizar</button>
        <button id="save-btn" class="primary" type="button">Guardar</button>
      </div>
      <div id="status" class="status">Listo</div>
    </aside>

    <main class="main">
      <section class="toolbar">
        <div>
          <h2 id="profile-title">Configuracion</h2>
          <p id="profile-subtitle"></p>
        </div>
        <div class="toolbar-actions">
          <button id="test-one-btn" class="secondary" type="button">Probar 1 foto</button>
          <button id="run-batch-btn" class="primary" type="button">Procesar lote</button>
          <button id="open-output-btn" class="secondary" type="button">Abrir OUT</button>
        </div>
      </section>

      <section class="grid">
        <form id="profile-form" class="panel-form"></form>
        <aside class="side-panel">
          <div class="panel-section">
            <h3>Alimentar IN</h3>
            <label id="photo-dropzone" class="file-drop photo-dropzone">
              <span>Subir o arrastrar fotos JPG</span>
              <input id="photo-upload" type="file" accept=".jpg,.jpeg,image/jpeg" multiple>
            </label>
            <button id="open-input-btn" class="secondary wide" type="button">Abrir IN</button>
          </div>
          <div id="work-panel" class="panel-section"></div>
          <div class="panel-section">
            <h3>Ultima ejecucion</h3>
            <pre id="run-output" class="run-output">Sin ejecuciones en esta sesion.</pre>
          </div>
          <div class="panel-section">
            <h3>Logs</h3>
            <button id="load-logs-btn" class="secondary wide" type="button">Ver logs</button>
            <pre id="logs" class="logs"></pre>
          </div>
        </aside>
      </section>
    </main>
  </div>
  <script src="/panel.js"></script>
</body>
</html>
"""


PANEL_CSS = """
:root {
  color-scheme: light;
  --bg: #f5f7f8;
  --panel: #ffffff;
  --ink: #182026;
  --muted: #63717d;
  --line: #d9e1e6;
  --accent: #0b6f78;
  --accent-strong: #07545b;
  --amber: #a45f13;
  --danger: #b42318;
  --ok: #167348;
  --shadow: 0 12px 28px rgba(20, 35, 45, 0.08);
}

* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: var(--bg);
  color: var(--ink);
  font-family: "Segoe UI", Arial, sans-serif;
  font-size: 14px;
}

button,
input,
select {
  font: inherit;
}

button {
  border: 1px solid var(--line);
  border-radius: 6px;
  cursor: pointer;
  min-height: 36px;
  padding: 0 12px;
}

button:disabled {
  cursor: wait;
  opacity: 0.65;
}

.primary {
  background: var(--accent);
  border-color: var(--accent);
  color: #ffffff;
}

.primary:hover {
  background: var(--accent-strong);
}

.secondary {
  background: #ffffff;
  color: var(--ink);
}

.wide {
  width: 100%;
}

.app-shell {
  display: grid;
  grid-template-columns: 280px minmax(0, 1fr);
  min-height: 100vh;
}

.sidebar {
  background: #11191f;
  color: #f3f7f8;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.brand {
  align-items: center;
  display: flex;
  gap: 12px;
}

.brand-mark {
  align-items: center;
  background: #e7a43a;
  border-radius: 6px;
  color: #11191f;
  display: flex;
  font-weight: 800;
  height: 40px;
  justify-content: center;
  width: 40px;
}

.brand h1,
.brand p,
.toolbar h2,
.toolbar p,
.panel-section h3 {
  margin: 0;
}

.brand h1 {
  font-size: 18px;
  letter-spacing: 0;
}

.brand p {
  color: #aebbc3;
  margin-top: 2px;
}

.runtime-summary {
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 8px;
  display: grid;
  gap: 10px;
  padding: 12px;
}

.runtime-summary div {
  display: grid;
  gap: 3px;
}

.runtime-summary strong {
  color: #ffffff;
  font-size: 12px;
}

.runtime-summary span {
  color: #aebbc3;
  font-size: 12px;
  overflow-wrap: anywhere;
}

.operation-panel label {
  color: #aebbc3;
}

.operation-panel input[type="number"] {
  min-height: 32px;
}

.operation-panel .field-grid {
  grid-template-columns: 1fr;
}

.operation-panel .check-row span {
  color: #d7e0e5;
}

.sidebar-actions {
  display: grid;
  gap: 8px;
  margin-top: auto;
}

.status {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 6px;
  color: #d7e0e5;
  line-height: 1.4;
  min-height: 42px;
  padding: 10px;
}

.main {
  padding: 24px;
}

.toolbar {
  align-items: center;
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}

.toolbar h2 {
  font-size: 24px;
  letter-spacing: 0;
  text-transform: capitalize;
}

.toolbar p {
  color: var(--muted);
  margin-top: 4px;
}

.toolbar-actions {
  display: flex;
  gap: 8px;
}

.grid {
  align-items: start;
  display: grid;
  gap: 18px;
  grid-template-columns: minmax(0, 1fr) 360px;
}

.panel-form,
.side-panel {
  display: grid;
  gap: 14px;
}

.form-section,
.panel-section {
  background: var(--panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: var(--shadow);
  padding: 16px;
}

.form-section h3,
.panel-section h3 {
  font-size: 16px;
  letter-spacing: 0;
  margin: 0 0 14px;
}

.field-grid {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.field-grid.three {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}

.operator-summary {
  background: #eef4f6;
  border: 1px solid var(--line);
  border-radius: 6px;
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  margin-bottom: 14px;
  padding: 12px;
}

.operator-summary div {
  display: grid;
  gap: 3px;
}

.operator-summary span {
  color: var(--muted);
}

.field {
  display: grid;
  gap: 6px;
}

.field.full {
  grid-column: 1 / -1;
}

label {
  color: var(--muted);
  font-size: 12px;
  font-weight: 600;
}

input,
select {
  background: #ffffff;
  border: 1px solid var(--line);
  border-radius: 6px;
  color: var(--ink);
  min-height: 36px;
  padding: 7px 9px;
  width: 100%;
}

input[type="checkbox"] {
  height: 18px;
  min-height: 0;
  width: 18px;
}

.path-row {
  display: grid;
  gap: 8px;
  grid-template-columns: minmax(0, 1fr) auto auto;
}

.check-row {
  align-items: center;
  display: flex;
  gap: 8px;
  min-height: 36px;
}

.asset-status {
  display: grid;
  gap: 10px;
}

.asset-area {
  display: grid;
  gap: 14px;
}

.asset-area h3 {
  margin-bottom: 0;
}

.asset-block {
  display: grid;
  gap: 10px;
}

.asset-block-head {
  align-items: center;
  display: flex;
  justify-content: space-between;
  gap: 12px;
}

.asset-block-head h4 {
  font-size: 14px;
  margin: 0;
}

.asset-block-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.asset-line {
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 10px;
}

.asset-head {
  align-items: center;
  display: flex;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 8px;
}

.badge {
  border-radius: 999px;
  font-size: 12px;
  font-weight: 700;
  padding: 3px 8px;
}

.badge.ok {
  background: #e8f5ee;
  color: var(--ok);
}

.badge.warn {
  background: #fff2df;
  color: var(--amber);
}

.badge.error {
  background: #fdeceb;
  color: var(--danger);
}

.asset-path {
  color: var(--muted);
  font-size: 12px;
  overflow-wrap: anywhere;
}

.asset-gallery {
  margin-top: 10px;
}

.asset-gallery-title {
  color: var(--muted);
  font-size: 12px;
  font-weight: 700;
  margin: 0 0 8px;
}

.asset-grid {
  display: grid;
  gap: 12px;
  grid-template-columns: repeat(auto-fill, minmax(210px, 1fr));
}

.asset-thumb-wrap {
  position: relative;
}

.asset-thumb {
  background:
    linear-gradient(45deg, #d7dde1 25%, transparent 25%),
    linear-gradient(-45deg, #d7dde1 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #d7dde1 75%),
    linear-gradient(-45deg, transparent 75%, #d7dde1 75%),
    #f5f7f8;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-size: 16px 16px;
  border: 2px solid var(--line);
  border-radius: 6px;
  color: var(--ink);
  display: grid;
  gap: 5px;
  height: auto;
  min-height: 0;
  padding: 8px;
  text-align: left;
  width: 100%;
}

.asset-thumb.active {
  border-color: var(--accent);
  box-shadow: 0 0 0 2px rgba(11, 111, 120, 0.12);
}

.asset-thumb img {
  aspect-ratio: 16 / 9;
  background: #11191f;
  border-radius: 4px;
  display: block;
  object-fit: cover;
  width: 100%;
}

.asset-thumb.overlay img {
  aspect-ratio: 16 / 10;
  object-fit: contain;
}

.asset-thumb span {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.asset-delete {
  align-items: center;
  background: rgba(17, 25, 31, 0.86);
  border-color: rgba(255, 255, 255, 0.35);
  border-radius: 999px;
  color: #ffffff;
  display: flex;
  font-size: 11px;
  font-weight: 800;
  height: 24px;
  justify-content: center;
  min-height: 24px;
  padding: 0;
  position: absolute;
  right: 8px;
  top: 8px;
  width: 24px;
}

.asset-delete:hover {
  background: var(--danger);
  border-color: var(--danger);
}

.asset-empty {
  border: 1px dashed var(--line);
  border-radius: 8px;
  color: var(--muted);
  padding: 18px;
  text-align: center;
}

.preview-section {
  padding: 14px;
}

.preview-head {
  align-items: center;
  display: flex;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 10px;
}

.preview-head h3 {
  margin: 0;
}

.preview-note {
  color: var(--muted);
  font-size: 12px;
}

.preview-frame {
  align-items: center;
  background: #11191f;
  border: 1px solid var(--line);
  border-radius: 8px;
  display: flex;
  justify-content: center;
  min-height: 250px;
  overflow: hidden;
  position: relative;
}

.preview-frame img {
  display: block;
  height: auto;
  max-height: 360px;
  object-fit: contain;
  width: 100%;
}

.preview-loading,
.preview-error {
  color: #d7e0e5;
  left: 0;
  padding: 18px;
  position: absolute;
  right: 0;
  text-align: center;
  top: 45%;
}

.asset-columns {
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.file-drop {
  align-items: center;
  border: 1px dashed #a7b5bd;
  border-radius: 8px;
  color: var(--muted);
  cursor: pointer;
  display: flex;
  justify-content: center;
  min-height: 76px;
  padding: 12px;
  text-align: center;
}

.file-drop:hover,
.file-drop.drag-over {
  background: #eef8f9;
  border-color: var(--accent);
  color: var(--accent-strong);
}

.file-drop.drag-over {
  box-shadow: inset 0 0 0 1px var(--accent);
}

.file-drop input {
  display: none;
}

.panel-section .file-drop + button,
.panel-section button + button {
  margin-top: 8px;
}

.run-output,
.logs {
  background: #11191f;
  border-radius: 6px;
  color: #d7e0e5;
  font-family: Consolas, monospace;
  font-size: 12px;
  margin: 0;
  max-height: 260px;
  overflow: auto;
  padding: 10px;
  white-space: pre-wrap;
}

@media (max-width: 980px) {
  .app-shell {
    grid-template-columns: 1fr;
  }

  .sidebar {
    min-height: auto;
  }

  .grid {
    grid-template-columns: 1fr;
  }

  .asset-columns {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 680px) {
  .main {
    padding: 14px;
  }

  .toolbar,
  .toolbar-actions {
    align-items: stretch;
    flex-direction: column;
  }

  .field-grid,
  .field-grid.three,
  .path-row {
    grid-template-columns: 1fr;
  }
}
"""


PANEL_JS = """
let state = null;
let selectedPark = null;
let previewVersion = 1;

const $ = (id) => document.getElementById(id);

function setStatus(message, kind = "info") {
  const status = $("status");
  status.textContent = message;
  status.dataset.kind = kind;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

async function api(path, options = {}) {
  const response = await fetch(path, options);
  const text = await response.text();
  let payload = null;
  try {
    payload = text ? JSON.parse(text) : null;
  } catch {
    payload = { error: text };
  }
  if (!response.ok) {
    throw new Error(payload?.error || `HTTP ${response.status}`);
  }
  return payload;
}

async function loadConfig() {
  setStatus("Cargando configuracion...");
  state = await api("/api/config");
  selectedPark = selectedPark || Object.keys(state.config.parks)[0];
  render();
  setStatus("Configuracion cargada");
}

function render() {
  renderTabs();
  renderRuntimeSummary();
  renderOperationPanel();
  renderForm();
  renderWorkPanel();
  renderAssets();
}

function parkConfig() {
  return state.config.parks[selectedPark];
}

function parkMeta() {
  return state.meta.parks[selectedPark] || {};
}

function renderTabs() {
  selectedPark = selectedPark || Object.keys(state.config.parks)[0];
}

function renderRuntimeSummary() {
  const bg = state.config.background_removal || {};
  const motor = `${bg.backend || "ben2"}${bg.model ? ` / ${bg.model}` : ""}`;
  $("runtime-summary").innerHTML = `
    <div>
      <strong>Motor de recorte</strong>
      <span>${escapeHtml(motor)}</span>
    </div>
    <div>
      <strong>Salida</strong>
      <span>Mismo tamano que el fondo seleccionado</span>
    </div>
  `;
}

function renderOperationPanel() {
  const park = parkConfig();
  $("operation-panel").innerHTML = `
    <div>
      <strong>Operacion</strong>
      <span>Procesado y calidad</span>
    </div>
    <div class="field-grid">
      ${checkboxField("Mover fotos procesadas", "move_original_to_processed", park.move_original_to_processed)}
      ${inputField("Calidad JPG", "jpg_quality", park.jpg_quality || 90, "number", "min='50' max='100'")}
    </div>
  `;
}

function inputField(label, key, value, type = "text", attrs = "") {
  return `
    <div class="field">
      <label for="${key}">${label}</label>
      <input id="${key}" data-key="${key}" type="${type}" value="${escapeHtml(value)}" ${attrs}>
    </div>
  `;
}

function pathField(label, key, value) {
  return `
    <div class="field full">
      <label for="${key}">${label}</label>
      <div class="path-row">
        <input id="${key}" data-key="${key}" type="text" value="${escapeHtml(value)}">
        <button data-pick="${key}" class="secondary" type="button">Seleccionar</button>
        <button data-open="${key}" class="secondary" type="button">Abrir</button>
      </div>
    </div>
  `;
}

function checkboxField(label, key, checked) {
  return `
    <div class="field">
      <label>${label}</label>
      <div class="check-row">
        <input id="${key}" data-key="${key}" type="checkbox" ${checked ? "checked" : ""}>
        <span>${checked ? "Activo" : "Inactivo"}</span>
      </div>
    </div>
  `;
}

function renderForm() {
  const park = parkConfig();
  const meta = parkMeta();
  $("profile-title").textContent = "Maskerade";
  $("profile-subtitle").textContent = `${meta.input_count || 0} JPG en IN · ${meta.output_count || 0} JPG en OUT`;

  $("profile-form").innerHTML = `
    <input id="background" data-key="background" type="hidden" value="${escapeHtml(park.background)}">
    <input id="overlay" data-key="overlay" type="hidden" value="${escapeHtml(park.overlay || "")}">
    <input id="logo" data-key="logo" type="hidden" value="${escapeHtml(park.logo || "")}">

    <section class="form-section preview-section">
      <div class="preview-head">
        <div>
          <h3>Preview final</h3>
          <div class="preview-note">${meta.preview_input ? `Usando ${escapeHtml(meta.preview_input)}` : "Sin fotos en IN: vista de fondo y overlay"}</div>
        </div>
        <button id="refresh-preview-btn" class="secondary" type="button">Actualizar preview</button>
      </div>
      <div class="preview-frame">
        <div id="preview-loading" class="preview-loading">Generando preview...</div>
        <img id="final-preview" alt="Preview final" src="/api/render-preview?park=${encodeURIComponent(selectedPark)}&v=${previewVersion}">
      </div>
    </section>

    <section class="form-section visual-assets">
      <div id="asset-status" class="asset-area"></div>
    </section>
  `;

  const preview = $("final-preview");
  const previewLoading = $("preview-loading");
  preview.addEventListener("load", () => {
    previewLoading.style.display = "none";
  });
  preview.addEventListener("error", () => {
    previewLoading.textContent = "No se pudo generar el preview";
    previewLoading.className = "preview-error";
  });
  $("refresh-preview-btn").addEventListener("click", refreshPreview);
}

function renderWorkPanel() {
  const park = parkConfig();
  const target = $("work-panel");
  if (!target) {
    return;
  }
  target.innerHTML = `
    <h3>Trabajo</h3>
    <div class="field full">
      <label for="input_dir">Carpeta IN</label>
      <div class="path-row">
        <input id="input_dir" data-key="input_dir" type="text" value="${escapeHtml(park.input_dir)}">
        <button data-pick="input_dir" class="secondary" type="button">Seleccionar</button>
        <button data-open="input_dir" class="secondary" type="button">Abrir</button>
      </div>
    </div>
    <div class="field full">
      <label for="output_dir">Carpeta OUT</label>
      <div class="path-row">
        <input id="output_dir" data-key="output_dir" type="text" value="${escapeHtml(park.output_dir)}">
        <button data-pick="output_dir" class="secondary" type="button">Seleccionar</button>
        <button data-open="output_dir" class="secondary" type="button">Abrir</button>
      </div>
    </div>
  `;
  target.querySelectorAll("[data-pick]").forEach((button) => {
    button.addEventListener("click", () => pickPath(button.dataset.pick));
  });
  target.querySelectorAll("[data-open]").forEach((button) => {
    button.addEventListener("click", () => openPath($(button.dataset.open).value));
  });
}

function renderAssets() {
  const park = parkConfig();
  const meta = parkMeta();
  const target = $("asset-status");
  if (!target) {
    return;
  }
  target.innerHTML = `
    <h3>Capas</h3>
    ${assetChooser("Fondo activo", "background", park.background, meta.background_exists, meta.background_assets || [])}
    ${assetChooser("Overlay activo", "overlay", park.overlay || "", meta.overlay_exists, meta.overlay_assets || [])}
    ${assetChooser("Logo activo", "logo", park.logo || "", meta.logo_exists, meta.logo_assets || [])}
  `;

  setupAssetDropzones();
  document.querySelectorAll("[data-asset-kind]").forEach((button) => {
    button.addEventListener("click", () => selectAsset(button.dataset.assetKind, button.dataset.assetPath));
  });
  document.querySelectorAll("[data-delete-asset-kind]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      deleteAsset(button.dataset.deleteAssetKind, button.dataset.deleteAssetPath);
    });
  });
  document.querySelectorAll("[data-clear-asset]").forEach((button) => {
    button.addEventListener("click", () => clearAsset(button.dataset.clearAsset));
  });
}

function assetChooser(label, kind, path, exists, assets) {
  const uploadLabel = kind === "background" ? "Subir o arrastrar fondo" : kind === "logo" ? "Subir o arrastrar logo PNG" : "Subir o arrastrar overlay PNG";
  const uploadKind = kind;
  const clearLabel = kind === "background" ? "Limpiar fondo" : kind === "logo" ? "Limpiar logo" : "Limpiar overlay";
  const activeName = path ? path.split(/[\\\\/]/).pop() : kind === "background" ? "Sin fondo seleccionado" : kind === "logo" ? "Sin logo" : "Sin overlay";
  return `
    <div class="asset-block">
      <div class="asset-block-head">
        <div>
          <h4>${label}</h4>
          <div class="asset-path">${escapeHtml(activeName)}</div>
        </div>
        <div class="asset-block-actions">
          <span class="badge ${exists ? "ok" : kind !== "background" ? "warn" : "error"}">${exists ? "OK" : kind !== "background" ? "Opcional" : "Falta"}</span>
          <button data-clear-asset="${kind}" class="secondary" type="button">${clearLabel}</button>
        </div>
      </div>
      <label class="file-drop asset-upload-zone" data-upload-zone-kind="${uploadKind}">
        <span>${uploadLabel}</span>
        <input data-upload-kind="${uploadKind}" type="file" accept="${kind === "background" ? "image/*" : ".png,image/png"}">
      </label>
      ${assetGallery(kind === "background" ? "Fondos disponibles" : kind === "logo" ? "Logos disponibles" : "Overlays disponibles", kind, assets, path)}
    </div>
  `;
}

function assetLine(label, path, exists, kind) {
  const badgeClass = exists ? "ok" : kind === "overlay" ? "warn" : "error";
  const badgeText = exists ? "OK" : kind === "overlay" ? "Opcional" : "Falta";
  const uploadControls = kind === "background" ? `
      <label class="file-drop">
        <span>Subir fondo</span>
        <input data-upload-kind="background" type="file" accept="image/*">
      </label>
  ` : `
      <label class="file-drop">
        <span>Subir o arrastrar overlay PNG</span>
        <input data-upload-kind="overlay" type="file" accept=".png,image/png">
      </label>
  `;
  return `
    <div class="asset-line">
      <div class="asset-head">
        <strong>${label}</strong>
        <span class="badge ${badgeClass}">${badgeText}</span>
      </div>
      <div class="asset-path">${escapeHtml(path)}</div>
      ${uploadControls}
    </div>
  `;
}

function assetGallery(title, kind, assets, activePath) {
  if (!assets.length) {
    return "";
  }
  const normalizedActive = normalizePath(activePath);
  return `
    <div class="asset-gallery">
      <p class="asset-gallery-title">${title}</p>
      <div class="asset-grid">
        ${assets.map((asset) => {
          const isActive = normalizePath(asset.path) === normalizedActive;
          return `
            <div class="asset-thumb-wrap">
              <button class="asset-thumb ${kind} ${isActive ? "active" : ""}" type="button" data-asset-kind="${kind}" data-asset-path="${escapeHtml(asset.path)}" title="${escapeHtml(asset.name)}">
                <img src="${escapeHtml(asset.url)}" alt="${escapeHtml(asset.name)}" loading="lazy">
                <span>${escapeHtml(asset.name)}</span>
              </button>
              <button class="asset-delete" type="button" data-delete-asset-kind="${kind}" data-delete-asset-path="${escapeHtml(asset.path)}" title="Eliminar ${escapeHtml(asset.name)}">X</button>
            </div>
          `;
        }).join("")}
      </div>
    </div>
  `;
}

function normalizePath(value) {
  return String(value || "").replaceAll("\\\\", "/").toLowerCase();
}

function num(id) {
  const value = $(id).value;
  return value === "" ? 0 : Number(value);
}

function bool(id) {
  return $(id).checked;
}

function updateParkFromForm() {
  if (!state || !selectedPark || !$("input_dir")) {
    return;
  }
  state.config.background_removal = {
    ...(state.config.background_removal || {}),
    backend: "ben2",
    model: "models/BEN2",
    max_processing_side: 0,
    ben2_model: "models/BEN2",
    ben2_device: "auto",
    ben2_refine_foreground: false
  };
  const park = parkConfig();
  park.input_dir = $("input_dir").value.trim();
  park.output_dir = $("output_dir").value.trim();
  park.background = $("background").value.trim();
  park.overlay = $("overlay").value.trim() || null;
  park.logo = $("logo").value.trim() || null;
  park.output_size = "input";
  park.jpg_quality = num("jpg_quality");
  park.move_original_to_processed = bool("move_original_to_processed");
  park.overwrite_output = false;
  park.unique_output_names = true;
  park.person = { ...(park.person || {}), anchor: "original", x: 0, y: 0, scale: 1, max_width_ratio: 1, max_height_ratio: 1 };
  park.overlay_settings = { ...(park.overlay_settings || {}) };
}

async function saveConfig() {
  updateParkFromForm();
  setBusy(true);
  try {
    await api("/api/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(state.config)
    });
    previewVersion += 1;
    await loadConfig();
    setStatus("Configuracion guardada");
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

function refreshPreview() {
  previewVersion += 1;
  const preview = $("final-preview");
  const previewLoading = $("preview-loading");
  if (!preview || !previewLoading) {
    return;
  }
  previewLoading.className = "preview-loading";
  previewLoading.textContent = "Generando preview...";
  previewLoading.style.display = "block";
  preview.src = `/api/render-preview?park=${encodeURIComponent(selectedPark)}&v=${previewVersion}`;
}

async function pickPath(key) {
  if (key === "background" || key === "overlay" || key === "logo") {
    await pickFile(key);
    return;
  }
  await pickFolder(key);
}

async function pickFolder(key) {
  updateParkFromForm();
  setBusy(true);
  try {
    const payload = await api("/api/pick-folder", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current: $(key).value })
    });
    if (payload.path) {
      $(key).value = payload.path;
      updateParkFromForm();
      setStatus("Carpeta seleccionada");
    }
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function pickFile(key) {
  updateParkFromForm();
  setBusy(true);
  try {
    const payload = await api("/api/pick-file", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        current: $(key).value,
        kind: key,
        park: selectedPark
      })
    });
    if (payload.path) {
      $(key).value = payload.path;
      updateParkFromForm();
      setStatus(key === "background" ? "Fondo seleccionado" : key === "logo" ? "Logo seleccionado" : "Overlay seleccionado");
    }
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function selectAsset(kind, path) {
  if (!path || !$(kind)) {
    return;
  }
  $(kind).value = path;
  updateParkFromForm();
  await saveConfig();
  setStatus(kind === "background" ? "Fondo aplicado" : kind === "logo" ? "Logo aplicado" : "Overlay aplicado");
}

async function clearAsset(kind) {
  const input = $(kind);
  if (!input) {
    return;
  }
  input.value = "";
  updateParkFromForm();
  await saveConfig();
    setStatus(kind === "background" ? "Fondo limpiado" : kind === "logo" ? "Logo desactivado" : "Overlay desactivado");
}

async function deleteAsset(kind, path) {
  if (!kind || !path) {
    return;
  }
  const name = path.split(/[\\\\/]/).pop();
  if (!window.confirm(`Eliminar ${name}?`)) {
    return;
  }
  updateParkFromForm();
  setBusy(true);
  try {
    await api("/api/delete-asset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ park: selectedPark, kind, path })
    });
    previewVersion += 1;
    await loadConfig();
    setStatus(kind === "background" ? "Fondo eliminado" : kind === "logo" ? "Logo eliminado" : "Overlay eliminado");
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function openPath(path) {
  if (!path) {
    setStatus("No hay ruta configurada", "error");
    return;
  }
  if (document.activeElement && typeof document.activeElement.blur === "function") {
    document.activeElement.blur();
  }
  try {
    window.blur();
  } catch (_) {
  }
  try {
    await api("/api/open-path", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ path })
    });
    setStatus("Ruta abierta");
  } catch (error) {
    setStatus(error.message, "error");
  }
}

async function uploadAsset(kind, file) {
  if (!file) {
    return;
  }
  updateParkFromForm();
  await saveConfig();
  setBusy(true);
  try {
    await api(`/api/upload?park=${encodeURIComponent(selectedPark)}&kind=${kind}&filename=${encodeURIComponent(file.name)}`, {
      method: "POST",
      headers: { "Content-Type": "application/octet-stream" },
      body: file
    });
    previewVersion += 1;
    await loadConfig();
    setStatus(kind === "background" ? "Fondo subido" : kind === "logo" ? "Logo subido" : kind === "mask" ? "Mascara subida" : "Overlay subido");
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function uploadPhotos(files) {
  if (!files.length) {
    return;
  }
  const jpgFiles = files.filter((file) => {
    const name = file.name.toLowerCase();
    return name.endsWith(".jpg") || name.endsWith(".jpeg") || file.type === "image/jpeg";
  });
  if (!jpgFiles.length) {
    setStatus("Solo se pueden subir fotos JPG/JPEG", "error");
    return;
  }
  if (jpgFiles.length !== files.length) {
    setStatus(`Se ignoraron ${files.length - jpgFiles.length} archivo(s) que no son JPG`);
  }
  updateParkFromForm();
  await saveConfig();
  setBusy(true);
  let uploaded = 0;
  try {
    for (const file of jpgFiles) {
      setStatus(`Subiendo ${uploaded + 1}/${jpgFiles.length}: ${file.name}`);
      await api(`/api/upload?park=${encodeURIComponent(selectedPark)}&kind=input_photo&filename=${encodeURIComponent(file.name)}`, {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file
      });
      uploaded += 1;
    }
    previewVersion += 1;
    await loadConfig();
    setStatus(`${uploaded} foto(s) subidas a IN`);
  } catch (error) {
    setStatus(error.message, "error");
  } finally {
    $("photo-upload").value = "";
    setBusy(false);
  }
}

function setupDropzone(dropzoneId, inputId, uploadHandler) {
  const dropzone = $(dropzoneId);
  const input = $(inputId);
  if (!dropzone || !input) {
    return;
  }
  setupDropzoneElement(dropzone, input, uploadHandler);
}

function setupDropzoneElement(dropzone, input, uploadHandler) {
  ["dragenter", "dragover"].forEach((eventName) => {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      event.stopPropagation();
      dropzone.classList.add("drag-over");
    });
  });

  ["dragleave", "dragend", "drop"].forEach((eventName) => {
    dropzone.addEventListener(eventName, (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (eventName !== "dragenter" && eventName !== "dragover") {
        dropzone.classList.remove("drag-over");
      }
    });
  });

  dropzone.addEventListener("drop", (event) => {
    const files = [...(event.dataTransfer?.files || [])];
    uploadHandler(files);
  });

  input.addEventListener("change", (event) => {
    uploadHandler([...(event.target.files || [])]);
  });
}

function setupAssetDropzones() {
  document.querySelectorAll(".asset-upload-zone").forEach((dropzone) => {
    const input = dropzone.querySelector("input");
    const kind = dropzone.dataset.uploadZoneKind;
    if (!input || !kind) {
      return;
    }
    setupDropzoneElement(dropzone, input, (files) => {
      uploadAsset(kind, files[0]);
    });
  });
}

function setupPhotoDropzone() {
  setupDropzone("photo-dropzone", "photo-upload", uploadPhotos);
}

async function runBatch() {
  updateParkFromForm();
  await saveConfig();
  setBusy(true);
  $("run-output").textContent = "Procesando...";
  try {
    const payload = await api(`/api/run-batch?park=${encodeURIComponent(selectedPark)}`, {
      method: "POST"
    });
    $("run-output").textContent = JSON.stringify(payload, null, 2);
    await loadConfig();
    setStatus("Lote procesado");
  } catch (error) {
    $("run-output").textContent = `ERROR: ${error.message}\n\nNo se ha generado una salida nueva. Si ves imagenes en OUT, pueden ser de una ejecucion anterior.`;
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function testOne() {
  updateParkFromForm();
  await saveConfig();
  setBusy(true);
  $("run-output").textContent = "Probando 1 foto...";
  try {
    const payload = await api(`/api/test-one?park=${encodeURIComponent(selectedPark)}`, {
      method: "POST"
    });
    $("run-output").textContent = JSON.stringify(payload, null, 2);
    await loadConfig();
    setStatus(payload.status === "processed" ? `Prueba procesada: ${payload.output}` : "Prueba fallida: no se genero salida nueva", payload.status === "processed" ? "info" : "error");
  } catch (error) {
    $("run-output").textContent = `ERROR: ${error.message}\n\nNo se ha generado una salida nueva. Si ves una imagen en OUT, puede ser de una ejecucion anterior.`;
    setStatus(error.message, "error");
  } finally {
    setBusy(false);
  }
}

async function loadLogs() {
  try {
    const payload = await api("/api/logs?limit=40");
    $("logs").textContent = payload.lines.join("\\n");
  } catch (error) {
    $("logs").textContent = error.message;
  }
}

function setBusy(isBusy) {
  document.querySelectorAll("button, input, select").forEach((element) => {
    element.disabled = isBusy;
  });
}

$("refresh-btn").addEventListener("click", loadConfig);
$("save-btn").addEventListener("click", saveConfig);
$("test-one-btn").addEventListener("click", testOne);
$("run-batch-btn").addEventListener("click", runBatch);
$("open-input-btn").addEventListener("click", () => openPath(parkConfig().input_dir));
$("open-output-btn").addEventListener("click", () => openPath(parkConfig().output_dir));
$("load-logs-btn").addEventListener("click", loadLogs);
setupPhotoDropzone();

loadConfig().catch((error) => setStatus(error.message, "error"));
"""
