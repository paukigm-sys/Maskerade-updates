from __future__ import annotations

import json
import logging
import threading
import time
from datetime import date, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any


LOG_MAX_BYTES = 10 * 1024 * 1024
LOG_RETENTION_DAYS = 15


class ProcessingLogger:
    def __init__(
        self,
        logger: logging.Logger,
        jsonl_path: Path,
        max_bytes: int = LOG_MAX_BYTES,
        retention_days: int = LOG_RETENTION_DAYS,
    ) -> None:
        self.logger = logger
        self.jsonl_path = jsonl_path
        self.max_bytes = max(1, int(max_bytes))
        self.retention_days = max(1, int(retention_days))
        self._lock = threading.Lock()
        self._active_day = date.today()
        self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)
        self._rotate_previous_day()
        self._cleanup_archives()
        self._rotate_if_needed(0)

    def photo_result(self, payload: dict[str, Any]) -> None:
        payload = {"timestamp": datetime.now().isoformat(timespec="seconds"), **payload}
        line = json.dumps(payload, ensure_ascii=False) + "\n"
        encoded_size = len(line.encode("utf-8"))
        with self._lock:
            self._rotate_if_needed(encoded_size)
            try:
                with self.jsonl_path.open("a", encoding="utf-8") as f:
                    f.write(line)
            except OSError as exc:
                fallback = self._archive_path(datetime.now())
                try:
                    with fallback.open("a", encoding="utf-8") as f:
                        f.write(line)
                    self.logger.warning("JSONL log locked, wrote fallback %s: %s", fallback, exc)
                except OSError as fallback_exc:
                    self.logger.warning(
                        "JSONL log disabled; primary=%s fallback=%s",
                        exc,
                        fallback_exc,
                    )

    def _rotate_if_needed(self, incoming_bytes: int) -> None:
        today = date.today()
        if self._active_day != today:
            self._rotate_current(datetime.combine(self._active_day, datetime.min.time()))
            self._active_day = today
            self._cleanup_archives()
        try:
            current_size = self.jsonl_path.stat().st_size
        except FileNotFoundError:
            current_size = 0
        if current_size > 0 and current_size + incoming_bytes > self.max_bytes:
            self._rotate_current(datetime.now())
            self._cleanup_archives()

    def _rotate_previous_day(self) -> None:
        try:
            modified = datetime.fromtimestamp(self.jsonl_path.stat().st_mtime)
        except FileNotFoundError:
            return
        if modified.date() != self._active_day:
            self._rotate_current(modified)

    def _rotate_current(self, stamp: datetime) -> None:
        if not self.jsonl_path.exists():
            return
        archive = self._archive_path(stamp)
        try:
            self.jsonl_path.replace(archive)
        except OSError as exc:
            self.logger.warning("Could not rotate JSONL log %s: %s", self.jsonl_path, exc)

    def _archive_path(self, stamp: datetime) -> Path:
        suffix = self.jsonl_path.suffix or ".jsonl"
        base = self.jsonl_path.with_name(
            f"{self.jsonl_path.stem}_{stamp:%Y%m%d_%H%M%S}{suffix}"
        )
        if not base.exists():
            return base
        index = 1
        while True:
            candidate = base.with_name(f"{base.stem}_{index:02d}{base.suffix}")
            if not candidate.exists():
                return candidate
            index += 1

    def _cleanup_archives(self) -> None:
        cutoff = time.time() - (self.retention_days * 24 * 60 * 60)
        suffix = self.jsonl_path.suffix or ".jsonl"
        pattern = f"{self.jsonl_path.stem}_*{suffix}"
        for path in self.jsonl_path.parent.glob(pattern):
            try:
                if path.is_file() and path.stat().st_mtime < cutoff:
                    path.unlink()
            except OSError as exc:
                self.logger.warning("Could not remove expired log %s: %s", path, exc)


def _cleanup_expired_logs(log_dir: Path, retention_days: int = LOG_RETENTION_DAYS) -> None:
    cutoff = time.time() - (max(1, int(retention_days)) * 24 * 60 * 60)
    for path in log_dir.iterdir():
        if not path.is_file():
            continue
        name = path.name.casefold()
        if ".log" not in name and not name.endswith(".jsonl"):
            continue
        try:
            if path.stat().st_mtime < cutoff:
                path.unlink()
        except OSError:
            continue


def maintain_logs(log_dir: Path, jsonl_path: Path | None = None) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    _cleanup_expired_logs(log_dir)
    ProcessingLogger(
        logging.getLogger("photoia.log_maintenance"),
        jsonl_path or log_dir / "processing.jsonl",
    )


def setup_logging(
    log_dir: Path,
    park: str | None = None,
    jsonl_path: Path | None = None,
) -> ProcessingLogger:
    log_dir.mkdir(parents=True, exist_ok=True)
    _cleanup_expired_logs(log_dir)
    logger = logging.getLogger("photoia")
    logger.setLevel(logging.INFO)
    for existing_handler in logger.handlers:
        try:
            existing_handler.close()
        except Exception:
            pass
    logger.handlers.clear()
    logger.propagate = False

    suffix = f"_{park}" if park else ""
    log_file = log_dir / f"photoia{suffix}_{datetime.now():%Y%m%d}.log"

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    try:
        file_handler: logging.Handler = RotatingFileHandler(
            log_file,
            maxBytes=LOG_MAX_BYTES,
            backupCount=5,
            encoding="utf-8",
        )
    except OSError as first_exc:
        log_file = log_dir / f"photoia{suffix}_{datetime.now():%Y%m%d_%H%M%S}.log"
        try:
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=LOG_MAX_BYTES,
                backupCount=5,
                encoding="utf-8",
            )
        except OSError as second_exc:
            file_handler = logging.NullHandler()
            logger.warning("File log disabled; primary=%s fallback=%s", first_exc, second_exc)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return ProcessingLogger(logger, jsonl_path or log_dir / "processing.jsonl")
