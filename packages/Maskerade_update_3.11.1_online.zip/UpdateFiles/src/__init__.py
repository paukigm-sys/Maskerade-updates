"""Maskerade package."""

__version__ = "3.11.1"
