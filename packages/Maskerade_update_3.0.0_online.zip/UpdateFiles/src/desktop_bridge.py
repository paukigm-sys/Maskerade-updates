from __future__ import annotations

import ast
import io
import json
import logging
import os
import re
import sys
import threading
import time
import uuid
import contextlib
from collections import OrderedDict
from copy import deepcopy
from datetime import datetime
from dataclasses import replace
from pathlib import Path

from PIL import Image, ImageOps

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from src import __version__
    from src.background_removal import BackgroundRemover
    from src.compositor import _apply_contact_shadow, apply_background_brightness, compose_image, harmonize_composed_image, prepare_overlay_layer
    from src.cloud_delivery import validate_cloud_credentials
    from src.config import load_settings
    from src.processor import PhotoProcessor
    from src.image_utils import LANCZOS, alpha_composite_at, list_images, natural_sort_key, open_image, resize_cover
    from src.logger import maintain_logs, setup_logging
    from src.photo_enhancer import LEGACY_ENHANCER2_ENGINES, QENHANCER_CUEVAS_ENGINES, enhance_photo
    from src.secure_settings import ensure_settings_storage, load_raw_settings, save_raw_settings, secure_settings_path
else:
    from . import __version__
    from .background_removal import BackgroundRemover
    from .compositor import _apply_contact_shadow, apply_background_brightness, compose_image, harmonize_composed_image, prepare_overlay_layer
    from .cloud_delivery import validate_cloud_credentials
    from .config import load_settings
    from .processor import PhotoProcessor
    from .image_utils import LANCZOS, alpha_composite_at, list_images, natural_sort_key, open_image, resize_cover
    from .logger import maintain_logs, setup_logging
    from .photo_enhancer import LEGACY_ENHANCER2_ENGINES, QENHANCER_CUEVAS_ENGINES, enhance_photo
    from .secure_settings import ensure_settings_storage, load_raw_settings, save_raw_settings, secure_settings_path


CONFIG_PATH = Path("config/settings.json")
PROFILE_NAME = "photo"
PREVIEW_DIR = Path("cache/desktop_previews")
PREVIEW_FILE = PREVIEW_DIR / "desktop_preview.jpg"
PREVIEW_SCENE_FILE = PREVIEW_DIR / "desktop_preview_scene.jpg"
PHOTO_ENHANCE_PREVIEW_FILE = PREVIEW_DIR / "desktop_photo_enhance_preview.jpg"
PREVIEW_SUBJECT_PREFIX = "desktop_preview_subject_"
PREVIEW_SHADOW_PREFIX = "desktop_preview_shadow_"
LEGACY_ROOT_PREVIEW_FILES = (
    Path("desktop_preview.jpg"),
    Path("desktop_preview_scene.jpg"),
    Path("desktop_photo_enhance_preview.jpg"),
)
PRESETS_DIR = Path("presets")
CLASSIC_PHOTO_PRESETS_FILE = Path("config/photo_enhance_classic_presets.json")
PHOTO_RETOUCH_PRESETS_FILE = Path("config/photo_retouch_presets.json")
QUICK_PHOTO_RETOUCH_IDS = {"neutral", "cuevas", "skin", "shadows", "burned", "print"}
PREVIEW_MAX_SIDE = 640
PREVIEW_FAST_MAX_SIDE = 520
PHOTO_ENHANCE_PREVIEW_MAX_SIDE = 900
CLASSIC_PHOTO_FIELDS = {
    "photo_enhance_brightness": "brightness",
    "photo_enhance_shadow_contrast": "shadow_contrast",
    "photo_enhance_highlight_contrast": "highlight_contrast",
    "photo_enhance_saturation": "saturation",
    "photo_enhance_red": "red",
    "photo_enhance_green": "green",
    "photo_enhance_blue": "blue",
    "photo_enhance_auto_brightness": "auto_brightness",
    "photo_enhance_auto_color": "auto_color",
    "photo_enhance_memory_color": "memory_color",
    "photo_enhance_shadows": "shadows",
    "photo_enhance_lights": "lights",
    "photo_enhance_global_sharpen": "global_sharpen",
    "photo_enhance_local_sharpen": "local_sharpen",
    "photo_enhance_denoise": "denoise",
    "photo_enhance_desaturate_shadows": "desaturate_shadows",
    "photo_enhance_hue_rotation": "hue_rotation",
}
PHOTO_RETOUCH_UI_KEYS = (
    "photo_enhance_enabled",
    "photo_enhance_engine",
    "photo_enhance_preset",
    "photo_enhance_recipe",
    "photo_enhance_autotune",
    "photo_enhance_strength",
    "photo_enhance_manual_exposure",
    "photo_enhance_manual_contrast",
    "photo_enhance_manual_fill_light",
    "photo_enhance_manual_gamma",
    "photo_enhance_manual_highlights",
    "photo_enhance_manual_black_point",
    "photo_enhance_manual_sharpness",
    "photo_enhance_manual_saturation",
    "photo_enhance_manual_temperature",
    "photo_enhance_manual_vibrance",
    "photo_enhance_manual_red",
    "photo_enhance_manual_green",
    "photo_enhance_manual_blue",
)
ORIENTATION_SIBLING_SHARED_PARK_KEYS = {
    "background_brightness",
    "jpg_quality",
    "harmonize_strength",
    "contact_shadow",
    "photo_enhance",
}


def _load_raw() -> dict:
    return load_raw_settings(CONFIG_PATH)


def _save_raw(raw: dict) -> None:
    save_raw_settings(CONFIG_PATH, raw)


def _root() -> Path:
    return CONFIG_PATH.resolve().parent.parent


def _legacy_cloud_key() -> str:
    return "".join(chr(code) for code in (110, 117, 118, 111, 108))


def _text_from_codes(codes: tuple[int, ...]) -> str:
    return "".join(chr(code) for code in codes)


def _cloud_section(raw: dict) -> dict:
    cloud = raw.get("cloud", {})
    if isinstance(cloud, dict):
        return cloud
    legacy = raw.get(_legacy_cloud_key(), {})
    return legacy if isinstance(legacy, dict) else {}


def _migrate_cloud_section(raw: dict) -> dict:
    legacy_key = _legacy_cloud_key()
    legacy = raw.get(legacy_key)
    if isinstance(legacy, dict) and not isinstance(raw.get("cloud"), dict):
        raw["cloud"] = legacy
    if legacy_key in raw:
        raw.pop(legacy_key, None)
    cloud = raw.setdefault("cloud", {})
    if isinstance(cloud, dict):
        _merge_legacy_cloud_defaults(cloud)
        legacy_identity_keys = (
            (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 117, 115, 101, 114, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_user_pool"),
            (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 99, 108, 105, 101, 110, 116, 95, 105, 100)), "identity_client"),
            (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 105, 100, 101, 110, 116, 105, 116, 121, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_pool"),
        )
        for old_key, new_key in legacy_identity_keys:
            if cloud.get(old_key) and not cloud.get(new_key):
                cloud[new_key] = cloud[old_key]
            cloud.pop(old_key, None)
        legacy_download = f"{legacy_key}_downloads"
        if str(cloud.get("download_dir") or "") == legacy_download:
            cloud["download_dir"] = "cloud_downloads"
        legacy_processed = f"processed/{legacy_key} processed"
        if str(cloud.get("processed_dir") or "").replace("\\", "/") == legacy_processed:
            cloud["processed_dir"] = "processed/cloud processed"
    return raw


def _merge_legacy_cloud_defaults(cloud: dict) -> None:
    root = _root()
    wanted = {
        "upload_endpoint",
        "watermark_endpoint",
        "qr_endpoint",
        "api_endpoint",
        "aws_region",
        "identity_user_pool",
        "identity_client",
        "identity_pool",
        "photo_events_table",
        "photo_bucket",
    }
    if all(str(cloud.get(key) or "").strip() for key in wanted):
        return
    defaults: dict[str, str] = {}
    for src_dir in _legacy_source_dirs(root):
        defaults.update(_legacy_dataclass_defaults(src_dir / "config.py"))
        defaults.update(_legacy_module_defaults(src_dir / f"{_legacy_cloud_key()}_module.py"))
        for key, value in defaults.items():
            if key in wanted and value and not str(cloud.get(key) or "").strip():
                cloud[key] = value
        if all(str(cloud.get(key) or "").strip() for key in wanted):
            return


def _legacy_source_dirs(root: Path) -> list[Path]:
    candidates: list[Path] = []
    env_value = os.environ.get("MASKERADE_LEGACY_SRC", "")
    if env_value:
        candidates.append(Path(env_value))
    candidates.append(root / "src")
    try:
        backups = sorted(
            (path for path in root.iterdir() if path.is_dir() and path.name.startswith("_backup")),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        backups = []
    candidates.extend(path / "src" for path in backups)

    unique: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            resolved = candidate
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(candidate)
    return unique


def _legacy_dataclass_defaults(path: Path) -> dict[str, str]:
    names = {"upload_endpoint", "watermark_endpoint", "qr_endpoint", "api_endpoint"}
    defaults: dict[str, str] = {}
    tree = _parse_python_source(path)
    if tree is None:
        return defaults
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        for item in node.body:
            name = ""
            value_node = None
            if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                name = item.target.id
                value_node = item.value
            elif isinstance(item, ast.Assign) and item.targets and isinstance(item.targets[0], ast.Name):
                name = item.targets[0].id
                value_node = item.value
            if name in names and value_node is not None:
                value = _literal_string(value_node)
                if value:
                    defaults[name] = value
    return defaults


def _legacy_module_defaults(path: Path) -> dict[str, str]:
    old_to_new = {
        _text_from_codes((65, 87, 83, 95, 82, 69, 71, 73, 79, 78)): "aws_region",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 85, 83, 69, 82, 95, 80, 79, 79, 76, 95, 73, 68)): "identity_user_pool",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 67, 76, 73, 69, 78, 84, 95, 73, 68)): "identity_client",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 73, 68, 69, 78, 84, 73, 84, 89, 95, 80, 79, 79, 76, 95, 73, 68)): "identity_pool",
        _text_from_codes((80, 72, 79, 84, 79, 95, 69, 86, 69, 78, 84, 83, 95, 84, 65, 66, 76, 69)): "photo_events_table",
        _text_from_codes((80, 72, 79, 84, 79, 95, 66, 85, 67, 75, 69, 84)): "photo_bucket",
    }
    defaults: dict[str, str] = {}
    tree = _parse_python_source(path)
    if tree is None:
        return defaults
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        value = _literal_string(node.value)
        if not value:
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in old_to_new:
                defaults[old_to_new[target.id]] = value
    return defaults


def _parse_python_source(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return None


def _literal_string(node: ast.AST | None) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value.strip()
    return ""


def create_config_snapshot(reason: str) -> int:
    raw = _load_raw()
    safe_reason = re.sub(r"[^A-Za-z0-9._-]+", "_", (reason or "batch").strip()).strip("._-")
    if not safe_reason:
        safe_reason = "batch"
    config_dir = _root() / "config"
    name = (
        f"settings_snapshot_{safe_reason}_"
        f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')[:-3]}_"
        f"{uuid.uuid4().hex[:8]}.json"
    )
    path = config_dir / name
    save_raw_settings(path, raw, force_secure=True)
    print(str(path.resolve()))
    return 0


def secure_migrate() -> int:
    config_path = CONFIG_PATH if CONFIG_PATH.is_absolute() else Path(__file__).resolve().parents[1] / CONFIG_PATH
    ensure_settings_storage(config_path)
    raw = load_raw_settings(config_path)
    raw = _migrate_cloud_section(raw)
    secure_path = save_raw_settings(config_path, raw)
    settings = load_settings(config_path)
    root = config_path.resolve().parent.parent
    try:
        secure_config = str(secure_path.resolve().relative_to(root)).replace("\\", "/")
    except Exception:
        secure_config = str(secure_path)
    _print("secure_config", secure_config)
    _print("settings_json_present", str(config_path.exists()).lower())
    _print("cloud_auth_password_set", str(bool(settings.cloud.auth_password)).lower())
    _print("profile_cache_present", str(secure_settings_path(config_path).exists()).lower())
    return 0


def _cleanup_desktop_preview_files(remove_subject_files: bool = False) -> None:
    root = _root()
    preview_files = tuple(LEGACY_ROOT_PREVIEW_FILES) + (
        PREVIEW_FILE,
        PREVIEW_SCENE_FILE,
        PHOTO_ENHANCE_PREVIEW_FILE,
    )
    for relative_path in preview_files:
        path = root / relative_path
        try:
            if path.is_file():
                path.unlink()
        except OSError:
            pass
    preview_dir = root / PREVIEW_DIR
    try:
        subject_files = tuple(preview_dir.glob(f"{PREVIEW_SUBJECT_PREFIX}*.png")) + tuple(
            preview_dir.glob(f"{PREVIEW_SHADOW_PREFIX}*.png")
        )
    except OSError:
        subject_files = ()
    for path in subject_files:
        try:
            stale = (time.time() - path.stat().st_mtime) >= 300
            if path.is_file() and (remove_subject_files or stale):
                path.unlink()
        except OSError:
            pass


def _rel(path: str | Path | None) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.is_absolute():
        p = _root() / p
    try:
        return str(p.resolve().relative_to(_root().resolve())).replace("\\", "/")
    except Exception:
        return str(p)


def _latest_existing_image(paths: list[Path]) -> Path | None:
    latest_path: Path | None = None
    latest_mtime = float("-inf")
    for path in paths:
        try:
            modified = path.stat().st_mtime
        except OSError:
            # Cloud or the processed-file mover may relocate it during this scan.
            continue
        if modified > latest_mtime:
            latest_path = path
            latest_mtime = modified
    return latest_path


def _abs(path: str | Path | None) -> Path | None:
    if not path:
        return None
    p = Path(path)
    if not p.is_absolute():
        p = _root() / p
    return p


def _image_size(path: str | Path | None) -> tuple[int, int] | None:
    abs_path = _abs(path)
    if not abs_path or not abs_path.exists() or not abs_path.is_file():
        return None
    try:
        with Image.open(abs_path) as image:
            return ImageOps.exif_transpose(image).size
    except Exception:
        return None


def _overlay_matches_background(park: dict, overlay_value: str | None = None) -> bool:
    overlay_path = overlay_value if overlay_value is not None else park.get("overlay")
    background_size = _image_size(park.get("background"))
    overlay_size = _image_size(overlay_path)
    if not background_size or not overlay_size:
        return False
    if background_size == overlay_size:
        return True
    bg_w, bg_h = background_size
    ov_w, ov_h = overlay_size
    if bg_w <= 0 or bg_h <= 0 or ov_w <= 0 or ov_h <= 0:
        return False
    return abs((bg_w / bg_h) - (ov_w / ov_h)) < 0.01


def _print(key: str, value: object) -> None:
    print(f"{key}\t{'' if value is None else value}")


def _clamp_int(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(max_value, value))


def _preset_dir() -> Path:
    path = _root() / PRESETS_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_preset_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ._ -]+", "_", name.strip())
    cleaned = cleaned.strip(" ._-")
    if not cleaned:
        raise SystemExit("Preset name is empty")
    return cleaned[:80]


def _preset_path(name: str) -> Path:
    return _preset_dir() / f"{_safe_preset_name(name)}.json"


def _preset_names() -> list[str]:
    directory = _preset_dir()
    return [path.stem for path in sorted(directory.glob("*.json"), key=lambda item: item.name.lower())]


def _preset_or_family_exists(name: str) -> bool:
    safe_name = _safe_preset_name(name)
    if _preset_path(safe_name).exists():
        return True
    folded = safe_name.casefold()
    if folded.endswith("_h") or folded.endswith("_v"):
        return False
    return _preset_path(f"{safe_name}_h").exists() or _preset_path(f"{safe_name}_v").exists()


def _active_preset_family_name(name: str) -> str:
    safe_name = _safe_preset_name(name)
    folded = safe_name.casefold()
    if not (folded.endswith("_h") or folded.endswith("_v")):
        return safe_name
    family = safe_name[:-2]
    if _preset_path(f"{family}_h").exists() and _preset_path(f"{family}_v").exists():
        return family
    return safe_name


def _classic_photo_presets_path() -> Path:
    path = _root() / CLASSIC_PHOTO_PRESETS_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load_classic_photo_presets() -> dict:
    path = _classic_photo_presets_path()
    if not path.exists():
        return {"version": 1, "presets": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"version": 1, "presets": []}
    if not isinstance(data, dict):
        return {"version": 1, "presets": []}
    presets = data.get("presets", [])
    if not isinstance(presets, list):
        presets = []
    cleaned = []
    for item in presets:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        values = item.get("values", {})
        if not name or not isinstance(values, dict):
            continue
        cleaned.append({"name": name, "values": values})
    return {"version": 1, "presets": cleaned}


def _save_classic_photo_presets(data: dict) -> None:
    path = _classic_photo_presets_path()
    payload = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    temp_path = path.with_suffix(".tmp.json")
    try:
        temp_path.write_text(payload, encoding="utf-8")
        temp_path.replace(path)
    except PermissionError:
        path.write_text(payload, encoding="utf-8")


def classic_photo_preset_list() -> int:
    data = _load_classic_photo_presets()
    for item in sorted(data.get("presets", []), key=lambda preset: str(preset.get("name", "")).casefold()):
        name = str(item.get("name") or "").strip()
        if name:
            print(name)
    return 0


def classic_photo_preset_get(name: str) -> int:
    wanted = str(name or "").strip().casefold()
    data = _load_classic_photo_presets()
    for item in data.get("presets", []):
        if str(item.get("name") or "").strip().casefold() != wanted:
            continue
        values = item.get("values", {})
        for ui_key in CLASSIC_PHOTO_FIELDS:
            print(f"{ui_key}={int(float(values.get(ui_key, 0) or 0))}")
        return 0
    raise SystemExit(f"Classic photo preset not found: {name}")


def classic_photo_preset_save(args: list[str]) -> int:
    if len(args) < 1:
        raise SystemExit("classic_photo_preset_save expects NAME [KEY VALUE ...]")
    name = _safe_preset_name(args[0])
    values = args[1:]
    if len(values) % 2 != 0:
        raise SystemExit("classic_photo_preset_save expects NAME [KEY VALUE ...]")
    payload = {key: 0 for key in CLASSIC_PHOTO_FIELDS}
    for index in range(0, len(values), 2):
        key = values[index]
        if key not in CLASSIC_PHOTO_FIELDS:
            continue
        payload[key] = int(float(values[index + 1]))
    data = _load_classic_photo_presets()
    presets = data.setdefault("presets", [])
    updated = False
    for item in presets:
        if str(item.get("name") or "").strip().casefold() == name.casefold():
            item["name"] = name
            item["updated_at"] = datetime.now().isoformat(timespec="seconds")
            item["values"] = payload
            updated = True
            break
    if not updated:
        presets.append(
            {
                "name": name,
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "values": payload,
            }
        )
    _save_classic_photo_presets(data)
    print(name)
    return 0


def classic_photo_preset_delete(name: str) -> int:
    wanted = str(name or "").strip().casefold()
    if not wanted:
        raise SystemExit("classic_photo_preset_delete expects NAME")
    data = _load_classic_photo_presets()
    presets = data.get("presets", [])
    remaining = [
        item
        for item in presets
        if str(item.get("name") or "").strip().casefold() != wanted
    ]
    if len(remaining) == len(presets):
        raise SystemExit(f"Classic photo preset not found: {name}")
    data["presets"] = remaining
    _save_classic_photo_presets(data)
    print(str(name or "").strip())
    return 0


def _photo_retouch_presets_path() -> Path:
    path = _root() / PHOTO_RETOUCH_PRESETS_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _load_photo_retouch_presets() -> dict:
    path = _photo_retouch_presets_path()
    if not path.exists():
        return {"version": 2, "presets": [], "quick_presets": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"version": 2, "presets": [], "quick_presets": {}}
    if not isinstance(data, dict) or not isinstance(data.get("presets", []), list):
        return {"version": 2, "presets": [], "quick_presets": {}}
    cleaned = []
    for item in data.get("presets", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "").strip()
        values = item.get("values", {})
        if name and isinstance(values, dict):
            cleaned.append({"name": name, "values": values})
    quick_presets = data.get("quick_presets", {})
    if not isinstance(quick_presets, dict):
        quick_presets = {}
    cleaned_quick = {}
    for recipe, item in quick_presets.items():
        recipe_id = str(recipe or "").strip().casefold()
        if recipe_id not in QUICK_PHOTO_RETOUCH_IDS or not isinstance(item, dict):
            continue
        values = item.get("values", {})
        if isinstance(values, dict):
            cleaned_quick[recipe_id] = {
                "values": values,
                "updated_at": item.get("updated_at"),
            }
    return {"version": 2, "presets": cleaned, "quick_presets": cleaned_quick}


def _save_photo_retouch_presets(data: dict) -> None:
    path = _photo_retouch_presets_path()
    payload = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    temp_path = path.with_suffix(".tmp.json")
    try:
        temp_path.write_text(payload, encoding="utf-8")
        temp_path.replace(path)
    except PermissionError:
        path.write_text(payload, encoding="utf-8")


def _photo_retouch_ui_values(photo_enhance: dict, name: str) -> dict:
    values: dict[str, object] = {
        "photo_enhance_enabled": "true" if bool(photo_enhance.get("enabled", True)) else "false",
        "photo_enhance_engine": str(photo_enhance.get("engine") or "qenhancer_cuevas"),
        "photo_enhance_preset": str(photo_enhance.get("preset") or "C_Channel 1.qes"),
        "photo_enhance_recipe": f"user:{name}",
        "photo_enhance_autotune": "false",
        "photo_enhance_strength": int(round(float(photo_enhance.get("strength", 1.0)) * 100.0)),
    }
    for key in PHOTO_RETOUCH_UI_KEYS:
        if not key.startswith("photo_enhance_manual_"):
            continue
        field_name = key[len("photo_enhance_"):]
        values[key] = int(float(photo_enhance.get(field_name, 0) or 0))
    return values


def photo_retouch_preset_list() -> int:
    data = _load_photo_retouch_presets()
    for item in sorted(data.get("presets", []), key=lambda preset: str(preset.get("name", "")).casefold()):
        name = str(item.get("name") or "").strip()
        if name:
            print(name)
    return 0


def photo_retouch_preset_get(name: str) -> int:
    wanted = str(name or "").strip().casefold()
    for item in _load_photo_retouch_presets().get("presets", []):
        if str(item.get("name") or "").strip().casefold() != wanted:
            continue
        values = item.get("values", {})
        for key in PHOTO_RETOUCH_UI_KEYS:
            if key in values:
                print(f"{key}={values[key]}")
        return 0
    raise SystemExit(f"Photo retouch preset not found: {name}")


def photo_retouch_preset_save(args: list[str]) -> int:
    if len(args) < 1 or len(args[1:]) % 2 != 0:
        raise SystemExit("photo_retouch_preset_save expects NAME [KEY VALUE ...]")
    name = _safe_preset_name(args[0])
    working = deepcopy(_load_raw())
    values = args[1:]
    for index in range(0, len(values), 2):
        key = values[index]
        if key not in PHOTO_RETOUCH_UI_KEYS:
            raise SystemExit(f"Unknown photo retouch key: {key}")
        set_value(key, values[index + 1], raw=working, save=False)
    photo_enhance = deepcopy(
        working.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).get("photo_enhance", {})
    )
    payload = _photo_retouch_ui_values(photo_enhance, name)
    data = _load_photo_retouch_presets()
    presets = data.setdefault("presets", [])
    for item in presets:
        if str(item.get("name") or "").strip().casefold() == name.casefold():
            item["name"] = name
            item["updated_at"] = datetime.now().isoformat(timespec="seconds")
            item["values"] = payload
            break
    else:
        presets.append(
            {
                "name": name,
                "created_at": datetime.now().isoformat(timespec="seconds"),
                "values": payload,
            }
        )
    _save_photo_retouch_presets(data)
    print(name)
    return 0


def photo_retouch_preset_delete(name: str) -> int:
    wanted = str(name or "").strip().casefold()
    if not wanted:
        raise SystemExit("photo_retouch_preset_delete expects NAME")
    data = _load_photo_retouch_presets()
    presets = data.get("presets", [])
    remaining = [
        item
        for item in presets
        if str(item.get("name") or "").strip().casefold() != wanted
    ]
    if len(remaining) == len(presets):
        raise SystemExit(f"Photo retouch preset not found: {name}")
    data["presets"] = remaining
    _save_photo_retouch_presets(data)
    print(str(name or "").strip())
    return 0


def quick_photo_retouch_preset_list() -> int:
    quick_presets = _load_photo_retouch_presets().get("quick_presets", {})
    for recipe in sorted(QUICK_PHOTO_RETOUCH_IDS):
        item = quick_presets.get(recipe, {})
        values = item.get("values", {}) if isinstance(item, dict) else {}
        if not isinstance(values, dict):
            continue
        for key in PHOTO_RETOUCH_UI_KEYS:
            if key in values:
                print(f"{recipe}\t{key}={values[key]}")
    return 0


def quick_photo_retouch_preset_save(args: list[str]) -> int:
    if len(args) < 1 or len(args[1:]) % 2 != 0:
        raise SystemExit("quick_photo_retouch_preset_save expects RECIPE [KEY VALUE ...]")
    recipe = str(args[0] or "").strip().casefold()
    if recipe not in QUICK_PHOTO_RETOUCH_IDS:
        raise SystemExit(f"Unknown quick photo retouch preset: {recipe}")

    working = deepcopy(_load_raw())
    values = args[1:]
    for index in range(0, len(values), 2):
        key = values[index]
        if key not in PHOTO_RETOUCH_UI_KEYS:
            raise SystemExit(f"Unknown photo retouch key: {key}")
        set_value(key, values[index + 1], raw=working, save=False)

    photo_enhance = deepcopy(
        working.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).get("photo_enhance", {})
    )
    payload = _photo_retouch_ui_values(photo_enhance, recipe)
    payload["photo_enhance_recipe"] = recipe
    data = _load_photo_retouch_presets()
    data.setdefault("quick_presets", {})[recipe] = {
        "updated_at": datetime.now().isoformat(timespec="seconds"),
        "values": payload,
    }
    data["version"] = 2
    _save_photo_retouch_presets(data)
    print(recipe)
    return 0


def _folder_preset_rules(raw: dict) -> list[dict]:
    rules = raw.get("folder_presets", raw.get("folder_preset_rules", []))
    if isinstance(rules, dict):
        rules = [
            {"pattern": pattern, "preset": preset, "enabled": True}
            for pattern, preset in rules.items()
        ]
    if not isinstance(rules, list):
        return []

    cleaned = []
    for item in rules:
        if not isinstance(item, dict):
            continue
        pattern = str(item.get("pattern") or item.get("folder") or item.get("prefix") or "").strip()
        preset = str(item.get("preset") or "").strip()
        if not pattern or not preset:
            continue
        cleaned.append(
            {
                "pattern": pattern,
                "preset": preset,
                "enabled": bool(item.get("enabled", True)),
                "photo_enhance": (
                    deepcopy(item.get("photo_enhance"))
                    if isinstance(item.get("photo_enhance"), dict)
                    else None
                ),
            }
        )
    return cleaned


def _copy_known(source: dict, keys: list[str]) -> dict:
    return {key: source[key] for key in keys if key in source}


def _current_preset_payload(raw: dict, name: str) -> dict:
    park = raw.get("parks", {}).get(PROFILE_NAME, {})
    payload = {
        "version": 1,
        "name": name,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "desktop": _copy_known(raw.get("desktop", {}), ["mask_protection", "mask_antighost", "person_zoom", "person_vertical"]),
        "park": _copy_known(
            park,
            [
                "background",
                "background_brightness",
                "overlay",
                "logo",
                "overlay_settings",
                "logo_settings",
                "text_layer",
                "person",
                "jpg_quality",
                "harmonize_strength",
                "contact_shadow",
                "photo_enhance",
            ],
        ),
    }
    _preserve_orientation_specific_background(name, payload)
    return payload


def _preset_orientation_suffix(name: str) -> str | None:
    safe_name = _safe_preset_name(name)
    lowered = safe_name.casefold()
    if lowered.endswith("_h"):
        return "h"
    if lowered.endswith("_v"):
        return "v"
    return None


def _background_orientation(value: object) -> str | None:
    if value is None or str(value).strip() == "":
        return None
    path = Path(str(value))
    if not path.is_absolute():
        path = _root() / path
    try:
        with Image.open(path) as image:
            image = ImageOps.exif_transpose(image)
            if image.width > image.height:
                return "h"
            if image.height > image.width:
                return "v"
    except Exception:
        return None
    return None


def _preserve_orientation_specific_background(name: str, payload: dict) -> None:
    target_suffix = _preset_orientation_suffix(name)
    if target_suffix is None:
        return

    park = payload.get("park", {})
    if not isinstance(park, dict):
        return
    background = park.get("background")
    if _background_orientation(background) in {None, target_suffix}:
        return

    preset_path = _preset_path(name)
    if not preset_path.exists():
        return
    try:
        existing_payload = json.loads(preset_path.read_text(encoding="utf-8-sig"))
    except Exception:
        return
    existing_park = existing_payload.get("park", {}) if isinstance(existing_payload, dict) else {}
    if not isinstance(existing_park, dict):
        return
    existing_background = existing_park.get("background")
    if _background_orientation(existing_background) == target_suffix:
        park["background"] = existing_background


def _orientation_sibling_name(name: str) -> str | None:
    safe_name = _safe_preset_name(name)
    lowered = safe_name.casefold()
    if lowered.endswith("_h"):
        return f"{safe_name[:-2]}_v"
    if lowered.endswith("_v"):
        return f"{safe_name[:-2]}_h"
    return None


def _sync_orientation_sibling_preset(name: str, payload: dict) -> None:
    sibling_name = _orientation_sibling_name(name)
    if not sibling_name:
        return

    sibling_path = _preset_path(sibling_name)
    if not sibling_path.exists():
        return

    sibling_payload = json.loads(sibling_path.read_text(encoding="utf-8-sig"))
    if not isinstance(sibling_payload, dict):
        return

    source_park = payload.get("park", {})
    sibling_park = sibling_payload.setdefault("park", {})
    if isinstance(source_park, dict) and isinstance(sibling_park, dict):
        for key in ORIENTATION_SIBLING_SHARED_PARK_KEYS:
            if key in source_park:
                sibling_park[key] = deepcopy(source_park[key])

    # El motor de recorte pertenece al perfil global, nunca al montaje.
    # Al guardar una familia tambien eliminamos el bloque heredado del hermano.
    sibling_payload.pop("background_removal", None)

    source_desktop = payload.get("desktop", {})
    sibling_desktop = sibling_payload.setdefault("desktop", {})
    if isinstance(source_desktop, dict) and isinstance(sibling_desktop, dict):
        for key in ("mask_protection", "mask_antighost"):
            if key in source_desktop:
                sibling_desktop[key] = deepcopy(source_desktop[key])

    sibling_payload["version"] = payload.get("version", sibling_payload.get("version", 1))
    sibling_payload["created_at"] = payload.get("created_at", datetime.now().isoformat(timespec="seconds"))
    sibling_payload["name"] = _safe_preset_name(str(sibling_payload.get("name") or sibling_name))
    sibling_path.write_text(json.dumps(sibling_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def save_preset(name: str, emit_path: bool = True) -> int:
    raw = _load_raw()
    safe_name = _safe_preset_name(name)
    payload = _current_preset_payload(raw, safe_name)
    path = _preset_path(safe_name)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _sync_orientation_sibling_preset(safe_name, payload)
    raw["active_preset"] = _active_preset_family_name(safe_name)
    raw["manual_composition_override"] = False
    _save_raw(raw)
    if emit_path:
        print(path.resolve())
    return 0


def apply_preset(name: str, emit_path: bool = True) -> int:
    path = _preset_path(name)
    if not path.exists():
        raise SystemExit(f"Preset not found: {name}")
    preset = json.loads(path.read_text(encoding="utf-8-sig"))
    raw = _load_raw()
    raw.setdefault("desktop", {}).update(preset.get("desktop", {}))
    raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).update(preset.get("park", {}))
    raw["active_preset"] = _active_preset_family_name(name)
    raw["manual_composition_override"] = False
    _save_raw(raw)
    if emit_path:
        print(path.resolve())
    return 0


def delete_preset(name: str, emit_path: bool = True) -> int:
    path = _preset_path(name)
    if path.exists():
        path.unlink()
    raw = _load_raw()
    if str(raw.get("active_preset") or "").casefold() == _safe_preset_name(name).casefold():
        raw.pop("active_preset", None)
        _save_raw(raw)
    return 0


def _preset_family_name(name: str) -> str:
    safe_name = _safe_preset_name(name)
    folded = safe_name.casefold()
    return safe_name[:-2] if folded.endswith("_h") or folded.endswith("_v") else safe_name


def delete_preset_family(name: str, emit_names: bool = True) -> int:
    family = _preset_family_name(name)
    deleted: list[str] = []
    for candidate in (family, f"{family}_h", f"{family}_v"):
        path = _preset_path(candidate)
        if path.exists():
            path.unlink()
            deleted.append(candidate)

    raw = _load_raw()
    active = str(raw.get("active_preset") or "").strip()
    if active and _preset_family_name(active).casefold() == family.casefold():
        raw.pop("active_preset", None)

    raw["folder_presets"] = [
        rule
        for rule in _folder_preset_rules(raw)
        if _preset_family_name(str(rule.get("preset") or "")).casefold() != family.casefold()
    ]
    raw.pop("folder_preset_rules", None)
    _save_raw(raw)
    if emit_names:
        for candidate in deleted:
            print(candidate)
    return 0


def save_folder_rule(
    pattern: str,
    preset: str,
    enabled: str = "true",
    photo_enhance_args: list[str] | None = None,
) -> int:
    pattern = str(pattern or "").strip()
    preset = str(preset or "").strip()
    if not pattern:
        raise SystemExit("Folder pattern is empty")
    if not preset:
        raise SystemExit("Preset name is empty")
    preset = _safe_preset_name(preset)
    if not _preset_or_family_exists(preset):
        raise SystemExit(f"Preset not found: {preset}")

    raw = _load_raw()
    rules = _folder_preset_rules(raw)
    enabled_value = str(enabled or "true").strip().lower() not in {"0", "false", "no", "off"}
    assigned_photo_enhance = None
    values = list(photo_enhance_args or [])
    if values:
        if len(values) % 2 != 0:
            raise SystemExit("folder_rule_save expects photo enhancement KEY VALUE pairs")
        working = deepcopy(raw)
        for index in range(0, len(values), 2):
            if not values[index].startswith("photo_enhance_"):
                raise SystemExit(f"Only photo enhancement keys can be assigned: {values[index]}")
            set_value(values[index], values[index + 1], raw=working, save=False)
        assigned_photo_enhance = deepcopy(
            working.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).get("photo_enhance", {})
        )

    next_rule = {"pattern": pattern, "preset": preset, "enabled": enabled_value}

    replaced = False
    for index, rule in enumerate(rules):
        if str(rule.get("pattern", "")).casefold() == pattern.casefold():
            if assigned_photo_enhance is None and isinstance(rule.get("photo_enhance"), dict):
                assigned_photo_enhance = deepcopy(rule["photo_enhance"])
            rules[index] = next_rule
            replaced = True
            break
    if not replaced:
        rules.append(next_rule)
    if assigned_photo_enhance is not None:
        next_rule["photo_enhance"] = assigned_photo_enhance

    raw["folder_presets"] = rules
    raw.pop("folder_preset_rules", None)
    _save_raw(raw)
    print(pattern)
    return 0


def delete_folder_rule(pattern: str) -> int:
    pattern = str(pattern or "").strip()
    if not pattern:
        raise SystemExit("Folder pattern is empty")
    raw = _load_raw()
    rules = [
        rule for rule in _folder_preset_rules(raw)
        if str(rule.get("pattern", "")).casefold() != pattern.casefold()
    ]
    raw["folder_presets"] = rules
    raw.pop("folder_preset_rules", None)
    _save_raw(raw)
    print(pattern)
    return 0


def _apply_mask_protection(raw: dict, value: int) -> None:
    value = _clamp_int(value, -100, 100)
    desktop = raw.setdefault("desktop", {})
    desktop["mask_protection"] = value
    desktop["mask_antighost"] = value


def _apply_mask_antighost(raw: dict, value: int) -> None:
    value = _clamp_int(value, -100, 100)
    raw.setdefault("desktop", {})["mask_antighost"] = value


def _apply_person_zoom(raw: dict, value: int) -> None:
    value = _clamp_int(value, 50, 160)
    raw.setdefault("desktop", {})["person_zoom"] = value
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    person = park.setdefault("person", {})
    person["scale"] = round(value / 100.0, 3)


def _apply_person_vertical(raw: dict, value: int) -> None:
    value = _clamp_int(value, -25, 25)
    raw.setdefault("desktop", {})["person_vertical"] = value
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    person = park.setdefault("person", {})
    person["anchor"] = "original"
    person["y"] = value


def state() -> int:
    settings = load_settings(CONFIG_PATH)
    maintain_logs(settings.logs.directory, settings.logs.jsonl_path)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    raw = _load_raw()
    raw_park = raw.get("parks", {}).get(PROFILE_NAME, {})
    desktop = raw.get("desktop", {})
    background_raw = raw_park.get("background") or ""
    overlay_raw = raw_park.get("overlay") or ""
    logo_raw = raw_park.get("logo") or ""

    input_images = list_images(park.input_dir)
    output_images = list_images(park.output_dir)
    processed_images = list_images(settings.processed_dir)
    latest_output = _latest_existing_image(output_images)
    latest_processed = _latest_existing_image(processed_images)
    first_input = _first_preview_input(input_images, park)

    _print("version", __version__)
    _print("root", settings.root_dir)
    _print("input", _rel(park.input_dir))
    _print("input_abs", park.input_dir)
    _print("output", _rel(park.output_dir))
    _print("output_abs", park.output_dir)
    _print("output_size", getattr(park, "output_size", "input"))
    _print("processed", _rel(settings.processed_dir))
    _print("processed_abs", settings.processed_dir)
    _print("failed", _rel(settings.failed_dir))
    _print("failed_abs", settings.failed_dir)
    _print("background", background_raw)
    _print("background_abs", _abs(background_raw) if background_raw else "")
    _print("background_brightness", getattr(park, "background_brightness", 1.0))
    _print("overlay", overlay_raw)
    _print("overlay_abs", _abs(overlay_raw) if overlay_raw else "")
    _print("logo", logo_raw)
    _print("logo_abs", _abs(logo_raw) if logo_raw else "")
    overlay_settings = raw_park.get("overlay_settings", {})
    _print("overlay_x", overlay_settings.get("x", 0))
    _print("overlay_y", overlay_settings.get("y", 0))
    _print("overlay_scale", overlay_settings.get("scale", 1))
    _print("overlay_mode", overlay_settings.get("mode", "original"))
    logo_settings = raw_park.get("logo_settings", {})
    _print("logo_x", logo_settings.get("x", 0))
    _print("logo_y", logo_settings.get("y", 0))
    _print("logo_scale", logo_settings.get("scale", 1))
    text_layer = raw_park.get("text_layer", {})
    _print("text_layer", text_layer.get("text", ""))
    _print("text_layer_font", text_layer.get("font", "Segoe UI"))
    _print("text_layer_color", text_layer.get("color", "#FFFFFF"))
    _print("text_layer_x", text_layer.get("x", 0))
    _print("text_layer_y", text_layer.get("y", 0))
    _print("text_layer_scale", text_layer.get("scale", 1.0))
    _print("text_layer_rotation", text_layer.get("rotation", 0))
    _print("move_processed", str(park.move_original_to_processed).lower())
    cloud = _cloud_section(raw)
    _print("cloud_enabled", str(bool(cloud.get("enabled", False))).lower())
    _print("cloud_mode", cloud.get("mode", "upload_only"))
    _print("cloud_download_dir", cloud.get("download_dir", "cloud_downloads"))
    _print("cloud_park", cloud.get("park", ""))
    _print("cloud_user_group", cloud.get("user_group", ""))
    _print("cloud_username", cloud.get("username", ""))
    _print("cloud_auth_username", cloud.get("auth_username", ""))
    _print("cloud_auth_password", "")
    _print("cloud_auth_password_set", str(bool(cloud.get("auth_password", ""))).lower())
    _print("jpg_quality", park.jpg_quality)
    _print("harmonize_strength", int(round(float(getattr(park, "harmonize_strength", 0.0)) * 100)))
    photo_enhance = getattr(park, "photo_enhance", None)
    photo_engine = str(getattr(photo_enhance, "engine", "qenhancer_cuevas") or "qenhancer_cuevas")
    _print("photo_enhance_engine", "qenhancer_cuevas" if photo_engine == "classic" else photo_engine)
    _print("photo_enhance_preset", getattr(photo_enhance, "preset", "C_Channel 1.qes"))
    _print("photo_enhance_recipe", getattr(photo_enhance, "recipe", "custom"))
    _print("photo_enhance_autotune", "false")
    _print("photo_enhance_save_logs", str(bool(getattr(photo_enhance, "save_logs", True))).lower())
    _print("photo_enhance_strength", int(round(float(getattr(photo_enhance, "strength", 0.0)) * 100)))
    _print("photo_enhance_enabled", str(bool(getattr(photo_enhance, "enabled", False))).lower())
    for field_name in (
        "brightness",
        "shadow_contrast",
        "highlight_contrast",
        "saturation",
        "red",
        "green",
        "blue",
        "auto_brightness",
        "auto_color",
        "memory_color",
        "shadows",
        "lights",
        "global_sharpen",
        "local_sharpen",
        "denoise",
        "desaturate_shadows",
        "hue_rotation",
        "manual_exposure",
        "manual_contrast",
        "manual_fill_light",
        "manual_gamma",
        "manual_highlights",
        "manual_black_point",
        "manual_sharpness",
        "manual_saturation",
        "manual_temperature",
        "manual_vibrance",
        "manual_red",
        "manual_green",
        "manual_blue",
    ):
        _print(f"photo_enhance_{field_name}", getattr(photo_enhance, field_name, 0))
    shadow_settings = getattr(park, "contact_shadow", None)
    _print("contact_shadow_strength", int(round(float(getattr(shadow_settings, "strength", 0.0)) * 100)))
    _print("mask_protection", desktop.get("mask_protection", 25))
    _print("mask_antighost", desktop.get("mask_antighost", 25))
    _print("person_zoom", desktop.get("person_zoom", int(round(float(park.person.scale) * 100))))
    _print("person_vertical", desktop.get("person_vertical", int(getattr(park.person, "y", 0) or 0)))
    removal = settings.background_removal
    if removal.birefnet_enabled:
        model_name = Path(str(removal.birefnet_model or "")).name.casefold()
        variant = "Dynamic" if model_name == "birefnet_dynamic" else "Portrait"
        if removal.birefnet_hybrid_ben2:
            engine_label = f"BiRefNet {variant} + BEN2/U2Net / {removal.birefnet_model}"
        else:
            engine_label = f"BiRefNet {variant} / {removal.birefnet_model} (BEN2 fallback)"
    else:
        engine_label = f"{removal.backend} / {removal.model}"
    _print("engine", engine_label)
    _print("in_count", len(input_images))
    _print("out_count", len(output_images))
    _print("latest_output", latest_output or "")
    _print("latest_processed", latest_processed or "")
    _print("first_input", first_input or "")
    _print("active_preset", raw.get("active_preset", ""))
    for preset_name in _preset_names():
        _print("preset", preset_name)
    for rule in _folder_preset_rules(raw):
        enabled = "1" if rule.get("enabled", True) else "0"
        photo_enhance = rule.get("photo_enhance") or {}
        recipe = str(photo_enhance.get("recipe") or "")
        _print(
            "folder_rule",
            f"{enabled}\t{rule.get('pattern', '')}\t{rule.get('preset', '')}\t{recipe}",
        )

    bg_dir = settings.root_dir / "assets" / "backgrounds"
    ov_dir = settings.root_dir / "assets" / "overlays"
    logo_dir = settings.root_dir / "assets" / "logos"
    if bg_dir.exists():
        for path in sorted(bg_dir.iterdir(), key=lambda item: natural_sort_key(item, bg_dir)):
            if path.is_file() and path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                _print("background_asset", path)
    if ov_dir.exists():
        for path in sorted(ov_dir.iterdir(), key=lambda item: natural_sort_key(item, ov_dir)):
            if path.is_file() and path.suffix.lower() == ".png":
                _print("overlay_asset", path)
    if logo_dir.exists():
        for path in sorted(logo_dir.iterdir(), key=lambda item: natural_sort_key(item, logo_dir)):
            if path.is_file() and path.suffix.lower() == ".png":
                _print("logo_asset", path)
    return 0


def _preview_size(size: tuple[int, int]) -> tuple[tuple[int, int], float]:
    longest = max(size)
    if longest <= PREVIEW_MAX_SIDE:
        return size, 1.0
    scale = PREVIEW_MAX_SIDE / longest
    return (max(1, int(size[0] * scale)), max(1, int(size[1] * scale))), scale


def _preview_size_for(size: tuple[int, int], max_side: int) -> tuple[tuple[int, int], float]:
    longest = max(size)
    if max_side <= 0:
        return size, 1.0
    if longest <= max_side:
        return size, 1.0
    scale = max_side / longest
    return (max(1, int(size[0] * scale)), max(1, int(size[1] * scale))), scale


def _background_preview_size(park, max_side: int) -> tuple[tuple[int, int], float]:
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        with Image.open(park.background_path) as background:
            return _preview_size_for(background.size, max_side)
    return (1600, 1000), 1.0


def _preset_preview_size(park, original_size: tuple[int, int], max_side: int) -> tuple[tuple[int, int], float]:
    output_size = getattr(park, "output_size", None)
    if isinstance(output_size, str):
        normalized = output_size.strip().lower()
        if normalized in {"input", "original", "source", "same_as_input"}:
            return _preview_size_for(original_size, max_side)
        if normalized in {"background", "selected_background", "fondo"}:
            if park.background_path and park.background_path.exists() and park.background_path.is_file():
                with Image.open(park.background_path) as background:
                    return _preview_size_for(background.size, max_side)
            return _preview_size_for(original_size, max_side)
    elif isinstance(output_size, tuple) and len(output_size) == 2:
        return _preview_size_for((int(output_size[0]), int(output_size[1])), max_side)

    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        with Image.open(park.background_path) as background:
            return _preview_size_for(background.size, max_side)
    return _preview_size_for(original_size, max_side)


def _preview_orientation(park) -> str:
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        try:
            with Image.open(park.background_path) as background:
                if background.height > background.width:
                    return "vertical"
                if background.width > background.height:
                    return "horizontal"
        except Exception:
            pass
    output_size = getattr(park, "output_size", None)
    if isinstance(output_size, tuple) and len(output_size) == 2:
        width, height = output_size
        if height > width:
            return "vertical"
        if width > height:
            return "horizontal"
    return ""


def _image_orientation(path: Path) -> str:
    try:
        with Image.open(path) as image:
            image = ImageOps.exif_transpose(image)
            if image.height > image.width:
                return "vertical"
            if image.width > image.height:
                return "horizontal"
    except Exception:
        pass
    return ""


def _first_preview_input(input_images: list[Path], park) -> Path | None:
    if not input_images:
        return None
    wanted = _preview_orientation(park)
    if not wanted:
        return input_images[0]
    for path in input_images:
        if _image_orientation(path) == wanted:
            return path
    return input_images[0]


def _scaled_overlay_settings(settings, scale: float):
    if scale == 1.0:
        return settings
    mode = settings.mode.lower()
    overlay_scale = settings.scale
    if mode in {"original", "source", "native"}:
        overlay_scale = settings.scale * scale
    return replace(
        settings,
        x=int(round(settings.x * scale)),
        y=int(round(settings.y * scale)),
        scale=overlay_scale,
    )


def _compose_background_overlay(park) -> Image.Image:
    overlay_image = None
    if park.overlay_path and park.overlay_path.exists():
        overlay_image = Image.open(park.overlay_path).convert("RGBA")

    background_source_size = None
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        background = Image.open(park.background_path).convert("RGB")
        background_source_size = background.size
        size, scale = _preview_size(background.size)
        background = resize_cover(background, size).convert("RGB")
        background = apply_background_brightness(background, getattr(park, "background_brightness", 1.0)).convert("RGB")
        canvas = background.convert("RGBA")
    else:
        size, scale = _preview_size(overlay_image.size if overlay_image else (1600, 1000))
        canvas = Image.new("RGBA", size, (15, 26, 32, 255))

    if overlay_image is not None:
        overlay, xy = prepare_overlay_layer(
            overlay_image,
            _scaled_overlay_settings(park.overlay_settings, scale),
            size,
            background_source_size,
        )
        alpha_composite_at(canvas, overlay, xy)
    if park.logo_path and park.logo_path.exists():
        logo, xy = prepare_overlay_layer(
            Image.open(park.logo_path).convert("RGBA"),
            _scaled_overlay_settings(park.logo_settings, scale),
            canvas.size,
            background_source_size,
        )
        alpha_composite_at(canvas, logo, xy)
    return canvas.convert("RGB")


def preset_thumbnail(name: str) -> int:
    safe_name = _safe_preset_name(name)
    preset_path = _preset_path(safe_name)
    if not preset_path.exists():
        raise SystemExit(f"Preset not found: {safe_name}")

    preset = json.loads(preset_path.read_text(encoding="utf-8-sig"))
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    processor = PhotoProcessor.__new__(PhotoProcessor)
    processor.settings = settings
    processor.park = park
    processor.logger = logging.getLogger("maskerade.preset_thumbnail")
    processor._warned_missing_preset_backgrounds = set()
    park = processor._park_with_preset(park, preset, safe_name)

    preview_dir = _root() / PREVIEW_DIR
    preview_dir.mkdir(parents=True, exist_ok=True)
    preview_path = preview_dir / f"preset_{safe_name}.jpg"
    source_paths = [preset_path, park.background_path, park.overlay_path, park.logo_path]
    latest_source = max(
        (path.stat().st_mtime for path in source_paths if path is not None and path.is_file()),
        default=0.0,
    )
    if preview_path.is_file() and preview_path.stat().st_mtime >= latest_source:
        print(preview_path.resolve())
        return 0

    final = _compose_background_overlay(park)
    final.save(preview_path, "JPEG", quality=82, optimize=False)
    print(preview_path.resolve())
    return 0


def _effective_preview_context(settings, park, input_path: Path | None = None, manual_search: bool = False):
    if input_path is None:
        return park, settings.background_removal, ""
    try:
        processor = PhotoProcessor.__new__(PhotoProcessor)
        processor.settings = settings
        processor.park = park
        processor.logger = logging.getLogger("maskerade.preview")
        processor._preset_cache = {}
        processor.force_live_context = manual_search
        processor.manual_search = manual_search
        # The regular preview state describes the automatic processing result.
        # Manual composition is handled by the desktop while editing and must
        # not hide a matching folder/file assignment in this state.
        processor.strict_preset_context = not manual_search
        context = processor._context_for_input(input_path)
        return context.park, context.background_removal, context.preset_name or ""
    except Exception:
        logging.getLogger("maskerade.preview").exception("Could not resolve preview preset for %s", input_path)
        return park, settings.background_removal, ""


def _preview_rule_match(settings, park, input_path: Path | None) -> tuple[str, str]:
    if input_path is None:
        return "", ""
    try:
        processor = PhotoProcessor.__new__(PhotoProcessor)
        processor.settings = settings
        processor.park = park
        for candidate in processor._preset_rule_candidates(input_path):
            for rule in settings.folder_preset_rules:
                if rule.enabled and processor._name_matches_rule(candidate, rule.pattern):
                    return rule.pattern, candidate
    except Exception:
        logging.getLogger("maskerade.preview").exception(
            "Could not resolve preview rule for %s",
            input_path,
        )
    return "", ""


def preview_state_for_input(path: str, manual_search: bool = False) -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_path = _abs(path)
    park, background_removal, preset_name = _effective_preview_context(
        settings,
        park,
        input_path,
        manual_search=manual_search,
    )
    rule_pattern, rule_candidate = _preview_rule_match(settings, park, input_path)
    text_layer = getattr(park, "text_layer", None)
    photo_enhance = getattr(park, "photo_enhance", None)
    shadow_settings = getattr(park, "contact_shadow", None)

    _print("first_input", input_path or "")
    _print("preview_preset", preset_name)
    _print("preview_rule", rule_pattern)
    _print("preview_rule_match", rule_candidate)
    _print("background", _rel(park.background_path) if park.background_path else "")
    _print("background_abs", park.background_path or "")
    _print("background_brightness", getattr(park, "background_brightness", 1.0))
    _print("output_size", getattr(park, "output_size", "input"))
    _print("overlay", _rel(park.overlay_path) if park.overlay_path else "")
    _print("overlay_abs", park.overlay_path or "")
    _print("logo", _rel(park.logo_path) if park.logo_path else "")
    _print("logo_abs", park.logo_path or "")
    _print("overlay_x", getattr(park.overlay_settings, "x", 0))
    _print("overlay_y", getattr(park.overlay_settings, "y", 0))
    _print("overlay_scale", getattr(park.overlay_settings, "scale", 1))
    _print("overlay_mode", getattr(park.overlay_settings, "mode", "original"))
    _print("logo_x", getattr(park.logo_settings, "x", 0))
    _print("logo_y", getattr(park.logo_settings, "y", 0))
    _print("logo_scale", getattr(park.logo_settings, "scale", 1))
    _print("text_layer", getattr(text_layer, "text", ""))
    _print("text_layer_font", getattr(text_layer, "font", "Segoe UI"))
    _print("text_layer_color", getattr(text_layer, "color", "#FFFFFF"))
    _print("text_layer_x", getattr(text_layer, "x", 0))
    _print("text_layer_y", getattr(text_layer, "y", 0))
    _print("text_layer_scale", getattr(text_layer, "scale", 1.0))
    _print("text_layer_rotation", getattr(text_layer, "rotation", 0))
    _print("mask_protection", getattr(background_removal, "mask_protection", 25))
    _print("mask_antighost", getattr(background_removal, "mask_antighost", 25))
    _print("person_zoom", int(round(float(getattr(park.person, "scale", 1.0)) * 100)))
    _print("person_vertical", int(getattr(park.person, "y", 0) or 0))
    _print("harmonize_strength", int(round(float(getattr(park, "harmonize_strength", 0.0)) * 100)))
    _print("contact_shadow_strength", int(round(float(getattr(shadow_settings, "strength", 0.0)) * 100)))
    photo_engine = str(getattr(photo_enhance, "engine", "qenhancer_cuevas") or "qenhancer_cuevas")
    _print("photo_enhance_engine", "qenhancer_cuevas" if photo_engine == "classic" else photo_engine)
    _print("photo_enhance_preset", getattr(photo_enhance, "preset", "C_Channel 1.qes"))
    _print("photo_enhance_recipe", getattr(photo_enhance, "recipe", "custom"))
    _print("photo_enhance_autotune", "false")
    _print("photo_enhance_strength", int(round(float(getattr(photo_enhance, "strength", 0.0)) * 100)))
    _print("photo_enhance_enabled", str(bool(getattr(photo_enhance, "enabled", False))).lower())
    for field_name in (
        "manual_exposure",
        "manual_contrast",
        "manual_fill_light",
        "manual_gamma",
        "manual_highlights",
        "manual_black_point",
        "manual_sharpness",
        "manual_saturation",
        "manual_temperature",
        "manual_vibrance",
        "manual_red",
        "manual_green",
        "manual_blue",
    ):
        _print(f"photo_enhance_{field_name}", getattr(photo_enhance, field_name, 0))
    return 0


def _fast_preview_subject(image: Image.Image) -> Image.Image:
    """Low-resolution cutout for UI preview only.

    The production batch still uses BEN2. This preview path favors speed and a
    translucent subject/photo layer so zoom/background/overlay changes feel
    immediate and the operator can see the background while composing.
    """
    rgba = image.convert("RGBA")
    rgba.putalpha(Image.new("L", rgba.size, 156))
    return rgba


def preview() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)

    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if not input_images:
        park, _, _ = _effective_preview_context(settings, park)
        final = _compose_background_overlay(park)
        final.save(preview_path, "JPEG", quality=86, optimize=True)
        print(preview_path.resolve())
        return 0

    first_input = _first_preview_input(input_images, park)
    park, background_removal, _ = _effective_preview_context(settings, park, first_input)

    if park.background_path is not None and (
        not park.background_path.exists() or not park.background_path.is_file()
    ):
        final = _compose_background_overlay(park)
        final.save(preview_path, "JPEG", quality=86, optimize=True)
        print(preview_path.resolve())
        return 0

    original_full = open_image(first_input)
    output_size, output_scale = _preset_preview_size(park, original_full.size, PREVIEW_MAX_SIDE)
    original_size, original_scale = _preview_size(original_full.size)
    original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
    preview_park = replace(
        park,
        output_size=output_size,
        overlay_settings=_scaled_overlay_settings(park.overlay_settings, output_scale),
        logo_settings=_scaled_overlay_settings(park.logo_settings, output_scale),
    )
    pre_enhance = _photo_enhance_before_background_removal_enabled(preview_park)
    if pre_enhance:
        original = enhance_photo(original, preview_park.photo_enhance)
    if park.background_path is None:
        final = compose_image(original, None, preview_park)
    else:
        preview_settings = replace(background_removal, max_processing_side=640)
        removal = BackgroundRemover(preview_settings).remove_background(original)
        final = compose_image(original, removal.person_rgba, preview_park, apply_harmonize=False)
    if not pre_enhance:
        final = enhance_photo(final, preview_park.photo_enhance)
    if park.background_path is not None:
        final = harmonize_composed_image(final, original, removal.person_rgba, preview_park)
    final.save(preview_path, "JPEG", quality=86, optimize=True)
    print(preview_path.resolve())
    return 0


def _photo_enhance_overrides(park, args: list[str]):
    if len(args) % 2 != 0:
        raise SystemExit("preview args expect KEY VALUE pairs")
    values: dict[str, object] = {}
    max_side = PREVIEW_FAST_MAX_SIDE
    selected_input: Path | None = None
    for index in range(0, len(args), 2):
        key = args[index]
        value = args[index + 1]
        if key == "max_side":
            requested_max_side = int(float(value))
            max_side = 0 if requested_max_side <= 0 else max(180, min(2400, requested_max_side))
        elif key == "selected_input":
            candidate = Path(str(value or "").strip())
            if candidate.exists() and candidate.is_file():
                selected_input = candidate
        elif key == "background":
            park = replace(park, background_path=_abs(value) if str(value or "").strip() else None)
        elif key == "background_brightness":
            park = replace(park, background_brightness=max(0.5, min(2.5, float(value or 1.0))))
        elif key == "overlay":
            park = replace(park, overlay_path=_abs(value) if str(value or "").strip() else None)
        elif key == "logo":
            park = replace(park, logo_path=_abs(value) if str(value or "").strip() else None)
        elif key == "overlay_x":
            park = replace(park, overlay_settings=replace(park.overlay_settings, x=int(float(value or 0)), anchor="top_left"))
        elif key == "overlay_y":
            park = replace(park, overlay_settings=replace(park.overlay_settings, y=int(float(value or 0)), anchor="top_left"))
        elif key == "overlay_scale":
            park = replace(
                park,
                overlay_settings=replace(
                    park.overlay_settings,
                    scale=max(0.1, min(3.0, float(value or 1.0))),
                    anchor="top_left",
                ),
            )
        elif key == "overlay_mode":
            mode = str(value or "original").strip().lower() or "original"
            park = replace(park, overlay_settings=replace(park.overlay_settings, mode=mode, anchor="top_left"))
        elif key == "logo_x":
            park = replace(
                park,
                logo_settings=replace(
                    park.logo_settings,
                    x=int(float(value or 0)),
                    mode="original",
                    anchor="top_left",
                ),
            )
        elif key == "logo_y":
            park = replace(
                park,
                logo_settings=replace(
                    park.logo_settings,
                    y=int(float(value or 0)),
                    mode="original",
                    anchor="top_left",
                ),
            )
        elif key == "logo_scale":
            park = replace(
                park,
                logo_settings=replace(
                    park.logo_settings,
                    scale=max(0.1, min(3.0, float(value or 1.0))),
                    mode="original",
                    anchor="top_left",
                ),
            )
        elif key == "text_layer":
            text = str(value or "")
            park = replace(park, text_layer=replace(park.text_layer, text=text, enabled=bool(text.strip())))
        elif key == "text_layer_font":
            park = replace(park, text_layer=replace(park.text_layer, font=str(value or "Segoe UI")))
        elif key == "text_layer_color":
            park = replace(park, text_layer=replace(park.text_layer, color=str(value or "#FFFFFF")))
        elif key == "text_layer_x":
            park = replace(park, text_layer=replace(park.text_layer, x=int(float(value or 0))))
        elif key == "text_layer_y":
            park = replace(park, text_layer=replace(park.text_layer, y=int(float(value or 0))))
        elif key == "text_layer_scale":
            park = replace(park, text_layer=replace(park.text_layer, scale=max(0.3, min(3.0, float(value or 1.0)))))
        elif key == "text_layer_rotation":
            park = replace(park, text_layer=replace(park.text_layer, rotation=max(-180.0, min(180.0, float(value or 0.0)))))
        elif key == "person_zoom":
            park = replace(park, person=replace(park.person, scale=max(0.5, min(1.6, float(value or 100) / 100.0))))
        elif key == "person_vertical":
            park = replace(park, person=replace(park.person, anchor="original", y=max(-25, min(25, int(float(value or 0))))))
        elif key == "harmonize_strength":
            park = replace(park, harmonize_strength=max(0.0, min(2.0, float(value or 0) / 100.0)))
        elif key == "contact_shadow_strength":
            strength = max(0.0, min(2.0, float(value or 0) / 100.0))
            park = replace(
                park,
                contact_shadow=replace(park.contact_shadow, enabled=strength > 0.0, strength=strength),
            )
        elif key == "photo_enhance_strength":
            strength = max(0.0, min(2.0, float(value) / 100.0))
            values["strength"] = strength
            values["enabled"] = strength > 0.0
        elif key == "photo_enhance_enabled":
            values["enabled"] = str(value or "").strip().lower() in {"1", "true", "yes", "si", "sí", "on"}
        elif key == "photo_enhance_engine":
            engine = str(value or "classic").strip().lower()
            values["engine"] = "qenhancer_cuevas" if engine in LEGACY_ENHANCER2_ENGINES else engine
        elif key == "photo_enhance_preset":
            values["preset"] = str(value or "C_Channel 1.qes").strip()
        elif key == "photo_enhance_recipe":
            recipe = str(value or "custom").strip() or "custom"
            values["recipe"] = recipe if recipe.lower().startswith("user:") else recipe.lower()
        elif key == "photo_enhance_autotune":
            values["autotune"] = False
        elif key == "photo_enhance_save_logs":
            values["save_logs"] = str(value or "").strip().lower() in {"1", "true", "yes", "si", "sí", "on"}
        elif key.startswith("photo_enhance_"):
            field_name = key[len("photo_enhance_"):]
            if hasattr(park.photo_enhance, field_name):
                values[field_name] = int(float(value))
    if values:
        park = replace(park, photo_enhance=replace(park.photo_enhance, **values))
    return park, max_side, selected_input


def _photo_enhance_before_background_removal_enabled(park) -> bool:
    photo_enhance = getattr(park, "photo_enhance", None)
    if photo_enhance is None or not bool(getattr(photo_enhance, "enabled", True)):
        return False
    engine = str(getattr(photo_enhance, "engine", "") or "").strip().lower()
    return engine == "classic" or engine in QENHANCER_CUEVAS_ENGINES


def preview_fast(args: list[str] | None = None) -> int:
    args = args or []
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    park, max_side, selected_input = _photo_enhance_overrides(park, args)
    input_images = list_images(park.input_dir)
    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if selected_input is not None or input_images:
        first_input = selected_input or _first_preview_input(input_images, park)
        park, _, _ = _effective_preview_context(settings, park, first_input)
        park, max_side, _ = _photo_enhance_overrides(park, args)
        original_full = open_image(first_input)
        output_size, output_scale = _preset_preview_size(park, original_full.size, max_side)
        original_size, original_scale = _preview_size_for(original_full.size, max_side)
        original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
        preview_park = replace(
            park,
            output_size=output_size,
            overlay_settings=_scaled_overlay_settings(park.overlay_settings, output_scale),
            logo_settings=_scaled_overlay_settings(park.logo_settings, output_scale),
        )

        pre_enhance = _photo_enhance_before_background_removal_enabled(preview_park)
        if pre_enhance:
            original = enhance_photo(original, preview_park.photo_enhance)
        subject = None if park.background_path is None else _fast_preview_subject(original)
        final = compose_image(original, subject, preview_park, apply_harmonize=False)
    else:
        park, _, _ = _effective_preview_context(settings, park)
        park, max_side, _ = _photo_enhance_overrides(park, args)
        final = _compose_background_overlay(park)
        pre_enhance = _photo_enhance_before_background_removal_enabled(park)

    if not pre_enhance:
        final = enhance_photo(final, park.photo_enhance)
    if selected_input is not None or input_images:
        final = harmonize_composed_image(final, original, subject, preview_park)
    final.save(preview_path, "JPEG", quality=74, optimize=False)
    print(preview_path.resolve())
    return 0


def _preview_remover(settings, remover_cache: dict[tuple, BackgroundRemover] | None) -> BackgroundRemover:
    if remover_cache is None:
        return BackgroundRemover(settings)
    key = (
        settings.backend,
        settings.model,
        settings.max_processing_side,
        settings.birefnet_enabled,
        settings.birefnet_model,
        settings.birefnet_device,
        settings.birefnet_input_size,
        settings.birefnet_fallback_ben2,
        settings.birefnet_hybrid_ben2,
        settings.ben2_model,
        settings.ben2_device,
        settings.ben2_refine_foreground,
    )
    remover = remover_cache.get(key)
    if remover is None:
        remover_cache.clear()
        remover = BackgroundRemover(settings)
        remover_cache[key] = remover
    else:
        remover.settings = settings
    return remover


def _preview_subject_request(args: list[str]) -> tuple[Path, int, int]:
    if len(args) % 2 != 0:
        raise ValueError("preview subject args expect KEY VALUE pairs")
    selected_input: Path | None = None
    max_side = PREVIEW_FAST_MAX_SIDE
    mask_protection = 25
    for index in range(0, len(args), 2):
        key = str(args[index])
        value = args[index + 1]
        if key == "selected_input":
            candidate = Path(str(value or "").strip())
            if candidate.exists() and candidate.is_file():
                selected_input = candidate
        elif key == "max_side":
            requested = int(float(value))
            max_side = max(180, min(960, requested))
        elif key == "mask_protection":
            mask_protection = max(-100, min(100, int(float(value))))
    if selected_input is None:
        raise FileNotFoundError("No hay foto seleccionada para el recorte de preview.")
    return selected_input, max_side, mask_protection


def _preview_subject_image(
    args: list[str],
    remover_cache: dict[tuple, BackgroundRemover],
    subject_cache: OrderedDict[tuple, Image.Image],
) -> tuple[Image.Image, bool, object]:
    selected_input, max_side, mask_protection = _preview_subject_request(args)
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    _, background_removal, _ = _effective_preview_context(settings, park, selected_input)
    preview_settings = replace(
        background_removal,
        max_processing_side=max_side,
        ben2_refine_foreground=False,
        mask_protection=mask_protection,
        mask_antighost=mask_protection,
    )
    stat = selected_input.stat()
    cache_key = (
        str(selected_input.resolve()).lower(),
        stat.st_size,
        stat.st_mtime_ns,
        max_side,
        mask_protection,
        preview_settings.backend,
        preview_settings.model,
        preview_settings.ben2_model,
        preview_settings.ben2_device,
    )
    cached = cache_key in subject_cache
    if cached:
        subject = subject_cache.pop(cache_key)
        subject_cache[cache_key] = subject
    else:
        original = open_image(selected_input)
        remover = _preview_remover(preview_settings, remover_cache)
        subject = remover.remove_background_preview(original).person_rgba
        subject_cache[cache_key] = subject
        while len(subject_cache) > 8:
            _, expired = subject_cache.popitem(last=False)
            expired.close()

    return subject, cached, park


def _render_preview_subject(
    args: list[str],
    remover_cache: dict[tuple, BackgroundRemover],
    subject_cache: OrderedDict[tuple, Image.Image],
) -> tuple[Path, bool]:
    subject, cached, _ = _preview_subject_image(args, remover_cache, subject_cache)

    preview_dir = _root() / PREVIEW_DIR
    preview_dir.mkdir(parents=True, exist_ok=True)
    preview_path = preview_dir / f"{PREVIEW_SUBJECT_PREFIX}{uuid.uuid4().hex}.png"
    subject.save(preview_path, "PNG", optimize=False)
    return preview_path, cached


def _contact_shadow_preview_layer(
    subject: Image.Image,
    shadow_settings,
    canvas_size: tuple[int, int],
    subject_box: tuple[int, int, int, int],
) -> Image.Image:
    canvas_width, canvas_height = canvas_size
    subject_x, subject_y, subject_width, subject_height = subject_box
    subject_canvas = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    resized_subject = subject.resize((subject_width, subject_height), LANCZOS)
    try:
        alpha_composite_at(subject_canvas, resized_subject, (subject_x, subject_y))
    finally:
        resized_subject.close()

    shadow_layer = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    try:
        _apply_contact_shadow(shadow_layer, subject_canvas, shadow_settings)
    finally:
        subject_canvas.close()
    return shadow_layer


def _render_preview_shadow(
    args: list[str],
    remover_cache: dict[tuple, BackgroundRemover],
    subject_cache: OrderedDict[tuple, Image.Image],
) -> tuple[Path, bool]:
    if len(args) % 2 != 0:
        raise ValueError("preview shadow args expect KEY VALUE pairs")
    values = {str(args[index]): str(args[index + 1]) for index in range(0, len(args), 2)}
    subject, cached, park = _preview_subject_image(args, remover_cache, subject_cache)
    canvas_size = (
        max(32, min(2400, int(float(values.get("canvas_width", "32"))))),
        max(32, min(2400, int(float(values.get("canvas_height", "32"))))),
    )
    subject_box = (
        int(float(values.get("subject_x", "0"))),
        int(float(values.get("subject_y", "0"))),
        max(1, min(4000, int(float(values.get("subject_width", "1"))))),
        max(1, min(4000, int(float(values.get("subject_height", "1"))))),
    )
    strength = max(0, min(200, int(float(values.get("strength", "0")))))
    shadow_settings = replace(
        park.contact_shadow,
        enabled=strength > 0,
        strength=strength / 100.0,
    )
    shadow_layer = _contact_shadow_preview_layer(
        subject,
        shadow_settings,
        canvas_size,
        subject_box,
    )
    preview_dir = _root() / PREVIEW_DIR
    preview_dir.mkdir(parents=True, exist_ok=True)
    preview_path = preview_dir / f"{PREVIEW_SHADOW_PREFIX}{uuid.uuid4().hex}.png"
    try:
        shadow_layer.save(preview_path, "PNG", optimize=False)
    finally:
        shadow_layer.close()
    return preview_path, cached


def _warm_preview_worker(remover_cache: dict[tuple, BackgroundRemover]) -> None:
    settings = load_settings(CONFIG_PATH)
    preview_settings = replace(
        settings.background_removal,
        max_processing_side=PREVIEW_FAST_MAX_SIDE,
        ben2_refine_foreground=False,
    )
    remover = _preview_remover(preview_settings, remover_cache)
    remover.warm_up()
    # Hybrid production keeps BEN2 and U2Net resident as a guarded rescue for
    # body/head regions lost by BiRefNet. warm_up() prepares all three engines.
    if not preview_settings.birefnet_enabled:
        remover.warm_up_human_rescue()


def _preview_state_text(path: str, manual_search: bool = False) -> str:
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        result = preview_state_for_input(path, manual_search=manual_search)
    if result != 0:
        raise RuntimeError(f"preview state failed with code {result}")
    return captured.getvalue()


def _settings_with_manual_mask_override(settings, raw_value: str | None):
    if raw_value is None:
        return settings, None
    try:
        level = _clamp_int(int(raw_value), 0, 100)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid manual mask_protection value: {raw_value!r}") from exc
    return (
        replace(
            settings,
            background_removal=replace(
                settings.background_removal,
                mask_protection=level,
                mask_antighost=level,
            ),
        ),
        level,
    )


def _worker_bool(values: dict[str, str], key: str, default: bool) -> bool:
    raw = values.get(key)
    if raw is None:
        return default
    return str(raw).strip().casefold() in {"1", "true", "yes", "on"}


class _WorkerEventCapture(io.StringIO):
    def __init__(self, event_sink=None):
        super().__init__()
        self._event_sink = event_sink
        self._pending = ""
        self._lock = threading.Lock()

    def write(self, value):
        text = str(value)
        complete_lines = []
        with self._lock:
            written = super().write(text)
            self._pending += text
            while "\n" in self._pending:
                line, self._pending = self._pending.split("\n", 1)
                line = line.rstrip("\r")
                if line.strip():
                    complete_lines.append(line)
        if self._event_sink is not None:
            for line in complete_lines:
                self._event_sink(line)
        return written

    def finish(self):
        pending = ""
        with self._lock:
            if self._pending.strip():
                pending = self._pending.rstrip("\r")
            self._pending = ""
        if pending and self._event_sink is not None:
            self._event_sink(pending)


def _process_manual_photo_in_worker(args: list[str], event_sink=None):
    if len(args) % 2 != 0:
        raise ValueError("manual_process args expect KEY VALUE pairs")
    values = {str(args[index]): str(args[index + 1]) for index in range(0, len(args), 2)}
    config_path = Path(values.get("config", "")).resolve()
    input_path = Path(values.get("file", "")).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Config snapshot not found: {config_path}")
    if not input_path.exists():
        raise FileNotFoundError(f"Input photo not found: {input_path}")

    settings = load_settings(config_path)
    manual_mask_value = values.get("mask_protection")
    settings, manual_mask_level = _settings_with_manual_mask_override(
        settings,
        manual_mask_value,
    )
    park_name = values.get("park", PROFILE_NAME)
    park = settings.get_park(park_name if park_name in settings.parks else next(iter(settings.parks)))
    processing_logger = setup_logging(
        settings.logs.directory,
        park.name,
        settings.logs.jsonl_path,
    )
    if manual_mask_level is not None:
        processing_logger.logger.info(
            "Manual ghost repair override: requested=%s applied=%s",
            manual_mask_value,
            manual_mask_level,
        )
    processor = PhotoProcessor(
        settings,
        park,
        processing_logger,
        force_live_context=_worker_bool(values, "force_live_context", True),
        manual_search=_worker_bool(values, "manual_search", True),
        strict_preset_context=_worker_bool(values, "strict_preset_context", False),
        skip_cloud_delivery=_worker_bool(values, "skip_cloud", True),
        warm_up_before_processing=False,
    )
    captured = _WorkerEventCapture(event_sink)
    try:
        with contextlib.redirect_stdout(captured):
            result = processor.process_file(
                input_path,
                wait_for_stability=_worker_bool(values, "wait_for_stability", False),
                archive_failed=_worker_bool(values, "archive_failed", False),
            )
        captured.finish()
        return result, captured.getvalue()
    finally:
        processor.shutdown(wait=True)
        captured.finish()


def _process_batch_in_worker(args: list[str], event_sink=None):
    if len(args) % 2 != 0:
        raise ValueError("batch_process args expect KEY VALUE pairs")
    values = {str(args[index]): str(args[index + 1]) for index in range(0, len(args), 2)}
    config_path = Path(values.get("config", "")).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Config snapshot not found: {config_path}")

    settings = load_settings(config_path)
    park_name = values.get("park", PROFILE_NAME)
    park = settings.get_park(park_name if park_name in settings.parks else next(iter(settings.parks)))
    processing_logger = setup_logging(
        settings.logs.directory,
        park.name,
        settings.logs.jsonl_path,
    )
    processor = PhotoProcessor(
        settings,
        park,
        processing_logger,
        strict_preset_context=True,
        skip_cloud_delivery=_worker_bool(values, "skip_cloud", False),
        warm_up_before_processing=False,
    )
    captured = _WorkerEventCapture(event_sink)
    try:
        with contextlib.redirect_stdout(captured):
            stats = processor.process_pending(
                wait_for_stability=_worker_bool(values, "wait_for_stability", False),
            )
            print(
                "Batch complete: "
                f"total={stats.total}, processed={stats.processed}, "
                f"failed={stats.failed}, skipped={stats.skipped}, "
                f"avg_seconds={stats.average_seconds:.2f}"
            )
        captured.finish()
        unarchived_failures = [
            result
            for result in stats.results
            if result.status == "failed" and result.failed_path is None
        ]
        return stats, captured.getvalue(), not unarchived_failures
    finally:
        processor.shutdown(wait=True)
        captured.finish()


def preview_worker() -> int:
    remover_cache: dict[tuple, BackgroundRemover] = {}
    subject_cache: OrderedDict[tuple, Image.Image] = OrderedDict()
    protocol_stdout = sys.stdout
    protocol_lock = threading.Lock()

    def send_protocol_message(payload):
        with protocol_lock:
            protocol_stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
            protocol_stdout.flush()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            if request.get("quit"):
                for subject in subject_cache.values():
                    subject.close()
                _cleanup_desktop_preview_files(remove_subject_files=True)
                send_protocol_message({"ok": True, "quit": True})
                return 0
            args = request.get("args") or []
            if not isinstance(args, list):
                raise ValueError("args must be a list")
            mode = str(request.get("mode") or "subject").strip().lower()
            started = time.perf_counter()
            request_ok = True
            event_sink = None
            if request.get("stream_events"):
                event_sink = lambda text: send_protocol_message(
                    {"type": "event", "text": text}
                )
            with contextlib.redirect_stdout(sys.stderr):
                if mode == "warmup":
                    _warm_preview_worker(remover_cache)
                    preview_path = None
                    cached = False
                    extra = {}
                elif mode == "preview_state":
                    values = {
                        str(args[index]): str(args[index + 1])
                        for index in range(0, len(args) - 1, 2)
                    }
                    selected_input = values.get("selected_input", "").strip()
                    if not selected_input:
                        raise FileNotFoundError("No hay foto seleccionada para resolver el preview.")
                    preview_path = None
                    cached = True
                    extra = {
                        "state": _preview_state_text(
                            selected_input,
                            manual_search=values.get("manual_search", "false").lower()
                            in {"1", "true", "yes", "on"},
                        )
                    }
                elif mode == "subject":
                    preview_path, cached = _render_preview_subject(
                        [str(value) for value in args],
                        remover_cache,
                        subject_cache,
                    )
                    extra = {}
                elif mode == "shadow":
                    preview_path, cached = _render_preview_shadow(
                        [str(value) for value in args],
                        remover_cache,
                        subject_cache,
                    )
                    extra = {}
                elif mode == "manual_process":
                    result, events = _process_manual_photo_in_worker(
                        [str(value) for value in args],
                        event_sink=event_sink,
                    )
                    preview_path = result.output_path
                    cached = True
                    request_ok = result.status == "processed"
                    extra = {
                        "events": events,
                        "status": result.status,
                        "message": result.message or "",
                        "duration": round(result.duration_seconds, 3),
                    }
                elif mode == "batch_process":
                    stats, events, request_ok = _process_batch_in_worker(
                        [str(value) for value in args],
                        event_sink=event_sink,
                    )
                    preview_path = None
                    cached = True
                    extra = {
                        "events": events,
                        "status": "processed" if request_ok else "failed",
                        "message": "" if request_ok else "El lote termino con errores sin archivar.",
                        "duration": round(stats.average_seconds, 3),
                    }
                else:
                    raise ValueError(f"Unsupported preview worker mode: {mode}")
            response = {
                "ok": request_ok,
                "path": str(preview_path.resolve()) if preview_path is not None else "",
                "cached": cached,
                "seconds": round(time.perf_counter() - started, 3),
            }
            response.update(extra)
            send_protocol_message(response)
        except Exception as exc:
            send_protocol_message({"ok": False, "error": str(exc)})
    return 0


def preview_fast_base() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if input_images:
        first_input = _first_preview_input(input_images, park)
        park, _, _ = _effective_preview_context(settings, park, first_input)
        base_park = replace(park, overlay_path=None)
        original_full = open_image(first_input)
        output_size, output_scale = _preset_preview_size(base_park, original_full.size, PREVIEW_FAST_MAX_SIDE)
        original_size, original_scale = _preview_size_for(original_full.size, PREVIEW_FAST_MAX_SIDE)
        original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
        preview_park = replace(
            base_park,
            output_size=output_size,
            overlay_settings=_scaled_overlay_settings(base_park.overlay_settings, output_scale),
            logo_settings=_scaled_overlay_settings(base_park.logo_settings, output_scale),
        )

        pre_enhance = _photo_enhance_before_background_removal_enabled(preview_park)
        if pre_enhance:
            original = enhance_photo(original, preview_park.photo_enhance)
        subject = None if base_park.background_path is None else _fast_preview_subject(original)
        final = compose_image(original, subject, preview_park, apply_harmonize=False)
    else:
        park, _, _ = _effective_preview_context(settings, park)
        base_park = replace(park, overlay_path=None)
        final = _compose_background_overlay(base_park)
        pre_enhance = _photo_enhance_before_background_removal_enabled(base_park)

    if not pre_enhance:
        final = enhance_photo(final, base_park.photo_enhance)
    if input_images:
        final = harmonize_composed_image(final, original, subject, preview_park)
    final.save(preview_path, "JPEG", quality=72, optimize=False)
    print(preview_path.resolve())
    return 0


def preview_photo_enhance(args: list[str]) -> int:
    if len(args) % 2 != 0:
        raise SystemExit("preview_photo_enhance expects KEY VALUE pairs")

    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    preview_path = _root() / PHOTO_ENHANCE_PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    requested_index = 0
    for index in range(0, len(args), 2):
        if args[index] == "preview_index":
            requested_index = int(float(args[index + 1]))
            break

    if input_images:
        selected_index = requested_index % len(input_images)
        first_input = input_images[selected_index]
        preview_label = f"{selected_index + 1}/{len(input_images)} {first_input.name}"
        original_full = open_image(first_input)
        preview_size, preview_scale = _preview_size_for(original_full.size, PHOTO_ENHANCE_PREVIEW_MAX_SIDE)
        final = original_full.resize(preview_size, LANCZOS) if preview_scale != 1.0 else original_full
        final = final.convert("RGB")
    else:
        park, _, _ = _effective_preview_context(settings, park)
        preview_label = "Sin fotos en IN"
        final = _compose_background_overlay(park)

    clean_args = []
    for index in range(0, len(args), 2):
        if args[index] != "preview_index":
            clean_args.extend([args[index], args[index + 1]])
    preview_park, _, _ = _photo_enhance_overrides(park, clean_args)
    final = enhance_photo(final, preview_park.photo_enhance)
    final.convert("RGB").save(preview_path, "JPEG", quality=86, optimize=False)
    print(preview_path.resolve())
    print(preview_label)
    return 0


def preview_scene() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    first_input = _first_preview_input(input_images, park)
    park, _, _ = _effective_preview_context(settings, park, first_input)
    preview_path = _root() / PREVIEW_SCENE_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    final = _compose_background_overlay(park)
    final.save(preview_path, "JPEG", quality=86, optimize=True)
    print(preview_path.resolve())
    return 0


def set_value(key: str, value: str, raw: dict | None = None, save: bool = True) -> int:
    raw = _load_raw() if raw is None else raw
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    if key == "manual_composition_override":
        raw["manual_composition_override"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
    elif key == "input":
        park["input_dir"] = _rel(value)
    elif key == "output":
        park["output_dir"] = _rel(value)
    elif key == "processed":
        raw["processed_dir"] = _rel(value)
    elif key == "failed":
        raw["failed_dir"] = _rel(value)
    elif key == "background":
        park["background"] = _rel(value)
        park["output_size"] = "background" if str(value or "").strip() else "input"
    elif key == "background_brightness":
        park["background_brightness"] = max(0.5, min(2.5, float(value or 1.0)))
    elif key == "overlay":
        old_overlay = park.get("overlay")
        park["overlay"] = _rel(value) if value else None
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["anchor"] = "top_left"
        if old_overlay != park["overlay"]:
            overlay_settings["mode"] = "stretch" if park["overlay"] else "original"
            overlay_settings["scale"] = 1
            overlay_settings["x"] = 0
            overlay_settings["y"] = 0
        else:
            overlay_settings["mode"] = "stretch" if park["overlay"] else "original"
    elif key == "overlay_mode":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["mode"] = str(value or "original").lower()
        overlay_settings["anchor"] = "top_left"
    elif key == "logo":
        old_logo = park.get("logo")
        park["logo"] = _rel(value) if value else None
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["anchor"] = "top_left"
        logo_settings["mode"] = "original"
        if old_logo != park["logo"]:
            logo_settings["scale"] = 1
            logo_settings["x"] = 0
            logo_settings["y"] = 0
    elif key == "overlay_x":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["x"] = int(float(value))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "overlay_y":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["y"] = int(float(value))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "overlay_scale":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["scale"] = max(0.1, min(3.0, float(value)))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "logo_x":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["x"] = int(float(value))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "logo_y":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["y"] = int(float(value))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "logo_scale":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["scale"] = max(0.1, min(3.0, float(value)))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "text_layer":
        text_layer = park.setdefault("text_layer", {})
        text_layer["text"] = str(value or "")
        text_layer["enabled"] = bool(str(value or "").strip())
        text_layer.setdefault("anchor", "top_center")
        text_layer.setdefault("x", 0)
        text_layer.setdefault("y", 0)
        text_layer.setdefault("scale", 1.0)
        text_layer.setdefault("rotation", 0.0)
        text_layer.setdefault("font", "Segoe UI")
        text_layer.setdefault("color", "#FFFFFF")
    elif key == "text_layer_font":
        text_layer = park.setdefault("text_layer", {})
        text_layer["font"] = str(value or "Segoe UI")
    elif key == "text_layer_color":
        text_layer = park.setdefault("text_layer", {})
        text_layer["color"] = str(value or "#FFFFFF")
    elif key == "text_layer_x":
        text_layer = park.setdefault("text_layer", {})
        text_layer["x"] = int(float(value))
    elif key == "text_layer_y":
        text_layer = park.setdefault("text_layer", {})
        text_layer["y"] = int(float(value))
    elif key == "text_layer_scale":
        text_layer = park.setdefault("text_layer", {})
        text_layer["scale"] = max(0.3, min(3.0, float(value)))
    elif key == "text_layer_rotation":
        text_layer = park.setdefault("text_layer", {})
        text_layer["rotation"] = max(-180.0, min(180.0, float(value)))
    elif key == "move_processed":
        park["move_original_to_processed"] = value.lower() in {"1", "true", "yes", "si", "sí"}
    elif key == "cloud_enabled":
        raw.setdefault("cloud", {})["enabled"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
    elif key == "cloud_mode":
        mode = str(value or "upload_only").strip().lower()
        if mode not in {"upload_only", "upload_download", "upload_and_download"}:
            raise SystemExit(f"Unknown cloud mode: {value}")
        raw.setdefault("cloud", {})["mode"] = mode
    elif key == "cloud_download_dir":
        raw.setdefault("cloud", {})["download_dir"] = _rel(value) if value else "cloud_downloads"
    elif key == "cloud_park":
        raw.setdefault("cloud", {})["park"] = str(value or "").strip()
    elif key == "cloud_user_group":
        raw.setdefault("cloud", {})["user_group"] = str(value or "").strip()
    elif key == "cloud_username":
        raw.setdefault("cloud", {})["username"] = str(value or "").strip()
    elif key == "cloud_auth_username":
        raw.setdefault("cloud", {})["auth_username"] = str(value or "").strip()
    elif key == "cloud_auth_password":
        password = str(value or "")
        if password:
            raw.setdefault("cloud", {})["auth_password"] = password
    elif key == "jpg_quality":
        park["jpg_quality"] = max(50, min(100, int(value)))
    elif key == "harmonize_strength":
        park["harmonize_strength"] = max(0.0, min(2.0, float(value) / 100.0))
    elif key == "photo_enhance_strength":
        strength = max(0.0, min(2.0, float(value) / 100.0))
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["enabled"] = strength > 0.0
        photo_enhance["strength"] = strength
    elif key == "photo_enhance_enabled":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["enabled"] = value.lower() in {"1", "true", "yes", "si", "sí"}
    elif key == "photo_enhance_engine":
        engine = str(value or "classic").strip().lower()
        if engine in LEGACY_ENHANCER2_ENGINES:
            engine = "qenhancer_cuevas"
        if engine not in {"classic", "none", "off", *QENHANCER_CUEVAS_ENGINES}:
            raise SystemExit(f"Unknown photo enhancer engine: {value}")
        photo_enhance = park.setdefault("photo_enhance", {})
        if engine == "off":
            photo_enhance["engine"] = "none"
        elif engine in QENHANCER_CUEVAS_ENGINES:
            photo_enhance["engine"] = "qenhancer_cuevas"
        else:
            photo_enhance["engine"] = engine
    elif key == "photo_enhance_preset":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["preset"] = str(value or "C_Channel 1.qes").strip() or "C_Channel 1.qes"
    elif key == "photo_enhance_recipe":
        photo_enhance = park.setdefault("photo_enhance", {})
        recipe = str(value or "custom").strip() or "custom"
        photo_enhance["recipe"] = recipe if recipe.lower().startswith("user:") else recipe.lower()
    elif key == "photo_enhance_autotune":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["autotune"] = False
    elif key == "photo_enhance_save_logs":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["save_logs"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
    elif key.startswith("photo_enhance_"):
        field_name = key[len("photo_enhance_"):]
        allowed = {
            "brightness",
            "shadow_contrast",
            "highlight_contrast",
            "saturation",
            "red",
            "green",
            "blue",
            "auto_brightness",
            "auto_color",
            "memory_color",
            "shadows",
            "lights",
            "global_sharpen",
            "local_sharpen",
            "denoise",
            "desaturate_shadows",
            "hue_rotation",
            "manual_exposure",
            "manual_contrast",
            "manual_fill_light",
            "manual_gamma",
            "manual_highlights",
            "manual_black_point",
            "manual_sharpness",
            "manual_saturation",
            "manual_temperature",
            "manual_vibrance",
            "manual_red",
            "manual_green",
            "manual_blue",
        }
        if field_name not in allowed:
            raise SystemExit(f"Unknown key: {key}")
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance[field_name] = int(float(value))
    elif key == "contact_shadow_strength":
        strength = max(0.0, min(2.0, float(value) / 100.0))
        shadow = park.setdefault("contact_shadow", {})
        shadow["enabled"] = strength > 0.0
        shadow["strength"] = strength
    elif key == "mask_protection":
        _apply_mask_protection(raw, int(value))
    elif key == "mask_antighost":
        _apply_mask_antighost(raw, int(value))
    elif key == "person_zoom":
        _apply_person_zoom(raw, int(value))
    elif key == "person_vertical":
        _apply_person_vertical(raw, int(value))
    else:
        raise SystemExit(f"Unknown key: {key}")
    if save:
        _save_raw(raw)
    return 0


def set_many(args: list[str]) -> int:
    if len(args) % 2 != 0:
        raise SystemExit("set_many expects KEY VALUE pairs")
    raw = _load_raw()
    for index in range(0, len(args), 2):
        set_value(args[index], args[index + 1], raw=raw, save=False)
    _save_raw(raw)
    return 0


def set_many_preset_save_state(args: list[str]) -> int:
    if len(args) < 1:
        raise SystemExit("set_many_preset_save_state expects NAME [KEY VALUE ...]")
    name = args[0]
    values = args[1:]
    if len(values) % 2 != 0:
        raise SystemExit("set_many_preset_save_state expects NAME [KEY VALUE ...]")
    raw = _load_raw()
    for index in range(0, len(values), 2):
        set_value(values[index], values[index + 1], raw=raw, save=False)
    safe_name = _safe_preset_name(name)
    payload = _current_preset_payload(raw, safe_name)
    path = _preset_path(safe_name)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _sync_orientation_sibling_preset(safe_name, payload)
    raw["active_preset"] = _active_preset_family_name(safe_name)
    raw["manual_composition_override"] = False
    _save_raw(raw)
    return state()


def preset_apply_state(name: str) -> int:
    apply_preset(name, emit_path=False)
    return state()


def preset_delete_state(name: str) -> int:
    delete_preset(name, emit_path=False)
    return state()


def preset_family_delete_state(name: str) -> int:
    delete_preset_family(name, emit_names=False)
    return state()


def preset_photo_enhance_get(name: str) -> int:
    path = _preset_path(name)
    if not path.exists():
        raise SystemExit(f"Preset not found: {name}")
    preset = json.loads(path.read_text(encoding="utf-8-sig"))
    photo_enhance = preset.get("park", {}).get("photo_enhance", {})
    print(str(photo_enhance.get("recipe") or "custom"))
    print(str(photo_enhance.get("preset") or "C_Channel 1.qes"))
    return 0


def preset_photo_enhance_assign_state(args: list[str]) -> int:
    if len(args) < 1:
        raise SystemExit("preset_photo_enhance_assign_state expects NAME [KEY VALUE ...]")
    name = args[0]
    values = args[1:]
    if len(values) % 2 != 0:
        raise SystemExit("preset_photo_enhance_assign_state expects NAME [KEY VALUE ...]")

    path = _preset_path(name)
    if not path.exists():
        raise SystemExit(f"Preset not found: {name}")

    raw = _load_raw()
    for index in range(0, len(values), 2):
        if not values[index].startswith("photo_enhance_"):
            raise SystemExit(f"Only photo enhancement keys can be assigned: {values[index]}")
        set_value(values[index], values[index + 1], raw=raw, save=False)

    assigned = deepcopy(raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).get("photo_enhance", {}))
    preset = json.loads(path.read_text(encoding="utf-8-sig"))
    preset.setdefault("park", {})["photo_enhance"] = assigned
    preset["created_at"] = datetime.now().isoformat(timespec="seconds")
    path.write_text(json.dumps(preset, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    _sync_orientation_sibling_preset(_safe_preset_name(name), preset)
    apply_preset(name, emit_path=False)
    return state()


def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]
    _cleanup_desktop_preview_files()
    if not argv or argv[0] == "state":
        return state()
    if argv[0] == "preview_scene":
        return preview_scene()
    if argv[0] == "preview_fast_base":
        return preview_fast_base()
    if argv[0] == "preview_fast":
        return preview_fast(argv[1:])
    if argv[0] == "preset_thumbnail" and len(argv) >= 2:
        return preset_thumbnail(" ".join(argv[1:]))
    if argv[0] == "preview_worker":
        return preview_worker()
    if argv[0] == "preview_photo_enhance":
        return preview_photo_enhance(argv[1:])
    if argv[0] == "preview_state" and len(argv) >= 2:
        return preview_state_for_input(" ".join(argv[1:]))
    if argv[0] == "preview_state_manual_search" and len(argv) >= 2:
        return preview_state_for_input(" ".join(argv[1:]), manual_search=True)
    if argv[0] == "snapshot_create":
        reason = " ".join(argv[1:]) if len(argv) >= 2 else "batch"
        return create_config_snapshot(reason)
    if argv[0] == "secure_migrate":
        return secure_migrate()
    if argv[0] == "cloud_credentials_check":
        settings = load_settings(CONFIG_PATH)
        if not validate_cloud_credentials(settings.cloud, logging.getLogger("maskerade.cloud.credentials")):
            raise SystemExit("Credenciales de Nuvolcam ausentes o incorrectas")
        _print("cloud_credentials", "ok")
        return 0
    if argv[0] == "classic_photo_preset_list":
        return classic_photo_preset_list()
    if argv[0] == "classic_photo_preset_get" and len(argv) >= 2:
        return classic_photo_preset_get(" ".join(argv[1:]))
    if argv[0] == "classic_photo_preset_save" and len(argv) >= 2:
        return classic_photo_preset_save(argv[1:])
    if argv[0] == "classic_photo_preset_delete" and len(argv) >= 2:
        return classic_photo_preset_delete(" ".join(argv[1:]))
    if argv[0] == "photo_retouch_preset_list":
        return photo_retouch_preset_list()
    if argv[0] == "photo_retouch_preset_get" and len(argv) >= 2:
        return photo_retouch_preset_get(" ".join(argv[1:]))
    if argv[0] == "photo_retouch_preset_save" and len(argv) >= 2:
        return photo_retouch_preset_save(argv[1:])
    if argv[0] == "photo_retouch_preset_delete" and len(argv) >= 2:
        return photo_retouch_preset_delete(" ".join(argv[1:]))
    if argv[0] == "quick_photo_retouch_preset_list":
        return quick_photo_retouch_preset_list()
    if argv[0] == "quick_photo_retouch_preset_save" and len(argv) >= 2:
        return quick_photo_retouch_preset_save(argv[1:])
    if argv[0] == "preview":
        return preview()
    if argv[0] == "set" and len(argv) >= 3:
        return set_value(argv[1], argv[2])
    if argv[0] == "secret_set" and len(argv) >= 2:
        return set_value(argv[1], sys.stdin.read())
    if argv[0] == "set_many" and len(argv) >= 3:
        return set_many(argv[1:])
    if argv[0] == "set_many_preset_save_state" and len(argv) >= 2:
        return set_many_preset_save_state(argv[1:])
    if argv[0] == "preset_save" and len(argv) >= 2:
        return save_preset(" ".join(argv[1:]))
    if argv[0] == "preset_apply" and len(argv) >= 2:
        return apply_preset(" ".join(argv[1:]))
    if argv[0] == "preset_delete" and len(argv) >= 2:
        return delete_preset(" ".join(argv[1:]))
    if argv[0] == "preset_apply_state" and len(argv) >= 2:
        return preset_apply_state(" ".join(argv[1:]))
    if argv[0] == "preset_delete_state" and len(argv) >= 2:
        return preset_delete_state(" ".join(argv[1:]))
    if argv[0] == "preset_family_delete_state" and len(argv) >= 2:
        return preset_family_delete_state(" ".join(argv[1:]))
    if argv[0] == "preset_photo_enhance_get" and len(argv) >= 2:
        return preset_photo_enhance_get(" ".join(argv[1:]))
    if argv[0] == "preset_photo_enhance_assign_state" and len(argv) >= 2:
        return preset_photo_enhance_assign_state(argv[1:])
    if argv[0] == "folder_rule_save" and len(argv) >= 3:
        enabled = argv[3] if len(argv) >= 4 else "true"
        return save_folder_rule(argv[1], argv[2], enabled, argv[4:])
    if argv[0] == "folder_rule_delete" and len(argv) >= 2:
        return delete_folder_rule(" ".join(argv[1:]))
    raise SystemExit("Usage: desktop_bridge.py state | set KEY VALUE | preset_save NAME | preset_apply NAME")


if __name__ == "__main__":
    raise SystemExit(main())

