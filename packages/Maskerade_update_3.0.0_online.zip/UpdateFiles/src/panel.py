from __future__ import annotations

import json
import mimetypes
import os
import re
import subprocess
import time
from io import BytesIO
from dataclasses import replace
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urlparse

from PIL import Image

from .config import ConfigurationError, load_settings
from .image_utils import list_images
from .logger import setup_logging
from .panel_templates import PANEL_CSS, PANEL_HTML, PANEL_JS
from .secure_settings import load_raw_settings, save_raw_settings


_PREVIEW_CACHE: dict[tuple, bytes] = {}
_PREVIEW_REMOVERS: dict[tuple, object] = {}
_PREVIEW_MAX_SIDE = 720
_PREVIEW_JPEG_QUALITY = 74


class PanelError(RuntimeError):
    def __init__(self, message: str, status: HTTPStatus = HTTPStatus.BAD_REQUEST) -> None:
        super().__init__(message)
        self.status = status


class PanelServer(ThreadingHTTPServer):
    def __init__(
        self,
        server_address: tuple[str, int],
        handler_class: type[BaseHTTPRequestHandler],
        config_path: str | Path,
    ) -> None:
        super().__init__(server_address, handler_class)
        self.config_path = Path(config_path).resolve()
        self.root_dir = self._guess_root_dir()

    def _guess_root_dir(self) -> Path:
        if self.config_path.parent.name.lower() == "config":
            return self.config_path.parent.parent
        return self.config_path.parent


class PanelRequestHandler(BaseHTTPRequestHandler):
    server: PanelServer

    def log_message(self, format: str, *args: object) -> None:
        del format, args

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/":
                self._send_text(PANEL_HTML, "text/html; charset=utf-8")
            elif parsed.path == "/panel.css":
                self._send_text(PANEL_CSS, "text/css; charset=utf-8")
            elif parsed.path == "/panel.js":
                self._send_text(PANEL_JS, "application/javascript; charset=utf-8")
            elif parsed.path == "/api/config":
                self._send_json(self._config_payload())
            elif parsed.path == "/api/logs":
                query = parse_qs(parsed.query)
                limit = int(query.get("limit", ["40"])[0])
                self._send_json({"lines": self._tail_logs(limit)})
            elif parsed.path == "/api/asset-preview":
                query = parse_qs(parsed.query)
                self._send_asset_preview(unquote(_one(query, "path")))
            elif parsed.path == "/api/render-preview":
                query = parse_qs(parsed.query)
                self._send_render_preview(
                    _one(query, "park"),
                    quality=str(query.get("quality", ["fast"])[0] or "fast"),
                    max_side=_optional_int(query.get("max_side", [""])[0]),
                )
            else:
                self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except Exception as exc:
            self._send_exception(exc)

    def do_POST(self) -> None:
        try:
            parsed = urlparse(self.path)
            if parsed.path == "/api/config":
                data = self._read_json()
                self._save_config(data)
                self._send_json({"ok": True})
            elif parsed.path == "/api/upload":
                query = parse_qs(parsed.query)
                park = _one(query, "park")
                kind = _one(query, "kind")
                filename = unquote(_one(query, "filename"))
                saved = self._handle_upload(park, kind, filename)
                self._send_json({"ok": True, "path": saved})
            elif parsed.path == "/api/delete-asset":
                data = self._read_json()
                deleted = self._handle_delete_asset(
                    str(data.get("park", "")),
                    str(data.get("kind", "")),
                    str(data.get("path", "")),
                )
                self._send_json({"ok": True, "path": deleted})
            elif parsed.path == "/api/run-batch":
                query = parse_qs(parsed.query)
                park = _one(query, "park")
                self._send_json(self._run_batch(park))
            elif parsed.path == "/api/test-one":
                query = parse_qs(parsed.query)
                park = _one(query, "park")
                self._send_json(self._test_one(park))
            elif parsed.path == "/api/open-path":
                data = self._read_json()
                self._open_path(str(data.get("path", "")))
                self._send_json({"ok": True})
            elif parsed.path == "/api/pick-folder":
                data = self._read_json()
                self._send_json({"path": self._pick_folder(str(data.get("current", "")))})
            elif parsed.path == "/api/pick-file":
                data = self._read_json()
                self._send_json(
                    {
                        "path": self._pick_file(
                            str(data.get("current", "")),
                            str(data.get("kind", "")),
                            str(data.get("park", "")),
                        )
                    }
                )
            else:
                self._send_json({"error": "Not found"}, HTTPStatus.NOT_FOUND)
        except Exception as exc:
            self._send_exception(exc)

    def _config_payload(self) -> dict[str, Any]:
        raw = self._read_config_file()
        settings = load_settings(self.server.config_path)
        parks: dict[str, Any] = {}
        for name, park in settings.parks.items():
            parks[name] = {
                "input_count": _count_images(park.input_dir),
                "output_count": _count_images(park.output_dir),
                "background_exists": bool(
                    park.background_path and park.background_path.exists()
                ),
                "overlay_exists": bool(park.overlay_path and park.overlay_path.exists()),
                "logo_exists": bool(park.logo_path and park.logo_path.exists()),
                "input_abs": str(park.input_dir),
                "output_abs": str(park.output_dir),
                "background_abs": str(park.background_path) if park.background_path else "",
                "overlay_abs": str(park.overlay_path) if park.overlay_path else None,
                "logo_abs": str(park.logo_path) if park.logo_path else None,
                "preview_input": _first_image_name(park.input_dir),
                "background_assets": _asset_entries(
                    settings.root_dir / "assets" / "backgrounds",
                    settings.root_dir,
                    {".jpg", ".jpeg", ".png", ".webp"},
                ),
                "overlay_assets": (
                    _asset_entries(
                        settings.root_dir / "assets" / "masks",
                        settings.root_dir,
                        {".png"},
                    )
                    + _asset_entries(
                        settings.root_dir / "assets" / "overlays",
                        settings.root_dir,
                        {".png"},
                    )
                ),
                "logo_assets": _asset_entries(
                    settings.root_dir / "assets" / "logos",
                    settings.root_dir,
                    {".png"},
                ),
            }
        return {
            "config": raw,
            "meta": {
                "config_path": str(self.server.config_path),
                "root_dir": str(settings.root_dir),
                "parks": parks,
            },
        }

    def _read_config_file(self) -> dict[str, Any]:
        return load_raw_settings(self.server.config_path)

    def _send_asset_preview(self, value: str) -> None:
        path = _resolve_ui_path(value, self.server.root_dir).resolve()
        root = self.server.root_dir.resolve()
        if not _is_relative_to(path, root):
            raise PanelError("Ruta de asset no permitida", HTTPStatus.FORBIDDEN)
        if not path.exists() or not path.is_file():
            raise PanelError("Asset no encontrado", HTTPStatus.NOT_FOUND)
        if path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp"}:
            raise PanelError("Tipo de asset no soportado", HTTPStatus.BAD_REQUEST)
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _send_render_preview(
        self,
        park_name: str,
        quality: str = "fast",
        max_side: int | None = None,
    ) -> None:
        started = time.perf_counter()
        phase_started = started
        timings: dict[str, float] = {}

        def mark_phase(name: str) -> None:
            nonlocal phase_started
            now = time.perf_counter()
            timings[name] = round(now - phase_started, 3)
            phase_started = now

        settings = load_settings(self.server.config_path)
        park = settings.get_park(park_name)
        quality_key = (quality or "fast").strip().lower()
        real_preview = quality_key in {"real", "ben2", "quality", "production"}
        preview_max_side = int(max_side if max_side is not None else (1280 if real_preview else _PREVIEW_MAX_SIDE))
        if preview_max_side < 0:
            preview_max_side = 0
        if park.background_path is not None and (
            not park.background_path.exists() or not park.background_path.is_file()
        ):
            raise PanelError("No hay fondo activo para generar preview", HTTPStatus.NOT_FOUND)

        from PIL import Image

        from .background_removal import BackgroundRemover
        from .compositor import compose_image, prepare_overlay_layer
        from .image_utils import alpha_composite_at, open_image, resize_cover

        first_photo = next(iter(list_images(park.input_dir)), None)
        cache_key = (
            "render-preview-v3",
            "real" if real_preview else "fast",
            preview_max_side,
            _PREVIEW_JPEG_QUALITY,
            _preview_cache_key(self.server.config_path, park, first_photo),
        )
        if not real_preview:
            cached = _PREVIEW_CACHE.get(cache_key)
            if cached is not None:
                self._send_image_bytes(
                    cached,
                    "image/jpeg",
                    extra_headers={
                        "X-Maskerade-Preview-Quality": "fast",
                        "X-Maskerade-Preview-Cache": "hit",
                    },
                )
                return
        mark_phase("settings")

        remover_cache_hit = False
        removal_seconds = 0.0
        preview_label = "real" if real_preview else "fast"

        def preview_size_for(size: tuple[int, int]) -> tuple[int, int]:
            if preview_max_side <= 0:
                return size
            return _preview_size(size, preview_max_side)

        def resize_for_selected_preview(image: Any) -> tuple[Any, float]:
            if preview_max_side <= 0:
                return image, 1.0
            return _resize_for_preview(image, preview_max_side)

        if first_photo:
            original = open_image(first_photo)
            preview_original, _ = resize_for_selected_preview(original)
            if park.background_path:
                background = Image.open(park.background_path).convert("RGB")
                preview_size = preview_size_for(background.size)
                preview_scale = preview_size[0] / max(1, background.size[0])
                subject = None
            else:
                background = preview_original.convert("RGB")
                preview_size = preview_original.size
                preview_scale = preview_size[0] / max(1, original.size[0])
                subject = None
            mark_phase("open")
            preview_park = replace(
                park,
                output_size=preview_size,
                overlay_settings=_scaled_overlay_settings(park.overlay_settings, preview_scale),
                logo_settings=_scaled_overlay_settings(park.logo_settings, preview_scale),
            )
            if park.background_path:
                if real_preview:
                    preview_removal_settings = replace(
                        settings.background_removal,
                        max_processing_side=0,
                    )
                    remover_key = (
                        "real",
                        preview_removal_settings.backend,
                        preview_removal_settings.model,
                        preview_removal_settings.max_processing_side,
                        preview_removal_settings.birefnet_enabled,
                        preview_removal_settings.birefnet_model,
                        preview_removal_settings.birefnet_device,
                        preview_removal_settings.birefnet_input_size,
                        preview_removal_settings.birefnet_fallback_ben2,
                        preview_removal_settings.birefnet_hybrid_ben2,
                        preview_removal_settings.ben2_model,
                        preview_removal_settings.ben2_device,
                        preview_removal_settings.ben2_refine_foreground,
                        preview_removal_settings.mask_protection,
                        preview_removal_settings.mask_antighost,
                    )
                else:
                    preview_removal_settings = replace(
                        settings.background_removal,
                        max_processing_side=min(
                            _PREVIEW_MAX_SIDE,
                            int(settings.background_removal.max_processing_side or _PREVIEW_MAX_SIDE),
                        ),
                    )
                    remover_key = (
                        "preview",
                        preview_removal_settings.backend,
                        preview_removal_settings.model,
                        preview_removal_settings.max_processing_side,
                        preview_removal_settings.birefnet_enabled,
                        preview_removal_settings.birefnet_model,
                        preview_removal_settings.birefnet_device,
                        preview_removal_settings.birefnet_input_size,
                        preview_removal_settings.birefnet_fallback_ben2,
                        preview_removal_settings.birefnet_hybrid_ben2,
                        preview_removal_settings.ben2_model,
                        preview_removal_settings.ben2_device,
                        preview_removal_settings.ben2_refine_foreground,
                    )
                remover = _PREVIEW_REMOVERS.get(remover_key)
                remover_cache_hit = remover is not None
                if remover is None:
                    remover = BackgroundRemover(preview_removal_settings)
                    _PREVIEW_REMOVERS[remover_key] = remover
                remove_started = time.perf_counter()
                subject = remover.remove_background(preview_original).person_rgba
                removal_seconds = round(time.perf_counter() - remove_started, 3)
            mark_phase("remove")
            final = compose_image(
                original=preview_original,
                person_rgba=subject,
                park=preview_park,
            )
            mark_phase("compose")
        else:
            if park.background_path:
                background = Image.open(park.background_path).convert("RGB")
                preview_size = preview_size_for(background.size)
                background_source_size = background.size
                final_rgba = resize_cover(background, preview_size).convert("RGBA")
            else:
                preview_size = preview_size_for((1600, 1000))
                background_source_size = None
                final_rgba = Image.new("RGBA", preview_size, (15, 26, 32, 255))
            if park.overlay_path and park.overlay_path.exists():
                overlay, overlay_xy = prepare_overlay_layer(
                    Image.open(park.overlay_path).convert("RGBA"),
                    park.overlay_settings,
                    final_rgba.size,
                    background_source_size,
                )
                alpha_composite_at(final_rgba, overlay, overlay_xy)
            if park.logo_path and park.logo_path.exists():
                logo, logo_xy = prepare_overlay_layer(
                    Image.open(park.logo_path).convert("RGBA"),
                    park.logo_settings,
                    final_rgba.size,
                    background_source_size,
                )
                alpha_composite_at(final_rgba, logo, logo_xy)
            final = final_rgba.convert("RGB")
            mark_phase("compose")

        buffer = BytesIO()
        final.save(buffer, "JPEG", quality=_PREVIEW_JPEG_QUALITY, optimize=True, subsampling=1)
        data = buffer.getvalue()
        mark_phase("encode")
        if not real_preview:
            _PREVIEW_CACHE.clear()
            _PREVIEW_CACHE[cache_key] = data
        total_seconds = round(time.perf_counter() - started, 3)
        self._send_image_bytes(
            data,
            "image/jpeg",
            extra_headers={
                "X-Maskerade-Preview-Quality": preview_label,
                "X-Maskerade-Preview-Max-Side": str(preview_max_side),
                "X-Maskerade-Preview-Remover-Cache": "hit" if remover_cache_hit else "miss",
                "X-Maskerade-Preview-Remove-Seconds": str(removal_seconds),
                "X-Maskerade-Preview-Total-Seconds": str(total_seconds),
                "X-Maskerade-Preview-Timings": json.dumps(timings, separators=(",", ":")),
            },
        )
        return

    def _send_image_bytes(
        self,
        data: bytes,
        content_type: str,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def _save_config(self, data: dict[str, Any]) -> None:
        if not isinstance(data, dict) or "parks" not in data:
            raise PanelError("Config JSON invalido")

        serialized = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
        temp_path = self.server.config_path.with_suffix(".tmp.json")
        temp_path.write_text(serialized, encoding="utf-8")
        try:
            load_settings(temp_path)
        except Exception:
            temp_path.unlink(missing_ok=True)
            raise

        save_raw_settings(self.server.config_path, data)
        temp_path.unlink(missing_ok=True)
        _PREVIEW_CACHE.clear()

    def _handle_upload(self, park_name: str, kind: str, filename: str) -> str:
        settings = load_settings(self.server.config_path)
        park = settings.get_park(park_name)
        safe_name = _safe_filename(filename)
        body = self._read_body()
        if not body:
            raise PanelError("Archivo vacio")

        if kind == "background":
            _ensure_extension(safe_name, {".jpg", ".jpeg", ".png", ".webp"})
            target = settings.root_dir / "assets" / "backgrounds" / safe_name
            config_key = "background"
        elif kind == "overlay":
            _ensure_extension(safe_name, {".png"})
            target = settings.root_dir / "assets" / "overlays" / safe_name
            config_key = "overlay"
        elif kind == "logo":
            _ensure_extension(safe_name, {".png"})
            target = settings.root_dir / "assets" / "logos" / safe_name
            config_key = "logo"
        elif kind == "mask":
            _ensure_extension(safe_name, {".png"})
            target = settings.root_dir / "assets" / "masks" / safe_name
            config_key = "overlay"
        elif kind == "input_photo":
            _ensure_extension(safe_name, {".jpg", ".jpeg"})
            target = park.input_dir / safe_name
            config_key = None
        else:
            raise PanelError(f"Tipo de subida no soportado: {kind}")

        target.parent.mkdir(parents=True, exist_ok=True)
        target = _unique_path(target)
        target.write_bytes(body)

        if config_key:
            raw = self._read_config_file()
            raw["parks"][park.name][config_key] = _relative_for_config(
                target,
                settings.root_dir,
            )
            self._save_config(raw)
        else:
            _PREVIEW_CACHE.clear()

        return str(target)

    def _handle_delete_asset(self, park_name: str, kind: str, value: str) -> str:
        settings = load_settings(self.server.config_path)
        park = settings.get_park(park_name)
        kind = kind.lower().strip()
        path = _resolve_ui_path(value, settings.root_dir).resolve()

        if kind == "background":
            allowed_roots = [settings.root_dir / "assets" / "backgrounds"]
            config_key = "background"
        elif kind == "overlay":
            allowed_roots = [
                settings.root_dir / "assets" / "overlays",
                settings.root_dir / "assets" / "masks",
            ]
            config_key = "overlay"
        elif kind == "logo":
            allowed_roots = [settings.root_dir / "assets" / "logos"]
            config_key = "logo"
        else:
            raise PanelError(f"Tipo de asset no soportado: {kind}")

        if not any(_is_relative_to(path, root.resolve()) for root in allowed_roots):
            raise PanelError("No se permite eliminar esta ruta", HTTPStatus.FORBIDDEN)
        if not path.exists() or not path.is_file():
            raise PanelError("Asset no encontrado", HTTPStatus.NOT_FOUND)

        relative = _relative_for_config(path, settings.root_dir)
        path.unlink()

        raw = self._read_config_file()
        park_raw = raw["parks"][park.name]
        active_value = str(park_raw.get(config_key) or "")
        if normalize_path(active_value) == normalize_path(relative):
            park_raw[config_key] = "" if kind == "background" else None
            self._save_config(raw)
        else:
            _PREVIEW_CACHE.clear()

        return relative

    def _run_batch(self, park_name: str) -> dict[str, Any]:
        settings = load_settings(self.server.config_path)
        park = settings.get_park(park_name)
        self._validate_backend_ready(settings.background_removal)
        processing_logger = setup_logging(
            settings.logs.directory,
            park.name,
            settings.logs.jsonl_path,
        )

        from .processor import PhotoProcessor, ProcessingBusyError

        try:
            stats = PhotoProcessor(settings, park, processing_logger).process_pending()
        except ProcessingBusyError as exc:
            raise PanelError(
                "Ya hay un procesamiento en marcha. "
                "Espera a que termine antes de lanzar otro lote."
            ) from exc
        return {
            "total": stats.total,
            "processed": stats.processed,
            "failed": stats.failed,
            "skipped": stats.skipped,
            "average_seconds": round(stats.average_seconds, 3),
            "results": [
                {
                    "status": result.status,
                    "input": result.input_path.name,
                    "output": result.output_path.name if result.output_path else None,
                    "seconds": round(result.duration_seconds, 3),
                    "backend": result.backend_used,
                    "message": result.message,
                }
                for result in stats.results
            ],
        }

    def _test_one(self, park_name: str) -> dict[str, Any]:
        settings = load_settings(self.server.config_path)
        park = replace(settings.get_park(park_name), move_original_to_processed=False)
        self._validate_backend_ready(settings.background_removal)

        from .image_utils import list_images
        from .processor import PhotoProcessor, ProcessingBusyError

        images = list_images(park.input_dir)
        if not images:
            raise PanelError(f"No hay JPG en IN para probar: {park.input_dir}")

        processing_logger = setup_logging(
            settings.logs.directory,
            park.name,
            settings.logs.jsonl_path,
        )
        try:
            result = PhotoProcessor(settings, park, processing_logger).process_file(images[0])
        except ProcessingBusyError as exc:
            raise PanelError(
                "Ya hay un procesamiento en marcha. "
                "Espera a que termine antes de lanzar otra prueba."
            ) from exc

        return {
            "input": result.input_path.name,
            "status": result.status,
            "output": result.output_path.name if result.output_path else None,
            "seconds": round(result.duration_seconds, 3),
            "backend": result.backend_used,
            "message": result.message,
        }

    def _validate_backend_ready(self, background_settings) -> None:
        backend = background_settings.backend.lower()
        if backend not in {"ben2", "ben"}:
            raise PanelError(
                f"Motor '{background_settings.backend}' no soportado en esta version limpia. "
                "Usa BEN2."
            )
        return

    def _open_path(self, value: str) -> None:
        path = _resolve_ui_path(value, self.server.root_dir)
        if not path.exists():
            target = path.parent if path.suffix else path
            target.mkdir(parents=True, exist_ok=True)
            path = target
        self._open_path_in_front(path)

    def _open_path_in_front(self, path: Path) -> None:
        target = path.resolve()
        script = r"""
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class MaskeradeFocus {
  [DllImport("user32.dll")]
  public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")]
  public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")]
  public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
}
"@

$SW_RESTORE = 9
$HWND_TOPMOST = [IntPtr](-1)
$HWND_NOTOPMOST = [IntPtr](-2)
$SWP_NOSIZE = 0x0001
$SWP_NOMOVE = 0x0002
$SWP_SHOWWINDOW = 0x0040
$target = [System.IO.Path]::GetFullPath($env:PHOTOIA_OPEN_PATH)
if ([System.IO.File]::Exists($target)) {
  $quoted = '"' + $target + '"'
  Start-Process explorer.exe -ArgumentList "/select,$quoted"
  $folder = [System.IO.Path]::GetDirectoryName($target)
} else {
  $folder = $target
  $quoted = '"' + $folder + '"'
  Start-Process explorer.exe -ArgumentList "/n,$quoted"
}

$folder = [System.IO.Path]::GetFullPath($folder)
$shell = New-Object -ComObject Shell.Application
$wscript = New-Object -ComObject WScript.Shell
for ($i = 0; $i -lt 25; $i++) {
  Start-Sleep -Milliseconds 120
  foreach ($window in $shell.Windows()) {
    try {
      $windowPath = $window.Document.Folder.Self.Path
      if ([System.IO.Path]::GetFullPath($windowPath) -eq $folder) {
        $hwnd = [IntPtr]$window.HWND
        [MaskeradeFocus]::ShowWindowAsync($hwnd, $SW_RESTORE) | Out-Null
        [MaskeradeFocus]::SetWindowPos($hwnd, $HWND_TOPMOST, 0, 0, 0, 0, $SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_SHOWWINDOW) | Out-Null
        [MaskeradeFocus]::SetForegroundWindow($hwnd) | Out-Null
        $wscript.AppActivate($window.LocationName) | Out-Null
        Start-Sleep -Milliseconds 250
        [MaskeradeFocus]::SetWindowPos($hwnd, $HWND_NOTOPMOST, 0, 0, 0, 0, $SWP_NOMOVE -bor $SWP_NOSIZE -bor $SWP_SHOWWINDOW) | Out-Null
        [MaskeradeFocus]::SetForegroundWindow($hwnd) | Out-Null
        return
      }
    } catch {
    }
  }
}
"""
        env = os.environ.copy()
        env["PHOTOIA_OPEN_PATH"] = str(target)
        try:
            subprocess.Popen(
                ["powershell", "-NoProfile", "-STA", "-WindowStyle", "Hidden", "-Command", script],
                env=env,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            os.startfile(str(target))  # type: ignore[attr-defined]

    def _pick_folder(self, current: str) -> str:
        if os.name == "nt":
            return self._pick_folder_with_powershell(current)
        try:
            import tkinter as tk
            from tkinter import filedialog
        except Exception:
            return self._pick_folder_with_powershell(current)

        initial = _initial_directory(
            _resolve_ui_path(current, self.server.root_dir),
            self.server.root_dir,
        )
        root = _dialog_root(tk)
        try:
            selected = filedialog.askdirectory(parent=root, initialdir=str(initial))
        finally:
            root.destroy()
        return selected or current

    def _pick_file(self, current: str, kind: str, park_name: str) -> str:
        settings = load_settings(self.server.config_path)
        park = settings.get_park(park_name)
        kind = kind.lower()
        if kind == "background":
            fallback_dir = settings.root_dir / "assets" / "backgrounds"
            filetypes = [
                ("Imagenes", "*.jpg *.jpeg *.png *.webp"),
                ("JPG", "*.jpg *.jpeg"),
                ("PNG", "*.png"),
                ("Todos", "*.*"),
            ]
        elif kind == "overlay":
            fallback_dir = settings.root_dir / "assets" / "overlays"
            filetypes = [("PNG", "*.png"), ("Todos", "*.*")]
        elif kind == "logo":
            fallback_dir = settings.root_dir / "assets" / "logos"
            filetypes = [("PNG", "*.png"), ("Todos", "*.*")]
        else:
            raise PanelError(f"Tipo de selector no soportado: {kind}")

        current_path = _resolve_ui_path(current, settings.root_dir) if current else fallback_dir
        initial = _initial_directory(current_path, fallback_dir)

        if os.name == "nt":
            return self._pick_file_with_powershell(current, kind, initial, settings.root_dir)

        try:
            import tkinter as tk
            from tkinter import filedialog
        except Exception:
            return self._pick_file_with_powershell(current, kind, initial, settings.root_dir)

        root = _dialog_root(tk)
        try:
            selected = filedialog.askopenfilename(
                parent=root,
                initialdir=str(initial),
                title="Seleccionar fondo" if kind == "background" else "Seleccionar logo" if kind == "logo" else "Seleccionar overlay",
                filetypes=filetypes,
            )
        finally:
            root.destroy()

        if not selected:
            return current
        return _relative_for_config(Path(selected), settings.root_dir)

    def _pick_file_with_powershell(
        self,
        current: str,
        kind: str,
        initial: Path,
        root_dir: Path,
    ) -> str:
        filter_value = (
            "Imagenes|*.jpg;*.jpeg;*.png;*.webp|JPG|*.jpg;*.jpeg|PNG|*.png|Todos|*.*"
            if kind == "background"
            else "PNG|*.png|Todos|*.*"
        )
        script = """
Add-Type -AssemblyName System.Windows.Forms
$form = New-Object System.Windows.Forms.Form
$form.TopMost = $true
$form.StartPosition = 'CenterScreen'
$form.Width = 1
$form.Height = 1
$form.ShowInTaskbar = $false
$form.Show()
$form.Activate()
$dialog = New-Object System.Windows.Forms.OpenFileDialog
$dialog.InitialDirectory = $env:PHOTOIA_INITIAL_DIR
$dialog.Filter = $env:PHOTOIA_FILTER
if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Out.Write($dialog.FileName)
}
$form.Close()
"""
        env = os.environ.copy()
        env["PHOTOIA_INITIAL_DIR"] = str(initial)
        env["PHOTOIA_FILTER"] = filter_value
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-STA", "-Command", script],
                capture_output=True,
                env=env,
                text=True,
                timeout=300,
            )
        except Exception as exc:
            raise PanelError(
                "No se pudo abrir el selector nativo. Puedes pegar la ruta manualmente."
            ) from exc
        if result.returncode != 0:
            raise PanelError(
                "El selector de archivos de Windows no se pudo abrir. "
                "Puedes pegar la ruta manualmente."
            )
        selected = result.stdout.strip()
        if not selected:
            return current
        return _relative_for_config(Path(selected), root_dir)

    def _pick_folder_with_powershell(self, current: str) -> str:
        initial = _resolve_ui_path(current, self.server.root_dir)
        script = """
Add-Type -AssemblyName System.Windows.Forms
$form = New-Object System.Windows.Forms.Form
$form.TopMost = $true
$form.StartPosition = 'CenterScreen'
$form.Width = 1
$form.Height = 1
$form.ShowInTaskbar = $false
$form.Show()
$form.Activate()
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.SelectedPath = $env:PHOTOIA_INITIAL_DIR
$dialog.Description = 'Seleccionar carpeta'
if ($dialog.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
  [Console]::Out.Write($dialog.SelectedPath)
}
$form.Close()
"""
        env = os.environ.copy()
        env["PHOTOIA_INITIAL_DIR"] = str(initial if initial.exists() else self.server.root_dir)
        try:
            result = subprocess.run(
                ["powershell", "-NoProfile", "-STA", "-Command", script],
                capture_output=True,
                env=env,
                text=True,
                timeout=300,
            )
        except Exception as exc:
            raise PanelError(
                "No se pudo abrir el selector nativo. Puedes pegar la ruta manualmente."
            ) from exc
        if result.returncode != 0:
            raise PanelError(
                "El selector de carpetas de Windows no se pudo abrir. "
                "Puedes pegar la ruta manualmente."
            )
        return result.stdout.strip() or current

    def _tail_logs(self, limit: int) -> list[str]:
        settings = load_settings(self.server.config_path)
        log_path = settings.logs.jsonl_path
        if not log_path.exists():
            return []
        lines = log_path.read_text(encoding="utf-8").splitlines()
        return lines[-max(1, min(limit, 500)) :]

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(length)

    def _read_json(self) -> dict[str, Any]:
        body = self._read_body()
        if not body:
            return {}
        return json.loads(body.decode("utf-8-sig"))

    def _send_text(
        self,
        text: str,
        content_type: str,
        status: HTTPStatus = HTTPStatus.OK,
    ) -> None:
        payload = text.encode("utf-8")
        self.send_response(status.value)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.wfile.write(payload)

    def _send_json(
        self,
        data: dict[str, Any],
        status: HTTPStatus = HTTPStatus.OK,
    ) -> None:
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status.value)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.end_headers()
        self.wfile.write(payload)

    def _send_exception(self, exc: Exception) -> None:
        if isinstance(exc, PanelError):
            self._send_json({"error": str(exc)}, exc.status)
            return
        if isinstance(exc, ConfigurationError):
            self._send_json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            return
        self._send_json(
            {"error": f"{exc.__class__.__name__}: {exc}"},
            HTTPStatus.INTERNAL_SERVER_ERROR,
        )


def run_panel(
    config_path: str | Path = "config/settings.json",
    host: str = "127.0.0.1",
    port: int = 8765,
) -> None:
    server = PanelServer((host, port), PanelRequestHandler, config_path)
    url = f"http://{host}:{server.server_port}"
    print(f"Maskerade panel listening on {url}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Stopping panel")
    finally:
        server.server_close()


def _one(query: dict[str, list[str]], key: str) -> str:
    value = query.get(key, [""])[0]
    if not value:
        raise PanelError(f"Falta parametro: {key}")
    return value


def _optional_int(value: object) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return int(text)
    except ValueError as exc:
        raise PanelError(f"Parametro numerico no valido: {text}") from exc


def _count_images(directory: Path) -> int:
    return len(list_images(directory))


def _first_image_name(directory: Path) -> str | None:
    images = list_images(directory)
    if not images:
        return None
    try:
        return str(images[0].relative_to(directory)).replace("\\", "/")
    except ValueError:
        return images[0].name


def _file_signature(path: Path | None) -> tuple[str, int, int] | None:
    if not path:
        return None
    try:
        stat = path.stat()
    except OSError:
        return None
    return str(path.resolve()), stat.st_size, stat.st_mtime_ns


def _preview_cache_key(config_path: Path, park: Any, first_photo: Path | None) -> tuple:
    config_sig = _file_signature(config_path)
    background_sig = _file_signature(park.background_path)
    overlay_sig = _file_signature(park.overlay_path)
    logo_sig = _file_signature(park.logo_path)
    photo_sig = _file_signature(first_photo)
    return (
        config_sig,
        park.name,
        background_sig,
        overlay_sig,
        logo_sig,
        photo_sig,
        str(park.output_size),
        str(park.person),
        str(park.overlay_settings),
        str(park.logo_settings),
    )


def _preview_size(size: tuple[int, int], max_side: int) -> tuple[int, int]:
    width, height = size
    longest = max(width, height)
    if longest <= max_side:
        return width, height
    scale = max_side / longest
    return max(1, round(width * scale)), max(1, round(height * scale))


def _resize_for_preview(image: Any, max_side: int) -> tuple[Any, float]:
    new_size = _preview_size(image.size, max_side)
    if new_size == image.size:
        return image, 1.0
    scale = new_size[0] / max(1, image.width)
    return image.resize(new_size, Image.Resampling.LANCZOS), scale


def _scaled_int(value: int, scale: float, minimum: int = 1) -> int:
    return max(minimum, int(round(value * scale)))


def _scaled_overlay_settings(settings: Any, scale: float) -> Any:
    if scale >= 0.999:
        return settings
    overlay_scale = settings.scale
    if settings.mode.lower() in {"original", "source", "native"}:
        overlay_scale = settings.scale * scale
    return replace(
        settings,
        x=_scaled_int(settings.x, scale, 0),
        y=_scaled_int(settings.y, scale, 0),
        scale=overlay_scale,
    )


def _asset_entries(
    directory: Path,
    root_dir: Path,
    allowed: set[str],
    name_filter: str | None = None,
) -> list[dict[str, str]]:
    if not directory.exists():
        return []
    entries = []
    for path in sorted(directory.iterdir(), key=lambda item: item.name.lower()):
        if not path.is_file() or path.suffix.lower() not in allowed:
            continue
        if name_filter and name_filter.lower() not in path.stem.lower():
            continue
        relative = _relative_for_config(path, root_dir)
        entries.append(
            {
                "name": path.name,
                "path": relative,
                "url": f"/api/asset-preview?path={quote(relative)}",
            }
        )
    return entries


def _safe_filename(filename: str) -> str:
    name = Path(filename).name.strip()
    if not name:
        raise PanelError("Nombre de archivo invalido")
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name)
    return name[:160]


def _ensure_extension(filename: str, allowed: set[str]) -> None:
    suffix = Path(filename).suffix.lower()
    if suffix not in allowed:
        allowed_list = ", ".join(sorted(allowed))
        raise PanelError(f"Extension no permitida '{suffix}'. Permitidas: {allowed_list}")


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for index in range(1, 10000):
        candidate = path.with_name(f"{path.stem}_{index:03d}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise PanelError(f"No se pudo crear un nombre unico para {path}")


def _relative_for_config(path: Path, root_dir: Path) -> str:
    try:
        return path.resolve().relative_to(root_dir.resolve()).as_posix()
    except ValueError:
        return str(path)


def _resolve_ui_path(value: str, root_dir: Path) -> Path:
    path = Path(value.strip() or root_dir)
    if path.is_absolute():
        return path
    return root_dir / path


def normalize_path(value: str) -> str:
    return value.replace("\\", "/").strip().lower()


def _is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _initial_directory(path: Path, fallback: Path) -> Path:
    if path.exists() and path.is_dir():
        return path
    if path.exists() and path.is_file():
        return path.parent
    if path.suffix and path.parent.exists():
        return path.parent
    if fallback.exists():
        return fallback
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def _dialog_root(tk: Any) -> Any:
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    root.lift()
    root.focus_force()
    root.update()
    return root
