from __future__ import annotations

import argparse
import json
import os
import urllib.error
from pathlib import Path

from . import __version__
from .model_resources import (
    hybrid_settings_active,
    ResourceNetworkError,
    install_resource,
    load_resource_manifest,
    resource_status,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="maskerade-model-resources")
    parser.add_argument("command", choices=("status", "install"))
    parser.add_argument("--app-dir", type=Path, default=Path.cwd())
    parser.add_argument("--manifest-url", default=None)
    parser.add_argument("--version", default=__version__)
    args = parser.parse_args(argv)
    try:
        manifest = load_resource_manifest(args.manifest_url, expected_version=args.version)
        status = resource_status(args.app_dir, manifest)
        if args.command == "status":
            print(f"status={status}")
            print(f"resource={manifest.resource}")
            print(f"version={manifest.version}")
            print(f"archive_bytes={manifest.archive_size}")
            print(f"parts={len(manifest.parts)}")
            print(f"configured={str(hybrid_settings_active(args.app_dir)).lower()}")
            return 0

        def report(percent: int, phase: str, message: str) -> None:
            safe_message = str(message).replace("|", "-").replace("\r", " ").replace("\n", " ")
            print(f"resource_progress={percent}|{phase}|{safe_message}", flush=True)

        target = install_resource(args.app_dir, manifest, progress=report)
        print("status=installed", flush=True)
        print(f"installed_path={target}", flush=True)
        return 0
    except urllib.error.HTTPError as exc:
        if args.command == "status" and exc.code == 404:
            print("status=unavailable")
            return 0
        print(f"Resource error: el servidor devolvio HTTP {exc.code}.", file=os.sys.stderr)
        return 5
    except (ResourceNetworkError, RuntimeError, OSError, json.JSONDecodeError) as exc:
        if args.command == "status" and isinstance(exc, ResourceNetworkError):
            print("status=unavailable")
            return 0
        print(f"Resource error: {exc}", file=os.sys.stderr)
        return 5

    except Exception as exc:
        print(f"Resource error: {exc}", file=os.sys.stderr)
        return 5

if __name__ == "__main__":
    raise SystemExit(main())
