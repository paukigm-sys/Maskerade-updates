from __future__ import annotations

import argparse
import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import __version__
from src.config import ConfigurationError, load_settings
from src.logger import setup_logging


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="maskerade",
        description="Batch/watch pipeline for Maskerade photo composites.",
    )
    parser.add_argument(
        "--config",
        default="config/settings.json",
        help="Path to settings JSON. Default: config/settings.json",
    )
    parser.add_argument(
        "--park",
        default="photo",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--batch",
        action="store_true",
        help="Process all JPG files currently in the selected input folder.",
    )
    parser.add_argument(
        "--watch",
        action="store_true",
        help="Continuously watch the selected input folder.",
    )
    parser.add_argument(
        "--panel",
        action="store_true",
        help="Launch the local configuration and batch processing panel.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Panel host. Default: 127.0.0.1",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Panel port. Default: 8765",
    )
    parser.add_argument(
        "--file",
        type=Path,
        help="Process one specific JPG file using the selected profile settings.",
    )
    parser.add_argument(
        "--live-context",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--automatic-context",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--manual-search",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--skip-cloud",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--cloud-output",
        type=Path,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--cloud-input",
        type=Path,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--lab",
        action="store_true",
        help="Run an isolated Lab experiment without touching the production output.",
    )
    parser.add_argument(
        "--lab-engine",
        default="all",
        help="Lab engine to run: all, base, ic-light-pack, shadow-generation, or ssn-shadow. Default: all.",
    )
    parser.add_argument(
        "--lab-variants",
        type=int,
        default=1,
        help="Number of variants for heavy generative Lab engines. Default: 1.",
    )
    parser.add_argument(
        "--lab-input",
        type=Path,
        help="Optional JPG for Lab. If omitted, the first JPG in IN is used.",
    )
    parser.add_argument(
        "--lab-output",
        type=Path,
        help="Optional Lab output folder. Default: lab/output.",
    )
    parser.add_argument(
        "--no-initial-batch",
        action="store_true",
        help="In watch mode, do not process files already present at startup.",
    )
    parser.add_argument(
        "--watch-stop-file",
        type=Path,
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--list-parks",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--update-check",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--update-install",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--update-url",
        help=argparse.SUPPRESS,
    )
    parser.add_argument(
        "--update-pid",
        type=int,
        default=0,
        help=argparse.SUPPRESS,
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.update_check:
            from src.updater import check_for_update

            info = check_for_update(args.update_url)
            print(f"status={info.status}")
            print(f"current={info.current_version}")
            print(f"latest={info.latest_version}")
            print(f"url={info.url}")
            print(f"sha256={info.sha256}")
            print(f"notes={info.notes}")
            print(f"manifest={info.manifest_url}")
            return 0

        if args.update_install:
            import os

            from src.updater import install_update

            try:
                app_dir = load_settings(args.config).root_dir
            except ConfigurationError:
                app_dir = _root_dir_from_config_arg(args.config)
            script_path = install_update(
                app_dir,
                current_pid=args.update_pid or int(os.environ.get("MASKERADE_PID", "0") or "0"),
                url=args.update_url,
            )
            print(f"installer={script_path}")
            return 0

        settings = load_settings(args.config)
        if args.list_parks:
            for name in sorted(settings.parks):
                print(name)
            return 0

        if args.panel:
            from src.panel import run_panel

            run_panel(args.config, args.host, args.port)
            return 0

        selected_modes = sum(bool(value) for value in [args.batch, args.watch, args.file, args.lab, args.cloud_output])
        if selected_modes != 1:
            parser.error("Choose exactly one processing mode")

        park = settings.get_park(args.park)

        if args.lab:
            from src.lab_runner import run_lab

            run_lab(
                settings=settings,
                park=park,
                engine=args.lab_engine,
                input_path=args.lab_input,
                output_dir=args.lab_output,
                variants=args.lab_variants,
            )
            return 0

        processing_logger = setup_logging(
            settings.logs.directory,
            park.name,
            settings.logs.jsonl_path,
        )

        from src.processor import PhotoProcessor

        processor = PhotoProcessor(
            settings,
            park,
            processing_logger,
            force_live_context=bool(args.file and args.live_context),
            manual_search=bool(args.file and args.manual_search),
            strict_preset_context=bool(args.batch or args.watch or (args.file and args.automatic_context)),
            skip_cloud_delivery=bool(args.skip_cloud),
        )

        if args.cloud_output:
            result = processor.deliver_existing_output(
                args.cloud_output,
                args.cloud_input or args.cloud_output,
            )
            processor.shutdown(wait=True)
            if result.status in {"processed", "warning"}:
                print(f"Cloud delivered: {args.cloud_output}")
                return 0
            print(f"Cloud failed: {result.message or args.cloud_output}")
            return 1

        if args.batch:
            stats = processor.process_pending()
            processor.shutdown(wait=True)
            print(
                "Batch complete: "
                f"total={stats.total}, processed={stats.processed}, "
                f"failed={stats.failed}, skipped={stats.skipped}, "
                f"avg_seconds={stats.average_seconds:.2f}"
            )
            unarchived_failures = [
                result
                for result in stats.results
                if result.status == "failed" and result.failed_path is None
            ]
            return 0 if not unarchived_failures else 1

        if args.file:
            result = processor.process_file(
                args.file,
                wait_for_stability=not args.manual_search,
                archive_failed=not args.manual_search,
            )
            processor.shutdown(wait=True)
            if result.status == "processed":
                print(f"Processed: {result.output_path}")
                return 0
            if result.failed_path is not None:
                print(
                    "Moved to failed: "
                    f"{result.input_path.name} | {result.message or 'archivo corrupto'} | "
                    f"{result.failed_path}"
                )
                return 0
            print(f"Failed: {result.message or result.input_path}")
            return 1

        if args.watch:
            from src.watcher import WatchService

            process_existing = (
                settings.processing.process_existing_on_watch_start
                and not args.no_initial_batch
            )
            try:
                WatchService(
                    processor,
                    processing_logger.logger,
                    stop_file=args.watch_stop_file,
                ).run(process_existing)
            finally:
                processor.shutdown(wait=True)
            return 0

    except ConfigurationError as exc:
        print(f"Configuration error: {exc}", file=sys.stderr)
        return 2
    except ModuleNotFoundError as exc:
        print(
            "Missing dependency: "
            f"{exc.name}. Run: python -m pip install -r requirements.txt",
            file=sys.stderr,
        )
        return 3
    except KeyboardInterrupt:
        print("Interrupted")
        return 130
    except Exception as exc:
        if args.update_check or args.update_install:
            print(f"Update error: {exc}", file=sys.stderr)
            return 4
        raise

    return 0


def _root_dir_from_config_arg(path: str | Path) -> Path:
    config_path = Path(path).resolve()
    if config_path.parent.name.lower() == "config":
        return config_path.parent.parent
    return config_path.parent


if __name__ == "__main__":
    raise SystemExit(main())
