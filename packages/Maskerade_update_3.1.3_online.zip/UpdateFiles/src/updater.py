from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import shutil
import ssl
import stat
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from . import __version__


DEFAULT_MANIFEST_URL = (
    "https://api.github.com/repos/paukigm-sys/Maskerade-updates/contents/latest.json?ref=main"
)
MAX_MANIFEST_BYTES = 512 * 1024
MAX_UPDATE_DOWNLOAD_BYTES = 256 * 1024 * 1024
MAX_ZIP_ENTRIES = 4096
MAX_ZIP_MEMBER_BYTES = 128 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 512 * 1024 * 1024
MAX_ZIP_COMPRESSION_RATIO = 500.0


class UpdateNetworkError(RuntimeError):
    """Network failure presented to the desktop without a Python traceback."""


@dataclass(frozen=True)
class UpdateInfo:
    status: str
    current_version: str
    latest_version: str
    url: str
    sha256: str
    notes: str
    manifest_url: str


def manifest_url() -> str:
    return os.environ.get("MASKERADE_UPDATE_URL", DEFAULT_MANIFEST_URL).strip() or DEFAULT_MANIFEST_URL


def check_for_update(url: str | None = None, timeout_seconds: int = 12) -> UpdateInfo:
    selected_url = url or manifest_url()
    _require_https_url(selected_url, "manifest")
    try:
        payload = _download_text(
            _cache_busted_manifest_url(selected_url),
            timeout_seconds=timeout_seconds,
        )
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return UpdateInfo(
                status="current",
                current_version=__version__,
                latest_version=__version__,
                url="",
                sha256="",
                notes="No hay update remoto publicado todavia.",
                manifest_url=selected_url,
            )
        raise
    data = _decode_manifest_payload(payload)
    latest_version = str(data.get("version") or "").strip()
    update_url = str(data.get("url") or "").strip()
    sha256 = str(data.get("sha256") or "").strip().lower()
    notes = str(data.get("notes") or "").strip()

    if not latest_version:
        raise RuntimeError("El manifest remoto no tiene version.")
    status = "update_available" if _version_key(latest_version) > _version_key(__version__) else "current"
    if status == "update_available":
        if not update_url:
            raise RuntimeError("El manifest remoto no tiene url de descarga.")
        _require_https_url(update_url, "descarga")
        if re.fullmatch(r"[0-9a-f]{64}", sha256) is None:
            raise RuntimeError("El manifest remoto no tiene un SHA256 valido.")
    return UpdateInfo(
        status=status,
        current_version=__version__,
        latest_version=latest_version,
        url=update_url,
        sha256=sha256,
        notes=notes,
        manifest_url=selected_url,
    )


def install_update(app_dir: Path, current_pid: int | None = None, url: str | None = None) -> Path:
    info = check_for_update(url=url, timeout_seconds=20)
    if info.status != "update_available":
        raise RuntimeError(f"Ya tienes la ultima version: {info.current_version}")

    app_dir = Path(app_dir).resolve()
    work_dir = app_dir / "tmp" / "updates" / _safe_name(info.latest_version)
    extract_dir = work_dir / "extracted"
    zip_path = work_dir / "update.zip"

    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    _download_file(info.url, zip_path)
    digest = _sha256(zip_path)
    if digest.lower() != info.sha256.lower():
        raise RuntimeError(
            "El update descargado no coincide con el SHA256 esperado. "
            f"Esperado {info.sha256}, recibido {digest}."
        )

    _extract_validated_zip(zip_path, extract_dir)

    payload_dir = _find_payload_dir(extract_dir)
    if payload_dir is None:
        raise RuntimeError("El ZIP de update no contiene archivos de Maskerade validos.")

    script_path = work_dir / "apply_update.bat"
    _write_apply_script(script_path, app_dir, payload_dir, current_pid)
    _launch_detached(script_path)
    return script_path


def _download_text(url: str, timeout_seconds: int) -> str:
    _require_https_url(url, "manifest")
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Maskerade-Updater",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(
                request,
                timeout=timeout_seconds,
                context=_ssl_context(),
            ) as response:
                _require_https_response(response, "manifest")
                payload = response.read(MAX_MANIFEST_BYTES + 1)
                if len(payload) > MAX_MANIFEST_BYTES:
                    raise RuntimeError("El manifest remoto es demasiado grande.")
                return payload.decode("utf-8-sig")
        except urllib.error.HTTPError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            if attempt >= 3:
                raise UpdateNetworkError(
                    "No se pudo conectar con el servidor de actualizaciones. "
                    "Comprueba Internet y vuelve a intentarlo."
                ) from exc
            time.sleep(float(attempt))

    raise AssertionError("Bucle de descarga inalcanzable")


def _download_file(url: str, destination: Path) -> None:
    _require_https_url(url, "descarga")
    request = urllib.request.Request(url, headers={"User-Agent": "Maskerade-Updater"})
    partial = destination.with_suffix(destination.suffix + ".part")
    for attempt in range(1, 4):
        try:
            partial.unlink(missing_ok=True)
            with urllib.request.urlopen(request, timeout=90, context=_ssl_context()) as response:
                _require_https_response(response, "descarga")
                content_length = _response_content_length(response)
                if content_length is not None and content_length > MAX_UPDATE_DOWNLOAD_BYTES:
                    raise RuntimeError("El paquete de actualizacion supera el tamano permitido.")
                with partial.open("wb") as handle:
                    downloaded = 0
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        downloaded += len(chunk)
                        if downloaded > MAX_UPDATE_DOWNLOAD_BYTES:
                            raise RuntimeError("El paquete de actualizacion supera el tamano permitido.")
                        handle.write(chunk)
            partial.replace(destination)
            return
        except urllib.error.HTTPError:
            partial.unlink(missing_ok=True)
            raise
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            partial.unlink(missing_ok=True)
            if attempt >= 3:
                raise UpdateNetworkError(
                    "No se pudo descargar la actualizacion. "
                    "Comprueba Internet y vuelve a intentarlo."
                ) from exc
            time.sleep(float(attempt))

    raise AssertionError("Bucle de descarga inalcanzable")


def _require_https_url(url: str, label: str) -> None:
    parsed = urllib.parse.urlsplit(str(url or "").strip())
    if (
        parsed.scheme.casefold() != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
    ):
        raise RuntimeError(f"La URL de {label} debe usar HTTPS y no incluir credenciales.")


def _cache_busted_manifest_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.append(("maskerade_cache", str(time.time_ns())))
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(query), parsed.fragment)
    )


def _decode_manifest_payload(payload: str) -> dict[str, Any]:
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise RuntimeError("El manifest remoto no contiene un objeto JSON valido.")

    if str(data.get("encoding") or "").casefold() == "base64" and "content" in data:
        encoded = str(data.get("content") or "").replace("\n", "").strip()
        try:
            decoded = base64.b64decode(encoded, validate=True).decode("utf-8-sig")
            data = json.loads(decoded)
        except (binascii.Error, UnicodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("La API de actualizaciones devolvio un manifest no valido.") from exc
        if not isinstance(data, dict):
            raise RuntimeError("El manifest remoto no contiene un objeto JSON valido.")
    return data


def _require_https_response(response: Any, label: str) -> None:
    geturl = getattr(response, "geturl", None)
    if not callable(geturl):
        return
    final_url = geturl()
    if final_url:
        _require_https_url(str(final_url), label)


def _response_content_length(response: Any) -> int | None:
    headers = getattr(response, "headers", None)
    if headers is None:
        return None
    try:
        raw = headers.get("Content-Length")
    except (AttributeError, TypeError):
        return None
    if raw in (None, ""):
        return None
    try:
        return max(0, int(raw))
    except (TypeError, ValueError):
        return None


def _ssl_context() -> ssl.SSLContext | None:
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


def _version_key(value: str) -> tuple[Any, ...]:
    parts = re.findall(r"\d+|[a-zA-Z]+", value)
    key: list[Any] = []
    for part in parts:
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.casefold()))
    return tuple(key)


def _safe_name(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._")
    return safe or "update"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _extract_validated_zip(zip_path: Path, extract_dir: Path) -> None:
    try:
        with zipfile.ZipFile(zip_path) as archive:
            _validate_zip_entries(archive, extract_dir)
            archive.extractall(extract_dir)
    except zipfile.BadZipFile as exc:
        raise RuntimeError("El paquete de actualizacion no es un ZIP valido.") from exc


def _validate_zip_entries(archive: zipfile.ZipFile, extract_dir: Path) -> None:
    entries = archive.infolist()
    if not entries or len(entries) > MAX_ZIP_ENTRIES:
        raise RuntimeError("El ZIP de update tiene una cantidad de archivos no permitida.")

    root = extract_dir.resolve()
    seen: set[str] = set()
    total_size = 0
    for entry in entries:
        raw_name = entry.filename
        if not raw_name or "\\" in raw_name or "\x00" in raw_name:
            raise RuntimeError("El ZIP de update contiene una ruta no valida.")
        path = PurePosixPath(raw_name)
        if path.is_absolute() or any(part in {"", ".", ".."} or ":" in part for part in path.parts):
            raise RuntimeError("El ZIP de update contiene una ruta no segura.")

        key = "/".join(path.parts).rstrip("/").casefold()
        if key in seen:
            raise RuntimeError("El ZIP de update contiene rutas duplicadas.")
        seen.add(key)

        target = (root / Path(*path.parts)).resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise RuntimeError("El ZIP de update intenta escribir fuera de su carpeta.") from exc

        mode = (entry.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(mode) or entry.flag_bits & 0x1:
            raise RuntimeError("El ZIP de update contiene enlaces o archivos cifrados no permitidos.")
        if entry.is_dir():
            continue
        if entry.file_size < 0 or entry.file_size > MAX_ZIP_MEMBER_BYTES:
            raise RuntimeError("El ZIP de update contiene un archivo demasiado grande.")
        total_size += entry.file_size
        if total_size > MAX_ZIP_TOTAL_BYTES:
            raise RuntimeError("El ZIP de update supera el tamano descomprimido permitido.")
        if entry.file_size and entry.compress_size == 0:
            raise RuntimeError("El ZIP de update contiene una relacion de compresion no valida.")
        if entry.compress_size and entry.file_size / entry.compress_size > MAX_ZIP_COMPRESSION_RATIO:
            raise RuntimeError("El ZIP de update contiene una relacion de compresion sospechosa.")


def _find_payload_dir(root: Path) -> Path | None:
    direct = root / "UpdateFiles"
    if direct.exists() and direct.is_dir():
        return direct
    for path in root.rglob("UpdateFiles"):
        if path.is_dir():
            return path
    if _looks_like_payload_dir(root):
        return root
    for path in root.iterdir():
        if path.is_dir() and _looks_like_payload_dir(path):
            return path
    return None


def _looks_like_payload_dir(path: Path) -> bool:
    return (path / "src").is_dir() and ((path / "main.py").is_file() or (path / "Maskerade.exe").is_file())


def _write_apply_script(
    script_path: Path,
    app_dir: Path,
    payload_dir: Path,
    current_pid: int | None,
) -> None:
    backup_stamp = "%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%"

    script = f"""@echo off
setlocal EnableExtensions
title Actualizando Maskerade
color 0B
set "DST={app_dir}"
set "SRC={payload_dir}"
set "STAMP={backup_stamp}"
set "STAMP=%STAMP: =0%"
set "BACKUP=%DST%\\_backup_online_update_%STAMP%"
set "LOG=%DST%\\logs\\online_update.log"
if not exist "%DST%\\logs" mkdir "%DST%\\logs" >nul 2>nul

echo.
echo === Maskerade - Actualizacion online ===
echo.
echo === Maskerade online update %DATE% %TIME% === > "%LOG%"
echo DST=%DST% >> "%LOG%"
echo SRC=%SRC% >> "%LOG%"
echo Esperando cierre de Maskerade...
echo Esperando cierre de Maskerade... >> "%LOG%"
timeout /t 2 /nobreak >nul
"%DST%\\.runtime\\python311\\python.exe" "%SRC%\\src\\update_runtime.py" --stop "%DST%" >> "%LOG%" 2>>&1
if errorlevel 1 (
    echo ERROR: No se pudieron cerrar los procesos de Maskerade. No se ha copiado el update.
    echo Revisa: %LOG%
    pause
    exit /b 1
)

if not exist "%SRC%" (
    echo ERROR: No encuentro la carpeta de update:
    echo %SRC%
    echo ERROR: No encuentro la carpeta de update: %SRC% >> "%LOG%"
    pause
    exit /b 1
)

mkdir "%BACKUP%" >nul 2>nul
for %%F in (Maskerade.exe PhotoIA.exe maskerade.ico desktop_bridge.py main.py Abrir_Maskerade.bat) do (
    if exist "%DST%\\%%F" copy /Y "%DST%\\%%F" "%BACKUP%\\%%F" >nul
)
if exist "%DST%\\src" (
    mkdir "%BACKUP%\\src" >nul 2>nul
    xcopy "%DST%\\src" "%BACKUP%\\src\\" /E /I /Y >nul
)
if exist "%DST%\\config" (
    mkdir "%BACKUP%\\config" >nul 2>nul
    xcopy "%DST%\\config" "%BACKUP%\\config\\" /E /I /Y >nul
)

echo Copiando update...
echo Copiando update... >> "%LOG%"
set "COPY_OK=0"
set "COPY_ATTEMPT=0"
:copy_attempt
set /a COPY_ATTEMPT+=1 >nul
xcopy "%SRC%" "%DST%\\" /E /I /Y >> "%LOG%" 2>>&1
set "COPY_ERROR=%ERRORLEVEL%"
if "%COPY_ERROR%"=="0" (
    set "COPY_OK=1"
    goto copy_done
)
echo Copia fallida %COPY_ATTEMPT%/3, codigo %COPY_ERROR% >> "%LOG%"
if %COPY_ATTEMPT% GEQ 3 goto copy_done
echo Reintentando copia... %COPY_ATTEMPT%/3
timeout /t 2 /nobreak >nul
goto copy_attempt
:copy_done
if not "%COPY_OK%"=="1" (
    echo ERROR: No se pudo copiar el update. Revisa:
    echo %LOG%
    echo ERROR: xcopy fallo con codigo %COPY_ERROR% >> "%LOG%"
    pause
    exit /b 1
)

echo Limpiando componentes antiguos...
echo Limpiando componentes antiguos... >> "%LOG%"
rmdir /s /q "%DST%\\branding" >> "%LOG%" 2>>&1
rmdir /s /q "%DST%\\assets\\branding" >> "%LOG%" 2>>&1
rmdir /s /q "%DST%\\src\\enhancer2" >> "%LOG%" 2>>&1
del /f /q "%DST%\\config\\enhancer2_presets.json" >> "%LOG%" 2>>&1

echo Migrando configuracion local a profile.cache...
echo Migrando configuracion local a profile.cache... >> "%LOG%"
set "MASKERADE_LEGACY_SRC=%BACKUP%\\src"
"%DST%\\.runtime\\python311\\python.exe" "%DST%\\desktop_bridge.py" secure_migrate >> "%LOG%" 2>>&1
if errorlevel 1 (
    echo ERROR: No pude migrar la configuracion local a profile.cache.
    echo El update ya esta copiado, pero no abro Maskerade para no dejar configuracion visible a medias.
    echo Revisa:
    echo %LOG%
    echo ERROR: secure_migrate fallo con codigo %ERRORLEVEL%; update detenido para proteger settings.json >> "%LOG%"
    pause
    exit /b 1
) else (
    set "MASKERADE_LEGACY_SRC="
    del /f /q "%DST%\\config\\settings.json" >> "%LOG%" 2>>&1
    del /f /q "%DST%\\config\\settings.tmp.json" >> "%LOG%" 2>>&1
    del /f /q "%DST%\\config\\settings_snapshot_*.json" >> "%LOG%" 2>>&1
)

echo.
echo Update instalado.
echo Backup:
echo %BACKUP%
echo.
echo Update instalado correctamente. Backup=%BACKUP% >> "%LOG%"
start "" "%DST%\\Maskerade.exe"
echo Abriendo Maskerade...
timeout /t 4 /nobreak >nul
endlocal
"""
    script_path.write_text(script, encoding="ascii")


def _launch_detached(script_path: Path) -> None:
    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NEW_CONSOLE
    subprocess.Popen(
        ["cmd.exe", "/c", str(script_path)],
        cwd=str(script_path.parent),
        creationflags=creationflags,
        close_fds=True,
    )
