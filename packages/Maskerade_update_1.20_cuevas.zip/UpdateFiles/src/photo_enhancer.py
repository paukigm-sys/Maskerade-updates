from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np
from PIL import Image, ImageEnhance, ImageOps

try:
    import cv2
except Exception:  # pragma: no cover - optional runtime fallback
    cv2 = None

if TYPE_CHECKING:
    from .config import PhotoEnhanceSettings

try:
    from .enhancer2 import enhance_image
    from .enhancer2.output import attach_report
except Exception:  # pragma: no cover - keeps the classic fallback available
    enhance_image = None
    attach_report = None


def enhance_photo(
    image: Image.Image,
    settings: "PhotoEnhanceSettings",
    logger: logging.Logger | None = None,
) -> Image.Image:
    """Apply local QEnhancer-style finishing to the final composited photo."""

    engine = str(getattr(settings, "engine", "classic") or "classic").strip().lower()
    autotune = bool(getattr(settings, "autotune", False)) or engine in {"autotune", "autopilot", "auto_tune"}
    if engine in {"none", "off", "disabled"}:
        return image
    if engine in {"enhancer2", "qenhance_auto_v2", "auto_v2", "v2", "autotune", "autopilot", "auto_tune"}:
        try:
            if enhance_image is None:
                raise RuntimeError("enhancer2 module is not available")
            result = enhance_image(
                image,
                preset_name=str(getattr(settings, "preset", "default_event") or "default_event"),
                strength=1.0,
                root_dir=Path.cwd(),
                autotune=autotune,
            )
            return result.image
        except Exception as exc:
            if logger is not None:
                logger.warning("QEnhance Auto v2 failed; using classic fallback: %s", exc)
            fallback_started = time.perf_counter()
            fallback = _enhance_classic(image, settings, 1.0, logger=logger)
            if attach_report is not None:
                fallback = attach_report(
                    fallback,
                    {
                        "engine": "enhancer2",
                        "engine_label": "QEnhance Auto v2",
                        "status": "failed_fallback_classic",
                        "preset": str(getattr(settings, "preset", "default_event") or "default_event"),
                        "requested_strength": 1.0,
                        "fallback_used": True,
                        "fallback_engine": "classic",
                        "error": str(exc),
                        "processing_ms": int(round((time.perf_counter() - fallback_started) * 1000)),
                    },
                )
            return fallback

    return _enhance_classic(image, settings, 1.0, logger=logger)


def _enhance_classic(
    image: Image.Image,
    settings: "PhotoEnhanceSettings",
    strength: float,
    logger: logging.Logger | None = None,
) -> Image.Image:
    try:
        if cv2 is None:
            return _enhance_pillow(image, settings, strength)
        return _enhance_cv(image, settings, strength)
    except Exception as exc:
        if logger is not None:
            logger.warning("Photo enhancer skipped: %s", exc)
        return image


def _enhance_pillow(image: Image.Image, settings: "PhotoEnhanceSettings", strength: float) -> Image.Image:
    result = image.convert("RGB")
    result = ImageOps.autocontrast(result, cutoff=max(0, min(3, int(2 * strength))))
    result = ImageEnhance.Color(result).enhance(1.0 + (float(settings.saturation) / 100.0) * strength)
    result = ImageEnhance.Contrast(result).enhance(1.0 + (float(settings.shadow_contrast + settings.highlight_contrast) / 220.0) * strength)
    result = ImageEnhance.Sharpness(result).enhance(1.0 + (float(settings.global_sharpen + settings.local_sharpen) / 140.0) * strength)
    return result


def _enhance_cv(image: Image.Image, settings: "PhotoEnhanceSettings", strength: float) -> Image.Image:
    src = np.asarray(image.convert("RGB")).astype(np.float32)
    original = src.copy()

    luminance = _luminance(src)
    black_preserve = _smoothstep(0.0, 34.0, luminance)
    highlight_preserve = 1.0 - _smoothstep(210.0, 252.0, luminance)
    editable = (0.25 + 0.75 * black_preserve) * (0.35 + 0.65 * highlight_preserve)

    src = _auto_brightness(src, settings, strength, editable)
    src = _qenhancer_tone(src, settings, strength, editable)
    src = _shadow_highlight_balance(src, settings, strength, editable)
    src = _clahe_luminance(src, settings, strength)
    src = _gray_world(src, settings, strength)
    src = _channel_balance(src, settings, strength)
    src = _rotate_hue_and_saturate(src, settings, strength)
    src = _desaturate_shadows(src, settings, strength)
    src = _denoise(src, settings, strength)
    src = _sharpen(src, settings, strength)

    # Preserve deep blacks and hot whites from the input so the correction feels
    # like photo finishing, not a gray wash.
    lum = _luminance(original)
    keep_black = 1.0 - _smoothstep(15.0, 54.0, lum)
    keep_white = _smoothstep(226.0, 252.0, lum) * 0.45
    keep = np.clip(keep_black * 0.58 + keep_white, 0.0, 0.78)[..., None]
    src = src * (1.0 - keep) + original * keep

    return Image.fromarray(np.clip(src, 0, 255).astype(np.uint8), "RGB")


def _auto_brightness(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    amount = max(0.0, float(settings.auto_brightness)) / 100.0 * strength
    if amount <= 0:
        return rgb
    lum = _luminance(rgb)
    p1, p99 = np.percentile(lum, [1.0, 99.0])
    if p99 <= p1 + 1:
        return rgb
    stretched = (rgb - p1) * (255.0 / (p99 - p1))
    stretched = np.clip(stretched, 0, 255)
    blend = np.clip(0.26 * amount, 0, 0.52) * editable[..., None]
    return rgb * (1.0 - blend) + stretched * blend


def _qenhancer_tone(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    amount = max(0.0, float(settings.auto_brightness)) / 100.0 * strength
    if amount <= 0.001:
        return rgb

    lum = _luminance(rgb)
    median = float(np.percentile(lum, 50.0))
    p95 = float(np.percentile(lum, 95.0))
    lift_need = float(np.clip((105.0 - median) / 78.0, 0.0, 1.0))
    bright_scene = float(np.clip((median - 92.0) / 70.0, 0.0, 1.0))

    # Dark no-flash photos need midtones and upper mids lifted, while daylight
    # photos mostly need cleaner blacks. This curve gives that QEnhancer-like
    # bite without washing out already bright files.
    gamma = max(0.62, 1.0 - 0.34 * min(1.45, amount) * lift_need)
    curved = np.clip(255.0 * np.power(np.clip(rgb / 255.0, 0.0, 1.0), gamma), 0, 255)
    lift_blend = np.clip((0.20 + 0.28 * lift_need) * amount, 0.0, 0.62) * editable[..., None]
    out = rgb * (1.0 - lift_blend) + curved * lift_blend

    upper_mids = _smoothstep(96.0, 220.0, lum) * (1.0 - _smoothstep(242.0, 255.0, lum))
    out += (10.0 * lift_need * min(1.35, amount)) * upper_mids[..., None] * editable[..., None]

    out_lum = _luminance(out)
    deep_shadow = 1.0 - _smoothstep(18.0, 74.0, out_lum)
    black_push = 8.0 + 10.0 * bright_scene + 6.0 * lift_need
    out -= black_push * min(1.35, amount) * deep_shadow[..., None]

    if p95 < 220.0:
        highlight_push = _smoothstep(150.0, 235.0, out_lum) * (1.0 - _smoothstep(238.0, 255.0, out_lum))
        out += (6.0 * lift_need * min(1.35, amount)) * highlight_push[..., None]

    return np.clip(out, 0, 255)


def _shadow_highlight_balance(
    rgb: np.ndarray,
    settings: "PhotoEnhanceSettings",
    strength: float,
    editable: np.ndarray,
) -> np.ndarray:
    lum = _luminance(rgb)
    shadows = 1.0 - _smoothstep(34.0, 128.0, lum)
    mids = _smoothstep(25.0, 118.0, lum) * (1.0 - _smoothstep(190.0, 246.0, lum))
    highs = _smoothstep(150.0, 245.0, lum)

    shadow_lift = float(settings.shadows) / 100.0 * strength
    highlight_hold = float(settings.lights) / 100.0 * strength
    shadow_contrast = float(settings.shadow_contrast) / 100.0 * strength
    highlight_contrast = float(settings.highlight_contrast) / 100.0 * strength
    brightness = float(settings.brightness) / 100.0 * strength

    out = rgb.copy()
    out += (10.0 * shadow_lift + 20.0 * brightness) * shadows[..., None] * editable[..., None]
    out += (12.0 * brightness) * mids[..., None] * editable[..., None]
    out -= (5.0 * highlight_hold) * highs[..., None]

    mean = np.maximum(1.0, _luminance(out))[..., None]
    contrast_gain = 1.0 + (0.13 * shadow_contrast * shadows + 0.10 * highlight_contrast * highs)[..., None]
    out = mean + (out - mean) * contrast_gain
    return np.clip(out, 0, 255)


def _clahe_luminance(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.memory_color)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    lab = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    clip = 1.2 + 1.7 * min(1.0, amount)
    clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=(8, 8))
    enhanced_l = clahe.apply(l_channel)
    blend = min(0.42, 0.20 * amount)
    l_channel = cv2.addWeighted(l_channel, 1.0 - blend, enhanced_l, blend, 0)
    merged = cv2.merge([l_channel, a_channel, b_channel])
    return cv2.cvtColor(merged, cv2.COLOR_LAB2RGB).astype(np.float32)


def _gray_world(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.auto_color)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    means = np.mean(np.clip(rgb, 1, 255), axis=(0, 1))
    gray = float(np.mean(means))
    gains = np.clip(gray / np.maximum(means, 1.0), 0.82, 1.18)
    blend = min(0.38, 0.16 * amount)
    corrected = np.clip(rgb * gains[None, None, :], 0, 255)
    return rgb * (1.0 - blend) + corrected * blend


def _channel_balance(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    offsets = np.array([settings.red, settings.green, settings.blue], dtype=np.float32) * 0.55 * strength
    gains = 1.0 + np.array([settings.red, settings.green, settings.blue], dtype=np.float32) * 0.0022 * strength
    return np.clip(rgb * gains[None, None, :] + offsets[None, None, :], 0, 255)


def _rotate_hue_and_saturate(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    hsv[..., 0] = (hsv[..., 0] + float(settings.hue_rotation) * 0.5 * strength) % 180.0
    sat_gain = 1.0 + float(settings.saturation) / 100.0 * 0.65 * strength
    hsv[..., 1] = np.clip(hsv[..., 1] * sat_gain, 0, 255)
    return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)


def _desaturate_shadows(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.desaturate_shadows)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    shadow = 1.0 - _smoothstep(35.0, 125.0, hsv[..., 2])
    hsv[..., 1] *= 1.0 - np.clip(0.45 * amount * shadow, 0, 0.55)
    return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)


def _denoise(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.denoise)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    h = max(1, int(round(2 + 5 * min(1.0, amount))))
    denoised = cv2.fastNlMeansDenoisingColored(np.clip(rgb, 0, 255).astype(np.uint8), None, h, h, 5, 15)
    blend = min(0.55, 0.22 * amount)
    return rgb * (1.0 - blend) + denoised.astype(np.float32) * blend


def _sharpen(rgb: np.ndarray, settings: "PhotoEnhanceSettings", strength: float) -> np.ndarray:
    amount = max(0.0, float(settings.global_sharpen + settings.local_sharpen)) / 100.0 * strength
    if amount <= 0.001:
        return rgb
    blur = cv2.GaussianBlur(rgb, (0, 0), 1.15)
    sharpened = np.clip(rgb + (rgb - blur) * (0.38 * amount), 0, 255)
    return sharpened


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)
