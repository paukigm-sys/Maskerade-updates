from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any


class ProcessingLogger:
    def __init__(self, logger: logging.Logger, jsonl_path: Path) -> None:
        self.logger = logger
        self.jsonl_path = jsonl_path
        self.jsonl_path.parent.mkdir(parents=True, exist_ok=True)

    def photo_result(self, payload: dict[str, Any]) -> None:
        payload = {"timestamp": datetime.now().isoformat(timespec="seconds"), **payload}
        line = json.dumps(payload, ensure_ascii=False) + "\n"
        try:
            with self.jsonl_path.open("a", encoding="utf-8") as f:
                f.write(line)
        except OSError as exc:
            fallback = self.jsonl_path.with_name(
                f"{self.jsonl_path.stem}_{datetime.now():%Y%m%d_%H%M%S}"
                f"{self.jsonl_path.suffix or '.jsonl'}"
            )
            try:
                with fallback.open("a", encoding="utf-8") as f:
                    f.write(line)
                self.logger.warning("JSONL log locked, wrote fallback %s: %s", fallback, exc)
            except OSError as fallback_exc:
                self.logger.warning(
                    "JSONL log disabled; primary=%s fallback=%s",
                    exc,
                    fallback_exc,
                )


def setup_logging(
    log_dir: Path,
    park: str | None = None,
    jsonl_path: Path | None = None,
) -> ProcessingLogger:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("photoia")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    suffix = f"_{park}" if park else ""
    log_file = log_dir / f"photoia{suffix}_{datetime.now():%Y%m%d}.log"

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    try:
        file_handler: logging.Handler = logging.FileHandler(log_file, encoding="utf-8")
    except OSError as first_exc:
        log_file = log_dir / f"photoia{suffix}_{datetime.now():%Y%m%d_%H%M%S}.log"
        try:
            file_handler = logging.FileHandler(log_file, encoding="utf-8")
        except OSError as second_exc:
            file_handler = logging.NullHandler()
            logger.warning("File log disabled; primary=%s fallback=%s", first_exc, second_exc)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return ProcessingLogger(logger, jsonl_path or log_dir / "processing.jsonl")
