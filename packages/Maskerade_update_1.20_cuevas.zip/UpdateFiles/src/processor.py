from __future__ import annotations

import fnmatch
import json
import logging
import os
import time
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps

from .background_removal import BackgroundRemover
from .compositor import compose_image, harmonize_composed_image
from .config import AppSettings, BackgroundRemovalSettings, ConfigurationError, ParkSettings
from .image_utils import (
    list_images,
    move_to_directory,
    open_image,
    unique_path,
    wait_for_stable_file,
)
from .logger import ProcessingLogger
from .photo_enhancer import enhance_photo
from .enhancer2.output import report_from_image, write_enhancement_log
from .nuvol_module import process_output_photo


@dataclass(frozen=True)
class ProcessResult:
    status: str
    input_path: Path
    output_path: Path | None
    duration_seconds: float
    backend_used: str | None = None
    message: str | None = None


@dataclass(frozen=True)
class BatchStats:
    total: int
    processed: int
    failed: int
    skipped: int
    average_seconds: float
    results: list[ProcessResult]


@dataclass(frozen=True)
class ProcessingContext:
    park: ParkSettings
    background_removal: BackgroundRemovalSettings
    preset_name: str | None = None
    folder_name: str | None = None


class ProcessingBusyError(RuntimeError):
    """Raised when another batch/process is already touching the input folder."""


def _read_lock_pid(path: Path) -> int | None:
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("pid="):
                return int(line.split("=", 1)[1].strip())
    except Exception:
        return None
    return None


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        try:
            import ctypes

            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return True
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _lock_is_stale(path: Path, age_limit_seconds: float) -> bool:
    try:
        age = time.time() - path.stat().st_mtime
    except FileNotFoundError:
        return False
    if age > age_limit_seconds:
        return True

    pid = _read_lock_pid(path)
    if pid is not None and not _pid_is_running(pid):
        return True
    return False


class PhotoProcessor:
    def __init__(
        self,
        settings: AppSettings,
        park: ParkSettings,
        processing_logger: ProcessingLogger,
    ) -> None:
        self.settings = settings
        self.park = park
        self.processing_logger = processing_logger
        self.logger = processing_logger.logger
        self.remover = BackgroundRemover(settings.background_removal, self.logger)
        self._removers: dict[BackgroundRemovalSettings, BackgroundRemover] = {
            settings.background_removal: self.remover
        }
        self._preset_cache: dict[str, dict[str, Any]] = {}
        self._nuvol_executor = ThreadPoolExecutor(
            max_workers=self._nuvol_worker_count(settings),
            thread_name_prefix="maskerade-nuvol",
        )
        self._nuvol_futures: list[Future] = []

    def update_settings(self, settings: AppSettings, park: ParkSettings) -> None:
        reload_remover = settings.background_removal != self.settings.background_removal
        self.settings = settings
        self.park = park
        if reload_remover:
            self.remover = BackgroundRemover(settings.background_removal, self.logger)
        self._removers = {settings.background_removal: self.remover}
        self._preset_cache.clear()

    def ensure_ready(self, park: ParkSettings | None = None) -> None:
        selected = park or self.park
        if selected.background_path is not None and (
            not selected.background_path.exists() or not selected.background_path.is_file()
        ):
            raise ConfigurationError("No se ha detectado Fondo, por favor selecciona uno.")

    def process_pending(self) -> BatchStats:
        with self._processing_lock("batch"):
            images = list_images(self.park.input_dir)
            if not images:
                self.logger.info("No JPG files found in %s", self.park.input_dir)
                self.cleanup_empty_input_dirs()
                return BatchStats(0, 0, 0, 0, 0.0, [])

            self.logger.info("Processing %s file(s)", len(images))

            results = [self.process_file(path, acquire_lock=False) for path in images]
            processed = sum(1 for result in results if result.status == "processed")
            failed = sum(1 for result in results if result.status == "failed")
            skipped = sum(1 for result in results if result.status == "skipped")
            durations = [
                result.duration_seconds
                for result in results
                if result.status == "processed" and result.duration_seconds > 0
            ]
            average = sum(durations) / len(durations) if durations else 0.0
            self.cleanup_empty_input_dirs()
            self.wait_for_nuvol()
            return BatchStats(len(images), processed, failed, skipped, average, results)

    def process_file(
        self,
        input_path: Path,
        acquire_lock: bool = True,
        wait_for_stability: bool = True,
    ) -> ProcessResult:
        if acquire_lock:
            with self._processing_lock("file"):
                return self._process_file_unlocked(input_path, wait_for_stability=wait_for_stability)
        return self._process_file_unlocked(input_path, wait_for_stability=wait_for_stability)

    def _process_file_unlocked(self, input_path: Path, wait_for_stability: bool = True) -> ProcessResult:
        start = time.perf_counter()
        input_path = Path(input_path)
        output_path: Path | None = None
        backend_used: str | None = None
        phase_times: dict[str, float] = {}
        phase_started = start

        def mark_phase(name: str) -> None:
            nonlocal phase_started
            now = time.perf_counter()
            phase_times[name] = round(now - phase_started, 3)
            phase_started = now

        try:
            if input_path.suffix.lower() not in {".jpg", ".jpeg"}:
                return ProcessResult("skipped", input_path, None, 0.0, message="Not a JPG")

            context = self._context_for_input(input_path)
            self.ensure_ready(context.park)
            mark_phase("context")
            self.logger.info("Processing file: %s", input_path)
            if wait_for_stability:
                wait_for_stable_file(
                    input_path,
                    self.settings.file_stability.interval_seconds,
                    self.settings.file_stability.stable_checks,
                    self.settings.file_stability.timeout_seconds,
                )
            mark_phase("wait_stable")

            original = open_image(input_path)
            mark_phase("open")
            person_rgba = None
            backend_used = "original"
            if self._requires_background_removal(context.park):
                removal = self._remover_for(context.background_removal).remove_background(original)
                person_rgba = removal.person_rgba
                backend_used = removal.backend_used
                mark_phase("background_removal")
            else:
                self.logger.info(
                    "No background selected; skipping BEN2 and processing original photo: %s",
                    input_path.name,
                )
                mark_phase("background_removal")
            final = compose_image(
                original=original,
                person_rgba=person_rgba,
                park=context.park,
                logger=self.logger,
                apply_harmonize=False,
            )
            mark_phase("compose")
            final = enhance_photo(final, context.park.photo_enhance, logger=self.logger)
            mark_phase("enhance")
            final = harmonize_composed_image(final, original, person_rgba, context.park, logger=self.logger)
            mark_phase("harmonize")
            output_path = self._output_path_for(input_path, context.park)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            self._save_jpeg(final, output_path, input_path, context.park)
            mark_phase("save")
            enhancer_log_path = self._write_enhancer_log(final, input_path, output_path, context.park)
            mark_phase("enhancer_log")

            nuvol_status = None
            nuvol_warning = None
            if getattr(self.settings, "nuvol", None) is not None and self.settings.nuvol.enabled:
                self._submit_nuvol(output_path, input_path, context.park.output_dir)
                nuvol_status = "queued"
            mark_phase("nuvol")

            moved_to = None
            archive_warning = None
            move_original = self._move_original_to_processed_enabled(context.park)
            if move_original:
                try:
                    moved_to = move_to_directory(
                        input_path,
                        self._archive_dir_for(self.settings.processed_dir, input_path, context.park),
                    )
                except PermissionError as exc:
                    archive_warning = "Original no movido a processed porque otro proceso lo tiene bloqueado"
                    self.logger.warning("%s: %s (%s)", archive_warning, input_path, exc)
            mark_phase("archive")

            duration = time.perf_counter() - start
            phase_text = " ".join(f"{key}={value:.3f}s" for key, value in phase_times.items())
            self.logger.info("Timing %s: %s total=%.3fs", input_path.name, phase_text, duration)
            self.logger.info(
                "Processed %s -> %s in %.2fs using %s",
                input_path.name,
                output_path.name,
                duration,
                backend_used,
            )
            self.processing_logger.photo_result(
                {
                    "status": "processed",
                    "profile": context.park.name,
                    "folder_preset": context.preset_name,
                    "folder_name": context.folder_name,
                    "move_original_to_processed": move_original,
                    "input": str(input_path),
                    "output": str(output_path),
                    "moved_to": str(moved_to) if moved_to else None,
                    "archive_warning": archive_warning,
                    "nuvol_status": nuvol_status,
                    "nuvol_warning": nuvol_warning,
                    "enhancer2_log": str(enhancer_log_path) if enhancer_log_path else None,
                    "duration_seconds": round(duration, 3),
                    "phase_times": phase_times,
                    "backend": backend_used,
                }
            )
            return ProcessResult(
                "processed",
                input_path,
                output_path,
                duration,
                backend_used,
                message="; ".join([msg for msg in [archive_warning, nuvol_warning] if msg]) or None,
            )

        except ConfigurationError as exc:
            duration = time.perf_counter() - start
            self.logger.error("%s", exc)
            self.processing_logger.photo_result(
                {
                    "status": "configuration_error",
                    "profile": self.park.name,
                    "input": str(input_path),
                    "duration_seconds": round(duration, 3),
                    "error": str(exc),
                }
            )
            return ProcessResult(
                "failed",
                input_path,
                output_path,
                duration,
                backend_used,
                str(exc),
            )

        except Exception as exc:
            duration = time.perf_counter() - start
            failed_path = None
            if self.settings.processing.move_failed_to_failed and input_path.exists():
                try:
                    failed_path = move_to_directory(
                        input_path,
                        self._archive_dir_for(self.settings.failed_dir, input_path, self.park),
                    )
                except Exception:
                    self.logger.exception("Could not move failed file: %s", input_path)

            self.logger.exception("Failed processing %s: %s", input_path, exc)
            self.processing_logger.photo_result(
                {
                    "status": "failed",
                    "profile": self.park.name,
                    "input": str(input_path),
                    "failed_path": str(failed_path) if failed_path else None,
                    "output": str(output_path) if output_path else None,
                    "duration_seconds": round(duration, 3),
                    "backend": backend_used,
                    "error": str(exc),
                }
            )
            return ProcessResult(
                "failed",
                input_path,
                output_path,
                duration,
                backend_used,
                str(exc),
            )

    def wait_for_nuvol(self) -> None:
        self._collect_nuvol_futures(wait=True)

    def _requires_background_removal(self, park: ParkSettings) -> bool:
        return park.background_path is not None

    def poll_nuvol(self) -> None:
        self._collect_nuvol_futures(wait=False)

    def cleanup_completed_nuvol_outputs(self, park: ParkSettings | None = None) -> int:
        if getattr(self.settings, "nuvol", None) is None or not self.settings.nuvol.enabled:
            return 0

        selected = park or self.park
        output_dir = selected.output_dir.resolve()
        download_dir = Path(getattr(self.settings.nuvol, "download_dir", None) or (self.settings.root_dir / "nuvol_downloads"))
        processed_dir = self.settings.nuvol.processed_dir or (self.settings.processed_dir / "nuvol processed")
        cleaned = 0

        for output_path in list_images(output_dir):
            try:
                relative = output_path.resolve().relative_to(output_dir)
            except ValueError:
                continue

            downloaded = download_dir / relative
            archived = processed_dir / relative
            if not downloaded.exists() and not archived.exists():
                continue

            try:
                self._archive_output_after_nuvol(output_path, processed_dir, output_dir)
                cleaned += 1
            except PermissionError as exc:
                self.logger.warning("Could not archive completed Nuvol output because it is locked: %s (%s)", output_path, exc)

        if cleaned:
            self.cleanup_empty_output_dirs(output_dir)
        return cleaned

    def shutdown(self, wait: bool = True) -> None:
        if wait:
            self.wait_for_nuvol()
        self._nuvol_executor.shutdown(wait=wait, cancel_futures=not wait)

    def _submit_nuvol(self, output_path: Path, input_path: Path, output_dir: Path) -> None:
        self.poll_nuvol()
        settings = self.settings.nuvol
        root_dir = self.settings.root_dir
        future = self._nuvol_executor.submit(
            self._run_nuvol_job,
            Path(output_path),
            Path(input_path),
            settings,
            root_dir,
            settings.processed_dir or (self.settings.processed_dir / "nuvol processed"),
            output_dir,
        )
        self._nuvol_futures.append(future)

    def _run_nuvol_job(
        self,
        output_path: Path,
        input_path: Path,
        settings: Any,
        root_dir: Path,
        processed_dir: Path,
        output_dir: Path,
    ):
        try:
            result = process_output_photo(output_path, input_path, settings, root_dir, self.logger)
            if result.status in {"uploaded", "downloaded", "skipped"}:
                try:
                    self._archive_output_after_nuvol(output_path, processed_dir, output_dir)
                except PermissionError as exc:
                    self.logger.warning(
                        "Could not archive completed Nuvol output in processed; moving to failed/nuvol: %s (%s)",
                        output_path,
                        exc,
                    )
                    self._archive_failed_nuvol_output(output_path, output_dir)
                self.cleanup_empty_output_dirs(output_dir)
            else:
                self._archive_failed_nuvol_output(output_path, output_dir)
            return result
        except Exception as exc:
            print(f"NUVOL error {output_path.name}", flush=True)
            self.logger.exception("Nuvol module failed for %s: %s", output_path, exc)
            self._archive_failed_nuvol_output(output_path, output_dir)
            raise

    def _archive_output_after_nuvol(self, output_path: Path, processed_dir: Path, output_dir: Path) -> Path | None:
        if not output_path.exists():
            return None
        try:
            relative_parent = output_path.parent.resolve().relative_to(output_dir.resolve())
        except ValueError:
            relative_parent = Path()
        target_dir = processed_dir / relative_parent if str(relative_parent) != "." else processed_dir
        archived = move_to_directory(output_path, target_dir)
        self.logger.info("Nuvol archived output after completion: %s -> %s", output_path, archived)
        return archived

    def _archive_failed_nuvol_output(self, output_path: Path, output_dir: Path) -> Path | None:
        if not output_path.exists():
            return None
        try:
            relative_parent = output_path.parent.resolve().relative_to(output_dir.resolve())
        except ValueError:
            relative_parent = Path()
        target_root = self.settings.failed_dir / "nuvol"
        target_dir = target_root / relative_parent if str(relative_parent) != "." else target_root
        archived = move_to_directory(output_path, target_dir)
        self.logger.warning("Nuvol failed; archived temporary output: %s -> %s", output_path, archived)
        self.cleanup_empty_output_dirs(output_dir)
        return archived

    def cleanup_empty_output_dirs(self, output_dir: Path | None = None) -> int:
        selected_output_dir = (output_dir or self.park.output_dir).resolve()
        return self._cleanup_empty_dirs(selected_output_dir, "OUT")

    def _collect_nuvol_futures(self, wait: bool) -> None:
        pending: list[Future] = []
        for future in self._nuvol_futures:
            if wait or future.done():
                try:
                    future.result()
                except Exception:
                    pass
            else:
                pending.append(future)
        self._nuvol_futures = pending

    def _nuvol_worker_count(self, settings: AppSettings) -> int:
        raw = getattr(getattr(settings, "nuvol", None), "max_parallel_jobs", 2)
        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = 2
        return max(1, min(4, value))

    def _context_for_input(self, input_path: Path) -> ProcessingContext:
        folder_name = self._top_level_input_folder(input_path)
        if self._is_direct_photo_mode(self.park):
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )
        for candidate in self._preset_rule_candidates(input_path):
            for rule in self.settings.folder_preset_rules:
                if not rule.enabled:
                    continue
                if not self._name_matches_rule(candidate, rule.pattern):
                    continue

                preset_name = self._variant_preset_name(rule.preset, input_path)
                preset = self._load_folder_preset(preset_name)
                park = self._park_with_preset(self.park, preset)
                background_removal = self._background_removal_with_preset(
                    self.settings.background_removal,
                    preset,
                )
                self.logger.info(
                    "Folder/file preset matched: %s -> %s for %s by %s",
                    rule.pattern,
                    preset_name,
                    input_path,
                    candidate,
                )
                return ProcessingContext(
                    park=park,
                    background_removal=background_removal,
                    preset_name=preset_name,
                    folder_name=folder_name,
                )
        return self._active_preset_context(input_path, folder_name=folder_name)

    def _active_preset_context(self, input_path: Path, folder_name: str | None = None) -> ProcessingContext:
        active_preset = str(getattr(self.settings, "active_preset", "") or "").strip()
        if not active_preset:
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )

        preset_name = self._variant_preset_name(active_preset, input_path)
        if self._preset_stem(preset_name).casefold() == self._preset_stem(active_preset).casefold():
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                preset_name=preset_name,
                folder_name=folder_name,
            )
        if not self._preset_exists(preset_name):
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )

        preset = self._load_folder_preset(preset_name)
        return ProcessingContext(
            park=self._park_with_preset(self.park, preset),
            background_removal=self._background_removal_with_preset(
                self.settings.background_removal,
                preset,
                apply_desktop_mask=False,
            ),
            preset_name=preset_name,
            folder_name=folder_name,
        )

    def _is_direct_photo_mode(self, park: ParkSettings) -> bool:
        return (
            park.background_path is None
            and park.overlay_path is None
            and park.logo_path is None
        )

    def _top_level_input_folder(self, input_path: Path) -> str | None:
        try:
            relative = input_path.resolve().relative_to(self.park.input_dir.resolve())
        except ValueError:
            return None
        if len(relative.parts) < 2:
            return None
        return relative.parts[0]

    def _preset_rule_candidates(self, input_path: Path) -> tuple[str, ...]:
        candidates: list[str] = []
        folder_name = self._top_level_input_folder(input_path)
        if folder_name:
            candidates.append(folder_name)
        if input_path.stem:
            candidates.append(input_path.stem)
        if input_path.name and input_path.name != input_path.stem:
            candidates.append(input_path.name)

        unique: list[str] = []
        seen: set[str] = set()
        for candidate in candidates:
            folded = candidate.casefold()
            if folded in seen:
                continue
            seen.add(folded)
            unique.append(candidate)
        return tuple(unique)

    def _name_matches_rule(self, name: str, pattern: str) -> bool:
        candidate = name.casefold()
        expected = pattern.strip().casefold()
        if not expected:
            return False
        if any(char in expected for char in "*?[]"):
            return fnmatch.fnmatchcase(candidate, expected)
        return candidate.startswith(expected)

    def _load_folder_preset(self, preset_name: str) -> dict[str, Any]:
        if preset_name in self._preset_cache:
            return self._preset_cache[preset_name]

        filename = Path(preset_name).name
        if not filename.lower().endswith(".json"):
            filename = f"{filename}.json"
        path = self.settings.root_dir / "presets" / filename
        if not path.exists():
            raise ConfigurationError(f"Preset para carpeta no encontrado: {preset_name}")

        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise ConfigurationError(f"Preset para carpeta no es JSON valido: {preset_name}") from exc
        if not isinstance(payload, dict):
            raise ConfigurationError(f"Preset para carpeta no valido: {preset_name}")
        self._preset_cache[preset_name] = payload
        return payload

    def _variant_preset_name(self, preset_name: str, input_path: Path) -> str:
        suffix = self._orientation_suffix(input_path)
        if suffix is None:
            return preset_name

        base = self._variant_base_name(preset_name)
        variant = f"{base}_{suffix}"
        if self._preset_exists(variant):
            return variant
        return preset_name

    def _variant_base_name(self, preset_name: str) -> str:
        base = self._preset_stem(preset_name)
        folded = base.casefold()
        if folded.endswith("_h") or folded.endswith("_v"):
            family = base[:-2]
            if self._preset_exists(f"{family}_h") or self._preset_exists(f"{family}_v"):
                return family
        return base

    def _orientation_suffix(self, input_path: Path) -> str | None:
        try:
            with Image.open(input_path) as image:
                width, height = ImageOps.exif_transpose(image).size
        except OSError:
            return None
        if width <= 0 or height <= 0:
            return None
        return "v" if height > width else "h"

    def _preset_stem(self, preset_name: str) -> str:
        return Path(preset_name).stem

    def _preset_exists(self, preset_name: str) -> bool:
        filename = Path(preset_name).name
        if not filename.lower().endswith(".json"):
            filename = f"{filename}.json"
        return (self.settings.root_dir / "presets" / filename).exists()

    def _park_with_preset(self, base: ParkSettings, preset: dict[str, Any]) -> ParkSettings:
        park_raw = preset.get("park", {})
        if not isinstance(park_raw, dict):
            return base

        kwargs: dict[str, Any] = {}
        for key, attr in (
            ("background", "background_path"),
            ("overlay", "overlay_path"),
            ("logo", "logo_path"),
        ):
            if key in park_raw:
                kwargs[attr] = self._preset_path_value(park_raw.get(key))

        if "person" in park_raw:
            kwargs["person"] = self._replace_known(base.person, park_raw.get("person"))
        if "overlay_settings" in park_raw:
            kwargs["overlay_settings"] = self._replace_known(
                base.overlay_settings,
                park_raw.get("overlay_settings"),
            )
        if "logo_settings" in park_raw:
            kwargs["logo_settings"] = self._replace_known(
                base.logo_settings,
                park_raw.get("logo_settings"),
            )
        if "text_layer" in park_raw:
            kwargs["text_layer"] = self._replace_known(base.text_layer, park_raw.get("text_layer"))
        if "contact_shadow" in park_raw:
            kwargs["contact_shadow"] = self._replace_known(
                base.contact_shadow,
                park_raw.get("contact_shadow"),
            )
        if "photo_enhance" in park_raw:
            kwargs["photo_enhance"] = self._replace_known(
                base.photo_enhance,
                park_raw.get("photo_enhance"),
            )
        if "jpg_quality" in park_raw and park_raw.get("jpg_quality") is not None:
            kwargs["jpg_quality"] = int(park_raw.get("jpg_quality"))
        if "harmonize_strength" in park_raw and park_raw.get("harmonize_strength") is not None:
            kwargs["harmonize_strength"] = float(park_raw.get("harmonize_strength"))

        return replace(base, **kwargs)

    def _background_removal_with_preset(
        self,
        base: BackgroundRemovalSettings,
        preset: dict[str, Any],
        apply_desktop_mask: bool = True,
    ) -> BackgroundRemovalSettings:
        background_raw = preset.get("background_removal", {})
        desktop_raw = preset.get("desktop", {})
        selected = self._replace_known(base, background_raw)
        if apply_desktop_mask and isinstance(desktop_raw, dict):
            updates: dict[str, Any] = {}
            if "mask_protection" in desktop_raw:
                updates["mask_protection"] = self._clamp_int(desktop_raw.get("mask_protection"), 0, 100)
            if "mask_antighost" in desktop_raw:
                updates["mask_antighost"] = self._clamp_int(desktop_raw.get("mask_antighost"), 0, 100)
            if updates:
                selected = replace(selected, **updates)
        return selected

    def _preset_path_value(self, value: object) -> Path | None:
        if value is None or str(value).strip() == "":
            return None
        path = Path(str(value))
        if path.is_absolute():
            return path
        return self.settings.root_dir / path

    def _replace_known(self, current: Any, data: object) -> Any:
        if not isinstance(data, dict):
            return current
        allowed = getattr(current, "__dataclass_fields__", {})
        updates = {key: value for key, value in data.items() if key in allowed}
        if not updates:
            return current
        return replace(current, **updates)

    def _clamp_int(self, value: object, min_value: int, max_value: int) -> int:
        try:
            number = int(value)
        except (TypeError, ValueError):
            number = min_value
        return max(min_value, min(max_value, number))

    def _remover_for(self, settings: BackgroundRemovalSettings) -> BackgroundRemover:
        remover = self._removers.get(settings)
        if remover is None:
            remover = BackgroundRemover(settings, self.logger)
            self._removers[settings] = remover
        return remover

    def _output_path_for(self, input_path: Path, park: ParkSettings | None = None) -> Path:
        selected = park or self.park
        output_dir = selected.output_dir
        if selected.mirror_input_folders:
            output_dir = self._archive_dir_for(selected.output_dir, input_path, selected)

        if selected.preserve_output_filename:
            filename = input_path.name
        else:
            suffix = selected.suffix
            filename = f"{input_path.stem}{suffix}.jpg"

        target = output_dir / filename

        return unique_path(target)

    def _archive_dir_for(
        self,
        base_dir: Path,
        input_path: Path,
        park: ParkSettings | None = None,
    ) -> Path:
        selected = park or self.park
        try:
            relative_parent = input_path.parent.resolve().relative_to(selected.input_dir.resolve())
        except ValueError:
            return base_dir
        if str(relative_parent) == ".":
            return base_dir
        return base_dir / relative_parent

    def _move_original_to_processed_enabled(self, park: ParkSettings) -> bool:
        enabled = park.move_original_to_processed
        if not self.settings.config_path.name.startswith("settings_snapshot_"):
            return enabled

        live_config = self.settings.root_dir / "config" / "settings.json"
        try:
            raw = json.loads(live_config.read_text(encoding="utf-8-sig"))
            park_raw = raw.get("parks", {}).get(park.name, {})
            if isinstance(park_raw, dict) and "move_original_to_processed" in park_raw:
                return bool(park_raw.get("move_original_to_processed"))
        except Exception as exc:
            self.logger.warning("Could not read live move-processed setting: %s", exc)
        return enabled

    def cleanup_empty_input_dirs(self) -> int:
        return self._cleanup_empty_dirs(self.park.input_dir.resolve(), "IN")

    def _cleanup_empty_dirs(self, root: Path, label: str) -> int:
        removed = 0
        if not root.exists():
            return removed

        directories = sorted(
            (path for path in root.rglob("*") if path.is_dir()),
            key=lambda path: len(path.parts),
            reverse=True,
        )
        for directory in directories:
            try:
                next(directory.iterdir())
                continue
            except StopIteration:
                pass
            except OSError:
                continue

            try:
                relative = directory.resolve().relative_to(root)
            except ValueError:
                continue

            if str(relative) == ".":
                continue

            try:
                directory.rmdir()
                removed += 1
                self.logger.info("Removed empty %s folder after processing: %s", label, directory)
            except OSError:
                continue

        return removed

    def _save_jpeg(
        self,
        image: Image.Image,
        output_path: Path,
        source_path: Path | None = None,
        park: ParkSettings | None = None,
    ) -> None:
        selected = park or self.park
        save_kwargs = {
            "quality": selected.jpg_quality,
            "optimize": True,
            "subsampling": 0,
        }
        image_to_save = image.convert("RGB")
        if source_path is not None:
            image_to_save, metadata = self._jpeg_image_and_metadata_from_source(image_to_save, source_path)
            save_kwargs.update(metadata)

        image_to_save.save(output_path, "JPEG", **save_kwargs)

        if source_path is not None:
            self._copy_source_timestamps(source_path, output_path)

    def _jpeg_image_and_metadata_from_source(
        self,
        image: Image.Image,
        source_path: Path,
    ) -> tuple[Image.Image, dict[str, object]]:
        metadata: dict[str, object] = {}
        image_to_save = image
        try:
            with Image.open(source_path) as source:
                exif = source.getexif()
                if exif:
                    source_orientation = int(exif.get(274, 1) or 1)
                    source_display_size = ImageOps.exif_transpose(source).size
                    image_to_save = self._restore_source_storage_orientation(
                        image_to_save,
                        source.size,
                        source_display_size,
                        source_orientation,
                    )
                    exif[274] = source_orientation if image_to_save.size != image.size else 1
                    metadata["exif"] = exif.tobytes()
                icc_profile = source.info.get("icc_profile")
                if icc_profile:
                    metadata["icc_profile"] = icc_profile
        except Exception as exc:
            self.logger.warning("Could not preserve metadata from %s: %s", source_path, exc)
        return image_to_save, metadata

    def _restore_source_storage_orientation(
        self,
        image: Image.Image,
        source_stored_size: tuple[int, int],
        source_display_size: tuple[int, int],
        source_orientation: int,
    ) -> Image.Image:
        if source_orientation not in (5, 6, 7, 8):
            return image
        if image.width == image.height:
            return image

        source_stored_is_landscape = source_stored_size[0] > source_stored_size[1]
        source_display_is_landscape = source_display_size[0] > source_display_size[1]
        output_is_landscape = image.width > image.height
        if source_stored_is_landscape == source_display_is_landscape:
            return image
        if output_is_landscape != source_display_is_landscape:
            return image

        inverse_transpose = {
            5: Image.Transpose.TRANSPOSE,
            6: Image.Transpose.ROTATE_90,
            7: Image.Transpose.TRANSVERSE,
            8: Image.Transpose.ROTATE_270,
        }
        return image.transpose(inverse_transpose[source_orientation])

    def _copy_source_timestamps(self, source_path: Path, output_path: Path) -> None:
        try:
            source_stat = source_path.stat()
            os.utime(output_path, (source_stat.st_atime, source_stat.st_mtime))
        except OSError as exc:
            self.logger.warning("Could not copy timestamps from %s to %s: %s", source_path, output_path, exc)

    def _write_enhancer_log(
        self,
        image: Image.Image,
        input_path: Path,
        output_path: Path,
        park: ParkSettings,
    ) -> Path | None:
        if not getattr(park.photo_enhance, "save_logs", True):
            return None
        report = report_from_image(image)
        if not report:
            return None
        try:
            return write_enhancement_log(
                report,
                self.settings.logs.directory / "enhancer2",
                input_path=input_path,
                output_path=output_path,
            )
        except Exception as exc:
            self.logger.warning("Could not write enhancer2 JSON log for %s: %s", input_path, exc)
            return None

    @contextmanager
    def _processing_lock(self, operation: str):
        lock_paths = [
            self.settings.logs.directory / "locks" / "photoia.lock",
            Path.cwd() / ".photoia.lock",
        ]
        lock_age_limit_seconds = 6 * 60 * 60
        descriptor: int | None = None
        lock_path: Path | None = None
        lock_errors: list[OSError] = []

        for candidate in lock_paths:
            try:
                candidate.parent.mkdir(parents=True, exist_ok=True)
                if candidate.exists():
                    lock_pid = _read_lock_pid(candidate)
                    if lock_pid == os.getpid() or _lock_is_stale(candidate, lock_age_limit_seconds):
                        self.logger.warning("Removing stale processing lock: %s", candidate)
                        try:
                            candidate.unlink(missing_ok=True)
                        except OSError as exc:
                            lock_errors.append(exc)
                            continue
                    else:
                        message = (
                            "Another processing job is already running. "
                            f"Lock: {candidate}"
                        )
                        raise ProcessingBusyError(message)
                descriptor = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                lock_path = candidate
                break
            except FileExistsError as exc:
                message = (
                    "Another processing job is already running. "
                    f"Lock: {candidate}"
                )
                raise ProcessingBusyError(message) from exc
            except OSError as exc:
                lock_errors.append(exc)

        if descriptor is None or lock_path is None:
            self.logger.warning("Processing lock disabled: %s", lock_errors)
            yield
            return

        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(f"pid={os.getpid()}\noperation={operation}\nstarted={time.time()}\n")
            yield
        finally:
            try:
                lock_path.unlink(missing_ok=True)
            except OSError as exc:
                self.logger.warning("Could not remove processing lock %s: %s", lock_path, exc)

