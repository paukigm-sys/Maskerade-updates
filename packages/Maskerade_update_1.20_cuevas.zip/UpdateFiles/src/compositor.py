from __future__ import annotations

import logging
from dataclasses import replace
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

from .config import ContactShadowSettings, OverlaySettings, ParkSettings, PersonPlacementSettings, TextLayerSettings
from .harmonizer import harmonize_composited_subject, harmonize_subject_layer
from .image_utils import LANCZOS, alpha_composite_at, resize_cover


def compose_image(
    original: Image.Image,
    person_rgba: Image.Image | None,
    park: ParkSettings,
    logger: logging.Logger | None = None,
    apply_harmonize: bool = True,
) -> Image.Image:
    logger = logger or logging.getLogger(__name__)
    background, background_source_size, output_size = _prepare_scene_background(original, park)
    canvas = background.convert("RGBA")

    if person_rgba is not None:
        subject_canvas = _prepare_subject_canvas(person_rgba, park, output_size)
        if apply_harmonize and park.harmonize_strength > 0:
            subject_canvas = harmonize_subject_layer(background, subject_canvas, park.harmonize_strength)
        _apply_contact_shadow(canvas, subject_canvas, park.contact_shadow)
        alpha_composite_at(canvas, subject_canvas, (0, 0))

    if park.overlay_path:
        if park.overlay_path.exists():
            overlay, overlay_xy = prepare_overlay_layer(
                Image.open(park.overlay_path).convert("RGBA"),
                park.overlay_settings,
                output_size,
                background_source_size,
            )
            alpha_composite_at(canvas, overlay, overlay_xy)
        else:
            logger.info("Overlay not found, skipping: %s", park.overlay_path)

    if park.logo_path:
        if park.logo_path.exists():
            logo_settings = _map_settings_from_background(
                park.logo_settings,
                output_size,
                background_source_size,
            )
            logo, logo_xy = prepare_overlay_layer(
                Image.open(park.logo_path).convert("RGBA"),
                logo_settings,
                output_size,
                background_source_size,
            )
            alpha_composite_at(canvas, logo, logo_xy)
        else:
            logger.info("Logo not found, skipping: %s", park.logo_path)

    _apply_text_layer(canvas, park.text_layer)

    return canvas.convert("RGB")


def harmonize_composed_image(
    image: Image.Image,
    original: Image.Image,
    person_rgba: Image.Image | None,
    park: ParkSettings,
    logger: logging.Logger | None = None,
) -> Image.Image:
    logger = logger or logging.getLogger(__name__)
    report = image.info.get("_enhancer2_report")
    if isinstance(report, dict) and report.get("preset") == "souvenir_family_flash_perfect_v1":
        return image.convert("RGB")
    if person_rgba is None or park.background_path is None or park.harmonize_strength <= 0:
        return image.convert("RGB")
    try:
        background, _, output_size = _prepare_scene_background(original, park)
        subject_canvas = _prepare_subject_canvas(person_rgba, park, output_size)
        return harmonize_composited_subject(background, image, subject_canvas, park.harmonize_strength)
    except Exception as exc:
        logger.warning("Late harmonize failed; keeping enhanced composite: %s", exc)
        return image.convert("RGB")


def _prepare_scene_background(
    original: Image.Image,
    park: ParkSettings,
) -> tuple[Image.Image, tuple[int, int], tuple[int, int]]:
    if park.background_path is None:
        output_size = original.size
        background_source_size = original.size
        background = original.convert("RGB")
    else:
        background_source = Image.open(park.background_path).convert("RGB")
        background_source_size = background_source.size
        output_size = _target_size(original, park.output_size, background_source_size)
        background = resize_cover(background_source, output_size).convert("RGB")
    return background, background_source_size, output_size


def _prepare_subject_canvas(
    person_rgba: Image.Image,
    park: ParkSettings,
    output_size: tuple[int, int],
) -> Image.Image:
    subject = _prepare_subject(person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))
    return subject_canvas


def _apply_text_layer(canvas: Image.Image, settings: TextLayerSettings) -> None:
    text = (settings.text or "").strip()
    if not settings.enabled or not text:
        return

    out_w, out_h = canvas.size
    draw = ImageDraw.Draw(canvas)
    base_size = max(18, int(round(out_w * 0.065 * max(0.35, min(3.0, float(settings.scale))))))
    font = _load_text_font(base_size, getattr(settings, "font", "Segoe UI"))

    max_width = int(out_w * 0.88)
    while base_size > 16:
        bbox = draw.textbbox((0, 0), text, font=font, stroke_width=max(2, base_size // 18))
        if bbox[2] - bbox[0] <= max_width:
            break
        base_size -= 2
        font = _load_text_font(base_size, getattr(settings, "font", "Segoe UI"))

    stroke = max(2, base_size // 18)
    bbox = draw.textbbox((0, 0), text, font=font, stroke_width=stroke)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    color = _parse_hex_color(settings.color, (255, 255, 255, 255))

    pad = max(8, stroke * 4)
    text_image = Image.new("RGBA", (text_w + pad * 2, text_h + pad * 2), (0, 0, 0, 0))
    text_draw = ImageDraw.Draw(text_image)
    text_draw.text(
        (pad - bbox[0], pad - bbox[1]),
        text,
        font=font,
        fill=color,
        stroke_width=stroke,
        stroke_fill=(0, 0, 0, 190),
    )
    rotation = max(-180.0, min(180.0, float(getattr(settings, "rotation", 0.0) or 0.0)))
    if abs(rotation) > 0.01:
        text_image = text_image.rotate(rotation, resample=Image.Resampling.BICUBIC, expand=True)

    center_x = out_w / 2.0 + int(settings.x)
    center_y = out_h * 0.065 + int(settings.y) + text_h / 2.0
    x = int(round(center_x - text_image.width / 2.0))
    y = int(round(center_y - text_image.height / 2.0))
    alpha_composite_at(canvas, text_image, (x, y))


def _load_text_font(size: int, font_name: str = "Segoe UI") -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    font_files = {
        "segoe ui": "segoeuib.ttf",
        "arial": "arialbd.ttf",
        "calibri": "calibrib.ttf",
        "impact": "impact.ttf",
        "times new roman": "timesbd.ttf",
        "georgia": "georgiab.ttf",
        "verdana": "verdanab.ttf",
        "tahoma": "tahomabd.ttf",
        "courier new": "courbd.ttf",
        "comic sans ms": "comicbd.ttf",
        "bahnschrift": "bahnschrift.ttf",
    }
    selected = font_files.get(str(font_name or "Segoe UI").strip().lower(), "segoeuib.ttf")
    candidates = [
        Path("C:/Windows/Fonts") / selected,
        Path("C:/Windows/Fonts/segoeuib.ttf"),
        Path("C:/Windows/Fonts/arialbd.ttf"),
        Path("C:/Windows/Fonts/calibrib.ttf"),
    ]
    for path in candidates:
        try:
            if path.exists():
                return ImageFont.truetype(str(path), size=size)
        except Exception:
            pass
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf", size=size)
    except Exception:
        return ImageFont.load_default()


def _parse_hex_color(value: str, fallback: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    raw = (value or "").strip().lstrip("#")
    if len(raw) not in {6, 8}:
        return fallback
    try:
        r = int(raw[0:2], 16)
        g = int(raw[2:4], 16)
        b = int(raw[4:6], 16)
        a = int(raw[6:8], 16) if len(raw) == 8 else 255
        return (r, g, b, a)
    except ValueError:
        return fallback


def _apply_contact_shadow(
    canvas: Image.Image,
    subject_canvas: Image.Image,
    settings: ContactShadowSettings,
) -> None:
    if not settings.enabled or settings.strength <= 0:
        return

    alpha = subject_canvas.getchannel("A")
    solid_alpha = alpha.point(lambda value: 255 if value > 32 else 0)
    bbox = solid_alpha.getbbox()
    if not bbox:
        return

    out_w, out_h = canvas.size
    left, top, right, bottom = bbox
    subject_w = max(1, right - left)
    subject_h = max(1, bottom - top)
    strength = max(0.0, min(2.0, float(settings.strength)))
    slider_curve = (min(strength, 1.0) * 1.35) ** 0.65
    above_100 = max(0.0, strength - 1.0)
    broad_strength = min(1.05, slider_curve * 0.48 + above_100 * 0.28)
    contact_mask_strength = min(1.85, min(1.0, slider_curve * 1.08) + above_100 * 0.68)

    base_floor_y = bottom + out_h * float(settings.y_offset_ratio)
    center_x = int(round((left + right) / 2))
    broad_w = max(8, int(round(subject_w * max(0.1, float(settings.width_ratio)) * 0.34 * (1.0 + above_100 * 0.03))))
    broad_h = max(4, int(round(out_h * max(0.002, float(settings.height_ratio)) * 0.20 * (1.0 + above_100 * 0.02))))
    floor_y = max(0, min(out_h - 1, int(round(base_floor_y - broad_h * 0.16))))

    shadow_mask = Image.new("L", canvas.size, 0)
    draw = ImageDraw.Draw(shadow_mask)
    draw.ellipse(
        (
            center_x - broad_w // 2,
            floor_y - broad_h // 2,
            center_x + broad_w // 2,
            floor_y + broad_h // 2,
        ),
        fill=min(255, int(round(42 * broad_strength * (1.0 + above_100 * 0.70)))),
    )
    blur = max(0, int(round(out_w * max(0.0, float(settings.blur_ratio)))))
    if blur > 0:
        shadow_mask = shadow_mask.filter(ImageFilter.GaussianBlur(blur))

    contact = _build_contact_shadow_from_feet(
        solid_alpha,
        bbox,
        output_size=canvas.size,
        strength=contact_mask_strength,
        contact_strength=max(0.0, min(2.4, float(settings.contact_strength))),
    )
    shadow_mask = ImageChops.lighter(shadow_mask, contact)
    boost = 1.0 + broad_strength * 0.05 + above_100 * 0.28
    shadow_mask = shadow_mask.point(lambda value: min(255, int(round(value * boost))))

    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    shadow.putalpha(shadow_mask)
    canvas.alpha_composite(shadow)


def _build_contact_shadow_from_feet(
    solid_alpha: Image.Image,
    bbox: tuple[int, int, int, int],
    output_size: tuple[int, int],
    strength: float,
    contact_strength: float,
) -> Image.Image:
    out_w, out_h = output_size
    left, top, right, bottom = bbox
    subject_w = max(1, right - left)
    subject_h = max(1, bottom - top)
    arr = np.asarray(solid_alpha.crop(bbox))
    if arr.size == 0:
        return Image.new("L", output_size, 0)

    lower_start = int(subject_h * 0.50)
    lower = arr[lower_start:, :]
    cols = np.where(lower > 0)[1]
    if cols.size == 0:
        return Image.new("L", output_size, 0)

    profile = np.full(subject_w, -1, dtype=np.int32)
    rows, cols = np.where(lower > 0)
    for col in np.unique(cols):
        profile[col] = rows[cols == col].max() + lower_start

    valid = profile >= 0
    valid_x = np.where(valid)[0]
    if valid_x.size < 3:
        return Image.new("L", output_size, 0)

    lowest_support_y = int(profile[valid_x].max())
    support_reach = max(int(round(subject_h * 0.22)), int(round(out_h * 0.050)))
    foot_min_y = max(int(subject_h * 0.62), lowest_support_y - support_reach)
    foot_x = valid_x[profile[valid_x] >= foot_min_y]
    if foot_x.size < 3:
        return Image.new("L", output_size, 0)

    cast_mask = Image.new("L", output_size, 0)
    soft_mask = Image.new("L", output_size, 0)
    cast_draw = ImageDraw.Draw(cast_mask)
    soft_draw = ImageDraw.Draw(soft_mask)
    max_gap = max(3, subject_w // 140)
    min_segment = max(4, int(round(subject_w * 0.005)))
    max_segment = max(min_segment + 1, int(round(subject_w * 0.052)))
    foot_band = max(8, int(round(out_h * 0.018)))
    blob_h = max(7, int(round(out_h * 0.018)))
    tight_h = max(4, int(round(out_h * 0.009)))
    cast_len = max(18, int(round(out_h * 0.118 * (0.86 + min(2.0, strength) * 0.12))))
    soft_fill = min(125, int(54 * strength * contact_strength))
    cast_fill = min(210, int(86 * strength * contact_strength))

    support_segments = [
        (start, end)
        for start, end in _contiguous_segments(foot_x, max_gap)
        if end - start + 1 >= min_segment
    ]
    if not support_segments:
        return Image.new("L", output_size, 0)

    widest_support = max(end - start + 1 for start, end in support_segments)
    min_real_support = max(min_segment, int(round(widest_support * 0.055)))

    for start, end in support_segments:
        if end - start + 1 < min_real_support:
            continue
        segment_cols = np.arange(start, end + 1)
        for chunk_start in range(start, end + 1, max_segment):
            chunk_end = min(end, chunk_start + max_segment - 1)
            chunk = np.arange(chunk_start, chunk_end + 1)
            segment_floor_y = max(foot_min_y, int(profile[chunk].max()) - foot_band)
            chunk = chunk[profile[chunk] >= segment_floor_y]
            if chunk.size < min_segment:
                continue

            local_x = int(round(float(np.median(chunk))))
            local_y = int(round(float(np.percentile(profile[chunk], 98))))
            foot_span = chunk_end - chunk_start + 1
            width = max(18, min(int(round(subject_w * 0.115)), int(round(foot_span * 1.38))))
            tight_width = max(14, min(int(round(width * 0.78)), int(round(subject_w * 0.080))))
            x = left + local_x
            y = top + local_y - int(round(tight_h * 0.12))
            cast_width = max(width, int(round(tight_width * 1.26)))
            cast_top_w = max(12, int(round(width * 0.92)))
            cast_origin_lift = max(
                int(round(out_h * 0.020)),
                int(round(tight_h * 2.80)),
                int(round(blob_h * 1.05)),
            )
            cast_y = y - cast_origin_lift
            cast_draw.polygon(
                (
                    (x - cast_top_w // 2, cast_y),
                    (x + cast_top_w // 2, cast_y),
                    (x + cast_width // 2, cast_y + cast_len),
                    (x - cast_width // 2, cast_y + cast_len),
                ),
                fill=cast_fill,
            )
            cast_draw.ellipse(
                (
                    x - cast_width // 2,
                    cast_y + int(round(cast_len * 0.52)),
                    x + cast_width // 2,
                    cast_y + int(round(cast_len * 1.18)),
                ),
                fill=cast_fill,
            )
            soft_draw.ellipse(
                (
                    x - width // 2,
                    y - int(blob_h * 1.05),
                    x + width // 2,
                    y + int(blob_h * 0.35),
                ),
                fill=soft_fill,
            )

    cast_mask = cast_mask.filter(ImageFilter.GaussianBlur(max(5, int(round(cast_len * 0.16)))))
    soft_mask = soft_mask.filter(ImageFilter.GaussianBlur(max(5, int(round(blob_h * 1.30)))))
    return ImageChops.lighter(cast_mask, soft_mask)


def _contiguous_segments(values: np.ndarray, max_gap: int) -> list[tuple[int, int]]:
    if values.size == 0:
        return []
    values = np.asarray(sorted(set(int(value) for value in values)), dtype=np.int32)
    breaks = np.where(np.diff(values) > max_gap)[0]
    starts = np.concatenate(([0], breaks + 1))
    ends = np.concatenate((breaks, [values.size - 1]))
    return [(int(values[start]), int(values[end])) for start, end in zip(starts, ends)]


def _target_size(
    original: Image.Image,
    configured_size: tuple[int, int] | str,
    background_size: tuple[int, int] | None = None,
) -> tuple[int, int]:
    if isinstance(configured_size, str):
        if configured_size.lower() in {"background", "selected_background", "fondo"}:
            if background_size is not None:
                return background_size
            return original.size
        if configured_size.lower() in {"input", "original", "source", "same_as_input"}:
            return original.size
        raise ValueError(f"Unsupported output_size value: {configured_size}")
    return configured_size


def _prepare_subject(
    subject: Image.Image,
    placement: PersonPlacementSettings,
    output_size: tuple[int, int],
) -> Image.Image:
    subject = subject.convert("RGBA")
    if placement.anchor.lower() in {"original", "source", "source_canvas"}:
        return _fit_source_canvas(subject, output_size, placement.scale, placement.x, placement.y)

    subject = _crop_to_alpha(subject)

    max_w = max(1, int(output_size[0] * placement.max_width_ratio))
    max_h = max(1, int(output_size[1] * placement.max_height_ratio))
    fit = min(max_w / subject.width, max_h / subject.height)
    scale = max(0.01, fit * placement.scale)
    new_size = (
        max(1, int(subject.width * scale)),
        max(1, int(subject.height * scale)),
    )
    return subject.resize(new_size, LANCZOS)


def _fit_source_canvas(
    subject: Image.Image,
    output_size: tuple[int, int],
    scale: float,
    offset_x_percent: int = 0,
    offset_y_percent: int = 0,
) -> Image.Image:
    out_w, out_h = output_size
    if out_w <= 0 or out_h <= 0:
        return subject

    fit = min(out_w / max(1, subject.width), out_h / max(1, subject.height))
    scale = max(0.2, min(2.0, float(scale or 1.0)))
    fitted = subject.resize(
        (
            max(1, int(round(subject.width * fit * scale))),
            max(1, int(round(subject.height * fit * scale))),
        ),
        LANCZOS,
    )
    canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    x = int(round((out_w - fitted.width) / 2 + (out_w * float(offset_x_percent or 0) / 100.0)))
    y = int(round((out_h - fitted.height) / 2 + (out_h * float(offset_y_percent or 0) / 100.0)))
    alpha_composite_at(canvas, fitted, (x, y))
    return canvas


def _scale_source_canvas(subject: Image.Image, scale: float, offset_x_percent: int = 0, offset_y_percent: int = 0) -> Image.Image:
    scale = max(0.2, min(2.0, float(scale or 1.0)))
    if abs(scale - 1.0) < 0.001:
        return subject

    width, height = subject.size
    scaled = subject.resize(
        (max(1, int(round(width * scale))), max(1, int(round(height * scale)))),
        LANCZOS,
    )
    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    x = int(round((width - scaled.width) / 2 + (width * float(offset_x_percent or 0) / 100.0)))
    y = int(round((height - scaled.height) / 2 + (height * float(offset_y_percent or 0) / 100.0)))
    alpha_composite_at(canvas, scaled, (x, y))
    return canvas


def _crop_to_alpha(image: Image.Image) -> Image.Image:
    alpha = image.getchannel("A")
    bbox = alpha.getbbox()
    if not bbox:
        return image

    pad_x = max(8, int((bbox[2] - bbox[0]) * 0.025))
    pad_y = max(8, int((bbox[3] - bbox[1]) * 0.025))
    left = max(0, bbox[0] - pad_x)
    top = max(0, bbox[1] - pad_y)
    right = min(image.width, bbox[2] + pad_x)
    bottom = min(image.height, bbox[3] + pad_y)
    return image.crop((left, top, right, bottom))


def _placement_for(
    subject_size: tuple[int, int],
    placement: PersonPlacementSettings,
) -> tuple[int, int]:
    width, height = subject_size
    anchor = placement.anchor.lower()

    if anchor in {"original", "source", "source_canvas"}:
        return 0, 0
    if anchor == "bottom_center":
        return int(placement.x - width / 2), int(placement.y - height)
    if anchor == "center":
        return int(placement.x - width / 2), int(placement.y - height / 2)
    if anchor == "top_left":
        return int(placement.x), int(placement.y)
    if anchor == "bottom_left":
        return int(placement.x), int(placement.y - height)
    if anchor == "bottom_right":
        return int(placement.x - width), int(placement.y - height)

    raise ValueError(f"Unsupported person anchor: {placement.anchor}")


def prepare_overlay_layer(
    overlay: Image.Image,
    settings: OverlaySettings,
    output_size: tuple[int, int],
    background_source_size: tuple[int, int] | None = None,
) -> tuple[Image.Image, tuple[int, int]]:
    if _is_full_scene_overlay(overlay.size, background_source_size, settings):
        mapped_settings = _map_settings_from_background(
            replace(settings, mode="original"),
            output_size,
            background_source_size,
        )
        return _prepare_overlay(overlay, mapped_settings, output_size)
    return _prepare_overlay(overlay, settings, output_size)


def _map_settings_from_background(
    settings: OverlaySettings,
    output_size: tuple[int, int],
    background_source_size: tuple[int, int] | None,
) -> OverlaySettings:
    if background_source_size is None:
        return settings
    if settings.mode.lower() not in {"original", "source", "native"}:
        return settings

    bg_w, bg_h = background_source_size
    out_w, out_h = output_size
    if bg_w <= 0 or bg_h <= 0 or out_w <= 0 or out_h <= 0:
        return settings

    cover_scale = max(out_w / bg_w, out_h / bg_h)
    crop_x = max(0.0, (bg_w * cover_scale - out_w) / 2.0)
    crop_y = max(0.0, (bg_h * cover_scale - out_h) / 2.0)
    return replace(
        settings,
        x=int(round(settings.x * cover_scale - crop_x)),
        y=int(round(settings.y * cover_scale - crop_y)),
        scale=settings.scale * cover_scale,
    )


def _is_full_scene_overlay(
    overlay_size: tuple[int, int],
    background_source_size: tuple[int, int] | None,
    settings: OverlaySettings,
) -> bool:
    if background_source_size is None:
        return False
    if settings.mode.lower() not in {"original", "source", "native", "cover"}:
        return False
    return overlay_size == background_source_size


def _prepare_overlay(
    overlay: Image.Image,
    settings: OverlaySettings,
    output_size: tuple[int, int],
) -> tuple[Image.Image, tuple[int, int]]:
    mode = settings.mode.lower()
    if mode in {"original", "source", "native"}:
        scale = max(0.01, settings.scale)
        if abs(scale - 1.0) < 0.001:
            prepared = overlay.convert("RGBA")
        else:
            prepared = overlay.resize(
                (max(1, int(overlay.width * scale)), max(1, int(overlay.height * scale))),
                LANCZOS,
            ).convert("RGBA")
        xy = (settings.x, settings.y)
    elif mode == "cover":
        prepared = resize_cover(overlay, output_size).convert("RGBA")
        scale = max(0.01, settings.scale)
        if abs(scale - 1.0) >= 0.001:
            prepared = prepared.resize(
                (max(1, int(prepared.width * scale)), max(1, int(prepared.height * scale))),
                LANCZOS,
            )
        xy = (settings.x, settings.y)
    elif mode == "stretch":
        prepared = overlay.resize(output_size, LANCZOS)
        xy = (settings.x, settings.y)
    elif mode == "contain":
        prepared = _resize_contain(overlay, output_size)
        xy = _overlay_position(prepared.size, output_size, settings)
    else:
        scale = max(0.01, settings.scale)
        prepared = overlay.resize(
            (max(1, int(overlay.width * scale)), max(1, int(overlay.height * scale))),
            LANCZOS,
        )
        xy = _overlay_position(prepared.size, output_size, settings)

    prepared = _apply_overlay_opacity(prepared, settings.opacity)

    return prepared, xy


def _apply_overlay_opacity(overlay: Image.Image, opacity: float) -> Image.Image:
    prepared = overlay.convert("RGBA")
    if opacity < 1.0:
        alpha = prepared.getchannel("A")
        alpha = alpha.point(lambda value: int(value * max(0.0, min(1.0, opacity))))
        prepared.putalpha(alpha)
    return prepared


def _resize_contain(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    target_w, target_h = size
    scale = min(target_w / image.width, target_h / image.height)
    return image.resize((max(1, int(image.width * scale)), max(1, int(image.height * scale))), LANCZOS)


def _overlay_position(
    overlay_size: tuple[int, int],
    output_size: tuple[int, int],
    settings: OverlaySettings,
) -> tuple[int, int]:
    width, height = overlay_size
    out_w, out_h = output_size
    anchor = settings.anchor.lower()
    if anchor == "bottom_center":
        return int(out_w / 2 - width / 2 + settings.x), int(out_h - height + settings.y)
    if anchor == "bottom_left":
        return int(settings.x), int(out_h - height + settings.y)
    if anchor == "bottom_right":
        return int(out_w - width + settings.x), int(out_h - height + settings.y)
    if anchor == "top_left":
        return int(settings.x), int(settings.y)
    return int(out_w / 2 - width / 2 + settings.x), int(out_h / 2 - height / 2 + settings.y)
