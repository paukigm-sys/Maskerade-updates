from __future__ import annotations

import json
import logging
import re
import sys
from datetime import datetime
from dataclasses import replace
from pathlib import Path

from PIL import Image, ImageOps

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from src import __version__
    from src.background_removal import BackgroundRemover
    from src.compositor import compose_image, harmonize_composed_image, prepare_overlay_layer
    from src.config import load_settings
    from src.processor import PhotoProcessor
    from src.image_utils import LANCZOS, alpha_composite_at, list_images, natural_sort_key, open_image, resize_cover
    from src.photo_enhancer import enhance_photo
else:
    from . import __version__
    from .background_removal import BackgroundRemover
    from .compositor import compose_image, harmonize_composed_image, prepare_overlay_layer
    from .config import load_settings
    from .processor import PhotoProcessor
    from .image_utils import LANCZOS, alpha_composite_at, list_images, natural_sort_key, open_image, resize_cover
    from .photo_enhancer import enhance_photo


CONFIG_PATH = Path("config/settings.json")
PROFILE_NAME = "photo"
PREVIEW_FILE = Path("desktop_preview.jpg")
PREVIEW_SCENE_FILE = Path("desktop_preview_scene.jpg")
PHOTO_ENHANCE_PREVIEW_FILE = Path("desktop_photo_enhance_preview.jpg")
PRESETS_DIR = Path("presets")
PREVIEW_MAX_SIDE = 640
PREVIEW_FAST_MAX_SIDE = 520
PHOTO_ENHANCE_PREVIEW_MAX_SIDE = 900


def _load_raw() -> dict:
    with CONFIG_PATH.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def _save_raw(raw: dict) -> None:
    payload = json.dumps(raw, ensure_ascii=False, indent=2) + "\n"
    temp_path = CONFIG_PATH.with_suffix(".tmp.json")
    try:
        temp_path.write_text(payload, encoding="utf-8")
        temp_path.replace(CONFIG_PATH)
    except PermissionError:
        CONFIG_PATH.write_text(payload, encoding="utf-8")


def _root() -> Path:
    return CONFIG_PATH.resolve().parent.parent


def _rel(path: str | Path | None) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.is_absolute():
        p = _root() / p
    try:
        return str(p.resolve().relative_to(_root().resolve())).replace("\\", "/")
    except Exception:
        return str(p)


def _abs(path: str | Path | None) -> Path | None:
    if not path:
        return None
    p = Path(path)
    if not p.is_absolute():
        p = _root() / p
    return p


def _image_size(path: str | Path | None) -> tuple[int, int] | None:
    abs_path = _abs(path)
    if not abs_path or not abs_path.exists() or not abs_path.is_file():
        return None
    try:
        with Image.open(abs_path) as image:
            return ImageOps.exif_transpose(image).size
    except Exception:
        return None


def _overlay_matches_background(park: dict, overlay_value: str | None = None) -> bool:
    overlay_path = overlay_value if overlay_value is not None else park.get("overlay")
    background_size = _image_size(park.get("background"))
    overlay_size = _image_size(overlay_path)
    if not background_size or not overlay_size:
        return False
    if background_size == overlay_size:
        return True
    bg_w, bg_h = background_size
    ov_w, ov_h = overlay_size
    if bg_w <= 0 or bg_h <= 0 or ov_w <= 0 or ov_h <= 0:
        return False
    return abs((bg_w / bg_h) - (ov_w / ov_h)) < 0.01


def _print(key: str, value: object) -> None:
    print(f"{key}\t{'' if value is None else value}")


def _clamp_int(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(max_value, value))


def _preset_dir() -> Path:
    path = _root() / PRESETS_DIR
    path.mkdir(parents=True, exist_ok=True)
    return path


def _safe_preset_name(name: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9ÁÉÍÓÚÜÑáéíóúüñ._ -]+", "_", name.strip())
    cleaned = cleaned.strip(" ._-")
    if not cleaned:
        raise SystemExit("Preset name is empty")
    return cleaned[:80]


def _preset_path(name: str) -> Path:
    return _preset_dir() / f"{_safe_preset_name(name)}.json"


def _preset_names() -> list[str]:
    directory = _preset_dir()
    return [path.stem for path in sorted(directory.glob("*.json"), key=lambda item: item.name.lower())]


def _folder_preset_rules(raw: dict) -> list[dict]:
    rules = raw.get("folder_presets", raw.get("folder_preset_rules", []))
    if isinstance(rules, dict):
        rules = [
            {"pattern": pattern, "preset": preset, "enabled": True}
            for pattern, preset in rules.items()
        ]
    if not isinstance(rules, list):
        return []

    cleaned = []
    for item in rules:
        if not isinstance(item, dict):
            continue
        pattern = str(item.get("pattern") or item.get("folder") or item.get("prefix") or "").strip()
        preset = str(item.get("preset") or "").strip()
        if not pattern or not preset:
            continue
        cleaned.append(
            {
                "pattern": pattern,
                "preset": preset,
                "enabled": bool(item.get("enabled", True)),
            }
        )
    return cleaned


def _copy_known(source: dict, keys: list[str]) -> dict:
    return {key: source[key] for key in keys if key in source}


def _current_preset_payload(raw: dict, name: str) -> dict:
    park = raw.get("parks", {}).get(PROFILE_NAME, {})
    return {
        "version": 1,
        "name": name,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "background_removal": _copy_known(
            raw.get("background_removal", {}),
            ["backend", "model", "max_processing_side", "ben2_model", "ben2_device", "ben2_refine_foreground"],
        ),
        "desktop": _copy_known(raw.get("desktop", {}), ["mask_protection", "mask_antighost", "person_zoom", "person_vertical"]),
        "park": _copy_known(
            park,
            [
                "background",
                "overlay",
                "logo",
                "overlay_settings",
                "logo_settings",
                "text_layer",
                "person",
                "jpg_quality",
                "harmonize_strength",
                "contact_shadow",
                "photo_enhance",
            ],
        ),
    }


def save_preset(name: str) -> int:
    raw = _load_raw()
    safe_name = _safe_preset_name(name)
    payload = _current_preset_payload(raw, safe_name)
    path = _preset_path(safe_name)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    raw["active_preset"] = safe_name
    _save_raw(raw)
    print(path.resolve())
    return 0


def apply_preset(name: str) -> int:
    path = _preset_path(name)
    if not path.exists():
        raise SystemExit(f"Preset not found: {name}")
    preset = json.loads(path.read_text(encoding="utf-8-sig"))
    raw = _load_raw()
    raw.setdefault("background_removal", {}).update(preset.get("background_removal", {}))
    raw.setdefault("desktop", {}).update(preset.get("desktop", {}))
    raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {}).update(preset.get("park", {}))
    raw["active_preset"] = _safe_preset_name(name)
    _save_raw(raw)
    print(path.resolve())
    return 0


def delete_preset(name: str) -> int:
    path = _preset_path(name)
    if path.exists():
        path.unlink()
    raw = _load_raw()
    if str(raw.get("active_preset") or "").casefold() == _safe_preset_name(name).casefold():
        raw.pop("active_preset", None)
        _save_raw(raw)
    return 0


def save_folder_rule(pattern: str, preset: str, enabled: str = "true") -> int:
    pattern = str(pattern or "").strip()
    preset = str(preset or "").strip()
    if not pattern:
        raise SystemExit("Folder pattern is empty")
    if not preset:
        raise SystemExit("Preset name is empty")
    if not _preset_path(preset).exists():
        raise SystemExit(f"Preset not found: {preset}")

    raw = _load_raw()
    rules = _folder_preset_rules(raw)
    enabled_value = str(enabled or "true").strip().lower() not in {"0", "false", "no", "off"}
    next_rule = {"pattern": pattern, "preset": preset, "enabled": enabled_value}

    replaced = False
    for index, rule in enumerate(rules):
        if str(rule.get("pattern", "")).casefold() == pattern.casefold():
            rules[index] = next_rule
            replaced = True
            break
    if not replaced:
        rules.append(next_rule)

    raw["folder_presets"] = rules
    raw.pop("folder_preset_rules", None)
    _save_raw(raw)
    print(pattern)
    return 0


def delete_folder_rule(pattern: str) -> int:
    pattern = str(pattern or "").strip()
    if not pattern:
        raise SystemExit("Folder pattern is empty")
    raw = _load_raw()
    rules = [
        rule for rule in _folder_preset_rules(raw)
        if str(rule.get("pattern", "")).casefold() != pattern.casefold()
    ]
    raw["folder_presets"] = rules
    raw.pop("folder_preset_rules", None)
    _save_raw(raw)
    print(pattern)
    return 0


def _apply_mask_protection(raw: dict, value: int) -> None:
    value = _clamp_int(value, 0, 100)
    raw.setdefault("desktop", {})["mask_protection"] = value


def _apply_mask_antighost(raw: dict, value: int) -> None:
    value = _clamp_int(value, 0, 100)
    raw.setdefault("desktop", {})["mask_antighost"] = value


def _apply_person_zoom(raw: dict, value: int) -> None:
    value = _clamp_int(value, 50, 160)
    raw.setdefault("desktop", {})["person_zoom"] = value
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    person = park.setdefault("person", {})
    person["scale"] = round(value / 100.0, 3)


def _apply_person_vertical(raw: dict, value: int) -> None:
    value = _clamp_int(value, -25, 25)
    raw.setdefault("desktop", {})["person_vertical"] = value
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    person = park.setdefault("person", {})
    person["anchor"] = "original"
    person["y"] = value


def state() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    raw = _load_raw()
    raw_park = raw.get("parks", {}).get(PROFILE_NAME, {})
    desktop = raw.get("desktop", {})
    background_raw = raw_park.get("background") or ""
    overlay_raw = raw_park.get("overlay") or ""
    logo_raw = raw_park.get("logo") or ""

    input_images = list_images(park.input_dir)
    output_images = list_images(park.output_dir)
    processed_images = list_images(settings.processed_dir)
    latest_output = max(output_images, key=lambda p: p.stat().st_mtime) if output_images else None
    latest_processed = max(processed_images, key=lambda p: p.stat().st_mtime) if processed_images else None
    first_input = _first_preview_input(input_images, park)

    _print("version", __version__)
    _print("root", settings.root_dir)
    _print("input", _rel(park.input_dir))
    _print("input_abs", park.input_dir)
    _print("output", _rel(park.output_dir))
    _print("output_abs", park.output_dir)
    _print("processed", _rel(settings.processed_dir))
    _print("processed_abs", settings.processed_dir)
    _print("background", background_raw)
    _print("background_abs", _abs(background_raw) if background_raw else "")
    _print("overlay", overlay_raw)
    _print("overlay_abs", _abs(overlay_raw) if overlay_raw else "")
    _print("logo", logo_raw)
    _print("logo_abs", _abs(logo_raw) if logo_raw else "")
    overlay_settings = raw_park.get("overlay_settings", {})
    _print("overlay_x", overlay_settings.get("x", 0))
    _print("overlay_y", overlay_settings.get("y", 0))
    _print("overlay_scale", overlay_settings.get("scale", 1))
    _print("overlay_mode", overlay_settings.get("mode", "original"))
    logo_settings = raw_park.get("logo_settings", {})
    _print("logo_x", logo_settings.get("x", 0))
    _print("logo_y", logo_settings.get("y", 0))
    _print("logo_scale", logo_settings.get("scale", 1))
    text_layer = raw_park.get("text_layer", {})
    _print("text_layer", text_layer.get("text", ""))
    _print("text_layer_font", text_layer.get("font", "Segoe UI"))
    _print("text_layer_color", text_layer.get("color", "#FFFFFF"))
    _print("text_layer_x", text_layer.get("x", 0))
    _print("text_layer_y", text_layer.get("y", 0))
    _print("text_layer_scale", text_layer.get("scale", 1.0))
    _print("text_layer_rotation", text_layer.get("rotation", 0))
    _print("move_processed", str(park.move_original_to_processed).lower())
    nuvol = raw.get("nuvol", {}) if isinstance(raw.get("nuvol", {}), dict) else {}
    _print("nuvol_enabled", str(bool(nuvol.get("enabled", False))).lower())
    _print("nuvol_mode", nuvol.get("mode", "upload_only"))
    _print("nuvol_download_dir", nuvol.get("download_dir", "nuvol_downloads"))
    _print("nuvol_park", nuvol.get("park", "monasterio"))
    _print("nuvol_user_group", nuvol.get("user_group", "monasterio"))
    _print("nuvol_username", nuvol.get("username", "photoIA"))
    _print("nuvol_auth_username", nuvol.get("auth_username", ""))
    _print("nuvol_auth_password", "")
    _print("nuvol_auth_password_set", str(bool(nuvol.get("auth_password", ""))).lower())
    _print("jpg_quality", park.jpg_quality)
    _print("harmonize_strength", int(round(float(getattr(park, "harmonize_strength", 0.0)) * 100)))
    photo_enhance = getattr(park, "photo_enhance", None)
    _print("photo_enhance_engine", getattr(photo_enhance, "engine", "classic"))
    _print("photo_enhance_preset", getattr(photo_enhance, "preset", "default_event"))
    _print("photo_enhance_autotune", str(bool(getattr(photo_enhance, "autotune", False))).lower())
    _print("photo_enhance_save_logs", str(bool(getattr(photo_enhance, "save_logs", True))).lower())
    _print("photo_enhance_strength", int(round(float(getattr(photo_enhance, "strength", 0.0)) * 100)))
    _print("photo_enhance_enabled", str(bool(getattr(photo_enhance, "enabled", False))).lower())
    for field_name in (
        "brightness",
        "shadow_contrast",
        "highlight_contrast",
        "saturation",
        "red",
        "green",
        "blue",
        "auto_brightness",
        "auto_color",
        "memory_color",
        "shadows",
        "lights",
        "global_sharpen",
        "local_sharpen",
        "denoise",
        "desaturate_shadows",
        "hue_rotation",
    ):
        _print(f"photo_enhance_{field_name}", getattr(photo_enhance, field_name, 0))
    shadow_settings = getattr(park, "contact_shadow", None)
    _print("contact_shadow_strength", int(round(float(getattr(shadow_settings, "strength", 0.0)) * 100)))
    _print("mask_protection", desktop.get("mask_protection", 55))
    _print("mask_antighost", desktop.get("mask_antighost", 0))
    _print("person_zoom", desktop.get("person_zoom", int(round(float(park.person.scale) * 100))))
    _print("person_vertical", desktop.get("person_vertical", int(getattr(park.person, "y", 0) or 0)))
    _print("engine", f"{settings.background_removal.backend} / {settings.background_removal.model}")
    _print("in_count", len(input_images))
    _print("out_count", len(output_images))
    _print("latest_output", latest_output or "")
    _print("latest_processed", latest_processed or "")
    _print("first_input", first_input or "")
    _print("active_preset", raw.get("active_preset", ""))
    for preset_name in _preset_names():
        _print("preset", preset_name)
    for rule in _folder_preset_rules(raw):
        enabled = "1" if rule.get("enabled", True) else "0"
        _print("folder_rule", f"{enabled}\t{rule.get('pattern', '')}\t{rule.get('preset', '')}")

    bg_dir = settings.root_dir / "assets" / "backgrounds"
    ov_dir = settings.root_dir / "assets" / "overlays"
    logo_dir = settings.root_dir / "assets" / "logos"
    if bg_dir.exists():
        for path in sorted(bg_dir.iterdir(), key=lambda item: natural_sort_key(item, bg_dir)):
            if path.is_file() and path.suffix.lower() in {".jpg", ".jpeg", ".png"}:
                _print("background_asset", path)
    if ov_dir.exists():
        for path in sorted(ov_dir.iterdir(), key=lambda item: natural_sort_key(item, ov_dir)):
            if path.is_file() and path.suffix.lower() == ".png":
                _print("overlay_asset", path)
    if logo_dir.exists():
        for path in sorted(logo_dir.iterdir(), key=lambda item: natural_sort_key(item, logo_dir)):
            if path.is_file() and path.suffix.lower() == ".png":
                _print("logo_asset", path)
    return 0


def _preview_size(size: tuple[int, int]) -> tuple[tuple[int, int], float]:
    longest = max(size)
    if longest <= PREVIEW_MAX_SIDE:
        return size, 1.0
    scale = PREVIEW_MAX_SIDE / longest
    return (max(1, int(size[0] * scale)), max(1, int(size[1] * scale))), scale


def _preview_size_for(size: tuple[int, int], max_side: int) -> tuple[tuple[int, int], float]:
    longest = max(size)
    if longest <= max_side:
        return size, 1.0
    scale = max_side / longest
    return (max(1, int(size[0] * scale)), max(1, int(size[1] * scale))), scale


def _background_preview_size(park, max_side: int) -> tuple[tuple[int, int], float]:
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        with Image.open(park.background_path) as background:
            return _preview_size_for(background.size, max_side)
    return (1600, 1000), 1.0


def _preset_preview_size(park, original_size: tuple[int, int], max_side: int) -> tuple[tuple[int, int], float]:
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        with Image.open(park.background_path) as background:
            return _preview_size_for(background.size, max_side)
    return _preview_size_for(original_size, max_side)


def _preview_orientation(park) -> str:
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        try:
            with Image.open(park.background_path) as background:
                if background.height > background.width:
                    return "vertical"
                if background.width > background.height:
                    return "horizontal"
        except Exception:
            pass
    output_size = getattr(park, "output_size", None)
    if isinstance(output_size, tuple) and len(output_size) == 2:
        width, height = output_size
        if height > width:
            return "vertical"
        if width > height:
            return "horizontal"
    return ""


def _image_orientation(path: Path) -> str:
    try:
        with Image.open(path) as image:
            image = ImageOps.exif_transpose(image)
            if image.height > image.width:
                return "vertical"
            if image.width > image.height:
                return "horizontal"
    except Exception:
        pass
    return ""


def _first_preview_input(input_images: list[Path], park) -> Path | None:
    if not input_images:
        return None
    wanted = _preview_orientation(park)
    if not wanted:
        return input_images[0]
    for path in input_images:
        if _image_orientation(path) == wanted:
            return path
    return input_images[0]


def _scaled_overlay_settings(settings, scale: float):
    if scale == 1.0:
        return settings
    mode = settings.mode.lower()
    overlay_scale = settings.scale
    if mode in {"original", "source", "native"}:
        overlay_scale = settings.scale * scale
    return replace(
        settings,
        x=int(round(settings.x * scale)),
        y=int(round(settings.y * scale)),
        scale=overlay_scale,
    )


def _compose_background_overlay(park) -> Image.Image:
    overlay_image = None
    if park.overlay_path and park.overlay_path.exists():
        overlay_image = Image.open(park.overlay_path).convert("RGBA")

    background_source_size = None
    if park.background_path and park.background_path.exists() and park.background_path.is_file():
        background = Image.open(park.background_path).convert("RGB")
        background_source_size = background.size
        size, scale = _preview_size(background.size)
        background = resize_cover(background, size).convert("RGB")
        canvas = background.convert("RGBA")
    else:
        size, scale = _preview_size(overlay_image.size if overlay_image else (1600, 1000))
        canvas = Image.new("RGBA", size, (15, 26, 32, 255))

    if overlay_image is not None:
        overlay, xy = prepare_overlay_layer(
            overlay_image,
            _scaled_overlay_settings(park.overlay_settings, scale),
            size,
            background_source_size,
        )
        alpha_composite_at(canvas, overlay, xy)
    if park.logo_path and park.logo_path.exists():
        logo, xy = prepare_overlay_layer(
            Image.open(park.logo_path).convert("RGBA"),
            _scaled_overlay_settings(park.logo_settings, scale),
            canvas.size,
            background_source_size,
        )
        alpha_composite_at(canvas, logo, xy)
    return canvas.convert("RGB")


def _effective_preview_context(settings, park, input_path: Path | None = None):
    if input_path is None:
        return park, settings.background_removal, ""
    try:
        processor = PhotoProcessor.__new__(PhotoProcessor)
        processor.settings = settings
        processor.park = park
        processor.logger = logging.getLogger("maskerade.preview")
        processor._preset_cache = {}
        context = processor._context_for_input(input_path)
        return context.park, context.background_removal, context.preset_name or ""
    except Exception:
        logging.getLogger("maskerade.preview").exception("Could not resolve preview preset for %s", input_path)
        return park, settings.background_removal, ""


def _fast_preview_subject(image: Image.Image) -> Image.Image:
    """Low-resolution cutout for UI preview only.

    The production batch still uses BEN2. This preview path favors speed and a
    translucent subject/photo layer so zoom/background/overlay changes feel
    immediate and the operator can see the background while composing.
    """
    rgba = image.convert("RGBA")
    rgba.putalpha(Image.new("L", rgba.size, 156))
    return rgba


def preview() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)

    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if not input_images:
        park, _, _ = _effective_preview_context(settings, park)
        final = _compose_background_overlay(park)
        final.save(preview_path, "JPEG", quality=86, optimize=True)
        print(preview_path.resolve())
        return 0

    first_input = _first_preview_input(input_images, park)
    park, background_removal, _ = _effective_preview_context(settings, park, first_input)

    if park.background_path is not None and (
        not park.background_path.exists() or not park.background_path.is_file()
    ):
        final = _compose_background_overlay(park)
        final.save(preview_path, "JPEG", quality=86, optimize=True)
        print(preview_path.resolve())
        return 0

    original_full = open_image(first_input)
    output_size, output_scale = _preset_preview_size(park, original_full.size, PREVIEW_MAX_SIDE)
    original_size, original_scale = _preview_size(original_full.size)
    original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
    preview_park = replace(
        park,
        output_size=output_size,
        overlay_settings=_scaled_overlay_settings(park.overlay_settings, output_scale),
        logo_settings=_scaled_overlay_settings(park.logo_settings, output_scale),
    )
    if park.background_path is None:
        final = compose_image(original, None, preview_park)
    else:
        preview_settings = replace(background_removal, max_processing_side=640)
        removal = BackgroundRemover(preview_settings).remove_background(original)
        final = compose_image(original, removal.person_rgba, preview_park, apply_harmonize=False)
    final = enhance_photo(final, preview_park.photo_enhance)
    if park.background_path is not None:
        final = harmonize_composed_image(final, original, removal.person_rgba, preview_park)
    final.save(preview_path, "JPEG", quality=86, optimize=True)
    print(preview_path.resolve())
    return 0


def _photo_enhance_overrides(park, args: list[str]):
    if len(args) % 2 != 0:
        raise SystemExit("preview args expect KEY VALUE pairs")
    values: dict[str, object] = {}
    max_side = PREVIEW_FAST_MAX_SIDE
    selected_input: Path | None = None
    for index in range(0, len(args), 2):
        key = args[index]
        value = args[index + 1]
        if key == "max_side":
            max_side = max(180, min(1200, int(float(value))))
        elif key == "selected_input":
            candidate = Path(str(value or "").strip())
            if candidate.exists() and candidate.is_file():
                selected_input = candidate
        elif key == "photo_enhance_strength":
            strength = max(0.0, min(2.0, float(value) / 100.0))
            values["strength"] = strength
            values["enabled"] = strength > 0.0
        elif key == "photo_enhance_engine":
            values["engine"] = str(value or "classic").strip().lower()
        elif key == "photo_enhance_preset":
            values["preset"] = str(value or "default_event").strip()
        elif key == "photo_enhance_autotune":
            values["autotune"] = str(value or "").strip().lower() in {"1", "true", "yes", "si", "sí", "on"}
        elif key == "photo_enhance_save_logs":
            values["save_logs"] = str(value or "").strip().lower() in {"1", "true", "yes", "si", "sí", "on"}
        elif key.startswith("photo_enhance_"):
            field_name = key[len("photo_enhance_"):]
            if hasattr(park.photo_enhance, field_name):
                values[field_name] = int(float(value))
    if values:
        park = replace(park, photo_enhance=replace(park.photo_enhance, **values))
    return park, max_side, selected_input


def preview_fast(args: list[str] | None = None) -> int:
    args = args or []
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    park, max_side, selected_input = _photo_enhance_overrides(park, args)
    input_images = list_images(park.input_dir)
    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if selected_input is not None or input_images:
        first_input = selected_input or _first_preview_input(input_images, park)
        park, _, _ = _effective_preview_context(settings, park, first_input)
        park, max_side, _ = _photo_enhance_overrides(park, args)
        original_full = open_image(first_input)
        output_size, output_scale = _preset_preview_size(park, original_full.size, max_side)
        original_size, original_scale = _preview_size_for(original_full.size, max_side)
        original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
        preview_park = replace(
            park,
            output_size=output_size,
            overlay_settings=_scaled_overlay_settings(park.overlay_settings, output_scale),
            logo_settings=_scaled_overlay_settings(park.logo_settings, output_scale),
        )

        subject = None if park.background_path is None else _fast_preview_subject(original)
        final = compose_image(original, subject, preview_park, apply_harmonize=False)
    else:
        park, _, _ = _effective_preview_context(settings, park)
        park, max_side, _ = _photo_enhance_overrides(park, args)
        final = _compose_background_overlay(park)

    final = enhance_photo(final, park.photo_enhance)
    if selected_input is not None or input_images:
        final = harmonize_composed_image(final, original, subject, preview_park)
    final.save(preview_path, "JPEG", quality=74, optimize=False)
    print(preview_path.resolve())
    return 0


def preview_fast_base() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    preview_path = _root() / PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)

    if input_images:
        first_input = _first_preview_input(input_images, park)
        park, _, _ = _effective_preview_context(settings, park, first_input)
        base_park = replace(park, overlay_path=None)
        original_full = open_image(first_input)
        output_size, output_scale = _preset_preview_size(base_park, original_full.size, PREVIEW_FAST_MAX_SIDE)
        original_size, original_scale = _preview_size_for(original_full.size, PREVIEW_FAST_MAX_SIDE)
        original = original_full.resize(original_size, LANCZOS) if original_scale != 1.0 else original_full
        preview_park = replace(
            base_park,
            output_size=output_size,
            overlay_settings=_scaled_overlay_settings(base_park.overlay_settings, output_scale),
            logo_settings=_scaled_overlay_settings(base_park.logo_settings, output_scale),
        )

        subject = None if base_park.background_path is None else _fast_preview_subject(original)
        final = compose_image(original, subject, preview_park, apply_harmonize=False)
    else:
        park, _, _ = _effective_preview_context(settings, park)
        base_park = replace(park, overlay_path=None)
        final = _compose_background_overlay(base_park)

    final = enhance_photo(final, base_park.photo_enhance)
    if input_images:
        final = harmonize_composed_image(final, original, subject, preview_park)
    final.save(preview_path, "JPEG", quality=72, optimize=False)
    print(preview_path.resolve())
    return 0


def preview_photo_enhance(args: list[str]) -> int:
    if len(args) % 2 != 0:
        raise SystemExit("preview_photo_enhance expects KEY VALUE pairs")

    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    preview_path = _root() / PHOTO_ENHANCE_PREVIEW_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    requested_index = 0
    for index in range(0, len(args), 2):
        if args[index] == "preview_index":
            requested_index = int(float(args[index + 1]))
            break

    if input_images:
        selected_index = requested_index % len(input_images)
        first_input = input_images[selected_index]
        preview_label = f"{selected_index + 1}/{len(input_images)} {first_input.name}"
        original_full = open_image(first_input)
        preview_size, preview_scale = _preview_size_for(original_full.size, PHOTO_ENHANCE_PREVIEW_MAX_SIDE)
        final = original_full.resize(preview_size, LANCZOS) if preview_scale != 1.0 else original_full
        final = final.convert("RGB")
    else:
        park, _, _ = _effective_preview_context(settings, park)
        preview_label = "Sin fotos en IN"
        final = _compose_background_overlay(park)

    clean_args = []
    for index in range(0, len(args), 2):
        if args[index] != "preview_index":
            clean_args.extend([args[index], args[index + 1]])
    preview_park, _, _ = _photo_enhance_overrides(park, clean_args)
    final = enhance_photo(final, preview_park.photo_enhance)
    final.convert("RGB").save(preview_path, "JPEG", quality=86, optimize=False)
    print(preview_path.resolve())
    print(preview_label)
    return 0


def preview_scene() -> int:
    settings = load_settings(CONFIG_PATH)
    park = settings.get_park(PROFILE_NAME if PROFILE_NAME in settings.parks else next(iter(settings.parks)))
    input_images = list_images(park.input_dir)
    first_input = _first_preview_input(input_images, park)
    park, _, _ = _effective_preview_context(settings, park, first_input)
    preview_path = _root() / PREVIEW_SCENE_FILE
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    final = _compose_background_overlay(park)
    final.save(preview_path, "JPEG", quality=86, optimize=True)
    print(preview_path.resolve())
    return 0


def set_value(key: str, value: str, raw: dict | None = None, save: bool = True) -> int:
    raw = _load_raw() if raw is None else raw
    park = raw.setdefault("parks", {}).setdefault(PROFILE_NAME, {})
    if key == "input":
        park["input_dir"] = _rel(value)
    elif key == "output":
        park["output_dir"] = _rel(value)
    elif key == "processed":
        raw["processed_dir"] = _rel(value)
    elif key == "background":
        park["background"] = _rel(value)
        park["output_size"] = "input"
    elif key == "overlay":
        old_overlay = park.get("overlay")
        park["overlay"] = _rel(value) if value else None
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["anchor"] = "top_left"
        if old_overlay != park["overlay"]:
            overlay_settings["mode"] = "stretch" if park["overlay"] else "original"
            overlay_settings["scale"] = 1
            overlay_settings["x"] = 0
            overlay_settings["y"] = 0
        else:
            overlay_settings["mode"] = "stretch" if park["overlay"] else "original"
    elif key == "overlay_mode":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["mode"] = str(value or "original").lower()
        overlay_settings["anchor"] = "top_left"
    elif key == "logo":
        old_logo = park.get("logo")
        park["logo"] = _rel(value) if value else None
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["anchor"] = "top_left"
        logo_settings["mode"] = "original"
        if old_logo != park["logo"]:
            logo_settings["scale"] = 1
            logo_settings["x"] = 0
            logo_settings["y"] = 0
    elif key == "overlay_x":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["x"] = int(float(value))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "overlay_y":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["y"] = int(float(value))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "overlay_scale":
        overlay_settings = park.setdefault("overlay_settings", {})
        overlay_settings["scale"] = max(0.1, min(3.0, float(value)))
        overlay_settings.setdefault("mode", "stretch" if park.get("overlay") else "original")
        overlay_settings["anchor"] = "top_left"
    elif key == "logo_x":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["x"] = int(float(value))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "logo_y":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["y"] = int(float(value))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "logo_scale":
        logo_settings = park.setdefault("logo_settings", {})
        logo_settings["scale"] = max(0.1, min(3.0, float(value)))
        logo_settings["mode"] = "original"
        logo_settings["anchor"] = "top_left"
    elif key == "text_layer":
        text_layer = park.setdefault("text_layer", {})
        text_layer["text"] = str(value or "")
        text_layer["enabled"] = bool(str(value or "").strip())
        text_layer.setdefault("anchor", "top_center")
        text_layer.setdefault("x", 0)
        text_layer.setdefault("y", 0)
        text_layer.setdefault("scale", 1.0)
        text_layer.setdefault("rotation", 0.0)
        text_layer.setdefault("font", "Segoe UI")
        text_layer.setdefault("color", "#FFFFFF")
    elif key == "text_layer_font":
        text_layer = park.setdefault("text_layer", {})
        text_layer["font"] = str(value or "Segoe UI")
    elif key == "text_layer_color":
        text_layer = park.setdefault("text_layer", {})
        text_layer["color"] = str(value or "#FFFFFF")
    elif key == "text_layer_x":
        text_layer = park.setdefault("text_layer", {})
        text_layer["x"] = int(float(value))
    elif key == "text_layer_y":
        text_layer = park.setdefault("text_layer", {})
        text_layer["y"] = int(float(value))
    elif key == "text_layer_scale":
        text_layer = park.setdefault("text_layer", {})
        text_layer["scale"] = max(0.3, min(3.0, float(value)))
    elif key == "text_layer_rotation":
        text_layer = park.setdefault("text_layer", {})
        text_layer["rotation"] = max(-180.0, min(180.0, float(value)))
    elif key == "move_processed":
        park["move_original_to_processed"] = value.lower() in {"1", "true", "yes", "si", "sí"}
    elif key == "nuvol_enabled":
        raw.setdefault("nuvol", {})["enabled"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
    elif key == "nuvol_mode":
        mode = str(value or "upload_only").strip().lower()
        if mode not in {"upload_only", "upload_download", "upload_and_download"}:
            raise SystemExit(f"Unknown nuvol mode: {value}")
        raw.setdefault("nuvol", {})["mode"] = mode
    elif key == "nuvol_download_dir":
        raw.setdefault("nuvol", {})["download_dir"] = _rel(value) if value else "nuvol_downloads"
    elif key == "nuvol_park":
        raw.setdefault("nuvol", {})["park"] = str(value or "").strip()
    elif key == "nuvol_user_group":
        raw.setdefault("nuvol", {})["user_group"] = str(value or "").strip()
    elif key == "nuvol_username":
        raw.setdefault("nuvol", {})["username"] = str(value or "").strip()
    elif key == "nuvol_auth_username":
        raw.setdefault("nuvol", {})["auth_username"] = str(value or "").strip()
    elif key == "nuvol_auth_password":
        password = str(value or "")
        if password:
            raw.setdefault("nuvol", {})["auth_password"] = password
    elif key == "jpg_quality":
        park["jpg_quality"] = max(60, min(100, int(value)))
    elif key == "harmonize_strength":
        park["harmonize_strength"] = max(0.0, min(2.0, float(value) / 100.0))
    elif key == "photo_enhance_strength":
        strength = max(0.0, min(2.0, float(value) / 100.0))
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["enabled"] = strength > 0.0
        photo_enhance["strength"] = strength
    elif key == "photo_enhance_enabled":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["enabled"] = value.lower() in {"1", "true", "yes", "si", "sí"}
    elif key == "photo_enhance_engine":
        engine = str(value or "classic").strip().lower()
        if engine not in {"classic", "enhancer2", "none", "off"}:
            raise SystemExit(f"Unknown photo enhancer engine: {value}")
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["engine"] = "none" if engine == "off" else engine
    elif key == "photo_enhance_preset":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["preset"] = str(value or "default_event").strip() or "default_event"
    elif key == "photo_enhance_autotune":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["autotune"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
        if photo_enhance["autotune"] and str(photo_enhance.get("engine", "classic")).lower() == "classic":
            photo_enhance["engine"] = "enhancer2"
    elif key == "photo_enhance_save_logs":
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance["save_logs"] = value.lower() in {"1", "true", "yes", "si", "sí", "on"}
    elif key.startswith("photo_enhance_"):
        field_name = key[len("photo_enhance_"):]
        allowed = {
            "brightness",
            "shadow_contrast",
            "highlight_contrast",
            "saturation",
            "red",
            "green",
            "blue",
            "auto_brightness",
            "auto_color",
            "memory_color",
            "shadows",
            "lights",
            "global_sharpen",
            "local_sharpen",
            "denoise",
            "desaturate_shadows",
            "hue_rotation",
        }
        if field_name not in allowed:
            raise SystemExit(f"Unknown key: {key}")
        photo_enhance = park.setdefault("photo_enhance", {})
        photo_enhance[field_name] = int(float(value))
    elif key == "contact_shadow_strength":
        strength = max(0.0, min(2.0, float(value) / 100.0))
        shadow = park.setdefault("contact_shadow", {})
        shadow["enabled"] = strength > 0.0
        shadow["strength"] = strength
    elif key == "mask_protection":
        _apply_mask_protection(raw, int(value))
    elif key == "mask_antighost":
        _apply_mask_antighost(raw, int(value))
    elif key == "person_zoom":
        _apply_person_zoom(raw, int(value))
    elif key == "person_vertical":
        _apply_person_vertical(raw, int(value))
    else:
        raise SystemExit(f"Unknown key: {key}")
    if save:
        _save_raw(raw)
    return 0


def set_many(args: list[str]) -> int:
    if len(args) % 2 != 0:
        raise SystemExit("set_many expects KEY VALUE pairs")
    raw = _load_raw()
    for index in range(0, len(args), 2):
        set_value(args[index], args[index + 1], raw=raw, save=False)
    _save_raw(raw)
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]
    if not argv or argv[0] == "state":
        return state()
    if argv[0] == "preview_scene":
        return preview_scene()
    if argv[0] == "preview_fast_base":
        return preview_fast_base()
    if argv[0] == "preview_fast":
        return preview_fast(argv[1:])
    if argv[0] == "preview_photo_enhance":
        return preview_photo_enhance(argv[1:])
    if argv[0] == "preview":
        return preview()
    if argv[0] == "set" and len(argv) >= 3:
        return set_value(argv[1], argv[2])
    if argv[0] == "secret_set" and len(argv) >= 2:
        return set_value(argv[1], sys.stdin.read())
    if argv[0] == "set_many" and len(argv) >= 3:
        return set_many(argv[1:])
    if argv[0] == "preset_save" and len(argv) >= 2:
        return save_preset(" ".join(argv[1:]))
    if argv[0] == "preset_apply" and len(argv) >= 2:
        return apply_preset(" ".join(argv[1:]))
    if argv[0] == "preset_delete" and len(argv) >= 2:
        return delete_preset(" ".join(argv[1:]))
    if argv[0] == "folder_rule_save" and len(argv) >= 3:
        enabled = argv[3] if len(argv) >= 4 else "true"
        return save_folder_rule(argv[1], argv[2], enabled)
    if argv[0] == "folder_rule_delete" and len(argv) >= 2:
        return delete_folder_rule(" ".join(argv[1:]))
    raise SystemExit("Usage: desktop_bridge.py state | set KEY VALUE | preset_save NAME | preset_apply NAME")


if __name__ == "__main__":
    raise SystemExit(main())

