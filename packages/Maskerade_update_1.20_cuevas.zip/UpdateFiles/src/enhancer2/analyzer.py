from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
from PIL import Image

try:
    import cv2
except Exception:  # pragma: no cover - optional runtime fallback
    cv2 = None


@dataclass(frozen=True)
class ImageAnalysis:
    width: int
    height: int
    mean_luma: float
    shadow_clip_percent: float
    highlight_clip_percent: float
    contrast_score: float
    saturation_score: float
    sharpness_score: float
    noise_score: float
    color_cast: str
    skin_detected: bool

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class EnhancementAnalyzer:
    def analyze(self, image: Image.Image) -> ImageAnalysis:
        original_width, original_height = image.size
        sample = image.convert("RGB")
        max_side = max(sample.size)
        if max_side > 900:
            scale = 900.0 / float(max_side)
            sample = sample.resize((max(1, int(sample.width * scale)), max(1, int(sample.height * scale))), Image.Resampling.BILINEAR)
        rgb = np.asarray(sample).astype(np.float32)
        height, width = rgb.shape[:2]
        luma = _luminance(rgb)
        hsv = _rgb_to_hsv(rgb)
        saturation = hsv[..., 1]

        return ImageAnalysis(
            width=int(original_width),
            height=int(original_height),
            mean_luma=round(float(np.mean(luma) / 255.0), 4),
            shadow_clip_percent=round(float(np.mean(luma <= 8.0) * 100.0), 4),
            highlight_clip_percent=round(float(np.mean(luma >= 247.0) * 100.0), 4),
            contrast_score=round(float(np.std(luma) / 80.0), 4),
            saturation_score=round(float(np.mean(saturation) / 255.0), 4),
            sharpness_score=round(_sharpness_score(luma), 4),
            noise_score=round(_noise_score(luma), 4),
            color_cast=_color_cast(np.mean(rgb, axis=(0, 1))),
            skin_detected=_skin_detected(rgb),
        )


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    if cv2 is None:
        maxc = np.max(rgb, axis=-1)
        minc = np.min(rgb, axis=-1)
        sat = np.zeros_like(maxc)
        nonzero = maxc > 0
        sat[nonzero] = ((maxc[nonzero] - minc[nonzero]) / maxc[nonzero]) * 255.0
        return np.stack([np.zeros_like(maxc), sat, maxc], axis=-1)
    return cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)


def _color_cast(means: np.ndarray) -> str:
    red, green, blue = [float(x) for x in means]
    spread = max(red, green, blue) - min(red, green, blue)
    if spread < 7.0:
        return "neutral"
    if red > blue + 10 and red > green - 4:
        return "warm"
    if blue > red + 10:
        return "cool"
    if green > red + 8 and green > blue + 8:
        return "green"
    if red > green + 8 and blue > green + 8:
        return "magenta"
    return "mixed"


def _sharpness_score(luma: np.ndarray) -> float:
    if cv2 is not None:
        lap = cv2.Laplacian(np.clip(luma, 0, 255).astype(np.uint8), cv2.CV_64F)
        variance = float(lap.var())
    else:
        gy, gx = np.gradient(luma)
        variance = float(np.var(np.hypot(gx, gy)))
    return float(np.clip(variance / 900.0, 0.0, 1.5))


def _noise_score(luma: np.ndarray) -> float:
    if cv2 is not None:
        blur = cv2.GaussianBlur(luma, (0, 0), 1.2)
    else:
        blur = _box_blur(luma)
    return float(np.clip(np.std(luma - blur) / 22.0, 0.0, 1.5))


def _box_blur(values: np.ndarray) -> np.ndarray:
    padded = np.pad(values, 1, mode="edge")
    total = (
        padded[:-2, :-2] + padded[:-2, 1:-1] + padded[:-2, 2:]
        + padded[1:-1, :-2] + padded[1:-1, 1:-1] + padded[1:-1, 2:]
        + padded[2:, :-2] + padded[2:, 1:-1] + padded[2:, 2:]
    )
    return total / 9.0


def _skin_detected(rgb: np.ndarray) -> bool:
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    mask = (
        (r > 55) & (g > 35) & (b > 22)
        & ((maxc - minc) > 12)
        & (r > g * 1.05)
        & (r > b * 1.12)
    )
    return bool(np.mean(mask) > 0.006)
