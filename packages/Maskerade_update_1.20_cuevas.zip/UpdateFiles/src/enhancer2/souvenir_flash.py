from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
from PIL import Image

try:
    import cv2
except Exception:  # pragma: no cover - optional runtime fallback
    cv2 = None

from .presets import EnhancementPreset


PRESET_NAME = "souvenir_family_flash_perfect_v1"


@dataclass(frozen=True)
class PhotoQualityMetrics:
    width: int
    height: int
    orientation: str
    luminance_p01: float
    luminance_p05: float
    luminance_p50: float
    luminance_p95: float
    luminance_p99: float
    highlight_area_ratio: float
    clipped_area_ratio: float
    dark_area_ratio: float
    mean_saturation: float
    green_area_ratio: float
    red_area_ratio: float
    face_count: int
    skin_detected: bool
    qr_detected: bool
    scene_type: str
    primary_problem: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class SouvenirMasks:
    subject: np.ndarray
    face: np.ndarray
    skin: np.ndarray
    white_clothes: np.ndarray
    black_clothes: np.ndarray
    red_clothes: np.ndarray
    green_background: np.ndarray
    highlight: np.ndarray
    clipped: np.ndarray
    qr: np.ndarray
    subject_confidence: float
    qr_bbox: tuple[int, int, int, int] | None

    def summary(self) -> dict[str, object]:
        return {
            "subject_confidence": round(float(self.subject_confidence), 4),
            "skin": bool(np.mean(self.skin) > 0.003),
            "white_clothes": bool(np.mean(self.white_clothes) > 0.003),
            "green_background": bool(np.mean(self.green_background) > 0.01),
            "red_clothes": bool(np.mean(self.red_clothes) > 0.003),
            "qr": self.qr_bbox is not None,
            "qr_bbox": self.qr_bbox,
        }


@dataclass(frozen=True)
class SouvenirParams:
    highlight_recovery: float
    white_clothes_recovery: float
    hotspot_compression: float
    green_background_exposure: float
    green_saturation_reduction: float
    red_saturation_reduction: float
    subject_pop: bool
    subject_exposure: float
    background_exposure: float
    face_lift: float
    skin_shine_reduction: float
    clarity: float
    sharpen: float
    denoise: float
    vignette: float

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class EnhancementValidation:
    passed: bool
    warnings: list[str]
    clipped_area_after: float
    highlight_area_after: float
    qr_difference: int

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class PhotoQualityAnalyzer:
    def analyze(self, image: Image.Image, qr_detected: bool = False) -> PhotoQualityMetrics:
        source_width, source_height = image.size
        sample = _analysis_image(image, 900)
        rgb = _to_rgb_array(sample)
        height, width = rgb.shape[:2]
        luma = _luminance(rgb)
        hsv = _rgb_to_hsv(rgb)
        saturation = hsv[..., 1]
        green = _green_mask(rgb, hsv, luma)
        red = _red_mask(rgb, hsv)
        skin = _skin_mask(rgb)

        clipped = (luma > 0.985) | (np.max(rgb, axis=2) > 0.980)
        highlight = luma > 0.900
        dark = luma < 0.080
        skin_detected = bool(np.mean(skin) > 0.006)
        highlight_ratio = float(np.mean(highlight))
        clipped_ratio = float(np.mean(clipped))
        green_ratio = float(np.mean(green))

        scene_type = "unknown"
        if skin_detected and (highlight_ratio > 0.035 or clipped_ratio > 0.012):
            scene_type = "family_flash_portrait"
        elif skin_detected:
            scene_type = "generic_portrait"

        primary = "unknown"
        if clipped_ratio > 0.020 or highlight_ratio > 0.080:
            primary = "overexposure"
        if skin_detected and highlight_ratio > 0.045:
            primary = "hard_flash"
        if primary == "unknown" and green_ratio > 0.18:
            primary = "green_background"

        percentiles = np.percentile(luma, [1, 5, 50, 95, 99])
        return PhotoQualityMetrics(
            width=int(source_width),
            height=int(source_height),
            orientation="portrait" if source_height >= source_width else "landscape",
            luminance_p01=round(float(percentiles[0]), 4),
            luminance_p05=round(float(percentiles[1]), 4),
            luminance_p50=round(float(percentiles[2]), 4),
            luminance_p95=round(float(percentiles[3]), 4),
            luminance_p99=round(float(percentiles[4]), 4),
            highlight_area_ratio=round(highlight_ratio, 4),
            clipped_area_ratio=round(clipped_ratio, 4),
            dark_area_ratio=round(float(np.mean(dark)), 4),
            mean_saturation=round(float(np.mean(saturation)), 4),
            green_area_ratio=round(green_ratio, 4),
            red_area_ratio=round(float(np.mean(red)), 4),
            face_count=1 if skin_detected else 0,
            skin_detected=skin_detected,
            qr_detected=qr_detected,
            scene_type=scene_type,
            primary_problem=primary,
        )


class MaskProvider:
    def build_masks(
        self,
        image: Image.Image,
        metrics: PhotoQualityMetrics,
        qr_info: tuple[np.ndarray, tuple[int, int, int, int] | None] | None = None,
    ) -> SouvenirMasks:
        source_width, source_height = image.size
        work_image = _analysis_image(image, 1200)
        rgb = _to_rgb_array(work_image)
        height, width = rgb.shape[:2]
        luma = _luminance(rgb)
        hsv = _rgb_to_hsv(rgb)

        skin = _skin_mask(rgb)
        highlight = (luma > 0.900).astype(np.float32)
        clipped = ((luma > 0.985) | (np.max(rgb, axis=2) > 0.980)).astype(np.float32)
        green = _green_mask(rgb, hsv, luma).astype(np.float32)
        red = _red_mask(rgb, hsv).astype(np.float32)
        white = ((luma > 0.760) & (hsv[..., 1] < 0.280)).astype(np.float32)
        black = ((luma < 0.250) & (hsv[..., 1] < 0.420)).astype(np.float32)
        if qr_info is None:
            qr, qr_bbox = _empty_qr_mask(source_width, source_height)
        else:
            qr, qr_bbox = qr_info
        qr_work = _resize_mask(qr, (width, height))

        central = _central_subject_prior(height, width)
        subject = np.maximum.reduce([
            central * 0.55,
            _feather(skin, 24),
            _feather(white, 18) * 0.65,
            _feather(red, 18) * 0.75,
            _feather(black, 18) * 0.70,
        ])
        subject = np.clip(subject * (1.0 - qr_work), 0.0, 1.0)
        green_background = np.clip(green * (1.0 - subject * 0.80) * (1.0 - qr_work), 0.0, 1.0)
        subject_confidence = float(np.clip(np.mean(subject > 0.32) * 7.5 + (0.35 if metrics.skin_detected else 0.0), 0.0, 1.0))

        return SouvenirMasks(
            subject=_resize_mask(_feather(subject, 30), (source_width, source_height)),
            face=_resize_mask(_feather(skin, 12), (source_width, source_height)),
            skin=_resize_mask(_feather(skin, 14), (source_width, source_height)),
            white_clothes=_resize_mask(_feather(white * (1.0 - qr_work), 18), (source_width, source_height)),
            black_clothes=_resize_mask(_feather(black * (1.0 - qr_work), 14), (source_width, source_height)),
            red_clothes=_resize_mask(_feather(red * (1.0 - qr_work), 14), (source_width, source_height)),
            green_background=_resize_mask(_feather(green_background, 32), (source_width, source_height)),
            highlight=_resize_mask(_feather(highlight * (1.0 - qr_work), 20), (source_width, source_height)),
            clipped=_resize_mask(clipped * (1.0 - qr_work), (source_width, source_height)),
            qr=qr,
            subject_confidence=subject_confidence,
            qr_bbox=qr_bbox,
        )


class AdaptiveSouvenirFlashEnhancer:
    def resolve_params(self, metrics: PhotoQualityMetrics, masks: SouvenirMasks, preset: EnhancementPreset) -> SouvenirParams:
        clipped = metrics.clipped_area_ratio
        highlights = metrics.highlight_area_ratio
        green = metrics.green_area_ratio
        red = metrics.red_area_ratio

        highlight_recovery = 0.55 + (0.10 if clipped > 0.040 else 0.0) + (0.08 if highlights > 0.120 else 0.0)
        white_recovery = 0.78 + (0.07 if clipped > 0.040 else 0.0)
        green_reduction = 0.12 + (0.04 if green > 0.250 else 0.0)
        green_exposure = -0.10 + (-0.03 if green > 0.250 else 0.0)
        red_reduction = 0.12 + (0.05 if red > 0.080 else 0.0)

        return SouvenirParams(
            highlight_recovery=_clamp(preset.get_float("highlight_recovery", highlight_recovery), 0.0, 0.75),
            white_clothes_recovery=_clamp(preset.get_float("white_clothes_recovery", white_recovery), 0.0, 0.85),
            hotspot_compression=_clamp(preset.get_float("hotspot_compression", 0.62), 0.0, 0.75),
            green_background_exposure=_clamp(preset.get_float("green_background_exposure", green_exposure), -0.40, 0.0),
            green_saturation_reduction=_clamp(preset.get_float("green_saturation_reduction", green_reduction), 0.0, 0.28),
            red_saturation_reduction=_clamp(preset.get_float("red_saturation_reduction", red_reduction), 0.0, 0.24),
            subject_pop=masks.subject_confidence >= 0.70,
            subject_exposure=_clamp(preset.get_float("subject_exposure", 0.06), 0.0, 0.22),
            background_exposure=_clamp(preset.get_float("background_exposure", -0.08), -0.40, 0.0),
            face_lift=_clamp(preset.get_float("face_lift", 0.10), 0.0, 0.22),
            skin_shine_reduction=_clamp(preset.get_float("skin_shine_reduction", 0.35), 0.0, 0.45),
            clarity=_clamp(preset.get_float("clarity", 0.14), 0.0, 0.28),
            sharpen=_clamp(preset.get_float("sharpen", 0.50), 0.0, 0.70),
            denoise=_clamp(preset.get_float("denoise", 0.12), 0.0, 0.55),
            vignette=_clamp(preset.get_float("vignette", 0.0), 0.0, 0.12),
        )

    def enhance(self, image: Image.Image, preset: EnhancementPreset) -> tuple[Image.Image, dict[str, Any]]:
        source = image.convert("RGB")
        original = _to_rgb_array(source)
        qr_enabled = preset.get_float("qr_protection", 0.0) >= 0.5
        qr_mask, qr_bbox = detect_qr_or_watermark(source) if qr_enabled else _empty_qr_mask(source.width, source.height)
        qr_original = original.copy()
        metrics_before = PhotoQualityAnalyzer().analyze(source, qr_detected=qr_bbox is not None)
        masks = MaskProvider().build_masks(source, metrics_before, qr_info=(qr_mask, qr_bbox))
        params = self.resolve_params(metrics_before, masks, preset)

        out = original.copy()
        out = _global_adjust(out)
        out = _white_balance(out, masks)
        out = _recover_highlights(out, masks.highlight, params.highlight_recovery)
        out = _recover_highlights(out, masks.white_clothes, params.white_clothes_recovery)
        out = _skin_flash_control(out, masks.skin, masks.highlight, params)
        out = _compress_remaining_hotspots(out, masks, params.hotspot_compression)
        out = _zone_saturation(out, masks.red_clothes, red_delta=-params.red_saturation_reduction, value_delta=-0.05)
        out = _zone_saturation(out, masks.green_background, green_delta=-params.green_saturation_reduction, value_delta=params.green_background_exposure)
        if params.subject_pop:
            out = _subject_pop(out, masks, params)
        out = _soft_vignette(out, masks, params.vignette)
        out = _denoise_background(out, masks, params.denoise)
        out = _luminance_sharpen(out, masks, params.sharpen)

        out = _restore_mask(out, qr_original, qr_mask)
        result = Image.fromarray(np.clip(out * 255.0, 0, 255).astype(np.uint8), "RGB")
        validation = EnhancementValidator().validate(original, out, masks, qr_original)
        if not validation.passed and "highlight_area_high" in validation.warnings:
            corrected = _recover_highlights(out, masks.highlight, 0.10)
            corrected = _restore_mask(corrected, qr_original, qr_mask)
            out = corrected
            result = Image.fromarray(np.clip(out * 255.0, 0, 255).astype(np.uint8), "RGB")
            validation = EnhancementValidator().validate(original, out, masks, qr_original)

        report = {
            "souvenir_metrics": metrics_before.to_dict(),
            "souvenir_masks": masks.summary(),
            "souvenir_params": params.to_dict(),
            "souvenir_validation": validation.to_dict(),
        }
        return result, report


class EnhancementValidator:
    def validate(
        self,
        before: np.ndarray,
        after: np.ndarray,
        masks: SouvenirMasks,
        qr_original: np.ndarray,
    ) -> EnhancementValidation:
        before_luma = _luminance(before)
        after_luma = _luminance(after)
        clipped_before = float(np.mean((before_luma > 0.985) | (np.max(before, axis=2) > 0.980)))
        highlight_before = float(np.mean(before_luma > 0.900))
        clipped_after = float(np.mean((after_luma > 0.985) | (np.max(after, axis=2) > 0.980)))
        highlight_after = float(np.mean(after_luma > 0.900))
        qr_diff = 0
        if masks.qr_bbox is not None:
            changed = np.abs(after - qr_original) * masks.qr[..., None]
            qr_diff = int(round(float(np.max(changed * 255.0))))
        warnings: list[str] = []
        if clipped_after > max(0.025, clipped_before + 0.020):
            warnings.append("clipped_area_high")
        if highlight_after > max(0.075, highlight_before + 0.020):
            warnings.append("highlight_area_high")
        if qr_diff != 0:
            warnings.append("qr_changed")
        return EnhancementValidation(
            passed=not warnings,
            warnings=warnings,
            clipped_area_after=round(clipped_after, 4),
            highlight_area_after=round(highlight_after, 4),
            qr_difference=qr_diff,
        )


def detect_qr_or_watermark(image: Image.Image) -> tuple[np.ndarray, tuple[int, int, int, int] | None]:
    rgb = np.asarray(image.convert("RGB"))
    height, width = rgb.shape[:2]
    mask = np.zeros((height, width), dtype=np.float32)
    bbox = _detect_corner_code(rgb)
    if bbox is None:
        bbox = _detect_qr_cv(rgb)
    if bbox is None:
        return mask, None
    left, top, right, bottom = bbox
    left = max(0, min(width, left))
    right = max(0, min(width, right))
    top = max(0, min(height, top))
    bottom = max(0, min(height, bottom))
    if right <= left or bottom <= top:
        return mask, None
    mask[top:bottom, left:right] = 1.0
    return mask, (left, top, right, bottom)


def _detect_qr_cv(rgb: np.ndarray) -> tuple[int, int, int, int] | None:
    if cv2 is None:
        return None
    try:
        detector = cv2.QRCodeDetector()
        ok, points = detector.detect(rgb)
        if not ok or points is None:
            return None
        pts = np.asarray(points).reshape(-1, 2)
        pad = 6
        left = int(np.floor(np.min(pts[:, 0]))) - pad
        right = int(np.ceil(np.max(pts[:, 0]))) + pad
        top = int(np.floor(np.min(pts[:, 1]))) - pad
        bottom = int(np.ceil(np.max(pts[:, 1]))) + pad
        return left, top, right, bottom
    except Exception:
        return None


def _detect_corner_code(rgb: np.ndarray) -> tuple[int, int, int, int] | None:
    height, width = rgb.shape[:2]
    gray = _luminance(rgb.astype(np.float32) / 255.0)
    max_side = max(24, int(round(min(width, height) * 0.135)))
    corners = [
        (0, height - max_side, max_side, height),
        (width - max_side, height - max_side, width, height),
    ]
    best: tuple[float, tuple[int, int, int, int] | None] = (0.0, None)
    for left, top, right, bottom in corners:
        crop = gray[top:bottom, left:right]
        if crop.size == 0:
            continue
        contrast = float(crop.std())
        dark = float(np.mean(crop < 0.18))
        light = float(np.mean(crop > 0.82))
        if cv2 is not None:
            edges = cv2.Laplacian((crop * 255).astype(np.uint8), cv2.CV_64F).var() / 255.0
        else:
            gy, gx = np.gradient(crop)
            edges = float(np.mean(np.hypot(gx, gy)))
        score = contrast + min(dark, light) + min(1.0, float(edges) * 0.07)
        if score > best[0]:
            best = (score, (left, top, right, bottom))
    if best[0] < 0.52:
        return None
    return best[1]


def _empty_qr_mask(width: int, height: int) -> tuple[np.ndarray, tuple[int, int, int, int] | None]:
    return np.zeros((height, width), dtype=np.float32), None


def _to_rgb_array(image: Image.Image) -> np.ndarray:
    return np.asarray(image.convert("RGB")).astype(np.float32) / 255.0


def _analysis_image(image: Image.Image, max_side: int) -> Image.Image:
    sample = image.convert("RGB")
    side = max(sample.size)
    if side <= max_side:
        return sample
    scale = float(max_side) / float(side)
    return sample.resize(
        (max(1, int(round(sample.width * scale))), max(1, int(round(sample.height * scale)))),
        Image.Resampling.BILINEAR,
    )


def _resize_mask(mask: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    width, height = size
    if mask.shape == (height, width):
        return np.clip(mask.astype(np.float32), 0.0, 1.0)
    if cv2 is None:
        image = Image.fromarray(np.clip(mask * 255.0, 0, 255).astype(np.uint8), "L")
        return np.asarray(image.resize((width, height), Image.Resampling.BILINEAR)).astype(np.float32) / 255.0
    return np.clip(cv2.resize(mask.astype(np.float32), (width, height), interpolation=cv2.INTER_LINEAR), 0.0, 1.0)


def _rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    if cv2 is None:
        maxc = np.max(rgb, axis=-1)
        minc = np.min(rgb, axis=-1)
        sat = np.zeros_like(maxc)
        nonzero = maxc > 0
        sat[nonzero] = (maxc[nonzero] - minc[nonzero]) / np.maximum(maxc[nonzero], 0.0001)
        return np.stack([np.zeros_like(maxc), sat, maxc], axis=-1)
    return cv2.cvtColor(np.clip(rgb * 255.0, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32) / np.array([179.0, 255.0, 255.0], dtype=np.float32)


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _skin_mask(rgb: np.ndarray) -> np.ndarray:
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    mask = (
        (r > 0.22) & (g > 0.13) & (b > 0.08)
        & ((maxc - minc) > 0.045)
        & (r > g * 1.04)
        & (r > b * 1.10)
    )
    return mask.astype(np.float32)


def _green_mask(rgb: np.ndarray, hsv: np.ndarray, luma: np.ndarray) -> np.ndarray:
    hue = hsv[..., 0]
    sat = hsv[..., 1]
    return ((hue > 0.18) & (hue < 0.46) & (sat > 0.18) & (luma > 0.10)).astype(np.float32)


def _red_mask(rgb: np.ndarray, hsv: np.ndarray) -> np.ndarray:
    hue = hsv[..., 0]
    sat = hsv[..., 1]
    return (((hue < 0.055) | (hue > 0.92)) & (sat > 0.28) & (rgb[..., 0] > 0.32)).astype(np.float32)


def _central_subject_prior(height: int, width: int) -> np.ndarray:
    yy, xx = np.mgrid[0:height, 0:width]
    cx = width * 0.50
    cy = height * 0.52
    rx = width * 0.42
    ry = height * 0.48
    dist = ((xx - cx) / max(rx, 1.0)) ** 2 + ((yy - cy) / max(ry, 1.0)) ** 2
    return np.clip(1.0 - (dist - 0.55) / 0.75, 0.0, 1.0).astype(np.float32)


def _feather(mask: np.ndarray, radius: int) -> np.ndarray:
    mask = np.asarray(mask, dtype=np.float32)
    if radius <= 0 or cv2 is None:
        return np.clip(mask, 0.0, 1.0)
    return np.clip(cv2.GaussianBlur(mask, (0, 0), float(radius) / 3.0), 0.0, 1.0)


def _global_adjust(rgb: np.ndarray) -> np.ndarray:
    luma = _luminance(rgb)
    out = rgb.copy()
    out -= (0.035 * _smoothstep(0.78, 1.0, luma))[..., None]
    out += (0.030 * (1.0 - _smoothstep(0.08, 0.42, luma)))[..., None]
    out = (out - 0.5) * 1.035 + 0.5
    return np.clip(out, 0.0, 1.0)


def _white_balance(rgb: np.ndarray, masks: SouvenirMasks) -> np.ndarray:
    protect = masks.skin * 0.55 + masks.qr
    gains = np.array([0.992, 0.976, 1.018], dtype=np.float32)
    corrected = np.clip(rgb * gains[None, None, :], 0.0, 1.0)
    blend = np.clip(0.55 * (1.0 - protect), 0.0, 0.55)[..., None]
    return rgb * (1.0 - blend) + corrected * blend


def _recover_highlights(rgb: np.ndarray, mask: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0.001:
        return rgb
    luma = _luminance(rgb)
    hot = np.clip(mask * _smoothstep(0.70, 1.0, luma), 0.0, 1.0)
    target = np.minimum(luma, 0.94 - 0.10 * strength)
    scale = np.divide(target, np.maximum(luma, 0.001))
    recovered = np.clip(rgb * scale[..., None], 0.0, 1.0)
    blend = np.clip(hot * strength, 0.0, 0.85)[..., None]
    return rgb * (1.0 - blend) + recovered * blend


def _skin_flash_control(rgb: np.ndarray, skin: np.ndarray, highlight: np.ndarray, params: SouvenirParams) -> np.ndarray:
    shine = np.clip(skin * highlight, 0.0, 1.0)
    out = _recover_highlights(rgb, shine, params.skin_shine_reduction)
    lift = np.clip(skin * (1.0 - highlight), 0.0, 1.0)[..., None]
    return np.clip(out + lift * params.face_lift * 0.10, 0.0, 1.0)


def _compress_remaining_hotspots(rgb: np.ndarray, masks: SouvenirMasks, amount: float) -> np.ndarray:
    if amount <= 0.001:
        return rgb
    luma = _luminance(rgb)
    max_channel = np.max(rgb, axis=2)
    hot = np.maximum(_smoothstep(0.86, 1.0, luma), _smoothstep(0.94, 1.0, max_channel))
    target_luma = np.minimum(luma, 0.900 + (luma - 0.900) * 0.30)
    luma_scale = np.divide(target_luma, np.maximum(luma, 0.001))
    target_max = np.minimum(max_channel, 0.960)
    max_scale = np.divide(target_max, np.maximum(max_channel, 0.001))
    scale = np.minimum(luma_scale, max_scale)
    compressed = np.clip(rgb * scale[..., None], 0.0, 1.0)
    protect = np.clip(masks.face * 0.28 + masks.qr, 0.0, 1.0)
    blend = np.clip(hot * amount * (1.0 - protect), 0.0, 0.82)[..., None]
    return rgb * (1.0 - blend) + compressed * blend


def _zone_saturation(rgb: np.ndarray, mask: np.ndarray, red_delta: float = 0.0, green_delta: float = 0.0, value_delta: float = 0.0) -> np.ndarray:
    if np.max(mask) <= 0.001 or cv2 is None:
        return rgb
    hsv = _rgb_to_hsv(rgb)
    delta = red_delta if abs(red_delta) > abs(green_delta) else green_delta
    adjusted = hsv.copy()
    adjusted[..., 1] = np.clip(adjusted[..., 1] * (1.0 + delta), 0.0, 1.0)
    adjusted[..., 2] = np.clip(adjusted[..., 2] + value_delta * 0.30, 0.0, 1.0)
    adjusted_rgb = cv2.cvtColor(
        np.clip(adjusted * np.array([179.0, 255.0, 255.0], dtype=np.float32), 0, 255).astype(np.uint8),
        cv2.COLOR_HSV2RGB,
    ).astype(np.float32) / 255.0
    blend = np.clip(mask, 0.0, 1.0)[..., None]
    return rgb * (1.0 - blend) + adjusted_rgb * blend


def _subject_pop(rgb: np.ndarray, masks: SouvenirMasks, params: SouvenirParams) -> np.ndarray:
    subject = masks.subject[..., None]
    background = (1.0 - masks.subject) * (1.0 - masks.qr)
    out = np.clip(rgb + subject * params.subject_exposure * 0.75 + background[..., None] * params.background_exposure * 0.35, 0.0, 1.0)
    detail = _local_detail(out)
    out += detail * (subject * params.clarity * 0.55 - background[..., None] * params.clarity * 0.26)
    return np.clip(out, 0.0, 1.0)


def _soft_vignette(rgb: np.ndarray, masks: SouvenirMasks, amount: float) -> np.ndarray:
    if amount <= 0.001:
        return rgb
    height, width = rgb.shape[:2]
    yy, xx = np.mgrid[0:height, 0:width]
    dist = np.sqrt(((xx - width / 2) / max(width / 2, 1)) ** 2 + ((yy - height / 2) / max(height / 2, 1)) ** 2)
    vignette = np.clip((dist - 0.48) / 0.52, 0.0, 1.0) ** 1.6
    protect = np.clip(masks.face * 0.9 + masks.qr, 0.0, 1.0)
    factor = 1.0 - amount * vignette * (1.0 - protect)
    return np.clip(rgb * factor[..., None], 0.0, 1.0)


def _denoise_background(rgb: np.ndarray, masks: SouvenirMasks, amount: float) -> np.ndarray:
    if amount <= 0.001 or cv2 is None:
        return rgb
    denoised = cv2.GaussianBlur(rgb, (0, 0), 0.45)
    blend = np.clip((1.0 - masks.subject) * amount * 0.32 * (1.0 - masks.qr), 0.0, 0.16)[..., None]
    return rgb * (1.0 - blend) + denoised * blend


def _luminance_sharpen(rgb: np.ndarray, masks: SouvenirMasks, amount: float) -> np.ndarray:
    if amount <= 0.001 or cv2 is None:
        return rgb
    blur = cv2.GaussianBlur(rgb, (0, 0), 0.75)
    detail = rgb - blur
    weight = np.clip((0.15 + masks.subject * 0.85 + masks.face * 0.35) * (1.0 - masks.qr), 0.0, 1.0)
    return np.clip(rgb + detail * (amount * 0.90) * weight[..., None], 0.0, 1.0)


def _local_detail(rgb: np.ndarray) -> np.ndarray:
    if cv2 is None:
        return np.zeros_like(rgb)
    blur = cv2.GaussianBlur(rgb, (0, 0), 1.4)
    return rgb - blur


def _restore_mask(out: np.ndarray, original: np.ndarray, mask: np.ndarray) -> np.ndarray:
    if np.max(mask) <= 0.0:
        return out
    exact = mask[..., None] > 0.5
    return np.where(exact, original, out)


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, float(value)))
