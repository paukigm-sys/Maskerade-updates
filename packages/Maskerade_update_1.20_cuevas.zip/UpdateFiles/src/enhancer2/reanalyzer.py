from __future__ import annotations

from dataclasses import asdict, dataclass

from .analyzer import ImageAnalysis


@dataclass(frozen=True)
class Reanalysis:
    accepted: bool
    input_score: int
    output_score: int
    warnings: list[str]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class ReAnalyzer:
    def compare(self, before: ImageAnalysis, after: ImageAnalysis) -> Reanalysis:
        warnings: list[str] = []
        if after.highlight_clip_percent > before.highlight_clip_percent + 3.0:
            warnings.append("highlight_clipping_increased")
        if after.shadow_clip_percent > before.shadow_clip_percent + 3.0:
            warnings.append("shadow_clipping_increased")
        if after.saturation_score > before.saturation_score + 0.35:
            warnings.append("saturation_jump")

        input_score = _score(before)
        output_score = _score(after)
        return Reanalysis(
            accepted=output_score >= input_score - 4 and len(warnings) < 2,
            input_score=input_score,
            output_score=output_score,
            warnings=warnings,
        )


def _score(analysis: ImageAnalysis) -> int:
    score = 70
    score -= int(abs(analysis.mean_luma - 0.52) * 70)
    score -= int(max(0.0, analysis.shadow_clip_percent - 2.0) * 1.6)
    score -= int(max(0.0, analysis.highlight_clip_percent - 1.5) * 1.8)
    score += int(min(analysis.contrast_score, 1.0) * 12)
    score += int(min(analysis.sharpness_score, 1.0) * 8)
    score -= int(max(0.0, analysis.noise_score - 0.45) * 12)
    return max(0, min(100, score))
