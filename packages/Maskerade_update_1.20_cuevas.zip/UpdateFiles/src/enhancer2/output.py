from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from PIL import Image


def attach_report(image: Image.Image, report: dict[str, Any]) -> Image.Image:
    image.info["_enhancer2_report"] = report
    return image


def report_from_image(image: Image.Image) -> dict[str, Any] | None:
    report = image.info.get("_enhancer2_report")
    return report if isinstance(report, dict) else None


def write_enhancement_log(
    report: dict[str, Any] | None,
    log_dir: Path,
    input_path: Path | None = None,
    output_path: Path | None = None,
) -> Path | None:
    if not report:
        return None
    payload = dict(report)
    payload["input"] = str(input_path) if input_path is not None else payload.get("input")
    payload["output"] = str(output_path) if output_path is not None else payload.get("output")

    log_dir.mkdir(parents=True, exist_ok=True)
    stem = (input_path.stem if input_path is not None else "image").replace(" ", "_")
    target = _unique_path(log_dir / f"{time.strftime('%Y%m%d-%H%M%S')}_{stem}.json")
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(target)
    return target


def write_image_atomic(image: Image.Image, output_path: Path, quality: int = 94) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = output_path.with_name(f".{output_path.name}.tmp{output_path.suffix}")
    suffix = output_path.suffix.lower()
    if suffix in {".jpg", ".jpeg"}:
        image.convert("RGB").save(tmp, "JPEG", quality=quality, optimize=True, subsampling=0)
    else:
        image.save(tmp)
    with Image.open(tmp) as check:
        check.verify()
    tmp.replace(output_path)


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for index in range(2, 10000):
        candidate = path.with_name(f"{path.stem}_{index}{path.suffix}")
        if not candidate.exists():
            return candidate
    return path.with_name(f"{path.stem}_{int(time.time() * 1000)}{path.suffix}")
