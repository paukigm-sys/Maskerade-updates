from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_PRESETS: dict[str, dict[str, float | int]] = {
    "default_event": {"strength": 0.72, "white_balance": 0.48, "exposure": 0.36, "gamma": 0.26, "global_contrast": 0.38, "local_contrast": 0.24, "shadow_recovery": 0.28, "highlight_protection": 0.58, "saturation": 0.16, "skin_protection": 0.88, "denoise": 0.14, "sharpen": 0.30, "jpeg_quality": 94},
    "pirates_flash": {"strength": 1.00, "white_balance": 0.26, "exposure": -0.34, "gamma": 0.00, "global_contrast": 0.60, "local_contrast": 0.32, "shadow_recovery": 0.02, "highlight_protection": 1.00, "saturation": 0.06, "skin_protection": 0.88, "denoise": 0.10, "sharpen": 0.48, "jpeg_quality": 94},
    "souvenir_family_flash_perfect_v1": {"strength": 1.00, "highlight_recovery": 0.62, "white_clothes_recovery": 0.84, "hotspot_compression": 0.62, "green_background_exposure": -0.13, "green_saturation_reduction": 0.18, "red_saturation_reduction": 0.16, "subject_exposure": 0.04, "background_exposure": -0.12, "face_lift": 0.08, "skin_shine_reduction": 0.42, "clarity": 0.18, "denoise": 0.00, "sharpen": 0.56, "vignette": 0.00, "qr_protection": 0, "jpeg_quality": 94},
    "cuevas_lowlight": {"strength": 0.78, "white_balance": 0.36, "exposure": 0.46, "gamma": 0.34, "global_contrast": 0.34, "local_contrast": 0.28, "shadow_recovery": 0.52, "highlight_protection": 0.78, "saturation": 0.10, "skin_protection": 0.94, "denoise": 0.28, "sharpen": 0.22, "jpeg_quality": 94},
    "dinos_daylight": {"strength": 0.74, "white_balance": 0.46, "exposure": 0.26, "gamma": 0.18, "global_contrast": 0.44, "local_contrast": 0.24, "shadow_recovery": 0.18, "highlight_protection": 0.64, "saturation": 0.22, "skin_protection": 0.88, "denoise": 0.08, "sharpen": 0.32, "jpeg_quality": 94},
    "ai_composite_subject": {"strength": 0.55, "white_balance": 0.34, "exposure": 0.20, "gamma": 0.16, "global_contrast": 0.24, "local_contrast": 0.10, "shadow_recovery": 0.18, "highlight_protection": 0.70, "saturation": 0.06, "skin_protection": 0.97, "denoise": 0.16, "sharpen": 0.16, "jpeg_quality": 94},
    "final_composite_grade": {"strength": 0.35, "white_balance": 0.35, "exposure": 0.15, "gamma": 0.15, "global_contrast": 0.20, "local_contrast": 0.10, "shadow_recovery": 0.15, "highlight_protection": 0.30, "saturation": 0.06, "skin_protection": 0.90, "denoise": 0.05, "sharpen": 0.15, "jpeg_quality": 94},
}


@dataclass(frozen=True)
class EnhancementPreset:
    name: str
    values: dict[str, float | int]

    def get_float(self, key: str, default: float = 0.0) -> float:
        try:
            return float(self.values.get(key, default))
        except (TypeError, ValueError):
            return default

    def get_int(self, key: str, default: int = 0) -> int:
        try:
            return int(self.values.get(key, default))
        except (TypeError, ValueError):
            return default


class PresetManager:
    def __init__(self, root_dir: Path | None = None, preset_path: Path | None = None) -> None:
        self.root_dir = Path(root_dir) if root_dir is not None else Path.cwd()
        self.preset_path = preset_path or (self.root_dir / "config" / "enhancer2_presets.json")

    def load(self, name: str | None) -> EnhancementPreset:
        presets = self.load_all()
        selected = str(name or "default_event").strip() or "default_event"
        if selected not in presets:
            selected = "default_event"
        return EnhancementPreset(selected, dict(presets[selected]))

    def load_all(self) -> dict[str, dict[str, float | int]]:
        presets = {key: dict(value) for key, value in DEFAULT_PRESETS.items()}
        if not self.preset_path.exists():
            return presets
        try:
            payload = json.loads(self.preset_path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            return presets
        if not isinstance(payload, dict):
            return presets
        for key, value in payload.items():
            if not isinstance(key, str) or not isinstance(value, dict):
                continue
            cleaned = _numeric_values(value)
            if cleaned:
                base = dict(presets.get(key, DEFAULT_PRESETS["default_event"]))
                base.update(cleaned)
                presets[key] = base
        return presets


def _numeric_values(values: dict[str, Any]) -> dict[str, float | int]:
    cleaned: dict[str, float | int] = {}
    for key, value in values.items():
        if isinstance(value, bool):
            continue
        if isinstance(value, (int, float)):
            cleaned[key] = value
        elif isinstance(value, str):
            try:
                cleaned[key] = float(value)
            except ValueError:
                continue
    return cleaned
