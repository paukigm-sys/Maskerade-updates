from __future__ import annotations

import argparse
import sys
from pathlib import Path

from PIL import Image, ImageOps

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from src.enhancer2.output import write_enhancement_log, write_image_atomic
    from src.enhancer2.pipeline import enhance_image
else:
    from .output import write_enhancement_log, write_image_atomic
    from .pipeline import enhance_image


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="QEnhance Auto v2 local enhancer")
    parser.add_argument("input", nargs="?", help="Input image or folder")
    parser.add_argument("output", nargs="?", help="Output image or folder")
    parser.add_argument("--input-dir", help="Input folder")
    parser.add_argument("--output-dir", help="Output folder")
    parser.add_argument("--preset", default="default_event")
    parser.add_argument("--autotune", action="store_true")
    parser.add_argument("--strength", type=float, default=1.0)
    parser.add_argument("--quality", type=int, default=None)
    parser.add_argument("--log-dir", default="logs/enhancer2")
    args = parser.parse_args(argv)

    input_dir = Path(args.input_dir) if args.input_dir else None
    output_dir = Path(args.output_dir) if args.output_dir else None
    if input_dir or output_dir:
        if input_dir is None or output_dir is None:
            raise SystemExit("--input-dir and --output-dir must be used together")
        return _process_folder(input_dir, output_dir, args)

    if not args.input or not args.output:
        raise SystemExit("Usage: python -m src.enhancer2.cli input.jpg output.jpg [--preset NAME]")
    return _process_one(Path(args.input), Path(args.output), args)


def _process_folder(input_dir: Path, output_dir: Path, args) -> int:
    output_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for path in sorted(input_dir.iterdir()):
        if path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
            continue
        _process_one(path, output_dir / (path.stem + ".jpg"), args)
        count += 1
    print(f"processed\t{count}")
    return 0


def _process_one(input_path: Path, output_path: Path, args) -> int:
    with Image.open(input_path) as opened:
        source = ImageOps.exif_transpose(opened).convert("RGB")
    result = enhance_image(
        source,
        preset_name=args.preset,
        strength=args.strength,
        root_dir=Path.cwd(),
        autotune=bool(args.autotune),
    )
    quality = int(args.quality or result.report.get("decision", {}).get("jpeg_quality", 94))
    write_image_atomic(result.image, output_path, quality=quality)
    write_enhancement_log(result.report, Path(args.log_dir), input_path, output_path)
    print(output_path.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
