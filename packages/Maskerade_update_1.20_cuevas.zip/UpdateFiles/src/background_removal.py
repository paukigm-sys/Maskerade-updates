from __future__ import annotations

import logging
import sys
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageFilter

from .config import BackgroundRemovalSettings, ConfigurationError


@dataclass(frozen=True)
class RemovalResult:
    person_rgba: Image.Image
    mask: Image.Image
    backend_used: str
    warning: str | None = None


class BackgroundRemover:
    """Production remover: BEN2 with local mask cleanup."""

    def __init__(
        self,
        settings: BackgroundRemovalSettings,
        logger: logging.Logger | None = None,
    ) -> None:
        self.settings = settings
        self.logger = logger or logging.getLogger(__name__)
        self._ben2_model = None
        self._ben2_device = None
        self._u2net_human_session = None
        self._u2net_human_warning = False

    def remove_background(self, image: Image.Image) -> RemovalResult:
        backend = (self.settings.backend or "ben2").lower()
        if backend not in {"ben2", "ben"}:
            raise ConfigurationError(
                f"Motor de recorte no soportado: {self.settings.backend}. "
                "Esta version limpia solo usa BEN2."
            )

        working, scale = self._working_image(image)
        rgba = self._remove_with_ben2(working)
        if scale != 1.0:
            mask = rgba.getchannel("A").resize(image.size, Image.Resampling.LANCZOS)
            rgba = image.convert("RGBA")
            rgba.putalpha(mask)

        antighost = _calibrated_mask_repair_amount(
            getattr(self.settings, "mask_antighost", 0) or 0
        )
        if antighost > 0:
            rgba = self._apply_mask_antighost(rgba, amount=antighost, calibrated=True)
        rgba, _rescued = self._apply_u2net_human_rescue(image, rgba)
        rgba = self._apply_mask_protection(rgba, run_antighost=False)
        rgba = self._trim_soft_edge_noise(rgba)
        return RemovalResult(rgba, rgba.getchannel("A"), "ben2")

    def _apply_u2net_human_rescue(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        antighost_raw = max(0, min(100, int(getattr(self.settings, "mask_antighost", 0) or 0)))
        protection_raw = max(0, min(100, int(getattr(self.settings, "mask_protection", 0) or 0)))
        if max(antighost_raw, protection_raw) < 35:
            return rgba, False

        antighost = _calibrated_mask_repair_amount(antighost_raw)
        protection = _calibrated_mask_repair_amount(protection_raw)
        amount = antighost if antighost > 0 else max(0, protection - 45) * 2
        amount = max(0, min(100, int(amount)))
        if amount <= 0:
            return rgba, False

        try:
            import cv2
            import numpy as np
            import onnxruntime as ort
        except Exception:
            if not self._u2net_human_warning:
                self.logger.warning("Rescate antifantasma desactivado: falta onnxruntime/cv2/numpy.")
                self._u2net_human_warning = True
            return rgba, False

        model_path = self._u2net_human_model_path()
        if model_path is None:
            if not self._u2net_human_warning:
                self.logger.warning("Rescate antifantasma desactivado: no se encontro u2net_human_seg.onnx.")
                self._u2net_human_warning = True
            return rgba, False

        if self._u2net_human_session is None:
            self._u2net_human_session = ort.InferenceSession(
                str(model_path),
                providers=["CPUExecutionProvider"],
            )

        input_meta = self._u2net_human_session.get_inputs()[0]
        input_size = int(input_meta.shape[2] or 320)
        resized = source.convert("RGB").resize((input_size, input_size), Image.Resampling.LANCZOS)
        arr = np.asarray(resized, dtype=np.float32) / 255.0
        arr = (arr - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array(
            [0.229, 0.224, 0.225],
            dtype=np.float32,
        )
        tensor = arr.transpose(2, 0, 1)[None, :, :, :]
        raw = self._u2net_human_session.run(None, {input_meta.name: tensor})[0][0, 0]
        raw = raw - raw.min()
        max_value = float(raw.max())
        if max_value <= 0:
            return rgba, False
        raw = (raw / max_value * 255.0).astype(np.uint8)
        rescue_raw = np.asarray(
            Image.fromarray(raw, "L").resize(rgba.size, Image.Resampling.LANCZOS),
            dtype=np.uint8,
        )

        current = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(current > 0):
            return rgba, False

        strength = amount / 100.0
        threshold = int(round(145 - (82 * strength)))
        rescue_binary = (rescue_raw >= threshold).astype(np.uint8)
        if not np.any(rescue_binary):
            return rgba, False

        seed_threshold = max(12, int(round(42 - (24 * strength))))
        seed = (current >= seed_threshold).astype(np.uint8)
        seed_count, seed_labels, seed_stats, _ = cv2.connectedComponentsWithStats(seed, 8)
        if seed_count <= 1:
            return rgba, False

        seed_areas = seed_stats[1:, cv2.CC_STAT_AREA]
        main_seed_label = int(np.argmax(seed_areas)) + 1
        primary_seed = seed_labels == main_seed_label

        seed = primary_seed.astype(np.uint8)
        support_size = _odd_kernel(13 + int(round(30 * strength)))
        support = cv2.dilate(seed, np.ones((support_size, support_size), np.uint8), iterations=1)

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(rescue_binary, 8)
        keep = np.zeros_like(rescue_binary, dtype=np.uint8)
        min_area = max(180, int(rescue_binary.size * 0.000035))
        for label in range(1, component_count):
            area = stats[label, cv2.CC_STAT_AREA]
            if area < min_area:
                continue
            component = labels == label
            overlap = int(np.count_nonzero(support[component]))
            min_overlap = max(30, int(area * (0.035 + (0.025 * (1.0 - strength)))))
            if overlap >= min_overlap:
                keep[component] = 1

        if not np.any(keep):
            return rgba, False

        rescue = rescue_raw.astype(np.float32)
        rescue = ((rescue - threshold) * (255.0 / max(1, 255 - threshold))).clip(0, 255)
        rescue *= keep
        rescue = cv2.morphologyEx(
            rescue.astype(np.uint8),
            cv2.MORPH_CLOSE,
            np.ones((_odd_kernel(5 + int(round(8 * strength))),) * 2, np.uint8),
            iterations=1,
        )
        rescue = cv2.GaussianBlur(rescue, (_odd_kernel(3 + int(round(4 * strength))),) * 2, 0)
        rescued_alpha = np.maximum(current, rescue).astype(np.uint8)

        result = rgba.copy()
        result.putalpha(Image.fromarray(rescued_alpha, "L"))
        return result, True

    def _u2net_human_model_path(self) -> Path | None:
        candidates = [
            Path.cwd() / "models" / "u2net_human_seg.onnx",
            Path.home() / ".u2net" / "u2net_human_seg.onnx",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return None

    def _apply_mask_protection(
        self,
        rgba: Image.Image,
        run_antighost: bool = True,
    ) -> Image.Image:
        protection = _calibrated_mask_repair_amount(self.settings.mask_protection)
        antighost = _calibrated_mask_repair_amount(
            getattr(self.settings, "mask_antighost", 0) or 0
        )
        if run_antighost and antighost > 0:
            rgba = self._apply_mask_antighost(rgba, amount=antighost, calibrated=True)
        if protection <= 0:
            return rgba

        alpha = rgba.getchannel("A")
        strength = protection / 100.0
        alpha = alpha.point(_alpha_boost_lut(strength))

        if protection >= 12:
            close_size = _mask_filter_size(protection)
            alpha = alpha.filter(ImageFilter.MaxFilter(close_size))
            alpha = alpha.filter(ImageFilter.MinFilter(close_size))
        if protection >= 55:
            alpha = alpha.filter(ImageFilter.MaxFilter(_mask_filter_size(protection - 45)))

        blur = 0.05 + (0.65 * strength)
        if blur >= 0.5:
            alpha = alpha.filter(ImageFilter.GaussianBlur(blur))

        result = rgba.copy()
        result.putalpha(alpha)
        return result

    def _apply_mask_antighost(
        self,
        rgba: Image.Image,
        amount: int | None = None,
        calibrated: bool = False,
    ) -> Image.Image:
        if amount is None:
            amount = int(getattr(self.settings, "mask_antighost", 0) or 0)
        amount = (
            max(0, min(100, int(amount)))
            if calibrated
            else _calibrated_mask_repair_amount(amount)
        )
        if amount <= 0:
            return rgba

        try:
            import cv2
            import numpy as np
        except Exception:
            self.logger.warning("Antifantasma desactivado: faltan cv2/numpy.")
            return rgba

        arr = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(arr > 0):
            return rgba

        strength = amount / 100.0
        strong_threshold = max(72, int(round(154 - (62 * strength))))
        weak_threshold = max(10, int(round(24 - (8 * strength))))

        strong = (arr >= strong_threshold).astype(np.uint8) * 255
        weak = (arr >= weak_threshold).astype(np.uint8) * 255
        if not np.any(strong):
            return rgba

        support_size = _odd_kernel(7 + int(round(18 * strength)))
        support_seed = cv2.dilate(
            strong,
            np.ones((support_size, support_size), np.uint8),
            iterations=1,
        )
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(weak, 8)
        candidates = []
        repaired = np.zeros_like(arr, dtype=np.uint8)
        min_area = max(140, int(arr.size * (0.000025 + (0.00005 * strength))))
        for label in range(1, component_count):
            x = stats[label, cv2.CC_STAT_LEFT]
            y = stats[label, cv2.CC_STAT_TOP]
            w = stats[label, cv2.CC_STAT_WIDTH]
            h = stats[label, cv2.CC_STAT_HEIGHT]
            area = stats[label, cv2.CC_STAT_AREA]
            if area < min_area:
                continue
            component = labels == label
            strong_pixels = int(np.count_nonzero(strong[component]))
            supported_pixels = int(np.count_nonzero(support_seed[component]))
            min_supported = max(30, int(area * (0.08 - (0.03 * strength))))
            if strong_pixels > 0 or supported_pixels >= min_supported:
                candidates.append((label, area, x, y, w, h, strong_pixels))

        if not candidates:
            return rgba

        largest = max(candidates, key=lambda item: item[1])
        largest_label = largest[0]
        largest_area = largest[1]
        main_component = (labels == largest_label).astype(np.uint8) * 255
        main_support = cv2.dilate(
            main_component,
            np.ones((_odd_kernel(19 + int(round(24 * strength))),) * 2, np.uint8),
            iterations=1,
        )
        min_height = max(18, int(round(arr.shape[0] * (0.025 + (0.012 * strength)))))
        min_relative_area = 0.008 + (0.018 * strength)
        for label, area, _x, y, _w, h, strong_pixels in candidates:
            component = labels == label
            bottom = y + h
            area_ok = area >= (largest_area * min_relative_area)
            height_ok = h >= min_height
            anchored = label == largest_label or (
                strong_pixels > 0 and area >= (largest_area * (0.12 - (0.04 * strength)))
            )
            main_overlap = int(np.count_nonzero(main_support[component]))
            near_main = main_overlap >= max(20, int(area * (0.025 + (0.025 * strength))))
            lower_ok = bottom >= (arr.shape[0] * 0.25) or area >= (largest_area * 0.10)
            if (label == largest_label or near_main or (anchored and area_ok)) and height_ok and lower_ok:
                repaired[component] = 255

        if not np.any(repaired):
            return rgba

        close_size = _odd_kernel(5 + int(round(10 * strength)))
        repaired = cv2.morphologyEx(
            repaired,
            cv2.MORPH_CLOSE,
            np.ones((close_size, close_size), np.uint8),
            iterations=1,
        )
        repaired = _fill_mask_holes(repaired, cv2, np)

        edge_support_size = _odd_kernel(3 + int(round(6 * strength)))
        support = cv2.dilate(
            repaired,
            np.ones((edge_support_size, edge_support_size), np.uint8),
            iterations=1,
        )
        edge_threshold = max(8, int(round(28 - (14 * strength))))
        fill_alpha = int(round(24 + (166 * (strength ** 0.55))))
        keep = (repaired > 0) | ((arr >= edge_threshold) & (support > 0))
        boosted = np.zeros_like(arr)
        boosted[keep] = arr[keep]
        repair = (repaired > 0) & (boosted < fill_alpha)
        boosted[repair] = fill_alpha

        result = rgba.copy()
        result.putalpha(Image.fromarray(boosted, "L").filter(ImageFilter.GaussianBlur(0.2)))
        return result

    def _trim_soft_edge_noise(self, rgba: Image.Image) -> Image.Image:
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        core = alpha >= 135
        if not np.any(core):
            return rgba

        support = cv2.dilate(
            core.astype(np.uint8),
            np.ones((9, 9), np.uint8),
            iterations=1,
        ).astype(bool)
        cleaned = alpha.copy()
        cleaned[(cleaned < 80) & ~support] = 0

        binary = (cleaned >= 32).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        if component_count <= 1:
            return rgba

        keep = np.zeros_like(binary, dtype=bool)
        min_area = max(80, int(binary.size * 0.00002))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            component = labels == label
            core_pixels = int(np.count_nonzero(core[component]))
            if core_pixels > 0 or area >= min_area * 8:
                keep[component] = True

        if not np.any(keep):
            return rgba

        cleaned[~keep] = 0
        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.15)))
        return result

    def _filter_confident_subject_alpha(self, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        weak_threshold = max(10, int(round(34 - (14 * strength))))
        core_threshold = max(95, int(round(168 - (58 * strength))))
        weak = (alpha >= weak_threshold).astype(np.uint8)
        core = (alpha >= core_threshold).astype(np.uint8) * 255
        if not np.any(weak) or not np.any(core):
            return alpha

        bridge_size = _odd_kernel(max(7, int(round(min(width, height) * (0.008 + (0.004 * strength))))))
        bridge_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (bridge_size, bridge_size))
        core = cv2.morphologyEx(core, cv2.MORPH_CLOSE, bridge_kernel, iterations=1)
        core = cv2.dilate(core, bridge_kernel, iterations=1)

        component_count, labels, stats, _centroids = cv2.connectedComponentsWithStats(weak, 8)
        if component_count <= 2:
            return alpha

        original_area = int(np.count_nonzero(weak))
        filtered = np.zeros_like(alpha, dtype=np.uint8)
        min_component = max(90, int(alpha.size * 0.00005))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_component:
                continue
            y = int(stats[label, cv2.CC_STAT_TOP])
            comp_height = int(stats[label, cv2.CC_STAT_HEIGHT])
            bottom = y + comp_height
            component = labels == label
            core_pixels = int(np.count_nonzero(component & (core > 0)))
            max_alpha = int(alpha[component].max()) if area else 0
            tall_body = comp_height >= height * 0.20 and bottom >= height * 0.40
            anchored = core_pixels >= max(32, int(area * (0.005 + (0.006 * (1.0 - strength)))))
            if anchored or max_alpha >= 235 or (tall_body and core_pixels >= 10):
                filtered[component] = alpha[component]

        kept_area = int(np.count_nonzero(filtered >= weak_threshold))
        if kept_area < original_area * 0.45:
            return alpha
        return filtered

    def _filter_face_supported_alpha(self, rgba: Image.Image, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        cascade_path = Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"
        cascade = cv2.CascadeClassifier(str(cascade_path))
        if cascade.empty():
            return alpha

        gray = cv2.cvtColor(np.asarray(rgba.convert("RGB")), cv2.COLOR_RGB2GRAY)
        gray = cv2.equalizeHist(gray)
        min_face = max(18, min(width, height) // 90)
        faces = cascade.detectMultiScale(
            gray,
            scaleFactor=1.08,
            minNeighbors=4,
            minSize=(min_face, min_face),
        )
        if len(faces) == 0:
            return alpha

        faces = [(int(x), int(y), int(w), int(h)) for x, y, w, h in faces]
        median_face_area = float(np.median([w * h for _x, _y, w, h in faces]))
        faces = [face for face in faces if face[2] * face[3] >= median_face_area * 0.25]
        if not faces:
            return alpha

        support = np.zeros_like(alpha, dtype=np.uint8)
        for x, y, w, h in faces:
            cx = x + w // 2
            body_w = int(w * (4.6 + (2.0 * strength)))
            body_h = int(h * (9.0 + (3.0 * strength)))
            top = max(0, y - int(h * 0.8))
            left = max(0, cx - body_w // 2)
            right = min(width, cx + body_w // 2)
            bottom = min(height, y + body_h)
            cv2.rectangle(support, (left, top), (right, bottom), 255, -1)

            shoulder_w = int(w * (6.5 + (2.0 * strength)))
            shoulder_h = int(h * (1.8 + (0.5 * strength)))
            shoulder_top = max(0, y + int(h * 1.1))
            shoulder_left = max(0, cx - shoulder_w // 2)
            shoulder_right = min(width, cx + shoulder_w // 2)
            shoulder_bottom = min(height, shoulder_top + shoulder_h)
            cv2.rectangle(
                support,
                (shoulder_left, shoulder_top),
                (shoulder_right, shoulder_bottom),
                255,
                -1,
            )

        close_size = _odd_kernel(max(35, int(min(width, height) * (0.035 + (0.025 * strength)))))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_size, close_size))
        support = cv2.morphologyEx(support, cv2.MORPH_CLOSE, kernel, iterations=1)
        support = cv2.dilate(support, kernel, iterations=1)

        min_alpha = max(8, int(round(24 - (10 * strength))))
        original_area = int(np.count_nonzero(alpha >= min_alpha))
        if original_area == 0:
            return alpha

        subject = (alpha >= min_alpha).astype(np.uint8)
        component_count, labels, stats, _centroids = cv2.connectedComponentsWithStats(subject, 8)
        filtered = np.zeros_like(alpha, dtype=np.uint8)
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < max(50, original_area * 0.0003):
                continue
            component = labels == label
            overlap = int(np.count_nonzero(component & (support > 0)))
            if overlap > 0 or area >= original_area * 0.22:
                filtered[component] = alpha[component]

        kept_area = int(np.count_nonzero(filtered >= min_alpha))
        if kept_area < original_area * 0.35:
            return alpha
        return filtered

    def _filter_subject_core_alpha(self, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        weak_threshold = max(24, int(round(76 - (42 * strength))))
        weak = (alpha >= weak_threshold).astype(np.uint8) * 255
        if not np.any(weak):
            return alpha

        bridge_size = _odd_kernel(7 + int(round(16 * strength)))
        bridge_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (bridge_size, bridge_size),
        )
        core = cv2.erode(weak, bridge_kernel, iterations=1)
        core = cv2.morphologyEx(core, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(core, 8)
        if component_count <= 2:
            return alpha

        min_area = max(1500, int(alpha.size * (0.00055 + (0.00035 * strength))))
        min_height = max(80, int(height * (0.11 + (0.05 * strength))))
        valid = []
        for label in range(1, component_count):
            x = stats[label, cv2.CC_STAT_LEFT]
            y = stats[label, cv2.CC_STAT_TOP]
            comp_width = stats[label, cv2.CC_STAT_WIDTH]
            comp_height = stats[label, cv2.CC_STAT_HEIGHT]
            area = stats[label, cv2.CC_STAT_AREA]
            bottom = y + comp_height
            if area < min_area:
                continue
            if comp_height < min_height and bottom < (height * 0.72):
                continue
            if bottom < (height * 0.42) and area < (alpha.size * 0.018):
                continue
            score = area * (0.65 + (0.55 * (bottom / height)))
            valid.append((score, label, area, x, y, comp_width, comp_height, bottom))

        if not valid:
            return alpha

        valid.sort(reverse=True)
        largest_area = max(item[2] for item in valid)
        selected = np.zeros_like(alpha, dtype=np.uint8)
        for _score, label, area, _x, _y, _w, comp_height, bottom in valid:
            large_enough = area >= (largest_area * (0.055 + (0.055 * strength)))
            body_like = comp_height >= min_height and bottom >= (height * (0.50 + (0.10 * strength)))
            if large_enough and body_like:
                selected[labels == label] = 255

        if not np.any(selected):
            return alpha

        restore_size = _odd_kernel(bridge_size + 6)
        restore_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (restore_size, restore_size),
        )
        support = cv2.dilate(selected, restore_kernel, iterations=1)
        support = cv2.morphologyEx(support, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)
        kept = np.zeros_like(alpha)
        kept[(support > 0) & (alpha >= max(12, weak_threshold - 18))] = alpha[
            (support > 0) & (alpha >= max(12, weak_threshold - 18))
        ]
        return kept

    def _working_image(self, image: Image.Image) -> tuple[Image.Image, float]:
        max_side = int(self.settings.max_processing_side or 0)
        if max_side <= 0:
            return image.convert("RGB"), 1.0

        width, height = image.size
        longest = max(width, height)
        if longest <= max_side:
            return image.convert("RGB"), 1.0

        scale = max_side / longest
        size = (max(1, int(width * scale)), max(1, int(height * scale)))
        self.logger.info(
            "BEN2 preview/downscale: %sx%s -> %sx%s",
            width,
            height,
            size[0],
            size[1],
        )
        return image.convert("RGB").resize(size, Image.Resampling.LANCZOS), scale

    def _remove_with_ben2(self, image: Image.Image) -> Image.Image:
        torch = self._import_torch()
        BEN_Base = self._import_ben2()

        if self._ben2_model is None:
            device = self._torch_device(torch)
            model_name = self._model_name()
            self.logger.info("Loading BEN2 model '%s' on %s", model_name, device)
            try:
                model = BEN_Base.from_pretrained(model_name, local_files_only=True)
            except TypeError:
                model = BEN_Base.from_pretrained(model_name)
            except Exception as exc:
                raise ConfigurationError(
                    f"No se pudo cargar BEN2 desde '{model_name}'. "
                    "Comprueba que existe models/BEN2 y que las dependencias BEN2/Torch estan instaladas."
                ) from exc

            if model is None:
                raise ConfigurationError(f"BEN2 no devolvio modelo: {model_name}")

            self._ben2_model = model.to(device).eval()
            self._ben2_device = device

        with torch.inference_mode():
            rgba = self._ben2_model.inference(
                image.convert("RGB"),
                refine_foreground=self.settings.ben2_refine_foreground,
            )
        if not isinstance(rgba, Image.Image):
            raise TypeError("BEN2 no devolvio una imagen PIL")
        return rgba.convert("RGBA")

    def _model_name(self) -> str:
        configured = self.settings.ben2_model or self.settings.model or "models/BEN2"
        path = Path(configured)
        if not path.is_absolute():
            path = Path.cwd() / path
        if path.exists():
            return str(path)
        return configured

    def _torch_device(self, torch_module):
        requested = (self.settings.ben2_device or "auto").lower()
        if requested in {"cuda", "gpu"}:
            if not torch_module.cuda.is_available():
                raise ConfigurationError("BEN2 pidio CUDA, pero Torch no tiene GPU disponible.")
            return torch_module.device("cuda")
        if requested == "cpu":
            return torch_module.device("cpu")
        return torch_module.device("cuda" if torch_module.cuda.is_available() else "cpu")

    def _import_torch(self):
        try:
            import torch
        except ModuleNotFoundError as exc:
            raise ConfigurationError(
                "Falta Torch para BEN2. Instala dependencias con install_dependencies.bat."
            ) from exc
        return torch

    def _import_ben2(self):
        try:
            from ben2 import BEN_Base

            return BEN_Base
        except ModuleNotFoundError:
            model_dir = Path.cwd() / "models" / "BEN2"
            model_file = model_dir / "BEN2.py"
            if not model_file.exists():
                raise ConfigurationError(
                    "No se encontro BEN2 instalado ni models/BEN2/BEN2.py."
                )
            sys.path.insert(0, str(model_dir))
            try:
                from BEN2 import BEN_Base

                return BEN_Base
            except Exception as exc:
                raise ConfigurationError("No se pudo importar BEN2 local.") from exc


def _mask_filter_size(amount: int) -> int:
    radius = max(1, min(3, int(round(amount / 20))))
    return (radius * 2) + 1


def _odd_kernel(size: int) -> int:
    size = max(3, min(31, int(size)))
    return size if size % 2 else size + 1


def _calibrated_mask_repair_amount(value: int | str | float) -> int:
    value = max(0, min(100, int(value)))
    if value <= 0:
        return 0
    if value <= 10:
        return max(1, int(round(value * 0.45)))

    t = (value - 10) / 90.0
    return min(100, int(round(5 + (95 * (t ** 1.35)))))


def _fill_mask_holes(mask, cv2, np):
    flood = mask.copy()
    h, w = flood.shape[:2]
    padded = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, padded, (0, 0), 255)
    holes = cv2.bitwise_not(flood)
    return cv2.bitwise_or(mask, holes)


def _alpha_lut(cutoff: int, full: int) -> list[int]:
    if full <= cutoff:
        return [0 if value <= cutoff else 255 for value in range(256)]
    return [
        0
        if value <= cutoff
        else 255
        if value >= full
        else int(round(((value - cutoff) * 255) / (full - cutoff)))
        for value in range(256)
    ]


def _alpha_boost_lut(strength: float) -> list[int]:
    boost = 0.04 + (0.52 * max(0.0, min(1.0, strength)))
    return [
        0 if value <= 0 else min(255, int(round(value + ((255 - value) * boost))))
        for value in range(256)
    ]
