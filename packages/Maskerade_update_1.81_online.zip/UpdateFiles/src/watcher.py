from __future__ import annotations

import logging
import time
from pathlib import Path

from .config import SUPPORTED_IMAGE_EXTENSIONS, load_settings
from .image_utils import list_images
from .processor import PhotoProcessor, ProcessingBusyError

FileSignature = tuple[int, int, int, int]


class WatchService:
    FAILED_RETRY_DELAY_SECONDS = 5.0
    MAX_FAILED_ATTEMPTS = 3

    def __init__(self, processor: PhotoProcessor, logger: logging.Logger) -> None:
        self.processor = processor
        self.logger = logger
        self._stability: dict[Path, tuple[FileSignature, float]] = {}
        self._processed_signatures: dict[Path, FileSignature] = {}
        self._failed_retries: dict[Path, tuple[FileSignature, float, int]] = {}
        self._unready_since: dict[Path, float] = {}
        self._tree_signature: tuple[tuple[str, int, int], ...] | None = None
        self._tree_stable_since: float | None = None
        self._waiting_for_tree_log = False
        self._busy_path: Path | None = None
        self._busy_next_log_at = 0.0

    def run(self, process_existing: bool = True) -> None:
        self.processor.ensure_ready()
        self.logger.info("Hotfolder input: %s", self.processor.park.input_dir)

        self.logger.info("Hotfolder will process existing and repeated JPG files recursively")

        # Polling is deliberately used on Windows because folders often arrive
        # through copy/sync operations in bursts. A full-tree stability check is
        # more reliable than reacting to individual filesystem events.
        self._run_polling()

    def _run_watchdog(self) -> None:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        service = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.src_path)
                service._note_event(path, event.is_directory)

            def on_moved(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.dest_path)
                service._note_event(path, event.is_directory)

        observer = Observer()
        observer.schedule(Handler(), str(self.processor.park.input_dir), recursive=True)
        observer.start()
        self.logger.info("Watching %s recursively", self.processor.park.input_dir)

        try:
            while True:
                self._process_new_files()
                time.sleep(self.processor.settings.processing.watch_poll_interval_seconds)
        except KeyboardInterrupt:
            self.logger.info("Stopping watcher")
        finally:
            observer.stop()
            observer.join()

    def _run_polling(self) -> None:
        interval = self.processor.settings.processing.watch_poll_interval_seconds
        self.logger.info(
            "Polling %s every %.1fs",
            self.processor.park.input_dir,
            interval,
        )
        try:
            while True:
                try:
                    self._process_new_files()
                except Exception:
                    self.logger.exception(
                        "Hotfolder cycle failed unexpectedly; retrying on the next poll"
                    )
                time.sleep(interval)
        except KeyboardInterrupt:
            self.logger.info("Stopping polling watcher")

    def _note_event(self, path: Path, is_directory: bool) -> None:
        if is_directory:
            self.logger.info("Detected new folder: %s", path)
            return
        if path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            self.logger.info("Detected new file: %s", path)

    def _process_new_files(self) -> None:
        self._reload_processor_settings()
        current_images = list_images(self.processor.park.input_dir)
        current_set = set(current_images)
        for path in list(self._processed_signatures):
            if path not in current_set:
                self._processed_signatures.pop(path, None)
        for path in list(self._failed_retries):
            if path not in current_set:
                self._failed_retries.pop(path, None)
        for path in list(self._unready_since):
            if path not in current_set:
                self._unready_since.pop(path, None)
        candidates = [
            path
            for path in current_images
            if self._needs_processing(path)
        ]
        if not candidates:
            self._stability.clear()
            self._tree_signature = None
            self._tree_stable_since = None
            self._waiting_for_tree_log = False
            self._reset_busy_state()
            self.processor.poll_cloud()
            self.processor.cleanup_empty_input_dirs()
            return

        ready_candidates = [path for path in candidates if self._is_ready(path)]
        if not ready_candidates:
            self._log_waiting_once()
            self.processor.poll_cloud()
            return
        self._waiting_for_tree_log = False

        handled_any = False
        completed_all = True
        ready_to_process = [path for path in ready_candidates if self._needs_processing(path)]

        if ready_to_process:
            print(f"HOTPROGRESS start {len(ready_to_process)}", flush=True)

        total_ready = len(ready_to_process)
        for index, path in enumerate(ready_to_process, start=1):
            if not self._needs_processing(path):
                continue
            print(f"HOTPROGRESS item {index} {total_ready} {path.name}", flush=True)
            handled = self._handle_candidate(path)
            if not handled:
                completed_all = False
                break
            handled_any = True
            print(f"HOTPROGRESS done {index} {total_ready} {path.name}", flush=True)

        active = set(candidates)
        for path in list(self._stability):
            if path not in active:
                self._stability.pop(path, None)

        self.processor.cleanup_empty_input_dirs()
        self.processor.poll_cloud()
        if handled_any and completed_all:
            print(f"HOTPROGRESS complete {total_ready}", flush=True)
            self.logger.info(
                "Hotfolder image batch complete; Cloud continues in background"
            )

    def _is_tree_ready(self, candidates: list[Path]) -> bool:
        signature_items: list[tuple[str, int, int]] = []
        input_dir = self.processor.park.input_dir

        for path in candidates:
            try:
                stat = path.stat()
            except FileNotFoundError:
                self._stability.pop(path, None)
                continue

            if stat.st_size <= 0:
                self._mark_tree_unstable()
                self._log_waiting_once()
                return False

            try:
                relative = path.relative_to(input_dir).as_posix().lower()
            except ValueError:
                relative = str(path).lower()
            signature_items.append((relative, stat.st_size, int(stat.st_mtime_ns)))

        if not signature_items:
            return False

        signature = tuple(signature_items)
        now = time.monotonic()
        if signature != self._tree_signature:
            self._tree_signature = signature
            self._tree_stable_since = now
            self._log_waiting_once()
            return False

        stable_since = self._tree_stable_since or now
        interval = max(0.5, self.processor.settings.file_stability.interval_seconds)
        checks = max(1, self.processor.settings.file_stability.stable_checks)
        required_seconds = interval * checks

        if (now - stable_since) < required_seconds:
            self._log_waiting_once()
            return False

        self._waiting_for_tree_log = False
        return True

    def _mark_tree_unstable(self) -> None:
        self._tree_signature = None
        self._tree_stable_since = None

    def _log_waiting_once(self) -> None:
        if self._waiting_for_tree_log:
            return
        self.logger.info("Hotfolder waiting until IN and subfolders stop changing")
        self._waiting_for_tree_log = True

    def _is_ready(self, path: Path) -> bool:
        try:
            stat = path.stat()
        except FileNotFoundError:
            self._stability.pop(path, None)
            return False

        if stat.st_size <= 0:
            self._handle_persistently_unready(path, "archivo vacio")
            return False

        self._unready_since.pop(path, None)

        signature = self._signature_from_stat(stat)
        now = time.monotonic()
        previous = self._stability.get(path)

        if previous is None:
            self._stability[path] = (signature, now)
            return False

        previous_signature, stable_since = previous
        if signature != previous_signature:
            self._stability[path] = (signature, now)
            return False

        interval = max(0.5, self.processor.settings.file_stability.interval_seconds)
        checks = max(1, self.processor.settings.file_stability.stable_checks)
        required_seconds = interval * checks

        return (now - stable_since) >= required_seconds

    def _handle_candidate(self, path: Path) -> bool:
        if not path.exists():
            self.logger.warning("Hotfolder skipped disappeared file: %s", path)
            self._stability.pop(path, None)
            return True

        if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
            self._mark_current_signature(path)
            return True

        try:
            self._reload_processor_settings()
            result = self.processor.process_file(
                path,
                wait_for_stability=False,
                archive_failed=False,
            )
            if result.status in {"processed", "skipped"}:
                self._mark_current_signature(path)
                self._failed_retries.pop(path, None)
                self._stability.pop(path, None)
            elif result.status == "failed":
                self._schedule_failed_retry(path, result.message)
                self._stability.pop(path, None)
            self._reset_busy_state(path)
            return True
        except ProcessingBusyError:
            self._log_busy_retry(path)
            return False

    def _reload_processor_settings(self) -> None:
        try:
            settings = load_settings(self.processor.settings.config_path)
        except Exception as exc:
            self.logger.warning(
                "Hotfolder could not reload settings; keeping previous config: %s",
                exc,
            )
            return
        park_name = self.processor.park.name
        if park_name not in settings.parks:
            park_name = next(iter(settings.parks))
        self.processor.update_settings(settings, settings.get_park(park_name))

    def _log_busy_retry(self, path: Path) -> None:
        now = time.monotonic()
        if self._busy_path != path:
            self._busy_path = path
            self._busy_next_log_at = 0.0

        if now < self._busy_next_log_at:
            return

        self.logger.warning(
            "Hotfolder ocupado: hay otro proceso activo. Esperando turno para %s",
            path,
        )
        self._busy_next_log_at = now + 15.0

    def _reset_busy_state(self, path: Path | None = None) -> None:
        if path is not None and self._busy_path is not None and self._busy_path != path:
            return
        self._busy_path = None
        self._busy_next_log_at = 0.0

    def _file_signature(self, path: Path) -> FileSignature | None:
        try:
            stat = path.stat()
        except FileNotFoundError:
            return None
        return self._signature_from_stat(stat)

    def _signature_from_stat(self, stat) -> FileSignature:  # type: ignore[no-untyped-def]
        return (
            int(stat.st_size),
            int(stat.st_mtime_ns),
            int(stat.st_ctime_ns),
            int(getattr(stat, "st_ino", 0)),
        )

    def _needs_processing(self, path: Path) -> bool:
        signature = self._file_signature(path)
        if signature is None:
            return False
        if self._processed_signatures.get(path) == signature:
            return False

        failed_retry = self._failed_retries.get(path)
        if failed_retry is None:
            return True

        failed_signature, retry_at, _attempts = failed_retry
        if failed_signature != signature:
            self._failed_retries.pop(path, None)
            return True
        return time.monotonic() >= retry_at

    def _schedule_failed_retry(self, path: Path, message: str | None = None) -> None:
        signature = self._file_signature(path)
        if signature is None:
            self._failed_retries.pop(path, None)
            return

        previous = self._failed_retries.get(path)
        attempts = previous[2] + 1 if previous is not None and previous[0] == signature else 1
        if attempts >= self.MAX_FAILED_ATTEMPTS:
            try:
                archived = self.processor.archive_failed_input(path, force=True)
            except Exception as exc:
                archived = None
                self.logger.warning(
                    "Hotfolder no pudo apartar %s en failed; lo reintentara: %s",
                    path,
                    exc,
                )
            self._failed_retries.pop(path, None)
            if archived is not None:
                self._announce_failed_move(path, archived, f"{attempts} intentos fallidos")
                self.logger.error(
                    "Hotfolder aparto %s en failed tras %d intentos: %s",
                    path,
                    attempts,
                    archived,
                )
                return
            attempts = self.MAX_FAILED_ATTEMPTS - 1

        self._failed_retries[path] = (
            signature,
            time.monotonic() + self.FAILED_RETRY_DELAY_SECONDS,
            attempts,
        )
        detail = f": {message}" if message else ""
        self.logger.warning(
            "Hotfolder reintentara %s en %.0fs (intento %d/%d)%s",
            path,
            self.FAILED_RETRY_DELAY_SECONDS,
            attempts + 1,
            self.MAX_FAILED_ATTEMPTS,
            detail,
        )

    def _handle_persistently_unready(self, path: Path, reason: str) -> None:
        now = time.monotonic()
        first_seen = self._unready_since.setdefault(path, now)
        timeout = max(1.0, float(self.processor.settings.file_stability.timeout_seconds or 90.0))
        if now - first_seen < timeout:
            return

        try:
            archived = self.processor.archive_failed_input(path, force=True)
        except Exception as exc:
            archived = None
            self.logger.warning(
                "Hotfolder no pudo apartar %s en failed; lo reintentara: %s",
                path,
                exc,
            )
        self._unready_since.pop(path, None)
        if archived is not None:
            self._announce_failed_move(path, archived, f"{reason} tras {timeout:.0f}s")
            self.logger.error(
                "Hotfolder aparto %s en failed tras %.0fs (%s): %s",
                path,
                timeout,
                reason,
                archived,
            )

    def _announce_failed_move(self, source: Path, archived: Path, reason: str) -> None:
        safe_name = source.name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_reason = reason.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_target = str(archived).replace("\t", " ").replace("\r", " ").replace("\n", " ")
        print(f"HOTFAILED\t{safe_name}\t{safe_reason}\t{safe_target}", flush=True)

    def _mark_current_signature(self, path: Path) -> None:
        signature = self._file_signature(path)
        if signature is None:
            self._processed_signatures.pop(path, None)
            return
        self._processed_signatures[path] = signature

    def _handle_directory(self, path: Path) -> None:
        if not path.exists() or not path.is_dir():
            return
        for image_path in list_images(path):
            self._handle_candidate(image_path)
