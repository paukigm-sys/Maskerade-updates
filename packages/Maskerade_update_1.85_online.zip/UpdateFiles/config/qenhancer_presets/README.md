Coloca aqui presets QEnhancer `.qes`.

Maskerade los mostrara en el combo de presets cuando el motor sea `QEnhancer Cuevas`.
`C_Channel 1.qes` es el preset interno por defecto y no necesita archivo.
