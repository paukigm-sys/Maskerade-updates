from pathlib import Path
import sys


sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.desktop_bridge import main


if __name__ == "__main__":
    raise SystemExit(main())
