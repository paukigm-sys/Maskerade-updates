from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageFilter


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - face-preserving harmonization")
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--strength", type=float, default=-1.0, help="-1 exports 3 variants; otherwise 0..1")
    args = parser.parse_args()

    run_dir = args.run_dir.resolve()
    background_path = run_dir / "10_iclight_background.jpg"
    subject_path = run_dir / "11_iclight_foreground_subject.png"
    overlay_path = run_dir / "14_overlay_layer.png"
    if not background_path.exists() or not subject_path.exists():
        raise FileNotFoundError(f"Faltan capas en {run_dir}. Ejecuta primero Lab_Maskerade.")

    start = time.perf_counter()
    background = Image.open(background_path).convert("RGB")
    subject = Image.open(subject_path).convert("RGBA")
    overlay = Image.open(overlay_path).convert("RGBA") if overlay_path.exists() else None

    strengths = [args.strength] if args.strength >= 0 else [0.35, 0.65, 1.0]
    outputs = []
    for value in strengths:
        value = max(0.0, min(1.0, float(value)))
        result = harmonize_preserve_faces(background, subject, overlay, value)
        suffix = f"{int(round(value * 100)):03d}"
        output_path = run_dir / f"40_harmonize_preserveface_{suffix}.jpg"
        result.save(output_path, "JPEG", quality=94, optimize=True, subsampling=0)
        outputs.append({"strength": value, "output": str(output_path)})
        print(f"HARMONIZE_RESULT_{suffix}: {output_path}")

    contact = run_dir / "41_harmonize_contact_sheet.jpg"
    make_contact_sheet(run_dir, outputs, contact)
    meta = {
        "status": "ok",
        "engine": "harmonize-preserve-face",
        "seconds": round(time.perf_counter() - start, 3),
        "outputs": outputs,
        "contact_sheet": str(contact),
    }
    (run_dir / "42_harmonize_manifest.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"HARMONIZE_CONTACT: {contact}")
    return 0


def harmonize_preserve_faces(
    background: Image.Image,
    subject_rgba: Image.Image,
    overlay_rgba: Image.Image | None,
    strength: float,
) -> Image.Image:
    size = background.size
    subject_rgba = subject_rgba.resize(size, Image.LANCZOS) if subject_rgba.size != size else subject_rgba
    subject = np.asarray(subject_rgba).astype(np.float32)
    bg = np.asarray(background).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03

    if not mask.any():
        canvas = background.convert("RGBA")
        if overlay_rgba:
            canvas.alpha_composite(_fit_overlay(overlay_rgba, size))
        return canvas.convert("RGB")

    fg_rgb = subject[..., :3]
    sample_mask = _background_sample_mask(mask, bg.shape[:2])
    if not sample_mask.any():
        sample_mask = ~mask

    fg_lab = cv2.cvtColor(fg_rgb.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    bg_lab = cv2.cvtColor(bg.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)

    fg_pixels = fg_lab[mask]
    bg_pixels = bg_lab[sample_mask]
    fg_mean, fg_std = fg_pixels.mean(axis=0), fg_pixels.std(axis=0) + 1.0
    bg_mean, bg_std = bg_pixels.mean(axis=0), bg_pixels.std(axis=0) + 1.0

    # Conservative LAB transfer: enough to feel in-scene, without changing identity.
    target_mean = fg_mean * (1.0 - 0.55 * strength) + bg_mean * (0.55 * strength)
    target_std = fg_std * (1.0 - 0.35 * strength) + bg_std * (0.35 * strength)
    adjusted = (fg_lab - fg_mean) * (target_std / fg_std) + target_mean

    # Flash taming: compress only strong subject highlights.
    highlight = np.clip((fg_lab[..., 0:1] - 205.0) / 45.0, 0.0, 1.0) * alpha
    adjusted[..., 0:1] -= highlight * (22.0 * strength)

    # Keep skin/clothes from going too muddy.
    adjusted[..., 0] = np.maximum(adjusted[..., 0], fg_lab[..., 0] - 28.0 * strength)
    adjusted = adjusted.clip(0, 255)
    adjusted_rgb = cv2.cvtColor(adjusted.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)

    # Light wrap from the background around edges; this hides cut-out borders without redrawing faces.
    edge = _edge_alpha(alpha[..., 0])
    wrap = cv2.GaussianBlur(bg, (0, 0), 22)
    adjusted_rgb = adjusted_rgb * (1.0 - edge[..., None] * 0.28 * strength) + wrap * (edge[..., None] * 0.28 * strength)

    person = adjusted_rgb * alpha + bg * (1.0 - alpha)
    person = _add_soft_contact_shadow(person, mask, strength)
    canvas = Image.fromarray(person.clip(0, 255).astype(np.uint8), "RGB").convert("RGBA")
    if overlay_rgba:
        canvas.alpha_composite(_fit_overlay(overlay_rgba, size))
    return canvas.convert("RGB")


def _background_sample_mask(subject_mask: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    ys, xs = np.where(subject_mask)
    x1, x2 = max(0, xs.min() - w // 12), min(w, xs.max() + w // 12)
    y1, y2 = max(0, ys.min() - h // 12), min(h, ys.max() + h // 12)
    sample = np.zeros(shape, dtype=bool)
    sample[y1:y2, x1:x2] = True
    dilated = cv2.dilate(subject_mask.astype(np.uint8), np.ones((35, 35), np.uint8), iterations=1).astype(bool)
    return sample & ~dilated


def _edge_alpha(alpha: np.ndarray) -> np.ndarray:
    mask = (alpha > 0.03).astype(np.uint8)
    dilated = cv2.dilate(mask, np.ones((21, 21), np.uint8), iterations=1).astype(np.float32)
    eroded = cv2.erode(mask, np.ones((13, 13), np.uint8), iterations=1).astype(np.float32)
    edge = np.clip(dilated - eroded, 0, 1)
    edge = cv2.GaussianBlur(edge, (0, 0), 6)
    return np.clip(edge, 0, 1)


def _add_soft_contact_shadow(image: np.ndarray, mask: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0:
        return image
    h, w = mask.shape
    shadow = np.zeros((h, w), dtype=np.float32)
    ys, xs = np.where(mask)
    bottom = min(h - 1, int(np.percentile(ys, 92)))
    shadow[max(0, bottom - h // 90) : min(h, bottom + h // 45), max(0, xs.min()) : min(w, xs.max())] = 1.0
    shadow = cv2.GaussianBlur(shadow, (0, 0), max(10, w // 85))
    shadow = shadow[..., None] * (0.18 * strength)
    return image * (1.0 - shadow)


def _fit_overlay(overlay: Image.Image, size: tuple[int, int]) -> Image.Image:
    if overlay.size == size:
        return overlay.convert("RGBA")
    return overlay.resize(size, Image.LANCZOS).convert("RGBA")


def make_contact_sheet(run_dir: Path, outputs: list[dict[str, object]], output_path: Path) -> None:
    items = [("Base", run_dir / "01_photoia_base.jpg")]
    items.extend((f"Harmonize {int(float(item['strength']) * 100)}%", Path(str(item["output"]))) for item in outputs)
    thumb_w, thumb_h = 430, 260
    pad = 22
    label_h = 32
    rows = (len(items) + 1) // 2
    sheet = Image.new("RGB", (pad * 3 + thumb_w * 2, pad * (rows + 1) + (thumb_h + label_h) * rows), (245, 247, 249))
    from PIL import ImageDraw, ImageFont

    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
    for index, (label, path) in enumerate(items):
        row, col = divmod(index, 2)
        x = pad + col * (thumb_w + pad)
        y = pad + row * (thumb_h + label_h + pad)
        img = Image.open(path).convert("RGB")
        img.thumbnail((thumb_w, thumb_h), Image.LANCZOS)
        frame = Image.new("RGB", (thumb_w, thumb_h), (14, 28, 34))
        frame.paste(img, ((thumb_w - img.width) // 2, (thumb_h - img.height) // 2))
        draw.text((x, y), label, fill=(10, 20, 24), font=font)
        sheet.paste(frame, (x, y + label_h))
    sheet.save(output_path, "JPEG", quality=92, optimize=True)


if __name__ == "__main__":
    raise SystemExit(main())
