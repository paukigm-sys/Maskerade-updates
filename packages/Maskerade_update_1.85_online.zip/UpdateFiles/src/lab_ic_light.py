from __future__ import annotations

import argparse
import json
import math
import os
import time
from pathlib import Path

import numpy as np
import safetensors.torch as sf
import torch
from diffusers import (
    AutoencoderKL,
    DPMSolverMultistepScheduler,
    StableDiffusionImg2ImgPipeline,
    StableDiffusionPipeline,
    UNet2DConditionModel,
)
from diffusers.models.attention_processor import AttnProcessor2_0
from huggingface_hub import hf_hub_download
from PIL import Image
from transformers import CLIPTextModel, CLIPTokenizer


SD15_NAME = "stablediffusionapi/realistic-vision-v51"
IC_LIGHT_REPO = "lllyasviel/ic-light"
IC_LIGHT_FILE = "iclight_sd15_fbc.safetensors"


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - IC-Light isolated test")
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--steps", type=int, default=18)
    parser.add_argument("--cfg", type=float, default=6.5)
    parser.add_argument("--seed", type=int, default=12345)
    parser.add_argument("--width", type=int, default=768)
    parser.add_argument("--height", type=int, default=512)
    parser.add_argument("--prompt", default="realistic family photo, warm pirate adventure lighting, natural skin, cinematic, sharp faces")
    parser.add_argument("--negative", default="cartoon, painting, distorted faces, extra fingers, bad anatomy, low quality, blurry people")
    args = parser.parse_args()

    run_dir = args.run_dir.resolve()
    cache_dir = (Path.cwd() / "lab" / "cache").resolve()
    model_dir = (Path.cwd() / "lab" / "models").resolve()
    cache_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("HF_HOME", str(cache_dir))
    os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(cache_dir / "hub"))
    os.environ.setdefault("TRANSFORMERS_CACHE", str(cache_dir / "transformers"))

    background_path = run_dir / "10_iclight_background.jpg"
    subject_path = run_dir / "11_iclight_foreground_subject.png"
    overlay_path = run_dir / "14_overlay_layer.png"
    if not background_path.exists() or not subject_path.exists():
        raise FileNotFoundError(f"Faltan capas IC-Light en {run_dir}. Ejecuta primero Lab_Maskerade.")

    start = time.perf_counter()
    relit = run_ic_light(
        foreground_rgba=Image.open(subject_path).convert("RGBA"),
        background_rgb=Image.open(background_path).convert("RGB"),
        prompt=args.prompt,
        negative_prompt=args.negative,
        width=_multiple_of_64(args.width),
        height=_multiple_of_64(args.height),
        steps=args.steps,
        cfg=args.cfg,
        seed=args.seed,
        model_dir=model_dir,
    )

    result_path = run_dir / "20_iclight_result.jpg"
    final_path = run_dir / "21_iclight_final_with_overlay.jpg"
    relit.save(result_path, "JPEG", quality=94, optimize=True, subsampling=0)

    final = relit.convert("RGBA")
    if overlay_path.exists():
        overlay = Image.open(overlay_path).convert("RGBA").resize(final.size, Image.LANCZOS)
        final.alpha_composite(overlay)
    final.convert("RGB").save(final_path, "JPEG", quality=94, optimize=True, subsampling=0)

    meta = {
        "status": "ok",
        "engine": "ic-light",
        "seconds": round(time.perf_counter() - start, 3),
        "result": str(result_path),
        "final_with_overlay": str(final_path),
        "width": _multiple_of_64(args.width),
        "height": _multiple_of_64(args.height),
        "steps": args.steps,
        "cfg": args.cfg,
        "seed": args.seed,
    }
    (run_dir / "22_iclight_manifest.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"ICLIGHT_RESULT: {result_path}")
    print(f"ICLIGHT_FINAL: {final_path}")
    print(f"SECONDS: {meta['seconds']}")
    return 0


@torch.inference_mode()
def run_ic_light(
    foreground_rgba: Image.Image,
    background_rgb: Image.Image,
    prompt: str,
    negative_prompt: str,
    width: int,
    height: int,
    steps: int,
    cfg: float,
    seed: int,
    model_dir: Path,
) -> Image.Image:
    if not torch.cuda.is_available():
        raise RuntimeError("IC-Light necesita CUDA para esta prueba razonablemente rapida.")

    device = torch.device("cuda")
    dtype = torch.float16

    tokenizer = CLIPTokenizer.from_pretrained(SD15_NAME, subfolder="tokenizer")
    text_encoder = CLIPTextModel.from_pretrained(SD15_NAME, subfolder="text_encoder").to(device=device, dtype=dtype)
    vae = AutoencoderKL.from_pretrained(SD15_NAME, subfolder="vae").to(device=device, dtype=torch.bfloat16)
    unet = UNet2DConditionModel.from_pretrained(SD15_NAME, subfolder="unet")

    new_conv_in = torch.nn.Conv2d(
        12,
        unet.conv_in.out_channels,
        unet.conv_in.kernel_size,
        unet.conv_in.stride,
        unet.conv_in.padding,
    )
    new_conv_in.weight.zero_()
    new_conv_in.weight[:, :4, :, :].copy_(unet.conv_in.weight)
    new_conv_in.bias = unet.conv_in.bias
    unet.conv_in = new_conv_in
    original_forward = unet.forward

    def hooked_forward(sample, timestep, encoder_hidden_states, **kwargs):
        concat = kwargs["cross_attention_kwargs"]["concat_conds"].to(sample)
        concat = torch.cat([concat] * (sample.shape[0] // concat.shape[0]), dim=0)
        kwargs["cross_attention_kwargs"] = {}
        return original_forward(torch.cat([sample, concat], dim=1), timestep, encoder_hidden_states, **kwargs)

    unet.forward = hooked_forward

    offset_path = hf_hub_download(
        repo_id=IC_LIGHT_REPO,
        filename=IC_LIGHT_FILE,
        local_dir=str(model_dir / "ic-light"),
        local_dir_use_symlinks=False,
    )
    offset = sf.load_file(offset_path)
    origin = unet.state_dict()
    unet.load_state_dict({key: origin[key] + offset[key] for key in origin.keys()}, strict=True)
    del offset, origin
    unet = unet.to(device=device, dtype=dtype)
    unet.set_attn_processor(AttnProcessor2_0())
    vae.set_attn_processor(AttnProcessor2_0())

    scheduler = DPMSolverMultistepScheduler(
        num_train_timesteps=1000,
        beta_start=0.00085,
        beta_end=0.012,
        algorithm_type="sde-dpmsolver++",
        use_karras_sigmas=True,
        steps_offset=1,
    )
    t2i_pipe = StableDiffusionPipeline(
        vae=vae,
        text_encoder=text_encoder,
        tokenizer=tokenizer,
        unet=unet,
        scheduler=scheduler,
        safety_checker=None,
        requires_safety_checker=False,
        feature_extractor=None,
        image_encoder=None,
    )
    i2i_pipe = StableDiffusionImg2ImgPipeline(
        vae=vae,
        text_encoder=text_encoder,
        tokenizer=tokenizer,
        unet=unet,
        scheduler=scheduler,
        safety_checker=None,
        requires_safety_checker=False,
        feature_extractor=None,
        image_encoder=None,
    )

    fg = _prepare_foreground_condition(foreground_rgba, width, height)
    bg = _resize_cover_np(background_rgb, width, height)
    cond = _numpy_to_pytorch([fg, bg]).to(device=vae.device, dtype=vae.dtype)
    cond = vae.encode(cond).latent_dist.mode() * vae.config.scaling_factor
    cond = torch.cat([c[None, ...] for c in cond], dim=1)
    pos, neg = _encode_prompt_pair(tokenizer, text_encoder, device, prompt + ", best quality", negative_prompt)
    generator = torch.Generator(device=device).manual_seed(seed)

    latents = t2i_pipe(
        prompt_embeds=pos,
        negative_prompt_embeds=neg,
        width=width,
        height=height,
        num_inference_steps=steps,
        num_images_per_prompt=1,
        generator=generator,
        output_type="latent",
        guidance_scale=cfg,
        cross_attention_kwargs={"concat_conds": cond},
    ).images.to(vae.dtype) / vae.config.scaling_factor

    pixels = vae.decode(latents).sample
    image = _pytorch_to_numpy(pixels)[0]
    return Image.fromarray(image)


def _multiple_of_64(value: int) -> int:
    return max(256, int(round(value / 64)) * 64)


def _prepare_foreground_condition(image: Image.Image, width: int, height: int) -> np.ndarray:
    rgba = _resize_cover_rgba(image, width, height)
    rgb = np.asarray(rgba.convert("RGB")).astype(np.float32)
    alpha = np.asarray(rgba.getchannel("A")).astype(np.float32)[..., None] / 255.0
    conditioned = 127.0 + (rgb - 127.0) * alpha
    return conditioned.clip(0, 255).astype(np.uint8)


def _resize_cover_np(image: Image.Image, width: int, height: int) -> np.ndarray:
    return np.asarray(_resize_cover_rgb(image, width, height))


def _resize_cover_rgb(image: Image.Image, width: int, height: int) -> Image.Image:
    original_width, original_height = image.size
    scale = max(width / original_width, height / original_height)
    resized = image.resize((round(original_width * scale), round(original_height * scale)), Image.LANCZOS)
    left = (resized.width - width) // 2
    top = (resized.height - height) // 2
    return resized.crop((left, top, left + width, top + height)).convert("RGB")


def _resize_cover_rgba(image: Image.Image, width: int, height: int) -> Image.Image:
    original_width, original_height = image.size
    scale = max(width / original_width, height / original_height)
    resized = image.resize((round(original_width * scale), round(original_height * scale)), Image.LANCZOS)
    left = (resized.width - width) // 2
    top = (resized.height - height) // 2
    return resized.crop((left, top, left + width, top + height)).convert("RGBA")


@torch.inference_mode()
def _encode_prompt_inner(tokenizer, text_encoder, device, text: str):
    max_length = tokenizer.model_max_length
    chunk_length = tokenizer.model_max_length - 2
    id_start = tokenizer.bos_token_id
    id_end = tokenizer.eos_token_id
    tokens = tokenizer(text, truncation=False, add_special_tokens=False)["input_ids"]
    chunks = [[id_start] + tokens[i : i + chunk_length] + [id_end] for i in range(0, len(tokens), chunk_length)]
    padded = [chunk[:max_length] + [id_end] * max(0, max_length - len(chunk)) for chunk in chunks]
    token_ids = torch.tensor(padded).to(device=device, dtype=torch.int64)
    return text_encoder(token_ids).last_hidden_state


@torch.inference_mode()
def _encode_prompt_pair(tokenizer, text_encoder, device, positive: str, negative: str):
    cond = _encode_prompt_inner(tokenizer, text_encoder, device, positive)
    uncond = _encode_prompt_inner(tokenizer, text_encoder, device, negative)
    max_count = max(len(cond), len(uncond))
    cond = torch.cat([cond] * math.ceil(max_count / len(cond)), dim=0)[:max_count]
    uncond = torch.cat([uncond] * math.ceil(max_count / len(uncond)), dim=0)[:max_count]
    cond = torch.cat([item[None, ...] for item in cond], dim=1)
    uncond = torch.cat([item[None, ...] for item in uncond], dim=1)
    return cond, uncond


@torch.inference_mode()
def _numpy_to_pytorch(images: list[np.ndarray]) -> torch.Tensor:
    tensor = torch.from_numpy(np.stack(images, axis=0)).float() / 127.0 - 1.0
    return tensor.movedim(-1, 1)


@torch.inference_mode()
def _pytorch_to_numpy(images: torch.Tensor) -> list[np.ndarray]:
    results = []
    for image in images:
        item = image.movedim(0, -1)
        item = item * 127.5 + 127.5
        results.append(item.detach().float().cpu().numpy().clip(0, 255).astype(np.uint8))
    return results


if __name__ == "__main__":
    raise SystemExit(main())
