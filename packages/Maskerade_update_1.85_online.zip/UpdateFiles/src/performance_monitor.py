from __future__ import annotations

import logging
import subprocess
import threading
import time
from dataclasses import dataclass


@dataclass(frozen=True)
class PerformanceSample:
    cpu_percent: float | None
    memory_percent: float | None
    gpu_percent: float | None
    gpu_memory_percent: float | None
    gpu_memory_used_mb: float | None
    gpu_temperature_c: float | None


class PerformanceSampler:
    def __init__(
        self,
        logger: logging.Logger,
        enabled: bool = False,
        interval_seconds: float = 1.0,
    ) -> None:
        self.logger = logger
        self.enabled = bool(enabled)
        self.interval_seconds = max(0.5, float(interval_seconds or 1.0))
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._samples: list[PerformanceSample] = []

    def __enter__(self) -> PerformanceSampler:
        if not self.enabled:
            return self
        self._thread = threading.Thread(
            target=self._run,
            name="maskerade-perf",
            daemon=True,
        )
        self._thread.start()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if not self.enabled:
            return
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self.log_summary()

    def _run(self) -> None:
        self._sample()
        while not self._stop.wait(self.interval_seconds):
            self._sample()

    def _sample(self) -> None:
        self._samples.append(
            PerformanceSample(
                cpu_percent=_cpu_percent(),
                memory_percent=_memory_percent(),
                **_gpu_sample(),
            )
        )

    def log_summary(self) -> None:
        if not self._samples:
            return

        cpu = _series(sample.cpu_percent for sample in self._samples)
        memory = _series(sample.memory_percent for sample in self._samples)
        gpu = _series(sample.gpu_percent for sample in self._samples)
        gpu_mem = _series(sample.gpu_memory_percent for sample in self._samples)
        gpu_mem_used = _series(sample.gpu_memory_used_mb for sample in self._samples)
        gpu_temp = _series(sample.gpu_temperature_c for sample in self._samples)

        parts = [f"samples={len(self._samples)}"]
        _append_metric(parts, "cpu", cpu, "%")
        _append_metric(parts, "ram", memory, "%")
        _append_metric(parts, "gpu", gpu, "%")
        _append_metric(parts, "vram", gpu_mem, "%")
        _append_metric(parts, "vram_used", gpu_mem_used, "MB")
        _append_metric(parts, "gpu_temp", gpu_temp, "C")
        self.logger.info("Performance batch summary: %s", " ".join(parts))


def _cpu_percent() -> float | None:
    try:
        import psutil

        return float(psutil.cpu_percent(interval=None))
    except Exception:
        return None


def _memory_percent() -> float | None:
    try:
        import psutil

        return float(psutil.virtual_memory().percent)
    except Exception:
        return None


def _gpu_sample() -> dict[str, float | None]:
    empty = {
        "gpu_percent": None,
        "gpu_memory_percent": None,
        "gpu_memory_used_mb": None,
        "gpu_temperature_c": None,
    }
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        return empty

    if result.returncode != 0:
        return empty
    line = (result.stdout or "").splitlines()
    if not line:
        return empty
    try:
        gpu_raw, used_raw, total_raw, temp_raw = [part.strip() for part in line[0].split(",")[:4]]
        used = float(used_raw)
        total = max(1.0, float(total_raw))
        return {
            "gpu_percent": float(gpu_raw),
            "gpu_memory_percent": (used / total) * 100.0,
            "gpu_memory_used_mb": used,
            "gpu_temperature_c": float(temp_raw),
        }
    except Exception:
        return empty


def _series(values) -> tuple[float, float] | None:
    clean = [float(value) for value in values if value is not None]
    if not clean:
        return None
    return sum(clean) / len(clean), max(clean)


def _append_metric(
    parts: list[str],
    name: str,
    metric: tuple[float, float] | None,
    unit: str,
) -> None:
    if metric is None:
        return
    average, maximum = metric
    parts.append(f"{name}_avg={average:.1f}{unit}")
    parts.append(f"{name}_max={maximum:.1f}{unit}")
