from __future__ import annotations

import argparse
import json
import logging
import time
from dataclasses import replace
from pathlib import Path

from PIL import Image, ImageChops, ImageOps

from .background_removal import BackgroundRemover
from .config import BackgroundRemovalSettings, load_settings
from .image_utils import list_images, open_image


def run_compare(input_path: Path | None = None, output_dir: Path | None = None) -> Path:
    settings = load_settings()
    park = next(iter(settings.parks.values()))
    source = _resolve_input(park.input_dir, input_path)
    run_dir = _unique_run_dir(output_dir or settings.root_dir / "lab" / "output", source.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    original = open_image(source)
    logger = logging.getLogger("photoia.lab.ben2_refine")

    normal_result, normal_seconds = _run_ben2(original, settings.background_removal, False, logger)
    refined_result, refined_seconds = _run_ben2(original, settings.background_removal, True, logger)

    normal_subject = run_dir / "01_ben2_normal_subject.png"
    normal_mask = run_dir / "02_ben2_normal_mask.png"
    refined_subject = run_dir / "03_ben2_refine_subject.png"
    refined_mask = run_dir / "04_ben2_refine_mask.png"
    diff_mask = run_dir / "05_mask_difference.png"
    contact_sheet = run_dir / "06_compare_contact_sheet.jpg"

    normal_result.person_rgba.save(normal_subject)
    normal_result.mask.save(normal_mask)
    refined_result.person_rgba.save(refined_subject)
    refined_result.mask.save(refined_mask)
    _mask_difference(normal_result.mask, refined_result.mask).save(diff_mask)
    _contact_sheet(original, normal_result.person_rgba, refined_result.person_rgba).save(
        contact_sheet,
        "JPEG",
        quality=94,
        optimize=True,
    )

    manifest = {
        "input": str(source),
        "normal_seconds": round(normal_seconds, 3),
        "refine_foreground_seconds": round(refined_seconds, 3),
        "slowdown_ratio": round(refined_seconds / max(0.001, normal_seconds), 2),
        "outputs": {
            "normal_subject": str(normal_subject),
            "normal_mask": str(normal_mask),
            "refine_subject": str(refined_subject),
            "refine_mask": str(refined_mask),
            "mask_difference": str(diff_mask),
            "contact_sheet": str(contact_sheet),
        },
    }
    manifest_path = run_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"BEN2_REFINE_LAB: {run_dir}")
    print(f"normal: {normal_seconds:.2f}s")
    print(f"refine_foreground: {refined_seconds:.2f}s")
    print(f"slowdown: {manifest['slowdown_ratio']}x")
    return run_dir


def _run_ben2(
    image: Image.Image,
    base_settings: BackgroundRemovalSettings,
    refine_foreground: bool,
    logger: logging.Logger,
):
    remover = BackgroundRemover(
        replace(base_settings, ben2_refine_foreground=refine_foreground),
        logger,
    )
    start = time.perf_counter()
    result = remover.remove_background(image)
    return result, time.perf_counter() - start


def _resolve_input(input_dir: Path, input_path: Path | None) -> Path:
    if input_path is not None:
        path = input_path if input_path.is_absolute() else Path.cwd() / input_path
        if not path.exists():
            raise FileNotFoundError(f"No existe la foto Lab: {path}")
        return path

    images = list_images(input_dir)
    if not images:
        raise FileNotFoundError(f"No hay JPG en {input_dir}. Mete una foto en IN o usa --input.")
    return images[0]


def _unique_run_dir(root: Path, stem: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"ben2_refine_{stamp}_{stem}"
    candidate = base
    index = 1
    while candidate.exists():
        candidate = Path(f"{base}_{index:02d}")
        index += 1
    return candidate


def _mask_difference(left: Image.Image, right: Image.Image) -> Image.Image:
    left_l = left.convert("L")
    right_l = right.convert("L").resize(left_l.size, Image.Resampling.LANCZOS)
    diff = ImageChops.difference(left_l, right_l)
    return ImageOps.autocontrast(diff)


def _contact_sheet(original: Image.Image, normal: Image.Image, refined: Image.Image) -> Image.Image:
    thumb_size = (520, 360)
    tiles = [
        _fit_on_white(original.convert("RGB"), thumb_size),
        _fit_on_white(normal.convert("RGBA"), thumb_size),
        _fit_on_white(refined.convert("RGBA"), thumb_size),
    ]
    sheet = Image.new("RGB", (thumb_size[0] * 3, thumb_size[1]), "white")
    for index, tile in enumerate(tiles):
        sheet.paste(tile.convert("RGB"), (index * thumb_size[0], 0))
    return sheet


def _fit_on_white(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    canvas = Image.new("RGBA", size, (255, 255, 255, 255))
    thumb = image.copy()
    thumb.thumbnail(size, Image.Resampling.LANCZOS)
    x = (size[0] - thumb.width) // 2
    y = (size[1] - thumb.height) // 2
    canvas.alpha_composite(thumb.convert("RGBA"), (x, y))
    return canvas


def main() -> None:
    parser = argparse.ArgumentParser(description="Lab BEN2 normal vs refine_foreground")
    parser.add_argument("--input", type=Path, default=None, help="JPG concreto para probar")
    parser.add_argument("--output-dir", type=Path, default=None, help="Carpeta de salida del lab")
    args = parser.parse_args()
    run_compare(args.input, args.output_dir)


if __name__ == "__main__":
    main()
