from __future__ import annotations

import ctypes
import json
import os
from pathlib import Path
from typing import Any


SECURE_SETTINGS_NAME = "profile.cache"
SECURE_HEADER = b"MSKCFG1\n"
CRYPTPROTECT_LOCAL_MACHINE = 0x4


class SecureSettingsError(RuntimeError):
    """Raised when encrypted settings cannot be read or written."""


def load_raw_settings(config_path: str | Path) -> dict[str, Any]:
    path = Path(config_path).resolve()
    if _is_encrypted_file(path):
        return _read_encrypted_json(path)

    if _is_default_settings_path(path):
        secure_path = secure_settings_path(path)
        if secure_path.exists():
            return _read_encrypted_json(secure_path)

    if not path.exists():
        raise FileNotFoundError(f"Settings file not found: {path}")
    raw = _read_plain_json(path)
    secure_name = raw.get("secure_settings")
    if isinstance(secure_name, str) and secure_name and "parks" not in raw:
        sibling_secure_path = path.with_name(secure_name)
        if sibling_secure_path.exists():
            return _read_encrypted_json(sibling_secure_path)
    return raw


def save_raw_settings(
    config_path: str | Path,
    raw: dict[str, Any],
    *,
    force_secure: bool = False,
) -> Path:
    path = Path(config_path).resolve()
    if force_secure:
        _write_encrypted_json(path, raw)
        return path

    if _is_default_settings_path(path):
        secure_path = secure_settings_path(path)
        _write_encrypted_json(secure_path, raw)
        _remove_plain_settings_file(path)
        return secure_path

    _write_plain_json(path, raw)
    return path


def ensure_settings_storage(config_path: str | Path) -> None:
    path = Path(config_path).resolve()
    if not _is_default_settings_path(path):
        if not path.exists():
            _bootstrap_plain_settings(path)
        return

    secure_path = secure_settings_path(path)
    if secure_path.exists():
        try:
            _read_encrypted_json(secure_path)
        except Exception:
            if path.exists() and not _is_settings_stub(path):
                raw = _read_plain_json(path)
                save_raw_settings(path, raw)
                return
            example_path = path.with_name("settings.example.json")
            if example_path.exists():
                raw = _read_plain_json(example_path)
                save_raw_settings(path, raw)
                return
            raise
        _remove_plain_settings_file(path)
        return

    if path.exists() and not _is_settings_stub(path):
        raw = _read_plain_json(path)
        save_raw_settings(path, raw)
        return

    example_path = path.with_name("settings.example.json")
    if example_path.exists():
        raw = _read_plain_json(example_path)
        save_raw_settings(path, raw)


def secure_settings_path(config_path: str | Path) -> Path:
    return Path(config_path).resolve().with_name(SECURE_SETTINGS_NAME)


def _is_default_settings_path(path: Path) -> bool:
    return path.name.lower() == "settings.json" and path.parent.name.lower() == "config"


def _bootstrap_plain_settings(path: Path) -> None:
    example_path = path.with_name("settings.example.json")
    if not example_path.exists():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(example_path.read_bytes())


def _read_plain_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise SecureSettingsError(f"Settings root must be an object: {path}")
    return data


def _write_plain_json(path: Path, raw: dict[str, Any]) -> None:
    payload = _json_bytes(raw).decode("utf-8")
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        temp_path.write_text(payload, encoding="utf-8")
        temp_path.replace(path)
    except PermissionError:
        path.write_text(payload, encoding="utf-8")
        try:
            temp_path.unlink()
        except OSError:
            pass


def _read_encrypted_json(path: Path) -> dict[str, Any]:
    payload = path.read_bytes()
    if not payload.startswith(SECURE_HEADER):
        raise SecureSettingsError(f"Invalid encrypted settings file: {path}")
    decrypted = _dpapi_unprotect(payload[len(SECURE_HEADER):])
    data = json.loads(decrypted.decode("utf-8-sig"))
    if not isinstance(data, dict):
        raise SecureSettingsError(f"Settings root must be an object: {path}")
    return data


def _write_encrypted_json(path: Path, raw: dict[str, Any]) -> None:
    payload = SECURE_HEADER + _dpapi_protect(_json_bytes(raw))
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    try:
        temp_path.write_bytes(payload)
        temp_path.replace(path)
    except PermissionError:
        path.write_bytes(payload)
        try:
            temp_path.unlink()
        except OSError:
            pass


def _write_settings_stub(path: Path, secure_name: str) -> None:
    stub = {
        "secure_settings": secure_name,
        "managed_by": "Maskerade",
    }
    _write_plain_json(path, stub)


def _remove_plain_settings_file(path: Path) -> None:
    if not _is_default_settings_path(path):
        return
    try:
        path.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _is_settings_stub(path: Path) -> bool:
    try:
        data = _read_plain_json(path)
    except Exception:
        return False
    return data.get("secure_settings") == SECURE_SETTINGS_NAME and "parks" not in data


def _is_encrypted_file(path: Path) -> bool:
    try:
        with path.open("rb") as handle:
            return handle.read(len(SECURE_HEADER)) == SECURE_HEADER
    except OSError:
        return False


def _json_bytes(raw: dict[str, Any]) -> bytes:
    return (json.dumps(raw, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


class _DataBlob(ctypes.Structure):
    _fields_ = [
        ("cbData", ctypes.c_ulong),
        ("pbData", ctypes.POINTER(ctypes.c_char)),
    ]


def _dpapi_protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise SecureSettingsError("Encrypted settings require Windows DPAPI")
    in_buffer = ctypes.create_string_buffer(data, len(data))
    in_blob = _DataBlob(len(data), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DataBlob()
    ok = ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(in_blob),
        None,
        None,
        None,
        None,
        CRYPTPROTECT_LOCAL_MACHINE,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise SecureSettingsError("Windows DPAPI could not encrypt settings")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)


def _dpapi_unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise SecureSettingsError("Encrypted settings require Windows DPAPI")
    in_buffer = ctypes.create_string_buffer(data, len(data))
    in_blob = _DataBlob(len(data), ctypes.cast(in_buffer, ctypes.POINTER(ctypes.c_char)))
    out_blob = _DataBlob()
    ok = ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(in_blob),
        None,
        None,
        None,
        None,
        0,
        ctypes.byref(out_blob),
    )
    if not ok:
        raise SecureSettingsError("Windows DPAPI could not decrypt settings")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)
