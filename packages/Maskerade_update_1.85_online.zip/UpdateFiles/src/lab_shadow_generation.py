from __future__ import annotations

import argparse
import json
import importlib
import os
import sys
import types
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - IA shadow generation variants")
    parser.add_argument("--input", type=Path, default=None)
    parser.add_argument("--park", default="photo")
    parser.add_argument("--variants", type=int, default=4)
    parser.add_argument("--output-dir", type=Path, default=Path("lab/output"))
    parser.add_argument("--no-harmonize", action="store_true")
    args = parser.parse_args()

    status, _run_dir = run_shadow_generation_lab(
        input_path=args.input,
        park_name=args.park,
        variants=args.variants,
        output_dir=args.output_dir,
        no_harmonize=args.no_harmonize,
    )
    return 0 if status == "ok" else 2


def run_shadow_generation_lab(
    settings=None,
    park=None,
    input_path: Path | None = None,
    park_name: str = "photo",
    variants: int = 4,
    output_dir: Path | None = None,
    no_harmonize: bool = False,
) -> tuple[str, Path]:
    project_root = Path.cwd() if settings is None else settings.root_dir
    os.environ.setdefault("LIBCOM_MODEL_DIR", str(project_root / "models" / "libcom"))

    from .background_removal import BackgroundRemover
    from .compositor import _placement_for, _prepare_overlay, _prepare_subject, _target_size
    from .config import load_settings
    from .harmonizer import harmonize_subject_layer
    from .image_utils import alpha_composite_at, open_image, resize_cover

    if settings is None:
        settings = load_settings()
    if park is None:
        park = settings.get_park(park_name)

    input_path = _resolve_input(input_path, park.input_dir)
    output_root = output_dir or (settings.root_dir / "lab" / "output")
    run_dir = _unique_run_dir(output_root, input_path.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    original = open_image(input_path)
    output_size = _target_size(original, park.output_size)
    background = resize_cover(Image.open(park.background_path).convert("RGB"), output_size).convert("RGB")

    start = time.perf_counter()
    removal = BackgroundRemover(settings.background_removal).remove_background(original)
    subject = _prepare_subject(removal.person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))
    ben2_seconds = time.perf_counter() - start

    if not no_harmonize and park.harmonize_strength > 0:
        subject_for_shadow = harmonize_subject_layer(background, subject_canvas, park.harmonize_strength)
    else:
        subject_for_shadow = subject_canvas

    overlay_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    if park.overlay_path and park.overlay_path.exists():
        overlay, xy = _prepare_overlay(Image.open(park.overlay_path).convert("RGBA"), park.overlay_settings, output_size)
        alpha_composite_at(overlay_canvas, overlay, xy)

    shadowfree = background.convert("RGBA")
    alpha_composite_at(shadowfree, subject_for_shadow, (0, 0))
    shadowfree_rgb = shadowfree.convert("RGB")
    mask = subject_canvas.getchannel("A")

    composite_path = run_dir / "00_shadowfree_composite.png"
    mask_path = run_dir / "00_foreground_mask.png"
    final_base_path = run_dir / "00_base_with_overlay.jpg"
    shadowfree_rgb.save(composite_path)
    mask.save(mask_path)
    _finish_with_overlay(shadowfree_rgb, overlay_canvas).save(final_base_path, "JPEG", quality=94, optimize=True, subsampling=0)

    outputs = [{"label": "Base sin sombra IA", "path": str(final_base_path)}]
    try:
        ShadowGenerationModel = _load_shadow_generation_model()
    except Exception as exc:
        manifest = {
            "status": "missing_libcom",
            "message": "Instala libcom para ejecutar GPSDiffusion shadow generation.",
            "error": repr(exc),
            "input": str(input_path),
            "run_dir": str(run_dir),
            "shadowfree_composite": str(composite_path),
            "foreground_mask": str(mask_path),
            "ben2_seconds": round(ben2_seconds, 3),
        }
        (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"SHADOW_LAB_MISSING_LIBCOM: {run_dir}")
        print("Instala libcom para probar GPSDiffusion.")
        return "missing_libcom", run_dir

    model_start = time.perf_counter()
    _patch_huggingface_download_for_libcom()
    original_argv = sys.argv[:]
    sys.argv = [sys.argv[0]]
    try:
        try:
            net = ShadowGenerationModel(device=0)
            preds = net(str(composite_path), str(mask_path), number=max(1, min(8, variants)))
        except Exception as exc:
            manifest = {
                "status": "failed_model",
                "message": "GPSDiffusion no pudo terminar la generacion de sombras.",
                "error": repr(exc),
                "input": str(input_path),
                "run_dir": str(run_dir),
                "shadowfree_composite": str(composite_path),
                "foreground_mask": str(mask_path),
                "ben2_seconds": round(ben2_seconds, 3),
                "model_seconds_before_error": round(time.perf_counter() - model_start, 3),
            }
            (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"SHADOW_LAB_FAILED: {run_dir}")
            return "failed_model", run_dir
    finally:
        sys.argv = original_argv
    model_seconds = time.perf_counter() - model_start

    for index, pred in enumerate(preds, start=1):
        pred_rgb = _as_pil_rgb(pred, output_size)
        final = _finish_with_overlay(pred_rgb, overlay_canvas)
        out_path = run_dir / f"{index:02d}_gpsdiffusion_shadow.jpg"
        final.save(out_path, "JPEG", quality=94, optimize=True, subsampling=0)
        outputs.append({"label": f"GPSDiffusion sombra {index}", "path": str(out_path)})

    contact = run_dir / "contact_sheet.jpg"
    _make_contact_sheet(outputs, contact)
    manifest = {
        "status": "ok",
        "input": str(input_path),
        "run_dir": str(run_dir),
        "shadowfree_composite": str(composite_path),
        "foreground_mask": str(mask_path),
        "ben2_seconds": round(ben2_seconds, 3),
        "shadow_generation_seconds": round(model_seconds, 3),
        "outputs": outputs,
        "contact_sheet": str(contact),
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"SHADOW_LAB: {contact}")
    print(f"RUN_DIR: {run_dir}")
    return "ok", run_dir


def _patch_huggingface_download_for_libcom() -> None:
    """LibCom 0.1.7 passes a removed hf_hub_download(progress=...) arg."""
    try:
        import huggingface_hub
    except Exception:
        return
    current = getattr(huggingface_hub, "hf_hub_download", None)
    if current is None or getattr(current, "_photoia_libcom_patch", False):
        return

    def hf_hub_download_compat(*args, **kwargs):
        kwargs.pop("progress", None)
        return current(*args, **kwargs)

    hf_hub_download_compat._photoia_libcom_patch = True
    huggingface_hub.hf_hub_download = hf_hub_download_compat


def _load_shadow_generation_model():
    """Load only libcom.shadow_generation, bypassing libcom's broad __init__ imports."""
    try:
        from libcom.shadow_generation.shadow_generation import ShadowGenerationModel

        return ShadowGenerationModel
    except Exception as first_error:
        site_packages = next((Path(path) for path in sys.path if (Path(path) / "libcom").exists()), None)
        if site_packages is None:
            raise first_error
        libcom_path = site_packages / "libcom"
        module = types.ModuleType("libcom")
        module.__path__ = [str(libcom_path)]
        sys.modules["libcom"] = module
        imported = importlib.import_module("libcom.shadow_generation.shadow_generation")
        return imported.ShadowGenerationModel


def _finish_with_overlay(image: Image.Image, overlay_canvas: Image.Image) -> Image.Image:
    canvas = image.convert("RGBA")
    alpha_composite_at = _alpha_composite_at_local
    alpha_composite_at(canvas, overlay_canvas.convert("RGBA"), (0, 0))
    return canvas.convert("RGB")


def _alpha_composite_at_local(base: Image.Image, overlay: Image.Image, xy: tuple[int, int]) -> None:
    base.alpha_composite(overlay, dest=xy)


def _as_pil_rgb(value: object, output_size: tuple[int, int]) -> Image.Image:
    if isinstance(value, Image.Image):
        image = value.convert("RGB")
    else:
        arr = np.asarray(value)
        if arr.ndim == 3 and arr.shape[2] >= 3:
            arr = arr[..., :3].astype(np.uint8)
            image = Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB), "RGB")
        else:
            raise ValueError(f"Formato de salida de sombra no soportado: {arr.shape}")
    if image.size != output_size:
        image = image.resize(output_size, Image.LANCZOS)
    return image


def _resolve_input(input_path: Path | None, input_dir: Path) -> Path:
    if input_path:
        path = input_path if input_path.is_absolute() else Path.cwd() / input_path
        if not path.exists():
            raise FileNotFoundError(path)
        return path
    images = sorted(p for p in input_dir.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    if not images:
        raise FileNotFoundError(f"No hay imagenes en {input_dir}")
    return images[0]


def _unique_run_dir(root: Path, stem: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"{stamp}_{_safe(stem)}_shadow_generation"
    for index in range(1000):
        candidate = base if index == 0 else root / f"{base.name}_{index:03d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError("No se pudo crear carpeta unica de Lab")


def _safe(value: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in value).strip("_") or "foto"


def _make_contact_sheet(outputs: list[dict[str, str]], output_path: Path) -> None:
    thumb_w, thumb_h = 520, 330
    pad = 20
    label_h = 30
    cols = 2
    rows = (len(outputs) + cols - 1) // cols
    sheet = Image.new(
        "RGB",
        (pad * (cols + 1) + thumb_w * cols, pad * (rows + 1) + (thumb_h + label_h) * rows),
        (238, 242, 245),
    )
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
    for i, item in enumerate(outputs):
        row, col = divmod(i, cols)
        x = pad + col * (thumb_w + pad)
        y = pad + row * (thumb_h + label_h + pad)
        draw.text((x, y), item["label"], fill=(10, 20, 24), font=font)
        img = Image.open(item["path"]).convert("RGB")
        img.thumbnail((thumb_w, thumb_h), Image.LANCZOS)
        frame = Image.new("RGB", (thumb_w, thumb_h), (14, 28, 34))
        frame.paste(img, ((thumb_w - img.width) // 2, (thumb_h - img.height) // 2))
        sheet.paste(frame, (x, y + label_h))
    sheet.save(output_path, "JPEG", quality=92, optimize=True)


if __name__ == "__main__":
    raise SystemExit(main())
