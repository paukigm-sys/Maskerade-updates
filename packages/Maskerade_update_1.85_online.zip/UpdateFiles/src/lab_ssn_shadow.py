from __future__ import annotations

import argparse
import importlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageFilter


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - SSN soft shadow variants")
    parser.add_argument("--input", type=Path, default=None)
    parser.add_argument("--park", default="photo")
    parser.add_argument("--variants", type=int, default=3)
    parser.add_argument("--output-dir", type=Path, default=Path("lab/output"))
    args = parser.parse_args()

    status, _run_dir = run_ssn_shadow_lab(
        input_path=args.input,
        park_name=args.park,
        variants=args.variants,
        output_dir=args.output_dir,
    )
    return 0 if status == "ok" else 2


def run_ssn_shadow_lab(
    settings=None,
    park=None,
    input_path: Path | None = None,
    park_name: str = "photo",
    variants: int = 3,
    output_dir: Path | None = None,
) -> tuple[str, Path]:
    from .background_removal import BackgroundRemover
    from .compositor import _placement_for, _prepare_subject, _target_size, prepare_overlay_layer
    from .config import load_settings
    from .harmonizer import harmonize_subject_layer
    from .image_utils import alpha_composite_at, open_image, resize_cover

    if settings is None:
        settings = load_settings()
    if park is None:
        park = settings.get_park(park_name)

    input_path = _resolve_input(input_path, park.input_dir)
    output_root = output_dir or (settings.root_dir / "lab" / "output")
    run_dir = _unique_run_dir(output_root, input_path.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    start = time.perf_counter()
    original = open_image(input_path)
    output_size = _target_size(original, park.output_size)
    background_source = Image.open(park.background_path).convert("RGB")
    background = resize_cover(background_source, output_size).convert("RGB")

    removal = BackgroundRemover(settings.background_removal).remove_background(original)
    subject = _prepare_subject(removal.person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))
    if park.harmonize_strength > 0:
        subject_canvas = harmonize_subject_layer(background, subject_canvas, park.harmonize_strength)

    overlay_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    if park.overlay_path and park.overlay_path.exists():
        overlay, xy = prepare_overlay_layer(
            Image.open(park.overlay_path).convert("RGBA"),
            park.overlay_settings,
            output_size,
            background_source.size,
        )
        alpha_composite_at(overlay_canvas, overlay, xy)

    base = background.convert("RGBA")
    alpha_composite_at(base, subject_canvas, (0, 0))
    alpha_composite_at(base, overlay_canvas, (0, 0))
    base_path = run_dir / "00_base_without_ssn_shadow.jpg"
    base.convert("RGB").save(base_path, "JPEG", quality=94, optimize=True, subsampling=0)

    subject_path = run_dir / "00_subject_layer.png"
    mask_path = run_dir / "00_subject_mask.png"
    subject_canvas.save(subject_path)
    subject_canvas.getchannel("A").save(mask_path)

    try:
        model = _load_ssn_model(settings.root_dir)
    except Exception as exc:
        manifest = _manifest("missing_ssn", input_path, run_dir, start)
        manifest.update({"error": repr(exc), "base": str(base_path), "subject_mask": str(mask_path)})
        _write_manifest(run_dir, manifest)
        return "missing_ssn", run_dir

    bbox = _shadow_crop_box(subject_canvas.getchannel("A"))
    alpha_crop, crop_box = _prepare_alpha_for_ssn(subject_canvas.getchannel("A"), bbox)
    alpha_crop_path = run_dir / "01_ssn_input_mask.png"
    Image.fromarray((alpha_crop * 255).astype(np.uint8), "L").save(alpha_crop_path)

    outputs = [{"label": "Base sin SSN", "path": str(base_path)}]
    variant_specs = _variant_specs(max(1, min(6, variants)))
    inference_start = time.perf_counter()
    for index, spec in enumerate(variant_specs, start=1):
        shadow = model.inference({"mask": alpha_crop, "ibl": spec["ibl"]})
        shadow_map = _place_shadow_on_canvas(
            shadow=shadow,
            crop_box=crop_box,
            output_size=output_size,
            intensity=spec["intensity"],
            gamma=spec["gamma"],
        )
        shadow_map_path = run_dir / f"{index:02d}_ssn_shadow_map_{spec['id']}.png"
        Image.fromarray((shadow_map * 255).astype(np.uint8), "L").save(shadow_map_path)

        final = _composite_shadow(background, subject_canvas, overlay_canvas, shadow_map)
        final_path = run_dir / f"{index:02d}_ssn_{spec['id']}.jpg"
        final.save(final_path, "JPEG", quality=94, optimize=True, subsampling=0)
        outputs.append({"label": spec["label"], "path": str(final_path), "shadow_map": str(shadow_map_path)})

    contact = run_dir / "contact_sheet.jpg"
    _make_contact_sheet(outputs, contact)

    manifest = _manifest("ok", input_path, run_dir, start)
    manifest.update(
        {
            "engine": "SSN Soft Shadow Network",
            "source": "https://shengcn.github.io/SSN/",
            "base": str(base_path),
            "subject_layer": str(subject_path),
            "subject_mask": str(mask_path),
            "ssn_input_mask": str(alpha_crop_path),
            "crop_box": crop_box,
            "inference_seconds": round(time.perf_counter() - inference_start, 3),
            "outputs": outputs,
            "contact_sheet": str(contact),
        }
    )
    _write_manifest(run_dir, manifest)
    print(f"SSN_LAB: {contact}")
    print(f"RUN_DIR: {run_dir}")
    return "ok", run_dir


def _load_ssn_model(project_root: Path):
    ssn_root = (project_root / "lab" / "ssn_hf").resolve()
    config = ssn_root / "configs" / "SSN.yaml"
    weight = ssn_root / "weights" / "SSN" / "0000001760.pt"
    if not config.exists() or not weight.exists():
        raise FileNotFoundError(f"Faltan archivos SSN en {ssn_root}")

    sys.path.insert(0, str(ssn_root))
    model_utils = importlib.import_module("model_utils")
    SSN = importlib.import_module("models.SSN").SSN
    return model_utils.load_model(str(config), str(weight), SSN, torch.device("cpu"))


def _shadow_crop_box(alpha: Image.Image) -> tuple[int, int, int, int]:
    solid = alpha.point(lambda value: 255 if value > 32 else 0)
    bbox = solid.getbbox()
    if not bbox:
        raise ValueError("No hay mascara de sujeto para SSN")
    out_w, out_h = alpha.size
    left, top, right, bottom = bbox
    w = right - left
    h = bottom - top
    side = int(max(w, h) * 1.28)
    side = max(side, 64)
    cx = (left + right) // 2
    cy = int(round((top + bottom) * 0.50))
    crop_left = max(0, min(out_w - side, cx - side // 2))
    crop_top = max(0, min(out_h - side, cy - side // 2))
    crop_right = min(out_w, crop_left + side)
    crop_bottom = min(out_h, crop_top + side)
    return crop_left, crop_top, crop_right, crop_bottom


def _prepare_alpha_for_ssn(alpha: Image.Image, box: tuple[int, int, int, int]) -> tuple[np.ndarray, tuple[int, int, int, int]]:
    crop = alpha.crop(box).resize((256, 256), Image.Resampling.LANCZOS)
    arr = np.asarray(crop, dtype=np.float32) / 255.0
    arr = np.clip(arr, 0.0, 1.0)
    return arr, box


def _variant_specs(count: int) -> list[dict[str, Any]]:
    specs = [
        ("left_soft", "Luz izq suave", 5.0, 5.0, 0.62, 2.2),
        ("right_soft", "Luz der suave", 26.0, 5.0, 0.62, 2.2),
        ("top_broad", "Luz cenital amplia", 16.0, 2.0, 0.50, 2.4),
        ("left_strong", "Luz izq marcada", 4.0, 4.0, 0.78, 1.9),
        ("right_strong", "Luz der marcada", 28.0, 4.0, 0.78, 1.9),
        ("front_soft", "Luz frontal suave", 16.0, 7.0, 0.56, 2.3),
    ]
    return [
        {"id": item[0], "label": item[1], "ibl": _make_ibl(item[2], item[3]), "intensity": item[4], "gamma": item[5]}
        for item in specs[:count]
    ]


def _make_ibl(cx: float, cy: float) -> np.ndarray:
    h, w = 16, 32
    yy, xx = np.mgrid[0:h, 0:w]
    blob = np.exp(-(((xx - cx) ** 2) / (2 * 4.8**2) + ((yy - cy) ** 2) / (2 * 2.8**2)))
    blob = cv2.GaussianBlur(blob.astype(np.float32), (0, 0), 1.0)
    total = float(blob.sum())
    return blob * (30.0 / total) if total > 1e-6 else blob


def _place_shadow_on_canvas(
    shadow: np.ndarray,
    crop_box: tuple[int, int, int, int],
    output_size: tuple[int, int],
    intensity: float,
    gamma: float,
) -> np.ndarray:
    left, top, right, bottom = crop_box
    target_w = max(1, right - left)
    target_h = max(1, bottom - top)
    shadow = np.clip(shadow.astype(np.float32), 0.0, 1.0)
    shadow = np.power(shadow, gamma) * intensity
    shadow = cv2.GaussianBlur(shadow, (0, 0), 1.2)
    resized = cv2.resize(shadow, (target_w, target_h), interpolation=cv2.INTER_CUBIC)
    canvas = np.zeros((output_size[1], output_size[0]), dtype=np.float32)
    canvas[top:bottom, left:right] = np.maximum(canvas[top:bottom, left:right], resized)
    return np.clip(canvas, 0.0, 0.92)


def _composite_shadow(
    background: Image.Image,
    subject_canvas: Image.Image,
    overlay_canvas: Image.Image,
    shadow_map: np.ndarray,
) -> Image.Image:
    bg = np.asarray(background.convert("RGB"), dtype=np.float32)
    attenuation = 1.0 - shadow_map[..., None]
    shaded = np.clip(bg * attenuation, 0, 255).astype(np.uint8)
    canvas = Image.fromarray(shaded, "RGB").convert("RGBA")
    alpha_composite = Image.alpha_composite
    canvas = alpha_composite(canvas, subject_canvas.convert("RGBA"))
    canvas = alpha_composite(canvas, overlay_canvas.convert("RGBA"))
    return canvas.convert("RGB")


def _resolve_input(input_path: Path | None, input_dir: Path) -> Path:
    if input_path:
        path = input_path if input_path.is_absolute() else Path.cwd() / input_path
        if not path.exists():
            raise FileNotFoundError(path)
        return path
    images = sorted(p for p in input_dir.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    if not images:
        raise FileNotFoundError(f"No hay imagenes en {input_dir}")
    return images[0]


def _unique_run_dir(root: Path, stem: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"{stamp}_{_safe(stem)}_ssn_shadow"
    for index in range(1000):
        candidate = base if index == 0 else root / f"{base.name}_{index:03d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError("No se pudo crear carpeta unica de Lab")


def _safe(value: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in value).strip("_") or "foto"


def _manifest(status: str, input_path: Path, run_dir: Path, start: float) -> dict[str, Any]:
    return {
        "status": status,
        "input": str(input_path),
        "run_dir": str(run_dir),
        "seconds": round(time.perf_counter() - start, 3),
    }


def _write_manifest(run_dir: Path, manifest: dict[str, Any]) -> None:
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def _make_contact_sheet(outputs: list[dict[str, str]], output_path: Path) -> None:
    thumb_w, thumb_h = 520, 330
    pad = 20
    label_h = 30
    cols = 2
    rows = (len(outputs) + cols - 1) // cols
    sheet = Image.new(
        "RGB",
        (pad * (cols + 1) + thumb_w * cols, pad * (rows + 1) + (thumb_h + label_h) * rows),
        (238, 242, 245),
    )
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
    for i, item in enumerate(outputs):
        row, col = divmod(i, cols)
        x = pad + col * (thumb_w + pad)
        y = pad + row * (thumb_h + label_h + pad)
        draw.text((x, y), item["label"], fill=(10, 20, 24), font=font)
        img = Image.open(item["path"]).convert("RGB")
        img.thumbnail((thumb_w, thumb_h), Image.Resampling.LANCZOS)
        frame = Image.new("RGB", (thumb_w, thumb_h), (14, 28, 34))
        frame.paste(img, ((thumb_w - img.width) // 2, (thumb_h - img.height) // 2))
        sheet.paste(frame, (x, y + label_h))
    sheet.save(output_path, "JPEG", quality=92, optimize=True)


if __name__ == "__main__":
    raise SystemExit(main())
