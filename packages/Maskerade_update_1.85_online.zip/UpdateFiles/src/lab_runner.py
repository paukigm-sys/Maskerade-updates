from __future__ import annotations

import json
import logging
import shutil
import time
from dataclasses import asdict
from pathlib import Path

from PIL import Image

from .background_removal import BackgroundRemover
from .compositor import (
    _placement_for,
    _prepare_overlay,
    _prepare_subject,
    _target_size,
    compose_image,
)
from .config import AppSettings, ParkSettings
from .image_utils import alpha_composite_at, list_images, open_image, resize_cover


SUPPORTED_LAB_ENGINES = {"all", "base", "ic-light-pack", "shadow-generation", "ssn-shadow"}


def run_lab(
    settings: AppSettings,
    park: ParkSettings,
    engine: str = "all",
    input_path: Path | None = None,
    output_dir: Path | None = None,
    variants: int = 1,
) -> Path:
    """Run isolated postprocess experiments without changing production output."""

    engine = engine.lower().strip()
    if engine not in SUPPORTED_LAB_ENGINES:
        available = ", ".join(sorted(SUPPORTED_LAB_ENGINES))
        raise ValueError(f"Motor Lab no soportado: {engine}. Disponibles: {available}")

    source = _resolve_input(park, input_path)
    lab_root = output_dir or (settings.root_dir / "lab" / "output")
    if engine == "shadow-generation":
        from .lab_shadow_generation import run_shadow_generation_lab

        status, run_dir = run_shadow_generation_lab(
            settings=settings,
            park=park,
            input_path=source,
            output_dir=lab_root,
            variants=variants,
        )
        print(f"LAB_SHADOW_STATUS: {status}")
        return run_dir

    if engine == "ssn-shadow":
        from .lab_ssn_shadow import run_ssn_shadow_lab

        status, run_dir = run_ssn_shadow_lab(
            settings=settings,
            park=park,
            input_path=source,
            output_dir=lab_root,
            variants=variants,
        )
        print(f"LAB_SSN_STATUS: {status}")
        return run_dir

    run_dir = _unique_run_dir(lab_root, source.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("photoia.lab")
    original = open_image(source)
    remover = BackgroundRemover(settings.background_removal, logger)
    start = time.perf_counter()
    removal = remover.remove_background(original)
    removal_seconds = time.perf_counter() - start

    subject_path = run_dir / "00_ben2_subject.png"
    mask_path = run_dir / "00_ben2_mask.png"
    removal.person_rgba.save(subject_path)
    removal.mask.save(mask_path)

    outputs: dict[str, object] = {
        "input": str(source),
        "run_dir": str(run_dir),
        "backend": removal.backend_used,
        "ben2_seconds": round(removal_seconds, 3),
        "engines": {},
    }

    if engine in {"all", "base"}:
        base_start = time.perf_counter()
        base = compose_image(original, removal.person_rgba, park, logger)
        base_path = run_dir / "01_photoia_base.jpg"
        base.save(base_path, "JPEG", quality=park.jpg_quality, optimize=True, subsampling=0)
        outputs["engines"]["base"] = {
            "status": "ok",
            "output": str(base_path),
            "seconds": round(time.perf_counter() - base_start, 3),
        }

    if engine in {"all", "ic-light-pack"}:
        pack_start = time.perf_counter()
        pack = _write_ic_light_pack(run_dir, original, removal.person_rgba, park)
        outputs["engines"]["ic-light-pack"] = {
            "status": "prepared",
            "message": (
                "Paquete de capas preparado. IC-Light aun no esta instalado ni conectado; "
                "este pack sirve para probarlo sin tocar Maskerade."
            ),
            "seconds": round(time.perf_counter() - pack_start, 3),
            **pack,
        }

    manifest_path = run_dir / "manifest.json"
    with manifest_path.open("w", encoding="utf-8") as handle:
        json.dump(outputs, handle, ensure_ascii=False, indent=2)

    print(f"LAB_READY: {run_dir}")
    print(f"MANIFEST: {manifest_path}")
    return run_dir


def _resolve_input(park: ParkSettings, input_path: Path | None) -> Path:
    if input_path:
        path = input_path
        if not path.is_absolute():
            path = Path.cwd() / path
        if not path.exists():
            raise FileNotFoundError(f"No existe la foto Lab: {path}")
        return path

    images = list_images(park.input_dir)
    if not images:
        raise FileNotFoundError(
            f"No hay JPG en {park.input_dir}. Mete una foto en IN o usa --lab-input ruta.jpg."
        )
    return images[0]


def _unique_run_dir(root: Path, stem: str) -> Path:
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"{timestamp}_{_safe_name(stem)}"
    if not base.exists():
        return base
    for index in range(1, 1000):
        candidate = root / f"{timestamp}_{_safe_name(stem)}_{index:03d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"No se pudo crear carpeta Lab unica en {root}")


def _safe_name(value: str) -> str:
    keep = []
    for char in value:
        if char.isalnum() or char in {"-", "_"}:
            keep.append(char)
        else:
            keep.append("_")
    return "".join(keep).strip("_") or "foto"


def _write_ic_light_pack(
    run_dir: Path,
    original: Image.Image,
    person_rgba: Image.Image,
    park: ParkSettings,
) -> dict[str, str]:
    output_size = _target_size(original, park.output_size)

    background = Image.open(park.background_path).convert("RGB")
    background = resize_cover(background, output_size).convert("RGB")
    background_path = run_dir / "10_iclight_background.jpg"
    background.save(background_path, "JPEG", quality=95, optimize=True, subsampling=0)

    subject = _prepare_subject(person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))

    foreground_path = run_dir / "11_iclight_foreground_subject.png"
    foreground_mask_path = run_dir / "12_iclight_subject_mask.png"
    no_overlay_path = run_dir / "13_composite_without_overlay.jpg"
    overlay_layer_path = run_dir / "14_overlay_layer.png"
    readme_path = run_dir / "README_IC_LIGHT.txt"

    subject_canvas.save(foreground_path)
    subject_canvas.getchannel("A").save(foreground_mask_path)

    no_overlay = background.convert("RGBA")
    alpha_composite_at(no_overlay, subject_canvas, (0, 0))
    no_overlay.convert("RGB").save(no_overlay_path, "JPEG", quality=95, optimize=True, subsampling=0)

    overlay_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    if park.overlay_path and park.overlay_path.exists():
        overlay, xy = _prepare_overlay(Image.open(park.overlay_path).convert("RGBA"), park.overlay_settings, output_size)
        alpha_composite_at(overlay_canvas, overlay, xy)
    overlay_canvas.save(overlay_layer_path)

    readme_path.write_text(
        "\n".join(
            [
                "Maskerade Lab - IC-Light pack",
                "",
                "Capas preparadas:",
                f"- Fondo: {background_path.name}",
                f"- Sujetos BEN2: {foreground_path.name}",
                f"- Mascara sujetos: {foreground_mask_path.name}",
                f"- Composite sin overlay: {no_overlay_path.name}",
                f"- Overlay colocado: {overlay_layer_path.name}",
                "",
                "Objetivo de la prueba:",
                "1. Usar IC-Light para reluminar la capa de sujetos contra el fondo.",
                "2. Recomponer despues el overlay encima.",
                "3. Comparar resultado contra 01_photoia_base.jpg.",
                "",
                "IC-Light oficial:",
                "https://github.com/lllyasviel/IC-Light",
            ]
        ),
        encoding="utf-8",
    )

    return {
        "background": str(background_path),
        "foreground_subject": str(foreground_path),
        "subject_mask": str(foreground_mask_path),
        "composite_without_overlay": str(no_overlay_path),
        "overlay_layer": str(overlay_layer_path),
        "readme": str(readme_path),
    }
