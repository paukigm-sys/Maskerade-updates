from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from .background_removal import BackgroundRemover
from .compositor import _placement_for, _prepare_overlay, _prepare_subject, _target_size
from .config import load_settings
from .harmonizer import harmonize_subject_layer
from .image_utils import alpha_composite_at, open_image, resize_cover


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - harmonize model comparison")
    parser.add_argument("--input", type=Path, default=None)
    parser.add_argument("--park", default="photo")
    parser.add_argument("--output-dir", type=Path, default=Path("lab/output"))
    args = parser.parse_args()

    settings = load_settings()
    park = settings.get_park(args.park)
    input_path = _resolve_input(args.input, park.input_dir)
    run_dir = _unique_run_dir(args.output_dir, input_path.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    original = open_image(input_path)
    output_size = _target_size(original, park.output_size)
    background = resize_cover(Image.open(park.background_path).convert("RGB"), output_size).convert("RGB")

    start = time.perf_counter()
    removal = BackgroundRemover(settings.background_removal).remove_background(original)
    subject = _prepare_subject(removal.person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))
    ben2_seconds = time.perf_counter() - start

    overlay_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    if park.overlay_path and park.overlay_path.exists():
        overlay, xy = _prepare_overlay(Image.open(park.overlay_path).convert("RGBA"), park.overlay_settings, output_size)
        alpha_composite_at(overlay_canvas, overlay, xy)

    variants = [
        ("00_base", "Base sin harmonize", subject_canvas),
        ("01_actual_65", "Harmonize actual 65", harmonize_subject_layer(background, subject_canvas, 0.65)),
        ("02_actual_100", "Harmonize actual 100", harmonize_subject_layer(background, subject_canvas, 1.0)),
        ("03_cinematic", "Cinematic match", _cinematic_match(background, subject_canvas, 0.85)),
        ("04_shadow_safe", "Shadow-safe match", _shadow_safe_match(background, subject_canvas, 0.9)),
    ]

    outputs: list[dict[str, str]] = []
    for stem, label, layer in variants:
        final = _finish(background, layer, overlay_canvas)
        path = run_dir / f"{stem}.jpg"
        final.save(path, "JPEG", quality=94, optimize=True, subsampling=0)
        outputs.append({"label": label, "path": str(path)})

    contact = run_dir / "contact_sheet.jpg"
    _make_contact_sheet(outputs, contact)
    manifest = {
        "input": str(input_path),
        "run_dir": str(run_dir),
        "ben2_seconds": round(ben2_seconds, 3),
        "outputs": outputs,
        "contact_sheet": str(contact),
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"HARMONIZE_COMPARE: {contact}")
    print(f"RUN_DIR: {run_dir}")
    return 0


def _finish(background: Image.Image, subject: Image.Image, overlay: Image.Image) -> Image.Image:
    canvas = background.convert("RGBA")
    alpha_composite_at(canvas, subject.convert("RGBA"), (0, 0))
    alpha_composite_at(canvas, overlay.convert("RGBA"), (0, 0))
    return canvas.convert("RGB")


def _cinematic_match(background: Image.Image, subject_rgba: Image.Image, strength: float) -> Image.Image:
    bg = np.asarray(background.convert("RGB")).astype(np.float32)
    subject = np.asarray(subject_rgba.convert("RGBA")).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return subject_rgba.convert("RGBA")

    fg = subject[..., :3]
    bg_lab = cv2.cvtColor(bg.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    fg_lab = cv2.cvtColor(fg.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    sample = _sample_mask(mask, bg.shape[:2])
    fg_pixels = fg_lab[mask]
    bg_pixels = bg_lab[sample]

    fg_mean, fg_std = fg_pixels.mean(axis=0), fg_pixels.std(axis=0) + 1.0
    bg_mean, bg_std = bg_pixels.mean(axis=0), bg_pixels.std(axis=0) + 1.0

    out = fg_lab.copy()
    # More chroma matching than luminance matching: keeps faces stable but moves the palette into the scene.
    chroma_strength = 0.72 * strength
    luma_strength = 0.28 * strength
    out[..., 0] = (fg_lab[..., 0] - fg_mean[0]) * (1.0 + (bg_std[0] / fg_std[0] - 1.0) * luma_strength) + (
        fg_mean[0] * (1.0 - luma_strength) + bg_mean[0] * luma_strength
    )
    for channel in (1, 2):
        out[..., channel] = (fg_lab[..., channel] - fg_mean[channel]) * (
            1.0 + (bg_std[channel] / fg_std[channel] - 1.0) * chroma_strength
        ) + (fg_mean[channel] * (1.0 - chroma_strength) + bg_mean[channel] * chroma_strength)

    # Stronger flash control, but only in subject whites/highlights.
    highlight = np.clip((fg_lab[..., 0:1] - 195.0) / 55.0, 0.0, 1.0) * alpha
    out[..., 0:1] -= highlight * 28.0 * strength
    out = out.clip(0, 255)
    rgb = cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)
    rgb = _edge_wrap(bg, rgb, alpha[..., 0], 0.22 * strength)
    return Image.fromarray(np.dstack([rgb.clip(0, 255), subject[..., 3:4]]).astype(np.uint8), "RGBA")


def _shadow_safe_match(background: Image.Image, subject_rgba: Image.Image, strength: float) -> Image.Image:
    bg = np.asarray(background.convert("RGB")).astype(np.float32)
    subject = np.asarray(subject_rgba.convert("RGBA")).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return subject_rgba.convert("RGBA")

    fg = subject[..., :3]
    bg_lab = cv2.cvtColor(bg.astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    fg_lab = cv2.cvtColor(fg.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    sample = _sample_mask(mask, bg.shape[:2])
    bg_mean = bg_lab[sample].mean(axis=0)
    fg_mean = fg_lab[mask].mean(axis=0)

    out = fg_lab.copy()
    # Gentle luma, stronger warmth/chroma. This avoids muddy faces in already dark photos.
    out[..., 0] += (bg_mean[0] - fg_mean[0]) * 0.18 * strength
    out[..., 1] += (bg_mean[1] - fg_mean[1]) * 0.55 * strength
    out[..., 2] += (bg_mean[2] - fg_mean[2]) * 0.55 * strength

    highlight = np.clip((fg_lab[..., 0:1] - 210.0) / 35.0, 0.0, 1.0) * alpha
    out[..., 0:1] -= highlight * 18.0 * strength
    out = out.clip(0, 255)
    rgb = cv2.cvtColor(out.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)
    rgb = _edge_wrap(bg, rgb, alpha[..., 0], 0.16 * strength)
    return Image.fromarray(np.dstack([rgb.clip(0, 255), subject[..., 3:4]]).astype(np.uint8), "RGBA")


def _edge_wrap(bg: np.ndarray, rgb: np.ndarray, alpha: np.ndarray, amount: float) -> np.ndarray:
    mask = (alpha > 0.03).astype(np.uint8)
    dilated = cv2.dilate(mask, np.ones((17, 17), np.uint8), iterations=1).astype(np.float32)
    eroded = cv2.erode(mask, np.ones((9, 9), np.uint8), iterations=1).astype(np.float32)
    edge = cv2.GaussianBlur(np.clip(dilated - eroded, 0, 1), (0, 0), 5)
    wrap = cv2.GaussianBlur(bg, (0, 0), 18)
    return rgb * (1.0 - edge[..., None] * amount) + wrap * (edge[..., None] * amount)


def _sample_mask(subject_mask: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    ys, xs = np.where(subject_mask)
    sample = np.zeros(shape, dtype=bool)
    pad_x = max(80, w // 10)
    pad_y = max(80, h // 10)
    sample[max(0, ys.min() - pad_y) : min(h, ys.max() + pad_y), max(0, xs.min() - pad_x) : min(w, xs.max() + pad_x)] = True
    dilated = cv2.dilate(subject_mask.astype(np.uint8), np.ones((39, 39), np.uint8), iterations=1).astype(bool)
    sample = sample & ~dilated
    return sample if sample.any() else ~subject_mask


def _resolve_input(input_path: Path | None, input_dir: Path) -> Path:
    if input_path:
        path = input_path if input_path.is_absolute() else Path.cwd() / input_path
        if not path.exists():
            raise FileNotFoundError(path)
        return path
    images = sorted(p for p in input_dir.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    if not images:
        raise FileNotFoundError(f"No hay imagenes en {input_dir}")
    return images[0]


def _unique_run_dir(root: Path, stem: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"{stamp}_{_safe(stem)}_harmonize_compare"
    for index in range(1000):
        candidate = base if index == 0 else root / f"{base.name}_{index:03d}"
        if not candidate.exists():
            return candidate
    raise RuntimeError("No se pudo crear carpeta unica de Lab")


def _safe(value: str) -> str:
    return "".join(char if char.isalnum() or char in {"-", "_"} else "_" for char in value).strip("_") or "foto"


def _make_contact_sheet(outputs: list[dict[str, str]], output_path: Path) -> None:
    thumb_w, thumb_h = 480, 300
    pad = 20
    label_h = 30
    cols = 2
    rows = (len(outputs) + cols - 1) // cols
    sheet = Image.new("RGB", (pad * (cols + 1) + thumb_w * cols, pad * (rows + 1) + (thumb_h + label_h) * rows), (238, 242, 245))
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except Exception:
        font = ImageFont.load_default()
    for i, item in enumerate(outputs):
        row, col = divmod(i, cols)
        x = pad + col * (thumb_w + pad)
        y = pad + row * (thumb_h + label_h + pad)
        draw.text((x, y), item["label"], fill=(10, 20, 24), font=font)
        img = Image.open(item["path"]).convert("RGB")
        img.thumbnail((thumb_w, thumb_h), Image.LANCZOS)
        frame = Image.new("RGB", (thumb_w, thumb_h), (14, 28, 34))
        frame.paste(img, ((thumb_w - img.width) // 2, (thumb_h - img.height) // 2))
        sheet.paste(frame, (x, y + label_h))
    sheet.save(output_path, "JPEG", quality=92, optimize=True)


if __name__ == "__main__":
    raise SystemExit(main())
