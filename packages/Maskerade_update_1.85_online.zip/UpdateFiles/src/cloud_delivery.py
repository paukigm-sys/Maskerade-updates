from __future__ import annotations

import json
import hashlib
import hmac
import mimetypes
import os
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib import request, error, parse


IMAGE_FIELD_NAME = "file"
_AUTH_CACHE: dict[str, dict[str, Any]] = {}
_AUTH_FAILURE_UNTIL: dict[str, float] = {}
_MODULE_PATH_LOGGED = False
_UPLOAD_EVENT_WAIT_ATTEMPTS = 12
_UPLOAD_EVENT_WAIT_DELAY_SECONDS = 0.5


def _required_setting(settings, name: str) -> str:
    value = str(getattr(settings, name, "") or "").strip()
    if not value:
        raise RuntimeError(f"Cloud setting is missing: {name}")
    return value


def _join_codes(codes: tuple[int, ...]) -> str:
    return "".join(chr(code) for code in codes)


def _aws_region(settings) -> str:
    return _required_setting(settings, "aws_region")


def _photo_bucket(settings) -> str:
    return _required_setting(settings, "photo_bucket")


@dataclass(frozen=True)
class CloudResult:
    status: str
    uploaded: bool = False
    downloaded: bool = False
    skipped: bool = False
    output_path: Path | None = None
    download_path: Path | None = None
    message: str = ""


def process_output_photo(output_path: Path, input_path: Path, settings, root_dir: Path, logger) -> CloudResult:
    if not getattr(settings, "enabled", False):
        return CloudResult("disabled", output_path=output_path)

    output_path = Path(output_path)
    input_path = Path(input_path)
    if not output_path.exists():
        return CloudResult("missing", output_path=output_path, message="Output file does not exist")

    mode = str(getattr(settings, "mode", "upload_only") or "upload_only").strip().lower()
    if mode in {"upload_download", "upload_and_download", "download", "subir_descargar"}:
        return _upload_and_download(output_path, input_path, settings, root_dir, logger)
    return _upload_only(output_path, settings, logger)


def _request_presigned_upload(photo_path: Path, settings, logger) -> bytes:
    endpoint = str(getattr(settings, "upload_endpoint", "") or "").strip()
    if not endpoint:
        raise RuntimeError("Cloud upload endpoint is empty")

    mime = mimetypes.guess_type(photo_path.name)[0] or "image/jpeg"
    now = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    payload = {
        "filename": photo_path.name,
        "park": str(getattr(settings, "park", "") or ""),
        "userGroup": str(getattr(settings, "user_group", "") or ""),
        "username": str(getattr(settings, "username", "") or ""),
        "contentType": mime,
        "exif": {
            "image": photo_path.name,
            "program": "Maskerade",
            "originalDateTime": now,
            "digitizationDateTime": now,
            "source": "maskerade-cloud-module",
            "uploadTimestamp": now,
        },
    }
    logger.info(
        "Cloud presigned request: %s -> park=%s userGroup=%s username=%s",
        photo_path.name,
        payload["park"],
        payload["userGroup"],
        payload["username"],
    )
    print(f"CLOUD presigned {photo_path.name} {_cloud_destination(settings)}", flush=True)
    return _post_json(endpoint, payload, timeout=_timeout(settings))


def _upload_to_s3(photo_path: Path, settings, logger) -> tuple[bytes, Any]:
    response = _request_presigned_upload(photo_path, settings, logger)
    payload = _json_or_text(response)
    presigned_url = _find_presigned_url(payload)
    if not presigned_url:
        raise RuntimeError(f"Cloud did not return presignedUrl: {_short_response(response)}")

    mime = mimetypes.guess_type(photo_path.name)[0] or "image/jpeg"
    print(f"CLOUD uploading {photo_path.name} {_cloud_destination(settings)}", flush=True)
    status = _put_file(presigned_url, photo_path, mime, timeout=_timeout(settings))
    logger.info("Cloud upload OK: %s HTTP %s", photo_path, status)
    print(f"CLOUD uploaded {photo_path.name} {_cloud_destination(settings)}", flush=True)
    return response, payload


def _upload_only(photo_path: Path, settings, logger) -> CloudResult:
    _upload_to_s3(photo_path, settings, logger)
    return CloudResult("uploaded", uploaded=True, output_path=photo_path, message="S3 HTTP 200")


def _upload_and_download(photo_path: Path, input_path: Path, settings, root_dir: Path, logger) -> CloudResult:
    total_start = time.perf_counter()
    _log_module_path_once(logger)
    phase_start = time.perf_counter()
    _, upload_payload = _upload_to_s3(photo_path, settings, logger)
    upload_seconds = time.perf_counter() - phase_start
    s3_key = _find_string(upload_payload, {"s3Key", "key", "Key"})
    endpoint = _branding_endpoint(settings)
    if not endpoint or not s3_key:
        message = "Uploaded OK, but branding/download skipped because s3Key or branding endpoint is missing"
        logger.warning("Cloud %s: %s", photo_path, message)
        return CloudResult("uploaded_no_download", uploaded=True, output_path=photo_path, message=message)

    print(f"CLOUD watermark {photo_path.name} {_cloud_destination(settings)}", flush=True)
    phase_start = time.perf_counter()
    watermark_response = _post_json(
        endpoint,
        {"s3Key": s3_key, "bucket": _photo_bucket(settings)},
        timeout=_timeout(settings),
    )
    watermark_payload = _json_or_text(watermark_response)
    branding_seconds = time.perf_counter() - phase_start
    logger.info("Cloud branding OK via %s: %s", _branding_kind(settings), _short_response(watermark_response))

    download_url = None if _branding_kind(settings) == "qr" else _find_download_url(watermark_payload)
    view_seconds = 0.0
    if not download_url:
        logger.info("Cloud branding did not return direct image URL; requesting signed view URL for %s", s3_key)
        phase_start = time.perf_counter()
        download_url = _get_backend_view_url(s3_key, settings)
        view_seconds = time.perf_counter() - phase_start

    download_dir = Path(getattr(settings, "download_dir", None) or (root_dir / "cloud_downloads"))
    relative_folder = _relative_parent(input_path, root_dir / "input")
    target_dir = download_dir / relative_folder if relative_folder else download_dir
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = _unique_path(target_dir / photo_path.name)

    print(f"CLOUD downloading {photo_path.name} {_cloud_destination(settings)}", flush=True)
    phase_start = time.perf_counter()
    data = _download_bytes_with_retry(download_url, timeout=_timeout(settings), attempts=5, delay=1.5)
    download_seconds = time.perf_counter() - phase_start
    phase_start = time.perf_counter()
    data = _copy_jpeg_exif_bytes(photo_path.read_bytes(), data)
    target_path.write_bytes(data)
    _copy_timestamps(photo_path, target_path)
    write_seconds = time.perf_counter() - phase_start
    phase_start = time.perf_counter()
    _mark_backend_downloaded(s3_key, settings, logger)
    mark_seconds = time.perf_counter() - phase_start
    logger.info("Cloud download OK: %s", target_path)
    logger.info(
        "Cloud timing %s: upload=%.3fs branding=%.3fs view=%.3fs download=%.3fs write_exif=%.3fs mark=%.3fs total=%.3fs",
        photo_path.name,
        upload_seconds,
        branding_seconds,
        view_seconds,
        download_seconds,
        write_seconds,
        mark_seconds,
        time.perf_counter() - total_start,
    )
    print(f"CLOUD downloaded {photo_path.name} {_cloud_destination(settings)}", flush=True)
    return CloudResult("downloaded", uploaded=True, downloaded=True, output_path=photo_path, download_path=target_path)

def _cloud_destination(settings) -> str:
    park = str(getattr(settings, "park", "") or "").strip()
    username = str(getattr(settings, "username", "") or "").strip()
    if park and username:
        return f"{park}/{username}"
    return park or username

def _log_module_path_once(logger) -> None:
    global _MODULE_PATH_LOGGED
    if _MODULE_PATH_LOGGED:
        return
    _MODULE_PATH_LOGGED = True
    logger.info("Cloud module loaded from: %s", __file__)

def _branding_kind(settings) -> str:
    park = str(getattr(settings, "park", "") or "").strip().lower()
    return "watermark" if park == "pirates" else "qr"

def _branding_endpoint(settings) -> str:
    if _branding_kind(settings) == "watermark":
        return str(getattr(settings, "watermark_endpoint", "") or "").strip()
    return str(
        getattr(settings, "qr_endpoint", "") or getattr(settings, "watermark_endpoint", "") or ""
    ).strip()

def _post_json(endpoint: str, payload: dict[str, Any], timeout: float) -> bytes:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"Cloud HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Cloud connection error: {exc.reason}") from exc


def _find_presigned_url(payload: Any) -> str | None:
    names = {"presignedUrl", "presignedURL", "presigned_url", "uploadUrl", "uploadURL", "signedUrl", "signedURL", "url"}
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        for value in payload.values():
            found = _find_presigned_url(value)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_presigned_url(item)
            if found:
                return found
    return None


def _find_string(payload: Any, names: set[str]) -> str | None:
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value:
                return value
        for value in payload.values():
            found = _find_string(value, names)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_string(item, names)
            if found:
                return found
    return None

def _put_file(url: str, file_path: Path, mime: str, timeout: float) -> int:
    file_bytes = file_path.read_bytes()
    req = request.Request(
        url,
        data=file_bytes,
        headers={"Content-Type": mime, "Content-Length": str(len(file_bytes))},
        method="PUT",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            resp.read()
            return int(resp.status)
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"S3 upload HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"S3 upload connection error: {exc.reason}") from exc
def _post_multipart(endpoint: str, fields: dict[str, str], file_path: Path, timeout: float) -> bytes:
    boundary = "----MaskeradeCloud" + uuid.uuid4().hex
    body = bytearray()
    for name, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.extend(str(value).encode("utf-8"))
        body.extend(b"\r\n")

    mime = mimetypes.guess_type(file_path.name)[0] or "image/jpeg"
    file_bytes = file_path.read_bytes()
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(
        f'Content-Disposition: form-data; name="{IMAGE_FIELD_NAME}"; filename="{file_path.name}"\r\n'.encode()
    )
    body.extend(f"Content-Type: {mime}\r\n\r\n".encode())
    body.extend(file_bytes)
    body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())

    req = request.Request(
        endpoint,
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"Cloud HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Cloud connection error: {exc.reason}") from exc


def _download_bytes(url: str, timeout: float) -> bytes:
    req = request.Request(url, headers={"User-Agent": "MaskeradeCloud/1.0"})
    with request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _download_bytes_with_retry(url: str, timeout: float, attempts: int, delay: float) -> bytes:
    last_error: Exception | None = None
    for attempt in range(1, max(1, attempts) + 1):
        try:
            data = _download_bytes(url, timeout=timeout)
            if data:
                return data
            last_error = RuntimeError("empty download")
        except Exception as exc:
            last_error = exc
        if attempt < attempts:
            time.sleep(delay)
    raise RuntimeError(f"Cloud download failed after {attempts} attempts: {last_error}")


def _api_endpoint(settings) -> str:
    return _required_setting(settings, "api_endpoint").rstrip("/")


def _get_backend_view_url(s3_key: str, settings) -> str:
    base = _api_endpoint(settings)
    response = _post_json(
        f"{base}/view",
        {"s3Key": s3_key, "bucket": _photo_bucket(settings)},
        timeout=_timeout(settings),
    )
    payload = _json_or_text(response)
    url = _find_download_url(payload)
    if not url:
        raise RuntimeError(f"Cloud view did not return a signed URL for {s3_key}: {payload}")
    return url


def _mark_backend_downloaded(s3_key: str, settings, logger) -> None:
    if _mark_remote_downloaded(s3_key, settings, logger):
        return

    logger.info("Cloud Desktop login not configured; skipping global downloaded state for %s", s3_key)


def _mark_remote_downloaded(s3_key: str, settings, logger) -> bool:
    credentials = _get_desktop_aws_credentials(settings, logger)
    if not credentials:
        return False

    try:
        _wait_for_remote_upload_event(s3_key, settings, credentials, logger)
        now = datetime.now(timezone.utc)
        code = (s3_key.split("/")[-1] or s3_key).rsplit(".", 1)[0]
        item = {
            "parkId": {"S": _normalize_park_id(getattr(settings, "park", ""))},
            "eventTimestamp": {"S": f"{now.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]}Z#{uuid.uuid4().hex[:8].upper()}"},
            "type": {"S": "photo_downloaded"},
            "eventType": {"S": "photo_downloaded"},
            "date": {"S": now.strftime("%Y-%m-%d")},
            "userId": {"S": str(getattr(settings, "auth_username", "") or "maskerade")},
            "s3Key": {"S": str(s3_key)},
            "code": {"S": code},
        }
        service = _join_codes((100, 121, 110, 97, 109, 111, 100, 98))
        region = _aws_region(settings)
        _aws_signed_json(
            service=service,
            endpoint=f"https://{service}.{region}.amazonaws.com/",
            target=_join_codes((68, 121, 110, 97, 109, 111, 68, 66, 95, 50, 48, 49, 50, 48, 56, 49, 48, 46, 80, 117, 116, 73, 116, 101, 109)),
            payload={"TableName": _required_setting(settings, "photo_events_table"), "Item": item},
            credentials=credentials,
            timeout=_timeout(settings),
        )
        logger.info("Cloud marked downloaded remotely: %s", s3_key)
        return True
    except Exception as exc:
        logger.warning("Cloud could not mark downloaded remotely for %s: %s", s3_key, exc)
        return False


def _wait_for_remote_upload_event(s3_key: str, settings, credentials: dict[str, str], logger) -> bool:
    service = _join_codes((100, 121, 110, 97, 109, 111, 100, 98))
    region = _aws_region(settings)
    since = datetime.now(timezone.utc) - timedelta(minutes=10)
    payload = {
        "TableName": _required_setting(settings, "photo_events_table"),
        "KeyConditionExpression": "#park = :park AND #event_time >= :since",
        "FilterExpression": "#event_type = :uploaded AND #s3_key = :s3_key",
        "ExpressionAttributeNames": {
            "#park": "parkId",
            "#event_time": "eventTimestamp",
            "#event_type": "eventType",
            "#s3_key": "s3Key",
        },
        "ExpressionAttributeValues": {
            ":park": {"S": _normalize_park_id(getattr(settings, "park", ""))},
            ":since": {"S": since.strftime("%Y-%m-%dT%H:%M:%S.000Z")},
            ":uploaded": {"S": "photo_uploaded"},
            ":s3_key": {"S": str(s3_key)},
        },
        "ScanIndexForward": False,
    }

    try:
        for attempt in range(_UPLOAD_EVENT_WAIT_ATTEMPTS):
            response = _aws_signed_json(
                service=service,
                endpoint=f"https://{service}.{region}.amazonaws.com/",
                target=_join_codes((68, 121, 110, 97, 109, 111, 68, 66, 95, 50, 48, 49, 50, 48, 56, 49, 48, 46, 81, 117, 101, 114, 121)),
                payload=payload,
                credentials=credentials,
                timeout=_timeout(settings),
            )
            if response.get("Items"):
                logger.info("Cloud upload event confirmed before downloaded state: %s", s3_key)
                return True
            if attempt + 1 < _UPLOAD_EVENT_WAIT_ATTEMPTS:
                time.sleep(_UPLOAD_EVENT_WAIT_DELAY_SECONDS)
    except Exception as exc:
        logger.warning("Cloud could not confirm uploaded state for %s: %s", s3_key, exc)
        time.sleep(2.0)
        return False

    logger.warning("Cloud upload event was not visible before downloaded state: %s", s3_key)
    return False


def _get_desktop_aws_credentials(settings, logger) -> dict[str, str] | None:
    username = str(getattr(settings, "auth_username", "") or os.environ.get("CLOUD_DESKTOP_USERNAME", "")).strip()
    password = str(getattr(settings, "auth_password", "") or os.environ.get("CLOUD_DESKTOP_PASSWORD", ""))
    if not username or not password:
        return None

    disabled_until = float(_AUTH_FAILURE_UNTIL.get(username, 0.0))
    if disabled_until > time.time():
        logger.warning(
            "Cloud desktop login skipped for %s after recent auth failure",
            username,
        )
        return None

    cache_key = username
    cached = _AUTH_CACHE.get(cache_key)
    if cached and float(cached.get("expires_at", 0)) > time.time() + 300:
        return cached["credentials"]

    try:
        region = _aws_region(settings)
        idp_service = _join_codes((99, 111, 103, 110, 105, 116, 111, 45, 105, 100, 112))
        auth_payload = _aws_json_unsigned(
            endpoint=f"https://{idp_service}.{region}.amazonaws.com/",
            target=_join_codes((65, 87, 83, 67, 111, 103, 110, 105, 116, 111, 73, 100, 101, 110, 116, 105, 116, 121, 80, 114, 111, 118, 105, 100, 101, 114, 83, 101, 114, 118, 105, 99, 101, 46, 73, 110, 105, 116, 105, 97, 116, 101, 65, 117, 116, 104)),
            payload={
                "AuthFlow": "USER_PASSWORD_AUTH",
                _join_codes((67, 108, 105, 101, 110, 116, 73, 100)): _required_setting(settings, "identity_client"),
                "AuthParameters": {"USERNAME": username, "PASSWORD": password},
            },
            timeout=_timeout(settings),
        )
    except Exception as exc:
        _AUTH_FAILURE_UNTIL[username] = time.time() + 30 * 60
        logger.warning(
            "Cloud desktop login failed for %s; downloaded marker disabled temporarily: %s",
            username,
            exc,
        )
        return None
    auth_result = auth_payload.get("AuthenticationResult") if isinstance(auth_payload, dict) else None
    id_token = auth_result.get("IdToken") if isinstance(auth_result, dict) else None
    if not id_token:
        raise RuntimeError(f"Cloud login did not return IdToken: {auth_payload}")

    region = _aws_region(settings)
    idp_service = _join_codes((99, 111, 103, 110, 105, 116, 111, 45, 105, 100, 112))
    identity_service = _join_codes((99, 111, 103, 110, 105, 116, 111, 45, 105, 100, 101, 110, 116, 105, 116, 121))
    logins_key = f"{idp_service}.{region}.amazonaws.com/{_required_setting(settings, 'identity_user_pool')}"
    identity_payload = _aws_json_unsigned(
        endpoint=f"https://{identity_service}.{region}.amazonaws.com/",
        target=_join_codes((65, 87, 83, 67, 111, 103, 110, 105, 116, 111, 73, 100, 101, 110, 116, 105, 116, 121, 83, 101, 114, 118, 105, 99, 101, 46, 71, 101, 116, 73, 100)),
        payload={_join_codes((73, 100, 101, 110, 116, 105, 116, 121, 80, 111, 111, 108, 73, 100)): _required_setting(settings, "identity_pool"), "Logins": {logins_key: id_token}},
        timeout=_timeout(settings),
    )
    identity_id = identity_payload.get("IdentityId") if isinstance(identity_payload, dict) else None
    if not identity_id:
        raise RuntimeError(f"Cloud identity did not return IdentityId: {identity_payload}")

    creds_payload = _aws_json_unsigned(
        endpoint=f"https://{identity_service}.{region}.amazonaws.com/",
        target=_join_codes((65, 87, 83, 67, 111, 103, 110, 105, 116, 111, 73, 100, 101, 110, 116, 105, 116, 121, 83, 101, 114, 118, 105, 99, 101, 46, 71, 101, 116, 67, 114, 101, 100, 101, 110, 116, 105, 97, 108, 115, 70, 111, 114, 73, 100, 101, 110, 116, 105, 116, 121)),
        payload={"IdentityId": identity_id, "Logins": {logins_key: id_token}},
        timeout=_timeout(settings),
    )
    raw = creds_payload.get("Credentials") if isinstance(creds_payload, dict) else None
    if not isinstance(raw, dict):
        raise RuntimeError(f"Cloud identity did not return credentials: {creds_payload}")

    credentials = {
        "access_key": raw.get("AccessKeyId") or "",
        "secret_key": raw.get("SecretKey") or "",
        "session_token": raw.get("SessionToken") or "",
        "region": region,
    }
    if not credentials["access_key"] or not credentials["secret_key"] or not credentials["session_token"]:
        raise RuntimeError("Cloud identity returned incomplete credentials")

    expires_at = _credential_expiry_epoch(raw.get("Expiration"))
    _AUTH_CACHE[cache_key] = {"credentials": credentials, "expires_at": expires_at}
    logger.info("Cloud desktop login OK for %s", username)
    return credentials


def _aws_json_unsigned(endpoint: str, target: str, payload: dict[str, Any], timeout: float) -> Any:
    data = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    req = request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/x-amz-json-1.1", "X-Amz-Target": target},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return _json_or_text(resp.read())
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"AWS HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"AWS connection error: {exc.reason}") from exc


def _aws_signed_json(
    service: str,
    endpoint: str,
    target: str,
    payload: dict[str, Any],
    credentials: dict[str, str],
    timeout: float,
) -> Any:
    data = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    parsed = parse.urlparse(endpoint)
    host = parsed.netloc
    path = parsed.path or "/"
    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")
    region = credentials["region"]
    payload_hash = hashlib.sha256(data).hexdigest()
    headers = {
        "content-type": "application/x-amz-json-1.0",
        "host": host,
        "x-amz-date": amz_date,
        "x-amz-security-token": credentials["session_token"],
        "x-amz-target": target,
    }
    signed_headers = ";".join(sorted(headers))
    canonical_headers = "".join(f"{key}:{headers[key]}\n" for key in sorted(headers))
    canonical_request = f"POST\n{path}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
    credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = (
        "AWS4-HMAC-SHA256\n"
        f"{amz_date}\n"
        f"{credential_scope}\n"
        f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    )
    signing_key = _aws_signature_key(credentials["secret_key"], date_stamp, region, service)
    signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()
    auth = (
        "AWS4-HMAC-SHA256 "
        f"Credential={credentials['access_key']}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, "
        f"Signature={signature}"
    )
    req = request.Request(
        endpoint,
        data=data,
        headers={
            "Authorization": auth,
            "Content-Type": headers["content-type"],
            "Host": host,
            "X-Amz-Date": amz_date,
            "X-Amz-Security-Token": credentials["session_token"],
            "X-Amz-Target": target,
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return _json_or_text(resp.read())
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"AWS signed HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"AWS signed connection error: {exc.reason}") from exc


def _aws_signature_key(secret_key: str, date_stamp: str, region: str, service: str) -> bytes:
    key = ("AWS4" + secret_key).encode("utf-8")
    for value in (date_stamp, region, service, "aws4_request"):
        key = hmac.new(key, value.encode("utf-8"), hashlib.sha256).digest()
    return key


def _credential_expiry_epoch(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        except Exception:
            return time.time() + 3300
    return time.time() + 3300


def _normalize_park_id(value: Any) -> str:
    return str(value or "").strip().lower()


def _json_or_text(data: bytes) -> Any:
    text = data.decode("utf-8", errors="replace")
    try:
        return json.loads(text)
    except Exception:
        return text


def _find_download_url(payload: Any) -> str | None:
    names = {
        "downloadUrl", "downloadURL", "download_url", "viewUrl", "viewURL", "view_url", "url", "signedUrl", "signedURL",
        "presignedUrl", "presignedURL", "resultUrl", "resultURL", "imageUrl", "imageURL",
    }
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        for value in payload.values():
            found = _find_download_url(value)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_download_url(item)
            if found:
                return found
    return None


def _short_response(data: bytes) -> str:
    return data.decode("utf-8", errors="replace")[:500]


def _timeout(settings) -> float:
    return max(10.0, float(getattr(settings, "timeout_seconds", 90.0) or 90.0))


def _relative_parent(path: Path, root: Path) -> Path | None:
    try:
        relative = path.parent.resolve().relative_to(root.resolve())
        if str(relative) == ".":
            return None
        return relative
    except Exception:
        return None


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    for index in range(1, 10000):
        candidate = parent / f"{stem}-{index}{suffix}"
        if not candidate.exists():
            return candidate
    return parent / f"{stem}-{int(time.time())}{suffix}"


def _copy_timestamps(source: Path, target: Path) -> None:
    try:
        stat = source.stat()
        os.utime(target, (stat.st_atime, stat.st_mtime))
    except Exception:
        pass


def _copy_jpeg_exif_bytes(source: bytes, target: bytes) -> bytes:
    exif = _extract_exif_segment(source)
    if not exif or not target.startswith(b"\xff\xd8"):
        return target
    cleaned = _remove_exif_segments(target)
    return cleaned[:2] + exif + cleaned[2:]


def _extract_exif_segment(data: bytes) -> bytes | None:
    if not data.startswith(b"\xff\xd8"):
        return None
    offset = 2
    while offset + 4 <= len(data) and data[offset] == 0xFF:
        marker = data[offset + 1]
        if marker in {0xDA, 0xD9}:
            break
        length = int.from_bytes(data[offset + 2:offset + 4], "big")
        segment = data[offset:offset + 2 + length]
        if marker == 0xE1 and segment[4:10] == b"Exif\x00\x00":
            return segment
        offset += 2 + length
    return None


def _remove_exif_segments(data: bytes) -> bytes:
    if not data.startswith(b"\xff\xd8"):
        return data
    chunks = [data[:2]]
    offset = 2
    while offset + 4 <= len(data) and data[offset] == 0xFF:
        marker = data[offset + 1]
        if marker in {0xDA, 0xD9}:
            chunks.append(data[offset:])
            return b"".join(chunks)
        length = int.from_bytes(data[offset + 2:offset + 4], "big")
        segment = data[offset:offset + 2 + length]
        if not (marker == 0xE1 and segment[4:10] == b"Exif\x00\x00"):
            chunks.append(segment)
        offset += 2 + length
    chunks.append(data[offset:])
    return b"".join(chunks)


