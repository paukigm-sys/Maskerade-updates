from __future__ import annotations

import argparse
import json
import logging
import time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

from .background_removal import BackgroundRemover
from .compositor import compose_image
from .config import load_settings
from .image_utils import open_image


def main() -> int:
    parser = argparse.ArgumentParser(description="Maskerade Lab - mask postprocess variants")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--park", default="photo")
    parser.add_argument("--output-dir", type=Path, default=Path("lab/output"))
    args = parser.parse_args()

    settings = load_settings()
    park = settings.get_park(args.park)
    source = args.input.resolve()
    run_dir = _unique_run_dir(args.output_dir, source.stem)
    run_dir.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("photoia.lab.mask_postprocess")
    original = open_image(source)
    remover = BackgroundRemover(settings.background_removal, logger)

    start = time.perf_counter()
    result = remover.remove_background(original)
    ben2_seconds = time.perf_counter() - start

    base_rgba = result.person_rgba.convert("RGBA")
    base_alpha = base_rgba.getchannel("A")
    original_rgb = original.convert("RGB")

    variants = [
        ("00_base", "BEN2 actual", base_alpha),
        ("01_close_soft", "Cierra cortes finos suave", _close_alpha(base_alpha, 5, 0.45)),
        ("02_close_medium", "Cierra agujeros medio", _close_alpha(base_alpha, 9, 0.65)),
        ("03_fill_holes", "Rellena agujeros internos", _fill_small_holes(base_alpha, threshold=24, max_area=45000)),
        (
            "04_fill_close",
            "Rellena + cierre medio",
            _close_alpha(_fill_small_holes(base_alpha, threshold=24, max_area=45000), 7, 0.55),
        ),
        (
            "05_clean_fill_close",
            "Limpia manchas + rellena + cierre",
            _close_alpha(_remove_small_islands(_fill_small_holes(base_alpha, 24, 45000), 350), 7, 0.55),
        ),
        (
            "06_solid_core_soft",
            "Solidifica interior suave",
            _solidify_core(base_alpha, threshold=28, close_size=9, edge_keep=7, boost=220),
        ),
        (
            "07_solid_core_medium",
            "Solidifica interior medio",
            _solidify_core(base_alpha, threshold=22, close_size=13, edge_keep=9, boost=245),
        ),
        (
            "08_solid_core_clean",
            "Limpia + interior solido",
            _solidify_core(_remove_small_islands(base_alpha, 350), threshold=22, close_size=13, edge_keep=9, boost=245),
        ),
        (
            "09_opaque_feather_6",
            "Interior opaco borde 6px",
            _opaque_subject(base_alpha, threshold=22, close_size=11, feather_px=6, min_area=350),
        ),
        (
            "10_opaque_feather_10",
            "Interior opaco borde 10px",
            _opaque_subject(base_alpha, threshold=18, close_size=13, feather_px=10, min_area=350),
        ),
        (
            "11_grabcut_soft",
            "GrabCut guiado suave",
            _grabcut_guided_alpha(original_rgb, base_alpha, fg_threshold=160, maybe_threshold=36, iterations=3),
        ),
        (
            "12_grabcut_medium",
            "GrabCut guiado medio",
            _grabcut_guided_alpha(original_rgb, base_alpha, fg_threshold=135, maybe_threshold=48, iterations=4),
        ),
        (
            "13_grabcut_clean",
            "GrabCut + borde 6px",
            _opaque_subject(
                _grabcut_guided_alpha(original_rgb, base_alpha, fg_threshold=145, maybe_threshold=42, iterations=4),
                threshold=22,
                close_size=7,
                feather_px=6,
                min_area=500,
            ),
        ),
        (
            "14_face_anchor_prune",
            "Caras ancla: corta fantasmas",
            _face_anchor_alpha(original_rgb, base_alpha, mode="prune", strength=0.55),
        ),
        (
            "15_face_anchor_rescue",
            "Caras ancla + rescate cuerpo",
            _face_anchor_alpha(original_rgb, base_alpha, mode="rescue", strength=0.70),
        ),
        (
            "16_face_anchor_strict",
            "Caras ancla estricto",
            _face_anchor_alpha(original_rgb, base_alpha, mode="strict", strength=0.85),
        ),
    ]

    outputs: list[dict[str, str]] = []
    sheet_tiles: list[tuple[str, Image.Image]] = []
    base_final = None

    for key, label, alpha in variants:
        subject = base_rgba.copy()
        subject.putalpha(alpha)
        subject_path = run_dir / f"{key}_subject.png"
        mask_path = run_dir / f"{key}_mask.png"
        final_path = run_dir / f"{key}_final.jpg"

        subject.save(subject_path)
        alpha.save(mask_path)
        final = compose_image(original, subject, park, logger)
        final.save(final_path, "JPEG", quality=94, optimize=True, subsampling=0)
        if base_final is None:
            base_final = final

        outputs.append(
            {
                "key": key,
                "label": label,
                "subject": str(subject_path),
                "mask": str(mask_path),
                "final": str(final_path),
            }
        )
        sheet_tiles.append((label, final))

    contact_path = run_dir / "contact_sheet.jpg"
    _contact_sheet(sheet_tiles).save(contact_path, "JPEG", quality=92, optimize=True, subsampling=0)

    manifest = {
        "input": str(source),
        "ben2_seconds": round(ben2_seconds, 3),
        "run_dir": str(run_dir),
        "contact_sheet": str(contact_path),
        "outputs": outputs,
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"MASK_POSTPROCESS_LAB: {run_dir}")
    print(f"ben2: {ben2_seconds:.2f}s")
    print(f"contact_sheet: {contact_path}")
    return 0


def _close_alpha(alpha: Image.Image, kernel: int, blur: float) -> Image.Image:
    kernel = max(3, int(kernel) | 1)
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    morph = cv2.morphologyEx(arr, cv2.MORPH_CLOSE, np.ones((kernel, kernel), np.uint8), iterations=1)
    image = Image.fromarray(morph, "L")
    if blur > 0:
        image = image.filter(ImageFilter.GaussianBlur(blur))
    return image


def _fill_small_holes(alpha: Image.Image, threshold: int, max_area: int) -> Image.Image:
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    solid = (arr > threshold).astype(np.uint8)
    inverted = 1 - solid
    count, labels, stats, _ = cv2.connectedComponentsWithStats(inverted, connectivity=8)

    fill = solid.copy()
    h, w = solid.shape
    for label in range(1, count):
        x, y, bw, bh, area = stats[label]
        touches_edge = x == 0 or y == 0 or x + bw >= w or y + bh >= h
        if not touches_edge and area <= max_area:
            fill[labels == label] = 1

    filled = arr.copy()
    filled[(fill == 1) & (solid == 0)] = 255
    return Image.fromarray(filled, "L").filter(ImageFilter.GaussianBlur(0.35))


def _remove_small_islands(alpha: Image.Image, min_area: int) -> Image.Image:
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    solid = (arr > 24).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(solid, connectivity=8)
    keep = np.zeros_like(solid)
    for label in range(1, count):
        if stats[label, cv2.CC_STAT_AREA] >= min_area:
            keep[labels == label] = 1
    cleaned = arr.copy()
    cleaned[keep == 0] = 0
    return Image.fromarray(cleaned, "L")


def _solidify_core(alpha: Image.Image, threshold: int, close_size: int, edge_keep: int, boost: int) -> Image.Image:
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    kernel = np.ones((close_size, close_size), np.uint8)
    solid = (arr > threshold).astype(np.uint8) * 255
    closed = cv2.morphologyEx(solid, cv2.MORPH_CLOSE, kernel)
    filled = _flood_fill_external_holes(closed)

    edge_kernel = np.ones((edge_keep, edge_keep), np.uint8)
    inner = cv2.erode(filled, edge_kernel, iterations=1) > 0

    boosted = arr.copy()
    boosted[inner] = np.maximum(boosted[inner], boost)
    boosted = cv2.GaussianBlur(boosted, (3, 3), 0)
    return Image.fromarray(boosted, "L")


def _flood_fill_external_holes(mask: np.ndarray) -> np.ndarray:
    flood = mask.copy()
    h, w = flood.shape[:2]
    padded = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, padded, (0, 0), 255)
    holes = cv2.bitwise_not(flood)
    return cv2.bitwise_or(mask, holes)


def _opaque_subject(alpha: Image.Image, threshold: int, close_size: int, feather_px: int, min_area: int) -> Image.Image:
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    kernel = np.ones((close_size, close_size), np.uint8)
    binary = (arr > threshold).astype(np.uint8) * 255
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
    binary = _flood_fill_external_holes(binary)
    binary = _keep_large_components(binary, min_area)

    dist = cv2.distanceTransform((binary > 0).astype(np.uint8), cv2.DIST_L2, 5)
    feather = np.clip((dist / max(feather_px, 1)) * 255, 0, 255).astype(np.uint8)
    opaque = np.maximum(arr, feather)
    opaque[binary == 0] = 0
    return Image.fromarray(opaque, "L").filter(ImageFilter.GaussianBlur(0.35))


def _keep_large_components(mask: np.ndarray, min_area: int) -> np.ndarray:
    solid = (mask > 0).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(solid, connectivity=8)
    keep = np.zeros_like(solid, dtype=np.uint8)
    for label in range(1, count):
        if stats[label, cv2.CC_STAT_AREA] >= min_area:
            keep[labels == label] = 255
    return keep


def _grabcut_guided_alpha(
    original: Image.Image,
    alpha: Image.Image,
    fg_threshold: int,
    maybe_threshold: int,
    iterations: int,
) -> Image.Image:
    rgb = np.asarray(original.convert("RGB"), dtype=np.uint8)
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    if arr.max() == 0:
        return alpha.convert("L")

    maybe_threshold = max(1, min(254, int(maybe_threshold)))
    fg_threshold = max(maybe_threshold + 1, min(255, int(fg_threshold)))

    mask = np.full(arr.shape, cv2.GC_BGD, dtype=np.uint8)
    mask[arr >= max(2, maybe_threshold // 2)] = cv2.GC_PR_BGD
    mask[arr >= maybe_threshold] = cv2.GC_PR_FGD
    mask[arr >= fg_threshold] = cv2.GC_FGD

    if not np.any(mask == cv2.GC_FGD):
        nonzero = arr[arr > 0]
        if nonzero.size == 0:
            return alpha.convert("L")
        fallback = int(np.percentile(nonzero, 88))
        mask[arr >= max(fallback, maybe_threshold)] = cv2.GC_FGD

    kernel = np.ones((3, 3), np.uint8)
    sure_fg = (arr >= fg_threshold).astype(np.uint8) * 255
    sure_fg = cv2.erode(sure_fg, kernel, iterations=1)
    mask[sure_fg > 0] = cv2.GC_FGD

    bgd_model = np.zeros((1, 65), np.float64)
    fgd_model = np.zeros((1, 65), np.float64)
    try:
        cv2.grabCut(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR), mask, None, bgd_model, fgd_model, iterations, cv2.GC_INIT_WITH_MASK)
    except cv2.error:
        return alpha.convert("L")

    keep = ((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)).astype(np.uint8) * 255
    keep = cv2.morphologyEx(keep, cv2.MORPH_OPEN, kernel, iterations=1)
    keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)
    keep = _keep_large_components(keep, min_area=650)

    refined = arr.copy()
    refined[keep == 0] = 0
    refined[(keep > 0) & (arr >= maybe_threshold)] = np.maximum(refined[(keep > 0) & (arr >= maybe_threshold)], 210)
    return Image.fromarray(refined, "L").filter(ImageFilter.GaussianBlur(0.25))


def _detect_faces(original: Image.Image) -> list[tuple[int, int, int, int]]:
    rgb = np.asarray(original.convert("RGB"), dtype=np.uint8)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    min_size = max(18, min(gray.shape[:2]) // 100)
    candidates: list[tuple[int, int, int, int]] = []
    cascade_specs = [
        ("haarcascade_frontalface_default.xml", False),
        ("haarcascade_profileface.xml", False),
        ("haarcascade_profileface.xml", True),
    ]

    for cascade_name, flipped in cascade_specs:
        cascade = cv2.CascadeClassifier(str(Path(cv2.data.haarcascades) / cascade_name))
        if cascade.empty():
            continue
        scan = cv2.flip(gray, 1) if flipped else gray
        found = cascade.detectMultiScale(
            scan,
            scaleFactor=1.07,
            minNeighbors=3,
            minSize=(min_size, min_size),
        )
        for x, y, w, h in found:
            if flipped:
                x = gray.shape[1] - int(x) - int(w)
            candidates.append((int(x), int(y), int(w), int(h)))

    candidates.sort(key=lambda rect: rect[2] * rect[3], reverse=True)
    faces: list[tuple[int, int, int, int]] = []
    for rect in candidates:
        if all(_rect_overlap(rect, kept) < 0.35 for kept in faces):
            faces.append(rect)
    return faces


def _rect_overlap(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    left = max(ax, bx)
    top = max(ay, by)
    right = min(ax + aw, bx + bw)
    bottom = min(ay + ah, by + bh)
    if right <= left or bottom <= top:
        return 0.0
    intersection = (right - left) * (bottom - top)
    smaller = max(1, min(aw * ah, bw * bh))
    return intersection / smaller


def _face_support_mask(shape: tuple[int, int], faces: list[tuple[int, int, int, int]], strength: float) -> np.ndarray:
    h, w = shape
    support = np.zeros((h, w), dtype=np.uint8)
    for x, y, face_w, face_h in faces:
        center_x = x + face_w // 2
        body_w = int(face_w * (5.0 + 3.0 * strength))
        top = max(0, int(y - face_h * 0.55))
        bottom = min(h, int(y + face_h * (9.5 + 3.5 * strength)))
        left = max(0, center_x - body_w // 2)
        right = min(w, center_x + body_w // 2)
        cv2.rectangle(support, (left, top), (right, bottom), 255, -1)
        cv2.ellipse(
            support,
            (center_x, min(h - 1, int(y + face_h * 2.4))),
            (max(1, body_w // 2), max(1, int(face_h * 1.45))),
            0,
            0,
            360,
            255,
            -1,
        )

    kernel_size = max(9, int(min(w, h) * 0.012)) | 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
    support = cv2.morphologyEx(support, cv2.MORPH_CLOSE, kernel, iterations=2)
    return cv2.dilate(support, kernel, iterations=1)


def _face_anchor_alpha(original: Image.Image, alpha: Image.Image, mode: str, strength: float) -> Image.Image:
    arr = np.asarray(alpha.convert("L"), dtype=np.uint8)
    if arr.max() == 0:
        return alpha.convert("L")

    faces = _detect_faces(original)
    if not faces:
        return alpha.convert("L")

    support = _face_support_mask(arr.shape, faces, strength)
    threshold = 18 if mode == "strict" else 10
    solid = (arr > threshold).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(solid, connectivity=8)
    keep = np.zeros_like(solid, dtype=np.uint8)
    min_area = max(250, arr.size // 4000)

    for label in range(1, count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area < min_area:
            continue
        component = labels == label
        overlap = np.count_nonzero(component & (support > 0)) / max(area, 1)
        strong = np.count_nonzero(component & (arr > 140)) / max(area, 1)
        if mode == "strict":
            ok = overlap >= 0.22 or (overlap >= 0.10 and strong >= 0.35)
        else:
            ok = overlap >= 0.08 or (overlap >= 0.035 and strong >= 0.28)
        if ok:
            keep[component] = 1

    refined = arr.copy()
    refined[keep == 0] = 0
    if mode == "rescue":
        weak = (arr > 2) & (support > 0) & (keep > 0)
        refined[weak] = np.maximum(refined[weak], np.uint8(185))
        refined = cv2.GaussianBlur(refined, (3, 3), 0)
    return Image.fromarray(refined, "L")


def _unique_run_dir(root: Path, stem: str) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    base = root / f"mask_postprocess_{stamp}_{stem}"
    candidate = base
    index = 1
    while candidate.exists():
        candidate = root / f"{base.name}_{index:02d}"
        index += 1
    return candidate


def _contact_sheet(tiles: list[tuple[str, Image.Image]]) -> Image.Image:
    thumb_w, thumb_h = 520, 348
    cols = 2
    rows = (len(tiles) + cols - 1) // cols
    header_h = 34
    sheet = Image.new("RGB", (thumb_w * cols, (thumb_h + header_h) * rows), (18, 22, 28))
    draw = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("arial.ttf", 18)
    except OSError:
        font = ImageFont.load_default()

    for index, (label, image) in enumerate(tiles):
        col = index % cols
        row = index // cols
        x = col * thumb_w
        y = row * (thumb_h + header_h)
        draw.text((x + 10, y + 8), label, fill=(235, 238, 245), font=font)
        tile = ImageOps.contain(image.convert("RGB"), (thumb_w, thumb_h))
        canvas = Image.new("RGB", (thumb_w, thumb_h), (5, 12, 16))
        canvas.paste(tile, ((thumb_w - tile.width) // 2, (thumb_h - tile.height) // 2))
        sheet.paste(canvas, (x, y + header_h))

    return sheet


if __name__ == "__main__":
    raise SystemExit(main())
