from __future__ import annotations

import shutil
import time
import re
from pathlib import Path

from PIL import Image, ImageOps

from .config import SUPPORTED_IMAGE_EXTENSIONS


LANCZOS = Image.Resampling.LANCZOS
_NATURAL_PART_RE = re.compile(r"(\d+)")


def natural_sort_key(path: Path, root: Path | None = None) -> tuple[tuple[int, object], ...]:
    try:
        text = str(path.relative_to(root)) if root else str(path)
    except ValueError:
        text = str(path)

    text = text.replace("\\", "/").lower()
    parts = _NATURAL_PART_RE.split(text)
    return tuple((0, int(part)) if part.isdigit() else (1, part) for part in parts)


def open_image(path: Path) -> Image.Image:
    with Image.open(path) as image:
        return ImageOps.exif_transpose(image).convert("RGB")


def list_images(directory: Path) -> list[Path]:
    if not directory.exists():
        return []
    return sorted(
        (
            path
            for path in directory.rglob("*")
            if path.is_file()
            and path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
            and not any(part.startswith(".") for part in path.relative_to(directory).parts)
        ),
        key=lambda path: natural_sort_key(path, directory),
    )


def wait_for_stable_file(
    path: Path,
    interval_seconds: float,
    stable_checks: int,
    timeout_seconds: float,
) -> None:
    start = time.monotonic()
    last_signature: tuple[int, int] | None = None
    stable_count = 0

    while True:
        if not path.exists():
            raise FileNotFoundError(f"Input file disappeared: {path}")

        stat = path.stat()
        signature = (stat.st_size, int(stat.st_mtime_ns))
        if signature == last_signature and stat.st_size > 0:
            stable_count += 1
            if stable_count >= stable_checks:
                return
        else:
            stable_count = 0
            last_signature = signature

        if time.monotonic() - start > timeout_seconds:
            raise TimeoutError(f"File did not become stable in time: {path}")

        time.sleep(interval_seconds)


def resize_cover(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    target_w, target_h = size
    src_w, src_h = image.size
    scale = max(target_w / src_w, target_h / src_h)
    resized = image.resize((round(src_w * scale), round(src_h * scale)), LANCZOS)
    left = max(0, (resized.width - target_w) // 2)
    top = max(0, (resized.height - target_h) // 2)
    return resized.crop((left, top, left + target_w, top + target_h))


def unique_path(path: Path, overwrite: bool = False) -> Path:
    if overwrite or not path.exists():
        return path

    for counter in range(1, 10000):
        candidate = path.with_name(f"{path.stem}_{counter:03d}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Could not create unique filename for: {path}")


def move_to_directory(path: Path, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    target = unique_path(directory / path.name)
    for attempt in range(20):
        try:
            shutil.move(str(path), str(target))
            break
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(0.5)
    return target


def alpha_composite_at(base: Image.Image, overlay: Image.Image, xy: tuple[int, int]) -> None:
    if base.mode != "RGBA":
        raise ValueError("base must be RGBA")
    if overlay.mode != "RGBA":
        overlay = overlay.convert("RGBA")

    x, y = int(xy[0]), int(xy[1])
    src_left = max(0, -x)
    src_top = max(0, -y)
    dst_left = max(0, x)
    dst_top = max(0, y)
    width = min(overlay.width - src_left, base.width - dst_left)
    height = min(overlay.height - src_top, base.height - dst_top)

    if width <= 0 or height <= 0:
        return

    cropped = overlay.crop((src_left, src_top, src_left + width, src_top + height))
    base.alpha_composite(cropped, (dst_left, dst_top))
