"""Maskerade package."""

__version__ = "2.51"
