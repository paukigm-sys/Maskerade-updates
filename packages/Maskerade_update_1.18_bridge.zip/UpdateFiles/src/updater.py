from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import ssl
import subprocess
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import __version__


DEFAULT_MANIFEST_URL = (
    "https://raw.githubusercontent.com/paukigm-sys/Maskerade-updates/main/latest.json"
)


@dataclass(frozen=True)
class UpdateInfo:
    status: str
    current_version: str
    latest_version: str
    url: str
    sha256: str
    notes: str
    manifest_url: str


def manifest_url() -> str:
    return os.environ.get("MASKERADE_UPDATE_URL", DEFAULT_MANIFEST_URL).strip() or DEFAULT_MANIFEST_URL


def check_for_update(url: str | None = None, timeout_seconds: int = 12) -> UpdateInfo:
    selected_url = url or manifest_url()
    try:
        payload = _download_text(selected_url, timeout_seconds=timeout_seconds)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return UpdateInfo(
                status="current",
                current_version=__version__,
                latest_version=__version__,
                url="",
                sha256="",
                notes="No hay update remoto publicado todavia.",
                manifest_url=selected_url,
            )
        raise
    data = json.loads(payload)
    latest_version = str(data.get("version") or "").strip()
    update_url = str(data.get("url") or "").strip()
    sha256 = str(data.get("sha256") or "").strip().lower()
    notes = str(data.get("notes") or "").strip()

    if not latest_version:
        raise RuntimeError("El manifest remoto no tiene version.")
    status = "update_available" if _version_key(latest_version) > _version_key(__version__) else "current"
    if status == "update_available" and not update_url:
        raise RuntimeError("El manifest remoto no tiene url de descarga.")
    return UpdateInfo(
        status=status,
        current_version=__version__,
        latest_version=latest_version,
        url=update_url,
        sha256=sha256,
        notes=notes,
        manifest_url=selected_url,
    )


def install_update(app_dir: Path, current_pid: int | None = None, url: str | None = None) -> Path:
    info = check_for_update(url=url, timeout_seconds=20)
    if info.status != "update_available":
        raise RuntimeError(f"Ya tienes la ultima version: {info.current_version}")

    app_dir = Path(app_dir).resolve()
    work_dir = app_dir / "tmp" / "updates" / _safe_name(info.latest_version)
    extract_dir = work_dir / "extracted"
    zip_path = work_dir / "update.zip"

    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    _download_file(info.url, zip_path)
    if info.sha256:
        digest = _sha256(zip_path)
        if digest.lower() != info.sha256.lower():
            raise RuntimeError(
                "El update descargado no coincide con el SHA256 esperado. "
                f"Esperado {info.sha256}, recibido {digest}."
            )

    with zipfile.ZipFile(zip_path) as archive:
        archive.extractall(extract_dir)

    payload_dir = _find_payload_dir(extract_dir)
    if payload_dir is None:
        raise RuntimeError("El ZIP de update no contiene la carpeta UpdateFiles.")

    script_path = work_dir / "apply_update.bat"
    _write_apply_script(script_path, app_dir, payload_dir, current_pid)
    _launch_detached(script_path)
    return script_path


def _download_text(url: str, timeout_seconds: int) -> str:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Maskerade-Updater",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout_seconds, context=_ssl_context()) as response:
        return response.read().decode("utf-8-sig")


def _download_file(url: str, destination: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "Maskerade-Updater"})
    with urllib.request.urlopen(request, timeout=90, context=_ssl_context()) as response:
        with destination.open("wb") as handle:
            shutil.copyfileobj(response, handle)


def _ssl_context() -> ssl.SSLContext | None:
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


def _version_key(value: str) -> tuple[Any, ...]:
    parts = re.findall(r"\d+|[a-zA-Z]+", value)
    key: list[Any] = []
    for part in parts:
        if part.isdigit():
            key.append((0, int(part)))
        else:
            key.append((1, part.casefold()))
    return tuple(key)


def _safe_name(value: str) -> str:
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._")
    return safe or "update"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _find_payload_dir(root: Path) -> Path | None:
    direct = root / "UpdateFiles"
    if direct.exists() and direct.is_dir():
        return direct
    for path in root.rglob("UpdateFiles"):
        if path.is_dir():
            return path
    return None


def _write_apply_script(
    script_path: Path,
    app_dir: Path,
    payload_dir: Path,
    current_pid: int | None,
) -> None:
    backup_name = "_backup_online_update_%DATE:~-4%%DATE:~3,2%%DATE:~0,2%_%TIME:~0,2%%TIME:~3,2%"
    backup_name = backup_name.replace(" ", "0")
    pid_line = ""
    if current_pid and current_pid > 0:
        pid_line = f'taskkill /PID {current_pid} /F >> "%LOG%" 2>>&1\r\n'

    script = f"""@echo off
setlocal EnableExtensions
set "DST={app_dir}"
set "SRC={payload_dir}"
set "BACKUP=%DST%\\{backup_name}"
set "BACKUP=%BACKUP: =0%"
set "LOG=%DST%\\logs\\online_update.log"
if not exist "%DST%\\logs" mkdir "%DST%\\logs" >nul 2>nul

echo.
echo === Maskerade - Actualizacion online ===
echo.
echo === Maskerade online update %DATE% %TIME% === > "%LOG%"
echo DST=%DST% >> "%LOG%"
echo SRC=%SRC% >> "%LOG%"
echo Esperando cierre de Maskerade...
timeout /t 2 /nobreak >nul
{pid_line}taskkill /IM Maskerade.exe /F >> "%LOG%" 2>>&1
taskkill /IM PhotoIA.exe /F >> "%LOG%" 2>>&1

if not exist "%SRC%" (
    echo ERROR: No encuentro UpdateFiles:
    echo %SRC%
    echo ERROR: No encuentro UpdateFiles: %SRC% >> "%LOG%"
    pause
    exit /b 1
)

mkdir "%BACKUP%" >nul 2>nul
for %%F in (Maskerade.exe PhotoIA.exe maskerade.ico desktop_bridge.py main.py Abrir_Maskerade.bat) do (
    if exist "%DST%\\%%F" copy /Y "%DST%\\%%F" "%BACKUP%\\%%F" >nul
)
if exist "%DST%\\src" (
    mkdir "%BACKUP%\\src" >nul 2>nul
    xcopy "%DST%\\src" "%BACKUP%\\src\\" /E /I /Y >nul
)

echo Copiando update...
xcopy "%SRC%" "%DST%\\" /E /I /Y >> "%LOG%" 2>>&1
if errorlevel 1 (
    echo ERROR: No se pudo copiar el update. Revisa:
    echo %LOG%
    echo ERROR: xcopy fallo con codigo %ERRORLEVEL% >> "%LOG%"
    pause
    exit /b 1
)

echo.
echo Update instalado.
echo Backup:
echo %BACKUP%
echo.
echo Update instalado correctamente. Backup=%BACKUP% >> "%LOG%"
start "" "%DST%\\Maskerade.exe"
endlocal
"""
    script_path.write_text(script, encoding="ascii")


def _launch_detached(script_path: Path) -> None:
    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
    subprocess.Popen(
        ["cmd.exe", "/c", str(script_path)],
        cwd=str(script_path.parent),
        creationflags=creationflags,
        close_fds=True,
    )
