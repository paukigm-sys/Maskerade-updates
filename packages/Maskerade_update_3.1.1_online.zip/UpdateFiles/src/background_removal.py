from __future__ import annotations

import logging
import sys
import time
from dataclasses import dataclass
from importlib import import_module
from pathlib import Path
from threading import Lock
from typing import Any

from PIL import Image, ImageFilter

from .config import BackgroundRemovalSettings, ConfigurationError


_BEN2_MODEL_CACHE_LOCK = Lock()
_BIREFNET_MODEL_CACHE_LOCK = Lock()
_BIREFNET_WARM_LOCK = Lock()
_U2NET_SESSION_LOCK = Lock()
_BEN2_INFERENCE_LOCK = Lock()
_BIREFNET_INFERENCE_LOCK = Lock()
_HAIR_REPAIR_MODEL_LOCK = Lock()
_HAIR_REPAIR_INFERENCE_LOCK = Lock()
_BEN2_MODEL_CACHE: dict[tuple[str, str], tuple[Any, Any]] = {}
_BIREFNET_MODEL_CACHE: dict[tuple[str, str], tuple[Any, Any]] = {}
_BIREFNET_WARM_CACHE: set[tuple[int, int]] = set()
_U2NET_SESSION_CACHE: dict[str, tuple[Any, str]] = {}
_HAIR_REPAIR_MODEL_CACHE: tuple[Any, Any, Any, Any] | None = None
_STRUCTURAL_GRABCUT_MAX_SIDE = 960
_MASK_SLIDER_MIN = -100
_MASK_DEEP_AGGRESSION_START = -50
_MASK_RESCUE_START = 25
_MASK_LOW_CONSERVE_VETO_END = 25
_MASK_ZERO_RESCUE_AMOUNT = 10
_MASK_ZERO_RESCUE_ALPHA_SCALE = 0.10
_MASK_EXTRA_PROTECTION_START = 50
_MASK_QUALITY_REPAIR_START = 75
_MASK_ULTRA_CONSERVE_START = 100


@dataclass(frozen=True)
class RemovalResult:
    person_rgba: Image.Image
    mask: Image.Image
    backend_used: str
    warning: str | None = None


@dataclass(frozen=True)
class PreparedBackgroundRemoval:
    rgba: Image.Image
    scale: float
    timings: tuple[tuple[str, float], ...]
    backend_used: str = "ben2"
    ben2_rgba: Image.Image | None = None
    ben2_scale: float = 1.0


class BackgroundRemover:
    """Production remover: BEN2 with local mask cleanup."""

    def __init__(
        self,
        settings: BackgroundRemovalSettings,
        logger: logging.Logger | None = None,
    ) -> None:
        self.settings = settings
        self.logger = logger or logging.getLogger(__name__)
        self._cpu_processing_warned = False
        self._ben2_model = None
        self._ben2_device = None
        self._ben2_warm = False
        self._birefnet_model = None
        self._birefnet_device = None
        self._birefnet_warm = False
        self._birefnet_warning = False
        self._birefnet_hybrid_warning = False
        self._dynamic_tile_warning = False
        self._u2net_human_session = None
        self._u2net_human_provider = None
        self._u2net_human_warning = False
        self._last_u2net_human_alpha = None
        self._localized_human_rescue_active = False
        self._shared_u2net_human_alpha = None
        self._hair_repair_warning = False

    def remove_background(self, image: Image.Image) -> RemovalResult:
        prepared = self.prepare_background_removal(image)
        return self.finish_background_removal(image, prepared)

    def prepare_background_removal(self, image: Image.Image) -> PreparedBackgroundRemoval:
        backend = (self.settings.backend or "ben2").lower()
        if backend not in {"ben2", "ben", "birefnet", "birefnet-portrait"}:
            raise ConfigurationError(
                f"Motor de recorte no soportado: {self.settings.backend}. "
                "Esta version usa BiRefNet con retorno seguro a BEN2."
            )

        timings: list[tuple[str, float]] = []
        phase_start = time.perf_counter()
        if self._birefnet_enabled():
            # BiRefNet performs its own model resize. Feeding it the full source
            # here preserves the same detail and aspect ratio as the approved
            # Dynamic trials instead of first shrinking it with BEN2's limit.
            working = image.convert("RGB")
            scale = 1.0
            now = time.perf_counter()
            timings.append(("prepare", now - phase_start))
            phase_start = now
            try:
                rgba = self._remove_with_birefnet(working)
                now = time.perf_counter()
                timings.append(("birefnet", now - phase_start))
                ben2_rgba = None
                ben2_scale = 1.0
                if self._birefnet_hybrid_enabled():
                    try:
                        ben2_working, ben2_scale = self._working_image(image)
                        phase_start = time.perf_counter()
                        ben2_rgba = self._remove_with_ben2(ben2_working)
                        timings.append(
                            ("hybrid_ben2", time.perf_counter() - phase_start)
                        )
                    except Exception as hybrid_exc:
                        if not self._birefnet_hybrid_warning:
                            self.logger.warning(
                                "Refuerzo BEN2 para BiRefNet desactivado: %s",
                                hybrid_exc,
                            )
                            self._birefnet_hybrid_warning = True
                return PreparedBackgroundRemoval(
                    rgba=rgba,
                    scale=scale,
                    timings=tuple(timings),
                    backend_used=self._birefnet_backend_name(),
                    ben2_rgba=ben2_rgba,
                    ben2_scale=ben2_scale,
                )
            except Exception as exc:
                if not bool(getattr(self.settings, "birefnet_fallback_ben2", True)):
                    raise
                if not self._birefnet_warning:
                    self.logger.warning(
                        "BiRefNet fallo; retorno seguro a BEN2: %s",
                        exc,
                    )
                    self._birefnet_warning = True
                phase_start = time.perf_counter()
        working, scale = self._working_image(image)
        timings.append(("prepare_ben2", time.perf_counter() - phase_start))
        phase_start = time.perf_counter()
        rgba = self._remove_with_ben2(working)
        timings.append(("ben2", time.perf_counter() - phase_start))
        return PreparedBackgroundRemoval(
            rgba=rgba,
            scale=scale,
            timings=tuple(timings),
            backend_used="ben2",
        )

    def finish_background_removal(
        self,
        image: Image.Image,
        prepared: PreparedBackgroundRemoval,
    ) -> RemovalResult:
        timings = list(prepared.timings)
        phase_start = time.perf_counter()
        if prepared.backend_used.startswith("birefnet"):
            return self._finish_birefnet_background_removal(image, prepared)
        raw_mask_strength: int | None = None
        u2net_rescued: bool | None = None
        post_rescue_cleanup_ran = False
        post_rescue_cleanup_changed = False

        def mark_phase(name: str) -> None:
            nonlocal phase_start
            now = time.perf_counter()
            timings.append((name, now - phase_start))
            phase_start = now

        def log_timings() -> None:
            if not self.logger.isEnabledFor(logging.INFO):
                return
            total = sum(seconds for _name, seconds in timings)
            parts = " ".join(f"{name}={seconds:.3f}s" for name, seconds in timings)
            slider_parts = ""
            if raw_mask_strength is not None:
                protection_raw, antighost_raw = _mask_raw_values(self.settings)
                slider_parts = (
                    f" slider={raw_mask_strength}"
                    f" protection={protection_raw}"
                    f" antighost={antighost_raw}"
                    f" unified={_mask_uses_unified_slider(self.settings)}"
                    f" cleanup={_mask_cleanup_amount(self.settings)}"
                    f" rescue={_mask_human_rescue_amount(raw_mask_strength)}"
                    f" u2net_trigger={raw_mask_strength >= _MASK_RESCUE_START}"
                    f" u2net_rescued={u2net_rescued}"
                    f" post_rescue_cleanup={post_rescue_cleanup_ran}"
                    f" post_rescue_changed={post_rescue_cleanup_changed}"
                    f" zero_veto={raw_mask_strength <= _MASK_LOW_CONSERVE_VETO_END}"
                )
            self.logger.info("Mask timing: total=%.3fs%s %s", total, slider_parts, parts)

        rgba = prepared.rgba
        mask = rgba.getchannel("A")
        if prepared.scale != 1.0:
            mask = mask.resize(image.size, Image.Resampling.LANCZOS)
        rgba = image.convert("RGBA")
        rgba.putalpha(mask)
        mark_phase("resize_mask")

        raw_mask_strength = _mask_conserve_slider_value(self.settings)
        structural_cleanup = raw_mask_strength < _MASK_QUALITY_REPAIR_START
        self._shared_u2net_human_alpha = None
        self._last_u2net_human_alpha = None
        shared_human_alpha = None
        if (
            raw_mask_strength >= _MASK_RESCUE_START
            and raw_mask_strength <= _MASK_LOW_CONSERVE_VETO_END
        ):
            try:
                shared_human_alpha = self._u2net_human_alpha(image)
            except Exception as exc:
                if not self._u2net_human_warning:
                    self.logger.warning("Proteccion humana U2Net desactivada: %s", exc)
                    self._u2net_human_warning = True
            self._shared_u2net_human_alpha = shared_human_alpha
            mark_phase("human_segmentation")
        rgba = self._apply_structural_mask_cleanup(image, rgba)
        mark_phase("structural_cleanup")
        if raw_mask_strength <= _MASK_LOW_CONSERVE_VETO_END:
            rgba = self._apply_zero_max_human_veto(image, rgba)
            mark_phase("zero_veto")
        if raw_mask_strength < 0:
            rgba = self._apply_negative_mask_edge_cut(rgba, raw_mask_strength)
            mark_phase("negative_edge")

        if raw_mask_strength >= _MASK_RESCUE_START:
            before_rescue = rgba
            rgba, u2net_rescued = self._apply_u2net_human_rescue(image, rgba)
            mark_phase("u2net_rescue")
            if u2net_rescued and raw_mask_strength == _MASK_RESCUE_START:
                post_rescue_cleanup_ran = True
                localized_alpha = self._localized_default_human_rescue(
                    image,
                    before_rescue,
                    rgba,
                )
                rgba, post_rescue_cleanup_changed = self._cleanup_default_u2net_rescue(
                    before_rescue,
                    rgba,
                )
                if localized_alpha is not None:
                    try:
                        import numpy as np

                        cleaned_alpha = np.asarray(
                            rgba.getchannel("A").convert("L"),
                            dtype=np.uint8,
                        )
                        merged_alpha = np.maximum(cleaned_alpha, localized_alpha)
                        localized_changed = bool(np.any(merged_alpha > cleaned_alpha))
                        if localized_changed:
                            rgba = rgba.copy()
                            rgba.putalpha(Image.fromarray(merged_alpha, "L"))
                            post_rescue_cleanup_changed = True
                    except Exception as exc:
                        self.logger.warning(
                            "Mask localized human merge skipped: %s",
                            exc,
                        )
                rgba, detached_changed = self._cleanup_default_detached_artifacts(rgba)
                post_rescue_cleanup_changed = post_rescue_cleanup_changed or detached_changed
                rgba, interior_changed = self._solidify_default_human_interiors(rgba)
                post_rescue_cleanup_changed = post_rescue_cleanup_changed or interior_changed
                mark_phase("post_rescue_cleanup")
            if raw_mask_strength == _MASK_RESCUE_START:
                post_rescue_cleanup_ran = True
                rgba, floor_artifact_changed = self._cleanup_default_compact_floor_artifacts(
                    rgba
                )
                post_rescue_cleanup_changed = (
                    post_rescue_cleanup_changed or floor_artifact_changed
                )
                mark_phase("floor_artifact_cleanup")
        if raw_mask_strength >= _MASK_ULTRA_CONSERVE_START:
            rgba, ultra_group_changed = self._apply_ultra_group_human_rescue(image, rgba)
            if ultra_group_changed:
                mark_phase("ultra_group_rescue")
            rgba = self._solidify_translucent_subjects(rgba)
            mark_phase("solidify")
            rgba = self._apply_mask_protection(rgba, run_antighost=False)
            mark_phase("mask_protection")
            rgba = self._remove_ultra_conservative_artifacts(rgba)
            mark_phase("ultra_artifacts")
            rgba = self._antialias_alpha_edges(rgba)
            mark_phase("antialias")
            log_timings()
            self._shared_u2net_human_alpha = None
            return RemovalResult(rgba, rgba.getchannel("A"), "ben2")
        quality_repair = self._apply_quality_mask_repair(image, rgba)
        mark_phase("quality_repair")
        if quality_repair is not None:
            rgba = self._trim_soft_edge_noise(quality_repair)
            mark_phase("trim")
            rgba = self._antialias_alpha_edges(rgba)
            mark_phase("antialias")
            log_timings()
            self._shared_u2net_human_alpha = None
            return RemovalResult(rgba, rgba.getchannel("A"), "ben2")

        antighost = _mask_cleanup_amount(self.settings)
        run_final_antighost = antighost > 0 and (
            not structural_cleanup or raw_mask_strength <= 0
        )
        if (
            run_final_antighost
            and structural_cleanup
            and _mask_uses_unified_slider(self.settings)
        ):
            run_final_antighost = False
        if run_final_antighost:
            rgba = self._apply_mask_antighost(rgba, amount=antighost, calibrated=True)
            mark_phase("antighost")
        if not structural_cleanup:
            rgba = self._solidify_translucent_subjects(rgba)
            mark_phase("solidify")
        rgba = self._apply_mask_protection(rgba, run_antighost=False)
        mark_phase("mask_protection")
        rgba = self._trim_soft_edge_noise(rgba)
        mark_phase("trim")
        if raw_mask_strength == _MASK_RESCUE_START:
            rgba, default_edge_changed = self._refine_default_alpha_edge(rgba)
            mark_phase("default_edge_refine")
        rgba = self._antialias_alpha_edges(rgba)
        mark_phase("antialias")
        log_timings()
        self._shared_u2net_human_alpha = None
        return RemovalResult(rgba, rgba.getchannel("A"), "ben2")

    def remove_background_preview(self, image: Image.Image) -> RemovalResult:
        """Create a lightweight design-preview cutout without production repairs."""
        backend = (self.settings.backend or "ben2").lower()
        if backend not in {"ben2", "ben", "birefnet", "birefnet-portrait"}:
            raise ConfigurationError(
                f"Motor de recorte no soportado: {self.settings.backend}. "
                "Esta version usa BiRefNet con retorno seguro a BEN2."
            )

        working, _ = self._working_image(image)
        if self._birefnet_enabled():
            started = time.perf_counter()
            try:
                rgba = self._remove_with_birefnet(working)
                prepared = PreparedBackgroundRemoval(
                    rgba=rgba,
                    scale=1.0,
                    timings=(("birefnet_preview", time.perf_counter() - started),),
                    backend_used=self._birefnet_backend_name(),
                )
                return self._finish_birefnet_background_removal(working, prepared)
            except Exception as exc:
                if not bool(getattr(self.settings, "birefnet_fallback_ben2", True)):
                    raise
                if not self._birefnet_warning:
                    self.logger.warning(
                        "BiRefNet preview fallo; retorno seguro a BEN2: %s",
                        exc,
                    )
                    self._birefnet_warning = True
        rgba = self._remove_with_ben2(working)
        if _mask_conserve_slider_value(self.settings) < 0:
            rgba = self._apply_zero_max_human_veto(working, rgba)
        rgba = self._apply_mask_protection(rgba)
        if _mask_conserve_slider_value(self.settings) < 0:
            rgba = self._apply_negative_mask_edge_cut(
                rgba,
                _mask_conserve_slider_value(self.settings),
            )
        rgba = self._trim_soft_edge_noise(rgba)
        rgba = self._antialias_alpha_edges(rgba)
        return RemovalResult(rgba, rgba.getchannel("A"), "ben2")

    def warm_up(self) -> None:
        backend = (self.settings.backend or "ben2").lower()
        if backend not in {"ben2", "ben", "birefnet", "birefnet-portrait"}:
            return
        if self._birefnet_enabled():
            torch = self._import_torch()
            self._ensure_birefnet_model(torch)
            if self._birefnet_warm:
                if self._birefnet_hybrid_enabled():
                    self._warm_up_ben2()
                    self.warm_up_human_rescue()
                return
            warm_key = (id(self._birefnet_model), self._birefnet_input_size())
            with _BIREFNET_WARM_LOCK:
                if warm_key not in _BIREFNET_WARM_CACHE:
                    try:
                        passes = (
                            4
                            if getattr(self._birefnet_device, "type", "") == "cuda"
                            else 1
                        )
                        warm_image = Image.new("RGB", (256, 256), (8, 8, 8))
                        for _ in range(passes):
                            self._remove_with_birefnet(warm_image)
                        if getattr(self._birefnet_device, "type", "") == "cuda":
                            torch.cuda.synchronize()
                        _BIREFNET_WARM_CACHE.add(warm_key)
                        # Keep model weights resident but release temporary
                        # autotune/inference workspaces while the app is idle.
                        if getattr(self._birefnet_device, "type", "") == "cuda":
                            torch.cuda.empty_cache()
                        self.logger.info(
                            "BiRefNet warmup completed (%s passes)",
                            passes,
                        )
                    except Exception as exc:
                        self.logger.warning("BiRefNet warmup skipped: %s", exc)
            self._birefnet_warm = True
            if self._birefnet_hybrid_enabled():
                self._warm_up_ben2()
                self.warm_up_human_rescue()
            return
        self._warm_up_ben2()

    def _warm_up_ben2(self) -> None:
        torch = self._import_torch()
        self._ensure_ben2_model(torch=torch)
        if self._ben2_warm:
            return
        if getattr(self._ben2_device, "type", "") != "cuda":
            self._ben2_warm = True
            return

        self._configure_torch_acceleration(torch)
        try:
            with _BEN2_INFERENCE_LOCK:
                with torch.inference_mode():
                    self._ben2_model.inference(Image.new("RGB", (64, 64), (8, 8, 8)), refine_foreground=False)
            self.logger.info("BEN2 CUDA warmup completed")
        except Exception as exc:
            self.logger.warning("BEN2 CUDA warmup skipped: %s", exc)
        self._ben2_warm = True

    def warm_up_human_rescue(self) -> None:
        try:
            import numpy as np
            import onnxruntime as ort

            model_path = self._u2net_human_model_path()
            if model_path is None:
                return
            session = self._u2net_human_session_for(model_path, ort)
            input_meta = session.get_inputs()[0]
            raw_size = input_meta.shape[2]
            input_size = int(raw_size) if isinstance(raw_size, int) and raw_size > 0 else 320
            session.run(
                None,
                {input_meta.name: np.zeros((1, 3, input_size, input_size), dtype=np.float32)},
            )
            self.logger.info("U2Net CUDA/CPU warmup completed")
        except Exception as exc:
            self.logger.warning("U2Net warmup skipped: %s", exc)

    def warm_up_black_hair_repair(self) -> None:
        try:
            if self._hair_repair_models() is not None:
                self.logger.info("MediaPipe hair + SAM2 warmup completed")
        except Exception as exc:
            self.logger.warning("Black hair repair warmup skipped: %s", exc)

    def _apply_u2net_human_rescue(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        protection_raw, antighost_raw = _mask_raw_values(self.settings)
        if _mask_uses_unified_slider(self.settings):
            trigger_raw = protection_raw
            amount = _mask_human_rescue_amount(protection_raw)
        else:
            trigger_raw = max(protection_raw, antighost_raw)
            antighost = _calibrated_mask_repair_amount(antighost_raw)
            protection = _calibrated_mask_repair_amount(protection_raw)
            amount = antighost if antighost > 0 else max(0, protection - 45) * 2

        if trigger_raw < _MASK_RESCUE_START:
            return rgba, False
        global_human_rescue = trigger_raw >= _MASK_ULTRA_CONSERVE_START
        amount = max(0, min(100, int(amount)))
        if amount <= 0:
            return rgba, False

        try:
            import cv2
            import numpy as np
            import onnxruntime as ort
        except Exception:
            if not self._u2net_human_warning:
                self.logger.warning("Rescate antifantasma desactivado: falta onnxruntime/cv2/numpy.")
                self._u2net_human_warning = True
            return rgba, False

        rescue_raw = self._shared_u2net_human_alpha
        if rescue_raw is None:
            model_path = self._u2net_human_model_path()
            if model_path is None:
                if not self._u2net_human_warning:
                    self.logger.warning("Rescate antifantasma desactivado: no se encontro u2net_human_seg.onnx.")
                    self._u2net_human_warning = True
                return rgba, False

            self._u2net_human_session_for(model_path, ort)

            input_meta = self._u2net_human_session.get_inputs()[0]
            input_size = int(input_meta.shape[2] or 320)
            resized = source.convert("RGB").resize((input_size, input_size), Image.Resampling.LANCZOS)
            arr = np.asarray(resized, dtype=np.float32) / 255.0
            arr = (arr - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array(
                [0.229, 0.224, 0.225],
                dtype=np.float32,
            )
            tensor = arr.transpose(2, 0, 1)[None, :, :, :]
            raw = self._u2net_human_session.run(None, {input_meta.name: tensor})[0][0, 0]
            raw = raw - raw.min()
            max_value = float(raw.max())
            if max_value <= 0:
                return rgba, False
            raw = (raw / max_value * 255.0).astype(np.uint8)
            rescue_raw = np.asarray(
                Image.fromarray(raw, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )
        else:
            rescue_raw = np.asarray(rescue_raw, dtype=np.uint8)
            if rescue_raw.shape != (rgba.height, rgba.width):
                rescue_raw = np.asarray(
                    Image.fromarray(rescue_raw, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                    dtype=np.uint8,
                )
        self._last_u2net_human_alpha = rescue_raw

        current = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(current > 0) and not global_human_rescue:
            return rgba, False

        strength = amount / 100.0
        threshold = int(round(145 - (82 * strength)))
        rescue_binary = (rescue_raw >= threshold).astype(np.uint8)
        if not np.any(rescue_binary):
            return rgba, False

        support = np.zeros_like(rescue_binary, dtype=np.uint8)
        primary_center = None
        if np.any(current > 0):
            seed_threshold = max(12, int(round(42 - (24 * strength))))
            seed = (current >= seed_threshold).astype(np.uint8)
            seed_count, seed_labels, seed_stats, _ = cv2.connectedComponentsWithStats(seed, 8)
            if seed_count > 1:
                seed_areas = seed_stats[1:, cv2.CC_STAT_AREA]
                main_seed_label = int(np.argmax(seed_areas)) + 1
                primary_seed = (seed_labels == main_seed_label).astype(np.uint8)
                primary_y, primary_x = np.nonzero(primary_seed)
                if primary_x.size > 0:
                    primary_center = (float(primary_x.mean()), float(primary_y.mean()))
                support_size = _odd_kernel(13 + int(round(30 * strength)))
                support = cv2.dilate(
                    primary_seed,
                    np.ones((support_size, support_size), np.uint8),
                    iterations=1,
                )
            elif not global_human_rescue:
                return rgba, False

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(rescue_binary, 8)
        keep = np.zeros_like(rescue_binary, dtype=np.uint8)
        min_area = max(180, int(rescue_binary.size * 0.000035))
        image_height, image_width = rescue_binary.shape[:2]
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_area:
                continue
            component = labels == label
            overlap = int(np.count_nonzero(support[component]))
            min_overlap = max(30, int(area * (0.035 + (0.025 * (1.0 - strength)))))
            component_width = int(stats[label, cv2.CC_STAT_WIDTH])
            component_height = int(stats[label, cv2.CC_STAT_HEIGHT])
            component_top = int(stats[label, cv2.CC_STAT_TOP])
            component_bottom = component_top + component_height
            component_left = int(stats[label, cv2.CC_STAT_LEFT])
            component_center_x = component_left + component_width * 0.5
            component_center_y = component_top + component_height * 0.5
            near_primary = primary_center is None
            if primary_center is not None:
                primary_center_x, primary_center_y = primary_center
                near_primary = (
                    abs(component_center_x - primary_center_x) <= image_width * 0.32
                    and abs(component_center_y - primary_center_y) <= image_height * 0.40
                )
            global_body_like = (
                global_human_rescue
                and near_primary
                and component_height >= max(24, int(image_height * 0.055))
                and component_width >= max(10, int(image_width * 0.012))
                and component_bottom >= image_height * 0.22
                and component_width <= component_height * 4.5
            )
            if overlap >= min_overlap or global_body_like:
                keep[component] = 1

        if not np.any(keep):
            return rgba, False

        rescue = rescue_raw.astype(np.float32)
        rescue = ((rescue - threshold) * (255.0 / max(1, 255 - threshold))).clip(0, 255)
        rescue *= keep
        rescue *= _mask_rescue_alpha_scale(trigger_raw)
        rescue = cv2.morphologyEx(
            rescue.astype(np.uint8),
            cv2.MORPH_CLOSE,
            np.ones((_odd_kernel(5 + int(round(8 * strength))),) * 2, np.uint8),
            iterations=1,
        )
        rescue = cv2.GaussianBlur(rescue, (_odd_kernel(3 + int(round(4 * strength))),) * 2, 0)
        rescued_alpha = np.maximum(current, rescue).astype(np.uint8)

        result = rgba.copy()
        result.putalpha(Image.fromarray(rescued_alpha, "L"))
        return result, True

    def _apply_ultra_group_human_rescue(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Give the explicit 100% repair mode a second, closer human reading.

        Whole-frame U2Net is only 320px square.  In a wide crowded group a
        narrow or partly occluded person can therefore remain low-confidence.
        The local pass improves that person's resolution.  Complete local
        components are accepted only when they overlap subject evidence from
        BEN2 or the whole-frame pass.  This keeps the normal 25% path untouched
        and prevents the crop from inventing an unrelated silhouette.
        """
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        outer = self._last_u2net_human_alpha
        if outer is None:
            return rgba, False
        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if outer.shape != alpha.shape:
            outer = np.asarray(
                Image.fromarray(outer, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )

        # Build the crop from meaningful U2Net components, including weak
        # people while ignoring tiny top/edge noise.
        candidate = (outer >= 48).astype(np.uint8)
        count, labels, stats, _ = cv2.connectedComponentsWithStats(candidate, 8)
        selected = np.zeros_like(candidate)
        image_height, image_width = candidate.shape
        min_area = max(180, int(candidate.size * 0.00004))
        for label in range(1, count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            height = int(stats[label, cv2.CC_STAT_HEIGHT])
            top = int(stats[label, cv2.CC_STAT_TOP])
            if area < min_area or height < image_height * 0.055:
                continue
            if top + height < image_height * 0.22:
                continue
            selected[labels == label] = 1
        ys, xs = np.nonzero(selected)
        if xs.size == 0:
            return rgba, False

        left = int(xs.min())
        top = int(ys.min())
        right = int(xs.max()) + 1
        bottom = int(ys.max()) + 1
        margin_x = max(20, int(round((right - left) * 0.04)))
        margin_y = max(20, int(round((bottom - top) * 0.06)))
        left = max(0, left - margin_x)
        top = max(0, top - margin_y)
        right = min(image_width, right + margin_x)
        bottom = min(image_height, bottom + margin_y)
        crop_area = (right - left) * (bottom - top)
        if crop_area <= 0 or crop_area >= candidate.size * 0.92:
            return rgba, False

        try:
            local = self._u2net_human_alpha(
                source.convert("RGB").crop((left, top, right, bottom))
            )
        except Exception as exc:
            self.logger.warning("Mask ultra group rescue skipped: %s", exc)
            return rgba, False
        crop_height = bottom - top
        crop_width = right - left
        if local.shape != (crop_height, crop_width):
            local = np.asarray(
                Image.fromarray(local, "L").resize(
                    (crop_width, crop_height),
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.uint8,
            )
        placed = np.zeros_like(alpha)
        placed[top:bottom, left:right] = local

        # Keep complete local human components only when they are firmly
        # anchored to subject alpha already accepted by BEN2 or whole-frame
        # U2Net.  This is deliberately more permissive than two-scale pixel
        # intersection: an occluded person's legs may be missing from the
        # 320px whole-frame reading even though the closer crop sees them.
        local_binary = (placed >= 96).astype(np.uint8)
        local_count, local_labels, local_stats, _ = cv2.connectedComponentsWithStats(
            local_binary,
            8,
        )
        anchor = (alpha >= 32) | (outer >= 48)
        confirmed = np.zeros_like(anchor, dtype=bool)
        local_min_area = max(180, int(alpha.size * 0.00004))
        for label in range(1, local_count):
            component = local_labels == label
            area = int(local_stats[label, cv2.CC_STAT_AREA])
            component_height = int(local_stats[label, cv2.CC_STAT_HEIGHT])
            overlap = int(np.count_nonzero(component & anchor))
            if area < local_min_area or component_height < image_height * 0.05:
                continue
            if overlap < max(60, int(area * 0.03)):
                continue
            confirmed[component] = True
        confirmed_count = int(np.count_nonzero(confirmed))
        if confirmed_count == 0:
            return rgba, False
        repaired = alpha.copy()
        repaired[confirmed] = np.maximum(repaired[confirmed], placed[confirmed])
        strong_local = confirmed & (placed >= 160)
        repaired[strong_local] = np.maximum(repaired[strong_local], 220)
        changed = repaired > alpha
        changed_count = int(np.count_nonzero(changed))
        if changed_count == 0:
            return rgba, False

        result = rgba.copy()
        result.putalpha(Image.fromarray(repaired, "L"))
        self.logger.info(
            "Mask ultra group rescue: crop=%s,%s-%s,%s confirmed=%s changed=%s",
            left,
            top,
            right,
            bottom,
            confirmed_count,
            changed_count,
        )
        return result, True

    def _cleanup_default_detached_artifacts(
        self,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Remove small detached side props that have no U2Net human support at 25%."""
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        human = self._last_u2net_human_alpha
        if human is None:
            return rgba, False
        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if human.shape != alpha.shape:
            human = np.asarray(
                Image.fromarray(human, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )

        visible = (alpha >= 32).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(visible, 8)
        if component_count <= 1:
            return rgba, False

        height, width = alpha.shape[:2]
        image_area = alpha.size
        cleaned = alpha.copy()
        removed_components = 0
        removed_pixels = 0
        for label in range(1, component_count):
            component = labels == label
            area = int(stats[label, cv2.CC_STAT_AREA])
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            w = int(stats[label, cv2.CC_STAT_WIDTH])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            human_touch = int(np.count_nonzero(component & (human >= 32)))
            if human_touch >= max(24, int(area * 0.008)):
                continue

            small = area <= max(600, int(image_area * 0.05))
            side_component = x + w <= width * 0.30 or x >= width * 0.70
            thin_component = w <= width * 0.12 or h <= height * 0.16
            if not small or not (side_component or thin_component):
                continue

            cleaned[component] = 0
            removed_components += 1
            removed_pixels += area

        if removed_components == 0:
            self.logger.info("Mask detached cleanup: removed_components=0")
            return rgba, False

        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.08)))
        self.logger.info(
            "Mask detached cleanup: removed_components=%s removed_pixels=%s",
            removed_components,
            removed_pixels,
        )
        return result, True

    def _cleanup_default_compact_floor_artifacts(
        self,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Remove compact floor props outside the 25% human silhouette.

        BEN2 sometimes joins a photocall wheel or similar round floor prop to a
        shoe.  U2Net is useful as a broad human envelope, but it can also absorb
        a small part of that prop.  Only compact, nearly round lower-image lobes
        that extend beyond a generously dilated human envelope are removed.
        """
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        human = self._last_u2net_human_alpha
        if human is None:
            return rgba, False
        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if human.shape != alpha.shape:
            human = np.asarray(
                Image.fromarray(human, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )

        height, width = alpha.shape[:2]
        short_side = min(height, width)
        human_binary = (human >= 32).astype(np.uint8)
        human_count, human_labels, human_stats, _ = cv2.connectedComponentsWithStats(
            human_binary,
            8,
        )
        human_main = np.zeros_like(human_binary)
        min_human_area = max(180, int(alpha.size * 0.001))
        for label in range(1, human_count):
            area = int(human_stats[label, cv2.CC_STAT_AREA])
            component_height = int(human_stats[label, cv2.CC_STAT_HEIGHT])
            if area >= min_human_area and component_height >= height * 0.10:
                human_main[human_labels == label] = 1
        if not np.any(human_main):
            return rgba, False

        guard_radius = max(5, int(round(short_side * 0.006)))
        guard_size = guard_radius * 2 + 1
        guard_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (guard_size, guard_size),
        )
        human_guard = cv2.dilate(human_main, guard_kernel, iterations=1).astype(bool)
        outside = ((alpha >= 32) & ~human_guard).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(outside, 8)

        removed = np.zeros_like(outside, dtype=bool)
        removed_components = 0
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            w = int(stats[label, cv2.CC_STAT_WIDTH])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            if w <= 0 or h <= 0:
                continue
            aspect = w / float(h)
            fill = area / float(w * h)
            lower_floor = y >= height * 0.65 and y + h >= height * 0.76
            compact = 0.55 <= aspect <= 1.65 and fill >= 0.45
            plausible_size = (
                area >= max(180, int(alpha.size * 0.00025))
                and area <= int(alpha.size * 0.02)
                and w >= short_side * 0.025
                and h >= short_side * 0.025
                and w <= short_side * 0.18
                and h <= short_side * 0.18
            )
            if not (lower_floor and compact and plausible_size):
                continue
            removed[labels == label] = True
            removed_components += 1

        removed_pixels = int(np.count_nonzero(removed))
        if removed_pixels == 0:
            self.logger.info("Mask compact floor cleanup: removed_components=0")
            return rgba, False

        cleaned = alpha.copy()
        cleaned[removed] = 0
        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.08)))
        self.logger.info(
            "Mask compact floor cleanup: removed_components=%s removed_pixels=%s guard=%spx",
            removed_components,
            removed_pixels,
            guard_radius,
        )
        return result, True

    def _refine_default_alpha_edge(
        self,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Pull only the supported outer 25% matte edge slightly inward."""
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        visible = (alpha >= 8).astype(np.uint8)
        if not np.any(visible):
            return rgba, False

        distance = cv2.distanceTransform(visible, cv2.DIST_L2, 5)
        thick_core = (distance >= 3.0).astype(np.uint8)
        if not np.any(thick_core):
            return rgba, False
        support_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
        thick_support = cv2.dilate(thick_core, support_kernel, iterations=1).astype(bool)
        outer_band = (distance > 0) & (distance <= 2.2) & thick_support
        if not np.any(outer_band):
            return rgba, False

        edge_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        inward = cv2.erode(alpha, edge_kernel, iterations=1)
        inward = cv2.GaussianBlur(inward, (0, 0), 0.55)
        blended = np.rint(alpha.astype(np.float32) * 0.30 + inward.astype(np.float32) * 0.70)
        refined = alpha.copy()
        refined[outer_band] = np.minimum(
            refined[outer_band],
            blended[outer_band].astype(np.uint8),
        )
        changed_pixels = int(np.count_nonzero(refined != alpha))
        if changed_pixels == 0:
            return rgba, False

        result = rgba.copy()
        result.putalpha(Image.fromarray(refined, "L"))
        self.logger.info(
            "Mask default edge refine: changed=%s band=2.2px blend=0.70",
            changed_pixels,
        )
        return result, True

    def _solidify_default_human_interiors(
        self,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Raise weak 25% alpha only inside a U2Net-supported human silhouette.

        This pass deliberately cannot grow the silhouette: a pixel must already
        have BEN2/U2Net alpha and must sit several pixels inside a high-confidence
        human region.  Keeping the boundary out of the operation prevents the
        body repair from making the visible contour harder.
        """
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        human = self._last_u2net_human_alpha
        if human is None:
            return rgba, False
        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if human.shape != alpha.shape:
            human = np.asarray(
                Image.fromarray(human, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )

        high_human = (human >= 220).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(
            high_human,
            8,
        )
        if component_count <= 1:
            return rgba, False

        strong_alpha = alpha >= 180
        selected = np.zeros_like(high_human, dtype=np.uint8)
        min_area = max(180, int(alpha.size * 0.000035))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_area:
                continue
            component = labels == label
            anchored = int(np.count_nonzero(component & strong_alpha))
            if anchored >= max(30, int(area * 0.025)):
                selected[component] = 1

        if not np.any(selected):
            return rgba, False

        # Distance is measured inside U2Net's high-confidence human region, not
        # only inside the final alpha. Requiring distance from both boundaries
        # lets a broad translucent torso be repaired while excluding hair,
        # clothing contours, and the antialiased edge.
        distance = cv2.distanceTransform(selected, cv2.DIST_L2, 5)
        visible_distance = cv2.distanceTransform((alpha >= 12).astype(np.uint8), cv2.DIST_L2, 5)
        edge_guard = max(2.0, min(4.0, min(alpha.shape[:2]) * 0.0015))
        interior = (
            (distance >= edge_guard)
            & (visible_distance >= edge_guard)
            & (alpha >= 12)
            & (alpha < 225)
            & (human >= 220)
        )
        changed_pixels = int(np.count_nonzero(interior))
        if changed_pixels == 0:
            self.logger.info("Mask human interior solidify: changed=0")
            return rgba, False

        repaired = alpha.copy()
        target = np.minimum(245, np.maximum(225, human)).astype(np.uint8)
        repaired[interior] = np.maximum(repaired[interior], target[interior])
        actually_changed = int(np.count_nonzero(repaired > alpha))
        if actually_changed == 0:
            return rgba, False

        result = rgba.copy()
        result.putalpha(Image.fromarray(repaired, "L"))
        self.logger.info(
            "Mask human interior solidify: changed=%s edge_guard=%.2fpx",
            actually_changed,
            edge_guard,
        )
        return result, True

    def _localized_default_human_rescue(
        self,
        source: Image.Image,
        before_rescue: Image.Image,
        rescued: Image.Image,
    ):
        """Re-run the full 25% cutout on a crowded human group BEN2 under-segmented."""
        if self._localized_human_rescue_active:
            return None

        try:
            import cv2
            import numpy as np
        except Exception:
            return None

        human_alpha = self._last_u2net_human_alpha
        if human_alpha is None:
            return None

        base = np.asarray(before_rescue.getchannel("A").convert("L"), dtype=np.uint8)
        alpha = np.asarray(rescued.getchannel("A").convert("L"), dtype=np.uint8)
        if human_alpha.shape != base.shape:
            human_alpha = np.asarray(
                Image.fromarray(human_alpha, "L").resize(
                    before_rescue.size,
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.uint8,
            )

        added = alpha > base
        base_support = (base >= 64).astype(np.uint8)
        human_binary = (human_alpha >= 134).astype(np.uint8)
        human_count, human_labels, human_stats, _ = cv2.connectedComponentsWithStats(
            human_binary,
            8,
        )
        anchored_human = np.zeros_like(added, dtype=bool)
        anchored_labels: set[int] = set()
        min_human_area = max(180, int(base.size * 0.000035))
        for label in range(1, human_count):
            area = int(human_stats[label, cv2.CC_STAT_AREA])
            if area < min_human_area:
                continue
            component = human_labels == label
            overlap = int(np.count_nonzero(component & (base_support > 0)))
            if overlap >= max(30, int(area * 0.035)):
                anchored_human[component] = True
                anchored_labels.add(label)

        high_confidence_added = (
            added
            & anchored_human
            & (human_alpha >= 220)
        ).astype(np.uint8)
        body_count, body_labels, body_stats, _ = cv2.connectedComponentsWithStats(
            high_confidence_added,
            8,
        )
        near_base = cv2.dilate(
            base_support,
            np.ones((11, 11), np.uint8),
            iterations=1,
        ) > 0
        image_height, image_width = base.shape
        min_body_area = max(600, int(base.size * 0.006))
        trusted_labels: set[int] = set()
        trigger_components = 0
        for label in range(1, body_count):
            area = int(body_stats[label, cv2.CC_STAT_AREA])
            width = int(body_stats[label, cv2.CC_STAT_WIDTH])
            height = int(body_stats[label, cv2.CC_STAT_HEIGHT])
            top = int(body_stats[label, cv2.CC_STAT_TOP])
            if area < min_body_area or height < image_height * 0.20:
                continue
            if width < height * 0.20 or top + height < image_height * 0.65:
                continue
            component = body_labels == label
            near_pixels = int(np.count_nonzero(component & near_base))
            if near_pixels < area * 0.20:
                continue
            labels_here, counts_here = np.unique(
                human_labels[component],
                return_counts=True,
            )
            valid = labels_here > 0
            if not np.any(valid):
                continue
            trusted_label = int(labels_here[valid][np.argmax(counts_here[valid])])
            trusted_labels.add(trusted_label)
            trigger_components += 1

        fallback_interior_only = False
        if not trusted_labels:
            # Whole-frame U2Net can recognize a head/upper body yet score a dark
            # torso poorly against a dark photocall.  A local BEN2 rerun has much
            # more subject resolution. Trigger it only when an already-anchored
            # human group contains a broad translucent interior; the later merge
            # normally stays inside alpha that already existed.  A later,
            # stricter two-scale U2Net agreement may also rebuild a missing
            # human interior, but never either model's outer silhouette.
            for label in anchored_labels:
                x = int(human_stats[label, cv2.CC_STAT_LEFT])
                y = int(human_stats[label, cv2.CC_STAT_TOP])
                w = int(human_stats[label, cv2.CC_STAT_WIDTH])
                h = int(human_stats[label, cv2.CC_STAT_HEIGHT])
                if h < image_height * 0.24 or w < image_width * 0.10:
                    continue
                roi = np.s_[y : y + h, x : x + w]
                weak_inside = (
                    (base[roi] >= 32)
                    & (base[roi] < 180)
                    & (human_alpha[roi] >= 60)
                )
                weak_pixels = int(np.count_nonzero(weak_inside))
                bbox_area = max(1, w * h)
                if weak_pixels < max(12000, int(bbox_area * 0.025)):
                    continue
                trusted_labels.add(label)
                fallback_interior_only = True
                self.logger.info(
                    "Mask localized human fallback: label=%s weak=%s bbox=%sx%s",
                    label,
                    weak_pixels,
                    w,
                    h,
                )
                break
        if not trusted_labels:
            return None

        trusted_human = np.isin(human_labels, list(trusted_labels))
        ys, xs = np.nonzero(trusted_human)
        if xs.size == 0:
            return None
        left = int(xs.min())
        top = int(ys.min())
        right = int(xs.max()) + 1
        bottom = int(ys.max()) + 1
        margin = max(24, int(round(min(right - left, bottom - top) * 0.04)))
        left = max(0, left - margin)
        top = max(0, top - margin)
        right = min(image_width, right + margin)
        bottom = min(image_height, bottom + margin)
        crop_area = (right - left) * (bottom - top)
        if crop_area >= base.size * 0.90:
            self.logger.info(
                "Mask localized human rescue skipped: crop covers %.1f%% of image",
                crop_area * 100.0 / base.size,
            )
            return None

        outer_human_alpha = self._last_u2net_human_alpha
        crop_human_alpha = None
        self._localized_human_rescue_active = True
        try:
            crop = source.convert("RGB").crop((left, top, right, bottom))
            crop_alpha_image, candidate_crop_human = self._localized_crop_predictions(crop)
            crop_alpha = np.asarray(crop_alpha_image.convert("L"), dtype=np.uint8)
            if candidate_crop_human is not None:
                crop_human_alpha = np.asarray(candidate_crop_human, dtype=np.uint8).copy()
        except Exception as exc:
            self.logger.warning("Mask localized human rescue failed: %s", exc)
            return None
        finally:
            self._localized_human_rescue_active = False
            self._last_u2net_human_alpha = outer_human_alpha

        placed = np.zeros_like(base)
        placed[top:bottom, left:right] = crop_alpha
        allowed = trusted_human & (human_alpha >= 134)
        stronger = (placed > base) & allowed
        dual_u2 = np.zeros_like(stronger, dtype=bool)
        dual_u2_value = np.zeros_like(base)
        if fallback_interior_only:
            stronger &= base >= 32
            placed_distance = cv2.distanceTransform(
                (placed >= 24).astype(np.uint8),
                cv2.DIST_L2,
                5,
            )
            base_distance = cv2.distanceTransform(
                (base >= 32).astype(np.uint8),
                cv2.DIST_L2,
                5,
            )
            interior_existing = (
                (placed > base)
                & (placed >= 200)
                & (base >= 32)
                & (placed_distance >= 3.0)
                & (base_distance >= 3.0)
            )
            stronger |= interior_existing
            if crop_human_alpha is not None:
                crop_height = bottom - top
                crop_width = right - left
                if crop_human_alpha.shape != (crop_height, crop_width):
                    crop_human_alpha = np.asarray(
                        Image.fromarray(crop_human_alpha, "L").resize(
                            (crop_width, crop_height),
                            Image.Resampling.LANCZOS,
                        ),
                        dtype=np.uint8,
                    )
                placed_crop_human = np.zeros_like(base)
                placed_crop_human[top:bottom, left:right] = crop_human_alpha
                outer_human_distance = cv2.distanceTransform(
                    (human_alpha >= 245).astype(np.uint8),
                    cv2.DIST_L2,
                    5,
                )
                crop_human_distance = cv2.distanceTransform(
                    (placed_crop_human >= 245).astype(np.uint8),
                    cv2.DIST_L2,
                    5,
                )
                # BEN2 can entirely omit a dark torso even though U2Net sees it.
                # Recover only the deep interior independently confirmed at two
                # scales and belonging to the already anchored human group.
                # The four-pixel inset leaves the existing antialiased outline
                # untouched and prevents the hard contour seen in earlier tries.
                dual_u2 = (
                    trusted_human
                    & (base < 32)
                    & (human_alpha >= 245)
                    & (placed_crop_human >= 245)
                    & (outer_human_distance >= 4.0)
                    & (crop_human_distance >= 4.0)
                )
                dual_u2_value = np.minimum(human_alpha, placed_crop_human)
                stronger |= dual_u2
        rescued_pixels = int(np.count_nonzero(stronger))
        if rescued_pixels == 0:
            return None

        localized = base.copy()
        localized[stronger] = placed[stronger]
        localized[dual_u2] = np.maximum(
            localized[dual_u2],
            dual_u2_value[dual_u2],
        )
        # A localized rerun can find a crowded person correctly yet leave their
        # interior translucent.  Harden only the high-confidence human core that
        # the localized BEN2 pipeline also retained; keeping the outer edge from
        # ``placed`` avoids expanding silhouettes or creating a U2Net halo.
        human_core = (
            trusted_human
            & (human_alpha >= 220)
            & (placed >= 64)
        )
        if fallback_interior_only:
            human_core &= (
                (base >= 32)
                & (placed_distance >= 3.0)
                & (base_distance >= 3.0)
            )
        localized[human_core] = np.maximum(
            localized[human_core],
            human_alpha[human_core],
        )
        hardened_pixels = int(np.count_nonzero(human_core & (localized > placed)))
        self.logger.info(
            "Mask localized human rescue: components=%s crop=%s,%s-%s,%s "
            "pixels=%s hardened=%s dual_u2=%s",
            trigger_components,
            left,
            top,
            right,
            bottom,
            rescued_pixels,
            hardened_pixels,
            int(np.count_nonzero(dual_u2)),
        )
        return localized

    def _localized_crop_predictions(self, crop: Image.Image):
        """Run only the two models needed by the localized human safety check."""
        rgba = self._remove_with_ben2(crop)
        human_alpha = self._u2net_human_alpha(crop)
        return rgba.getchannel("A"), human_alpha

    def _localized_upper_body_predictions(self, crop: Image.Image):
        """Read heads/upper bodies closer, tiling wide groups with overlap."""
        import numpy as np

        width, height = crop.size
        if width < 1 or height < 1:
            return None, None, 0

        tile_width = min(width, max(160, int(round(height * 1.25))))
        if tile_width >= width:
            starts = [0]
        else:
            stride = max(1, int(round(tile_width * 0.72)))
            starts = list(range(0, max(1, width - tile_width + 1), stride))
            final_start = width - tile_width
            if starts[-1] != final_start:
                starts.append(final_start)

        merged_alpha = np.zeros((height, width), dtype=np.uint8)
        merged_human = np.zeros((height, width), dtype=np.uint8)
        completed = 0
        for tile_left in starts:
            tile_right = min(width, tile_left + tile_width)
            tile = crop.crop((tile_left, 0, tile_right, height))
            alpha_image, human_alpha = self._localized_crop_predictions(tile)
            if human_alpha is None:
                continue
            tile_alpha = np.asarray(alpha_image.convert("L"), dtype=np.uint8)
            tile_human = np.asarray(human_alpha, dtype=np.uint8)
            tile_shape = (height, tile_right - tile_left)
            if tile_alpha.shape != tile_shape:
                tile_alpha = np.asarray(
                    Image.fromarray(tile_alpha, "L").resize(
                        (tile_shape[1], tile_shape[0]),
                        Image.Resampling.LANCZOS,
                    ),
                    dtype=np.uint8,
                )
            if tile_human.shape != tile_shape:
                tile_human = np.asarray(
                    Image.fromarray(tile_human, "L").resize(
                        (tile_shape[1], tile_shape[0]),
                        Image.Resampling.LANCZOS,
                    ),
                    dtype=np.uint8,
                )
            merged_alpha[:, tile_left:tile_right] = np.maximum(
                merged_alpha[:, tile_left:tile_right],
                tile_alpha,
            )
            merged_human[:, tile_left:tile_right] = np.maximum(
                merged_human[:, tile_left:tile_right],
                tile_human,
            )
            completed += 1

        if completed == 0:
            return None, None, 0
        return merged_alpha, merged_human, completed

    def _apply_default_black_hair_repair(
        self,
        source: Image.Image,
        ben2_alpha: Image.Image,
        rgba: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Add confirmed dark hair without ever reducing the current alpha.

        The hair proposal is derived from the original BEN2 alpha, independently
        from U2Net.  MediaPipe supplies semantic hair support and SAM2 supplies
        the object boundary.  Accepted hair can only be unioned into the final
        mask; it can never delete a pixel rescued by BEN2 or U2Net.
        """
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba, False

        current = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        ben2 = np.asarray(ben2_alpha.convert("L"), dtype=np.uint8)
        if ben2.shape != current.shape:
            ben2 = np.asarray(
                Image.fromarray(ben2, "L").resize(
                    rgba.size,
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.uint8,
            )
        try:
            prediction = self._default_black_hair_masks(
                source,
                np.zeros_like(ben2),
                ben2,
            )
        except Exception as exc:
            if not self._hair_repair_warning:
                self.logger.warning("Reparacion de pelo negro desactivada: %s", exc)
                self._hair_repair_warning = True
            return rgba, False
        if prediction is None:
            return rgba, False

        hair_probability, masks = prediction
        if not masks:
            return rgba, False
        confirmed_hair = np.zeros_like(current, dtype=bool)
        for mask in masks:
            confirmed_hair |= np.asarray(mask, dtype=bool)
        confirmed_hair &= hair_probability >= 0.08
        if not np.any(confirmed_hair):
            return rgba, False

        target = cv2.GaussianBlur(
            confirmed_hair.astype(np.uint8) * 255,
            (0, 0),
            sigmaX=0.8,
            sigmaY=0.8,
        )
        repaired = np.maximum(current, target)
        added_pixels = int(np.count_nonzero(repaired > current))
        if added_pixels == 0:
            return rgba, False
        result = rgba.copy()
        result.putalpha(Image.fromarray(repaired, "L"))
        self.logger.info(
            "Mask black hair repair: masks=%s added=%s removed=0 source=ben2_sam2",
            len(masks),
            added_pixels,
        )
        return result, True

    def _default_black_hair_masks(self, source: Image.Image, before, current):
        """Return only SAM2 masks that pass a strict semantic-hair gate."""
        try:
            import cv2
            import numpy as np
            import torch
        except Exception as exc:
            raise RuntimeError("faltan cv2/numpy/torch") from exc

        models = self._hair_repair_models()
        if models is None:
            return None
        mp, face_detector, hair_segmenter, predictor = models
        image = np.ascontiguousarray(
            np.asarray(source.convert("RGB"), dtype=np.uint8)
        ).copy()
        height, width = image.shape[:2]
        with _HAIR_REPAIR_INFERENCE_LOCK:
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=image)
            detections = face_detector.detect(mp_image).detections
            if not detections:
                return None
            hair_result = hair_segmenter.segment(mp_image)
            hair_small = np.asarray(
                hair_result.confidence_masks[1].numpy_view(),
                dtype=np.float32,
            )
            hair = cv2.resize(
                hair_small,
                (width, height),
                interpolation=cv2.INTER_CUBIC,
            )
            hair = np.clip(hair, 0.0, 1.0)
            hair_support = cv2.dilate(
                (hair >= 0.08).astype(np.uint8),
                cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (31, 31)),
                iterations=1,
            ) > 0

            added = (
                current.astype(np.int16)
                > before.astype(np.int16) + 16
            )
            luminance = (
                image[:, :, 0].astype(np.float32) * 0.299
                + image[:, :, 1].astype(np.float32) * 0.587
                + image[:, :, 2].astype(np.float32) * 0.114
            )
            plausible_faces: list[tuple[Any, list[tuple[int, int, int, int]]]] = []
            for detection in detections:
                face = detection.bounding_box
                x, y, face_width, face_height = (
                    int(face.origin_x),
                    int(face.origin_y),
                    int(face.width),
                    int(face.height),
                )
                if face_width < max(28, min(width, height) // 45):
                    continue
                boxes = [
                    (
                        max(0, int(x - 0.65 * face_width)),
                        max(0, int(y - 0.40 * face_height)),
                        min(width - 1, int(x + 0.95 * face_width)),
                        min(height - 1, int(y + 2.70 * face_height)),
                    ),
                    (
                        max(0, int(x + 0.05 * face_width)),
                        max(0, int(y - 0.40 * face_height)),
                        min(width - 1, int(x + 1.65 * face_width)),
                        min(height - 1, int(y + 2.70 * face_height)),
                    ),
                ]
                broad_left = max(0, int(x - 0.70 * face_width))
                broad_top = max(0, int(y - 0.45 * face_height))
                broad_right = min(width, int(x + 1.70 * face_width))
                broad_bottom = min(height, int(y + 2.75 * face_height))
                suspect = (
                    added[broad_top:broad_bottom, broad_left:broad_right]
                    & (
                        hair[broad_top:broad_bottom, broad_left:broad_right]
                        >= 0.08
                    )
                    & (
                        luminance[
                            broad_top:broad_bottom,
                            broad_left:broad_right,
                        ]
                        <= 145.0
                    )
                )
                suspect_count = int(np.count_nonzero(suspect))
                if suspect_count < max(120, int(face_width * face_height * 0.006)):
                    continue
                plausible_faces.append((detection, boxes))
            if not plausible_faces:
                return None

            with torch.inference_mode(), torch.autocast(
                "cuda",
                dtype=torch.bfloat16,
            ):
                predictor.set_image(image)
            accepted: list[Any] = []
            for detection, boxes in plausible_faces:
                face = detection.bounding_box
                x, y, face_width, face_height = (
                    int(face.origin_x),
                    int(face.origin_y),
                    int(face.width),
                    int(face.height),
                )
                core = (
                    int(x + 0.18 * face_width),
                    int(y + 0.22 * face_height),
                    int(x + 0.82 * face_width),
                    int(y + 0.90 * face_height),
                )
                crown = (
                    int(x - 0.15 * face_width),
                    int(y - 0.40 * face_height),
                    int(x + 1.15 * face_width),
                    int(y + 0.35 * face_height),
                )
                candidates = []
                for box in boxes:
                    with torch.inference_mode(), torch.autocast(
                        "cuda",
                        dtype=torch.bfloat16,
                    ):
                        masks, scores, _ = predictor.predict(
                            box=np.asarray(box, dtype=np.float32),
                            multimask_output=True,
                        )
                    for mask, sam_score in zip(masks, scores):
                        mask = np.asarray(mask, dtype=bool)
                        pixels = max(1, int(np.count_nonzero(mask)))
                        area_ratio = pixels / max(1.0, face_width * face_height)
                        core_overlap = _mask_box_overlap(mask, core)
                        crown_overlap = _mask_box_overlap(mask, crown)
                        hair_mean = float(hair[mask].mean())
                        hair_precision = (
                            np.count_nonzero(mask & hair_support) / pixels
                        )
                        hair_strong = (
                            np.count_nonzero(mask & (hair >= 0.22)) / pixels
                        )
                        if not (
                            float(sam_score) >= 0.62
                            and 0.25 <= area_ratio <= 2.0
                            and core_overlap <= 0.15
                            and crown_overlap >= 0.08
                            and hair_mean >= 0.20
                            and hair_precision >= 0.85
                            and hair_strong >= 0.30
                        ):
                            continue
                        rank = (
                            float(sam_score)
                            + hair_mean
                            + hair_precision
                            + hair_strong
                            - core_overlap * 2.0
                        )
                        candidates.append((rank, mask))
                if candidates:
                    accepted.append(max(candidates, key=lambda item: item[0])[1])
            return hair, accepted

    def _hair_repair_models(self):
        global _HAIR_REPAIR_MODEL_CACHE

        cached = _HAIR_REPAIR_MODEL_CACHE
        if cached is not None:
            return cached
        face_path, hair_path, sam_path = self._hair_repair_model_paths()
        if face_path is None or hair_path is None or sam_path is None:
            return None
        try:
            import mediapipe as mp
            import torch
            from mediapipe.tasks import python as mp_python
            from mediapipe.tasks.python import vision
            from sam2.build_sam import build_sam2
            from sam2.sam2_image_predictor import SAM2ImagePredictor
        except Exception as exc:
            raise RuntimeError("faltan mediapipe/sam2") from exc
        if not torch.cuda.is_available():
            raise RuntimeError("SAM2 requiere CUDA para esta reparacion")

        with _HAIR_REPAIR_MODEL_LOCK:
            cached = _HAIR_REPAIR_MODEL_CACHE
            if cached is not None:
                return cached
            face_options = vision.FaceDetectorOptions(
                base_options=mp_python.BaseOptions(
                    model_asset_path=str(face_path),
                ),
                running_mode=vision.RunningMode.IMAGE,
                min_detection_confidence=0.30,
                min_suppression_threshold=0.30,
            )
            hair_options = vision.ImageSegmenterOptions(
                base_options=mp_python.BaseOptions(
                    model_asset_path=str(hair_path),
                ),
                running_mode=vision.RunningMode.IMAGE,
                output_confidence_masks=True,
            )
            face_detector = vision.FaceDetector.create_from_options(face_options)
            hair_segmenter = vision.ImageSegmenter.create_from_options(hair_options)
            original_jit_script = torch.jit.script
            try:
                torch.jit.script = lambda value: value
                sam = build_sam2(
                    "configs/sam2.1/sam2.1_hiera_t.yaml",
                    str(sam_path),
                    device="cuda",
                )
                predictor = SAM2ImagePredictor(sam)
            finally:
                torch.jit.script = original_jit_script
            _HAIR_REPAIR_MODEL_CACHE = (
                mp,
                face_detector,
                hair_segmenter,
                predictor,
            )
            self.logger.info("MediaPipe hair + SAM2 CUDA activos.")
            return _HAIR_REPAIR_MODEL_CACHE

    @staticmethod
    def _hair_repair_model_paths() -> tuple[Path | None, Path | None, Path | None]:
        face = Path.cwd() / "models" / "MediaPipe" / "blaze_face_full_range.tflite"
        hair = Path.cwd() / "models" / "MediaPipe" / "selfie_multiclass_256x256.tflite"
        sam = Path.cwd() / "models" / "SAM2" / "sam2.1_hiera_tiny.pt"
        return (
            face if face.exists() else None,
            hair if hair.exists() else None,
            sam if sam.exists() else None,
        )

    def _cleanup_default_u2net_rescue(
        self,
        before_rescue: Image.Image,
        rescued: Image.Image,
    ) -> tuple[Image.Image, bool]:
        """Keep the 25% U2Net gain close to BEN2's already-supported subject."""
        try:
            import cv2
            import numpy as np
        except Exception:
            return rescued, False

        base = np.asarray(before_rescue.getchannel("A").convert("L"), dtype=np.uint8)
        alpha = np.asarray(rescued.getchannel("A").convert("L"), dtype=np.uint8)
        added = alpha > base
        added_count = int(np.count_nonzero(added))
        if added_count == 0:
            self.logger.info("Mask post-rescue cleanup: no U2Net alpha gain")
            return rescued, False

        # At the practical 25% default U2Net should mend nearby human detail, not
        # grow a new silhouette across photocall text, stands, cars, or scenery.
        # Distance is measured from BEN2's supported alpha, so BEN2 pixels are
        # never removed by this pass.
        base_support = (base >= 64).astype(np.uint8)
        if not np.any(base_support):
            return rescued, False

        background = (base_support == 0).astype(np.uint8)
        distance = cv2.distanceTransform(background, cv2.DIST_L2, 5)
        background_count, background_labels = cv2.connectedComponents(background, 8)
        enclosed_hole = np.zeros_like(background, dtype=bool)
        if background_count > 1:
            border_labels = np.unique(
                np.concatenate(
                    (
                        background_labels[0, :],
                        background_labels[-1, :],
                        background_labels[:, 0],
                        background_labels[:, -1],
                    )
                )
            )
            exterior = np.isin(background_labels, border_labels)
            enclosed_hole = (background > 0) & ~exterior
        support_above = np.maximum.accumulate(base_support, axis=0) > 0
        support_below = np.maximum.accumulate(base_support[::-1, :], axis=0)[::-1, :] > 0
        vertical_bridge = (background > 0) & support_above & support_below
        short_side = min(alpha.shape[:2])
        max_distance = max(2, min(4, int(round(short_side * 0.002))))

        # BEN2 may leave a real arm, face edge, hair, or clothing detail with
        # weak alpha. U2Net is allowed to strengthen that evidence anywhere.
        # Where BEN2 has no evidence at all, only a very small outward repair is
        # accepted; this prevents high-confidence photocall letters from growing
        # out of a head or shoulder merely because U2Net also likes them.
        weak_base_evidence = base >= 8
        close_to_subject = distance <= max_distance

        # A completely missing horizontal body section can be wider than the
        # normal edge allowance. Preserve broad bridges between supported alpha,
        # but reject tall/narrow bridges characteristic of letters, poles, and
        # other background structure.
        bridge_candidate = (
            added
            & vertical_bridge
            & ~weak_base_evidence
            & ~enclosed_hole
            & ~close_to_subject
        ).astype(np.uint8)
        bridge_keep = np.zeros_like(added, dtype=bool)
        bridge_component_count, bridge_labels, bridge_stats, _ = (
            cv2.connectedComponentsWithStats(bridge_candidate, 8)
        )
        min_bridge_area = max(12, int(alpha.size * 0.000004))
        bridge_components_kept = 0
        for label in range(1, bridge_component_count):
            area = int(bridge_stats[label, cv2.CC_STAT_AREA])
            width = int(bridge_stats[label, cv2.CC_STAT_WIDTH])
            height = int(bridge_stats[label, cv2.CC_STAT_HEIGHT])
            if area < min_bridge_area or width < height * 0.55:
                continue
            bridge_keep[bridge_labels == label] = True
            bridge_components_kept += 1

        keep_added = added & (
            weak_base_evidence
            | enclosed_hole
            | close_to_subject
            | bridge_keep
        )
        rejected = added & ~keep_added
        rejected_count = int(np.count_nonzero(rejected))
        if rejected_count == 0:
            self.logger.info(
                "Mask post-rescue cleanup: added=%s kept=%s removed=0 max_distance=%spx bridges=%s",
                added_count,
                added_count,
                max_distance,
                bridge_components_kept,
            )
            return rescued, False

        cleaned = alpha.copy()
        cleaned[rejected] = base[rejected]
        result = rescued.copy()
        result.putalpha(Image.fromarray(cleaned, "L"))
        self.logger.info(
            "Mask post-rescue cleanup: added=%s kept=%s removed=%s max_distance=%spx bridges=%s",
            added_count,
            added_count - rejected_count,
            rejected_count,
            max_distance,
            bridge_components_kept,
        )
        return result, True

    def _u2net_human_model_path(self) -> Path | None:
        candidates = [
            Path.cwd() / "models" / "u2net_human_seg.onnx",
            Path.home() / ".u2net" / "u2net_human_seg.onnx",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return None

    def _apply_mask_protection(
        self,
        rgba: Image.Image,
        run_antighost: bool = True,
    ) -> Image.Image:
        protection = _mask_protection_amount(self.settings)
        antighost = _mask_cleanup_amount(self.settings)
        if run_antighost and antighost > 0:
            rgba = self._apply_mask_antighost(rgba, amount=antighost, calibrated=True)
        if protection <= 0:
            return rgba

        alpha = rgba.getchannel("A")
        strength = protection / 100.0
        alpha = alpha.point(_alpha_boost_lut(strength))

        if protection >= 12:
            close_size = _mask_filter_size(protection)
            alpha = alpha.filter(ImageFilter.MaxFilter(close_size))
            alpha = alpha.filter(ImageFilter.MinFilter(close_size))
        if protection >= _MASK_EXTRA_PROTECTION_START:
            alpha = alpha.filter(ImageFilter.MaxFilter(_mask_filter_size(protection - 45)))

        blur = 0.05 + (0.65 * strength)
        if blur >= 0.5:
            alpha = alpha.filter(ImageFilter.GaussianBlur(blur))

        result = rgba.copy()
        result.putalpha(alpha)
        return result

    def _apply_mask_antighost(
        self,
        rgba: Image.Image,
        amount: int | None = None,
        calibrated: bool = False,
    ) -> Image.Image:
        if amount is None:
            amount = int(getattr(self.settings, "mask_antighost", 0) or 0)
        amount = (
            max(0, min(100, int(amount)))
            if calibrated
            else _calibrated_mask_repair_amount(amount)
        )
        if amount <= 0:
            return rgba

        try:
            import cv2
            import numpy as np
        except Exception:
            self.logger.warning("Antifantasma desactivado: faltan cv2/numpy.")
            return rgba

        arr = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(arr > 0):
            return rgba

        strength = amount / 100.0
        strong_threshold = max(72, int(round(154 - (62 * strength))))
        weak_threshold = max(10, int(round(24 - (8 * strength))))

        strong = (arr >= strong_threshold).astype(np.uint8) * 255
        weak = (arr >= weak_threshold).astype(np.uint8) * 255
        if not np.any(strong):
            return rgba

        support_size = _odd_kernel(7 + int(round(10 * (1.0 - strength))))
        support_seed = cv2.dilate(
            strong,
            np.ones((support_size, support_size), np.uint8),
            iterations=1,
        )
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(weak, 8)
        candidates = []
        repaired = np.zeros_like(arr, dtype=np.uint8)
        min_area = max(140, int(arr.size * (0.000025 + (0.00005 * strength))))
        for label in range(1, component_count):
            x = stats[label, cv2.CC_STAT_LEFT]
            y = stats[label, cv2.CC_STAT_TOP]
            w = stats[label, cv2.CC_STAT_WIDTH]
            h = stats[label, cv2.CC_STAT_HEIGHT]
            area = stats[label, cv2.CC_STAT_AREA]
            if area < min_area:
                continue
            component = labels == label
            strong_pixels = int(np.count_nonzero(strong[component]))
            supported_pixels = int(np.count_nonzero(support_seed[component]))
            min_supported = max(30, int(area * (0.08 + (0.06 * strength))))
            if strong_pixels > 0 or supported_pixels >= min_supported:
                candidates.append((label, area, x, y, w, h, strong_pixels))

        if not candidates:
            return rgba

        largest = max(candidates, key=lambda item: item[1])
        largest_label = largest[0]
        largest_area = largest[1]
        main_component = (labels == largest_label).astype(np.uint8) * 255
        main_support = cv2.dilate(
            main_component,
            np.ones((_odd_kernel(13 + int(round(18 * (1.0 - strength)))),) * 2, np.uint8),
            iterations=1,
        )
        min_height = max(18, int(round(arr.shape[0] * (0.025 + (0.012 * strength)))))
        min_relative_area = 0.008 + (0.030 * strength)
        for label, area, _x, y, _w, h, strong_pixels in candidates:
            component = labels == label
            bottom = y + h
            area_ok = area >= (largest_area * min_relative_area)
            height_ok = h >= min_height
            anchored = label == largest_label or (
                strong_pixels > 0 and area >= (largest_area * (0.12 - (0.04 * strength)))
            )
            main_overlap = int(np.count_nonzero(main_support[component]))
            near_main = main_overlap >= max(20, int(area * (0.045 + (0.065 * strength))))
            lower_ok = bottom >= (arr.shape[0] * 0.25) or area >= (largest_area * 0.10)
            if (label == largest_label or near_main or (anchored and area_ok)) and height_ok and lower_ok:
                repaired[component] = 255

        if not np.any(repaired):
            return rgba

        close_size = _odd_kernel(5 + int(round(10 * strength)))
        repaired = cv2.morphologyEx(
            repaired,
            cv2.MORPH_CLOSE,
            np.ones((close_size, close_size), np.uint8),
            iterations=1,
        )
        repaired = _fill_mask_holes(repaired, cv2, np)

        edge_support_size = _odd_kernel(3 + int(round(6 * strength)))
        support = cv2.dilate(
            repaired,
            np.ones((edge_support_size, edge_support_size), np.uint8),
            iterations=1,
        )
        edge_threshold = max(8, int(round(28 - (14 * strength))))
        fill_alpha = int(round(24 + (166 * (strength ** 0.55))))
        keep = (repaired > 0) | ((arr >= edge_threshold) & (support > 0))
        boosted = np.zeros_like(arr)
        boosted[keep] = arr[keep]
        repair = (repaired > 0) & (boosted < fill_alpha)
        boosted[repair] = fill_alpha

        result = rgba.copy()
        result.putalpha(Image.fromarray(boosted, "L").filter(ImageFilter.GaussianBlur(0.2)))
        return result

    def _solidify_translucent_subjects(self, rgba: Image.Image) -> Image.Image:
        raw_strength = _mask_conserve_slider_value(self.settings)
        if raw_strength < 20:
            return rgba

        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        strength = raw_strength / 100.0
        weak_threshold = max(5, int(round(32 - 18 * strength)))
        core_threshold = max(85, int(round(175 - 70 * strength)))
        weak = (alpha >= weak_threshold).astype(np.uint8)
        core = (alpha >= core_threshold).astype(np.uint8)
        if not np.any(weak) or not np.any(core):
            return rgba

        height, width = alpha.shape[:2]
        support_size = _odd_kernel(max(9, int(round(min(width, height) * (0.010 + 0.014 * strength)))))
        support_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (support_size, support_size))
        core_support = cv2.morphologyEx(core * 255, cv2.MORPH_CLOSE, support_kernel, iterations=1)
        core_support = cv2.dilate(core_support, support_kernel, iterations=1 + int(strength >= 0.65))

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(weak, 8)
        if component_count <= 1:
            return rgba

        selected = np.zeros_like(alpha, dtype=np.uint8)
        min_area = max(450, int(alpha.size * (0.00018 + 0.00012 * (1.0 - strength))))
        min_height = max(28, int(height * (0.035 + 0.020 * (1.0 - strength))))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_area:
                continue
            y = int(stats[label, cv2.CC_STAT_TOP])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            bottom = y + h
            if h < min_height and bottom < height * 0.75:
                continue
            component = labels == label
            core_pixels = int(np.count_nonzero(core[component]))
            support_pixels = int(np.count_nonzero(core_support[component]))
            core_ratio = core_pixels / max(1, area)
            body_like = h >= height * 0.10 and bottom >= height * 0.35
            support_ok = support_pixels >= max(20, int(area * (0.012 + 0.018 * (1.0 - strength))))
            if (
                core_pixels >= max(40, int(area * (0.008 + 0.010 * (1.0 - strength))))
                or (body_like and support_ok)
                or core_ratio >= 0.015
            ):
                selected[component] = 255

        if not np.any(selected):
            return rgba

        refine_size = _odd_kernel(5 + int(round(10 * strength)))
        refine_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (refine_size, refine_size))
        selected = cv2.morphologyEx(selected, cv2.MORPH_CLOSE, refine_kernel, iterations=1)
        selected = _fill_mask_holes(selected, cv2, np)

        distance = cv2.distanceTransform((selected > 0).astype(np.uint8), cv2.DIST_L2, 3)
        edge_width = 2.0 + 5.0 * strength
        interior = distance >= edge_width
        near_edge = (selected > 0) & ~interior

        target_interior = int(round(205 + 50 * strength))
        target_edge = int(round(125 + 60 * strength))
        mid_threshold = max(36, int(round(92 - 72 * strength)))
        target_mid = int(round(190 + 45 * strength))
        repaired = alpha.copy()
        interior_supported = interior & (alpha >= mid_threshold)
        repaired[interior_supported] = np.maximum(repaired[interior_supported], target_interior)
        supported_mid = (selected > 0) & (alpha >= mid_threshold)
        repaired[supported_mid] = np.maximum(repaired[supported_mid], target_mid)
        supported_edge = near_edge & (alpha >= max(weak_threshold, mid_threshold - 20))
        repaired[supported_edge] = np.maximum(repaired[supported_edge], target_edge)

        result = rgba.copy()
        result.putalpha(Image.fromarray(repaired, "L").filter(ImageFilter.GaussianBlur(0.12)))
        return result

    def _apply_negative_mask_edge_cut(
        self,
        rgba: Image.Image,
        raw_strength: int | float,
    ) -> Image.Image:
        if raw_strength >= 0:
            return rgba

        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        strength = _negative_mask_extra_aggression(raw_strength)
        if strength <= 0:
            return rgba

        # Fractional erosion makes -1/-5/-10 visibly progressive instead of
        # jumping only when the kernel size changes.
        erode_pixels = 9.0 * strength
        full_steps = int(erode_pixels)
        fraction = erode_pixels - full_steps
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        eroded = alpha.copy()
        for _ in range(full_steps):
            eroded = cv2.erode(eroded, kernel, iterations=1)
        if fraction > 0:
            next_eroded = cv2.erode(eroded, kernel, iterations=1)
            eroded = (
                eroded.astype(np.float32) * (1.0 - fraction)
                + next_eroded.astype(np.float32) * fraction
            ).clip(0, 255).astype(np.uint8)

        low_alpha_cutoff = int(round(8 + (38 * strength)))
        eroded[eroded < low_alpha_cutoff] = 0

        result = rgba.copy()
        result.putalpha(Image.fromarray(eroded, "L"))
        return result

    def _apply_quality_mask_repair(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> Image.Image | None:
        raw_strength = _mask_conserve_slider_value(self.settings)
        if raw_strength < _MASK_QUALITY_REPAIR_START:
            return None

        try:
            import cv2
            import numpy as np
        except Exception:
            return None

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        strength = raw_strength / 100.0
        selected_alpha = None
        try:
            u2_alpha = self._u2net_human_alpha(source)
        except Exception as exc:
            if not self._u2net_human_warning:
                self.logger.warning("Veto antifantasma U2Net desactivado: %s", exc)
                self._u2net_human_warning = True
            u2_alpha = None

        if u2_alpha is not None:
            candidate = self._combine_ben2_with_u2net_veto(alpha, u2_alpha, strength, cv2, np)
            raw_area = int(np.count_nonzero(alpha >= 20))
            candidate_area = int(np.count_nonzero(candidate >= 20))
            removed_ratio = (
                max(0, raw_area - candidate_area) / max(1, raw_area)
            )
            if removed_ratio <= 0.12 and candidate_area >= raw_area * 0.62:
                selected_alpha = candidate
                self.logger.info(
                    "Quality mask: U2Net veto accepted (removed %.1f%% of BEN2 area)",
                    removed_ratio * 100.0,
                )
            else:
                self.logger.info(
                    "Quality mask: U2Net veto skipped (removed %.1f%% of BEN2 area)",
                    removed_ratio * 100.0,
                )

        if selected_alpha is None:
            selected_alpha = self._alpha_curve_repair(alpha, strength, cv2, np)

        selected_alpha = self._restore_supported_weak_detail(alpha, selected_alpha, strength, cv2, np)

        result = rgba.copy()
        result.putalpha(Image.fromarray(selected_alpha, "L"))
        return result

    def _apply_zero_max_human_veto(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> Image.Image:
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        try:
            human = (
                self._shared_u2net_human_alpha
                if self._shared_u2net_human_alpha is not None
                else self._u2net_human_alpha(source)
            )
        except Exception as exc:
            if not self._u2net_human_warning:
                self.logger.warning("Veto humano 0%% desactivado: %s", exc)
                self._u2net_human_warning = True
            return rgba

        if human.shape != alpha.shape:
            human = np.asarray(
                Image.fromarray(human, "L").resize(rgba.size, Image.Resampling.LANCZOS),
                dtype=np.uint8,
            )

        raw_strength = _mask_conserve_slider_value(self.settings)
        extra_aggression = _negative_mask_extra_aggression(raw_strength)
        positive_relief = (
            max(0.0, min(1.0, raw_strength / _MASK_LOW_CONSERVE_VETO_END))
            if raw_strength > 0
            else 0.0
        )
        deep_aggression = min(
            1.0,
            max(
                0.0,
                (-raw_strength - abs(_MASK_DEEP_AGGRESSION_START))
                / abs(_MASK_SLIDER_MIN - _MASK_DEEP_AGGRESSION_START),
            ),
        )
        deep_curve = deep_aggression ** 3
        height, width = alpha.shape[:2]
        base_support_size = max(17, min(67, int(round(min(width, height) * 0.040))))
        support_scale = (
            1.0
            + (0.55 * positive_relief)
            - (0.78 * extra_aggression)
            - (0.22 * deep_curve)
        )
        support_size = _odd_kernel(max(3, int(round(base_support_size * support_scale))))
        human_threshold = int(
            round(
                34
                - (18 * positive_relief)
                + (94 * extra_aggression)
                + (50 * deep_curve)
            )
        )
        human_seed = (human >= human_threshold).astype(np.uint8)
        if not np.any(human_seed):
            return rgba

        if extra_aggression >= 0.70:
            erode_size = _odd_kernel(
                1
                + int(round(4 * ((extra_aggression - 0.70) / 0.30)))
                + int(round(8 * deep_curve))
            )
            if erode_size > 1:
                human_seed = cv2.erode(
                    human_seed,
                    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (erode_size, erode_size)),
                    iterations=1,
                )
                if not np.any(human_seed):
                    return rgba

        human_support = cv2.dilate(
            human_seed,
            np.ones((support_size, support_size), np.uint8),
            iterations=1,
        ) > 0

        cleaned = alpha.copy()
        far_from_human = ~human_support
        far_cutoff = int(round(248 - (116 * positive_relief) + (8 * extra_aggression)))
        if far_cutoff >= 256:
            cleaned[far_from_human] = 0
        else:
            cleaned[far_from_human & (cleaned < far_cutoff)] = 0

        binary = (cleaned >= 32).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        if component_count > 1:
            keep = np.zeros_like(binary, dtype=bool)
            for label in range(1, component_count):
                component = labels == label
                area = int(stats[label, cv2.CC_STAT_AREA])
                human_touch = int(np.count_nonzero(human_support[component]))
                strong_pixels = int(np.count_nonzero(component & (alpha >= 210)))
                human_ratio = max(0.006, 0.018 - (0.010 * positive_relief) + (0.18 * extra_aggression))
                human_ok = human_touch >= max(18, int(area * human_ratio))
                strong_ok = (
                    extra_aggression < 0.35
                    and strong_pixels >= max(16, int(area * (0.04 + 0.08 * extra_aggression)))
                )
                if human_ok or strong_ok:
                    keep[component] = True
            if np.any(keep):
                cleaned[~keep] = 0

        if extra_aggression >= 0.82 and np.any(cleaned > 0):
            edge_erosion = _odd_kernel(1 + int(round(4 * ((extra_aggression - 0.82) / 0.18))))
            if edge_erosion > 1:
                visible = (cleaned >= 24).astype(np.uint8) * 255
                visible = cv2.erode(
                    visible,
                    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (edge_erosion, edge_erosion)),
                    iterations=1,
                )
                cleaned[visible == 0] = 0

        if deep_curve > 0 and np.any(cleaned > 0):
            visible = (cleaned >= 24).astype(np.uint8)
            distance = cv2.distanceTransform(visible, cv2.DIST_L2, 5)
            erosion_pixels = max(0.5, min(width, height) * 0.040 * deep_curve)
            cleaned[distance <= erosion_pixels] = 0

        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.10)))
        return result

    def _apply_structural_mask_cleanup(
        self,
        source: Image.Image,
        rgba: Image.Image,
    ) -> Image.Image:
        raw_strength = _mask_conserve_slider_value(self.settings)
        if raw_strength >= _MASK_QUALITY_REPAIR_START:
            return rgba

        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        try:
            grabcut_start = time.perf_counter()
            cleaned = self._grabcut_structural_alpha(source, alpha, raw_strength, cv2, np)
            grabcut_seconds = time.perf_counter() - grabcut_start
        except Exception as exc:
            self.logger.info("Limpieza estructural de mascara omitida: %s", exc)
            return rgba

        if cleaned is None:
            return rgba

        artifacts_start = time.perf_counter()
        aggression = _structural_cleanup_aggression(raw_strength)
        cleaned = self._remove_long_thin_mask_artifacts(cleaned, aggression, cv2, np)
        artifacts_seconds = time.perf_counter() - artifacts_start
        if self.logger.isEnabledFor(logging.INFO):
            self.logger.info(
                "Mask structural cleanup timing: raw=%s size=%sx%s grabcut=%.3fs artifacts=%.3fs",
                raw_strength,
                rgba.size[0],
                rgba.size[1],
                grabcut_seconds,
                artifacts_seconds,
            )
        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.12)))
        return result

    def _grabcut_structural_alpha(self, source: Image.Image, alpha, raw_strength: int, cv2, np):
        height, width = alpha.shape[:2]
        work_width = width
        work_height = height
        alpha_work = alpha
        longest = max(width, height)
        if longest > _STRUCTURAL_GRABCUT_MAX_SIDE:
            scale = _STRUCTURAL_GRABCUT_MAX_SIDE / longest
            work_width = max(1, int(round(width * scale)))
            work_height = max(1, int(round(height * scale)))
            alpha_work = np.asarray(
                Image.fromarray(alpha, "L").resize(
                    (work_width, work_height),
                    Image.Resampling.BILINEAR,
                ),
                dtype=np.uint8,
            )

        rgb_image = source.convert("RGB")
        if rgb_image.size != (work_width, work_height):
            rgb_image = rgb_image.resize((work_width, work_height), Image.Resampling.LANCZOS)
        rgb = np.asarray(rgb_image, dtype=np.uint8)

        aggression = _structural_cleanup_aggression(raw_strength)
        maybe_threshold = int(round(26 + (22 * aggression)))
        foreground_threshold = int(round(192 + (33 * aggression)))
        maybe_threshold = max(8, min(96, maybe_threshold))
        foreground_threshold = max(maybe_threshold + 12, min(245, foreground_threshold))

        mask = np.full(alpha_work.shape, cv2.GC_BGD, dtype=np.uint8)
        mask[alpha_work >= max(2, maybe_threshold // 2)] = cv2.GC_PR_BGD
        mask[alpha_work >= maybe_threshold] = cv2.GC_PR_FGD
        mask[alpha_work >= foreground_threshold] = cv2.GC_FGD

        if not np.any(mask == cv2.GC_FGD) or not np.any(mask == cv2.GC_BGD):
            return None

        background_model = np.zeros((1, 65), np.float64)
        foreground_model = np.zeros((1, 65), np.float64)
        iterations = 2 + int(raw_strength <= 25)
        cv2.grabCut(
            rgb,
            mask,
            None,
            background_model,
            foreground_model,
            iterations,
            cv2.GC_INIT_WITH_MASK,
        )
        keep = (mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD)
        if not np.any(keep):
            return None

        if alpha_work.shape != alpha.shape:
            keep = cv2.dilate(
                keep.astype(np.uint8),
                np.ones((3, 3), np.uint8),
                iterations=1,
            ).astype(bool)
            keep = np.asarray(
                Image.fromarray(keep.astype(np.uint8) * 255, "L").resize(
                    (width, height),
                    Image.Resampling.NEAREST,
                ),
                dtype=np.uint8,
            ) > 0

        cleaned = np.where(keep, alpha, 0).astype(np.uint8)
        original_area = int(np.count_nonzero(alpha >= max(16, maybe_threshold // 2)))
        cleaned_area = int(np.count_nonzero(cleaned >= max(16, maybe_threshold // 2)))
        if original_area <= 0 or cleaned_area < original_area * 0.42:
            return None
        return cleaned

    def _remove_long_thin_mask_artifacts(self, alpha, aggression: float, cv2, np):
        binary = (alpha >= 16).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        if component_count <= 1:
            return alpha

        height, width = alpha.shape[:2]
        cleaned = alpha.copy()
        horizontal_width = max(95, int(round(width * (0.065 + (0.035 * aggression)))))
        horizontal_kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT,
            (_odd_kernel(horizontal_width), 3),
        )
        horizontal = cv2.morphologyEx(binary * 255, cv2.MORPH_OPEN, horizontal_kernel, iterations=1)
        if np.any(horizontal):
            body_size = _odd_kernel(max(23, int(round(min(width, height) * 0.038))))
            body_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (body_size, body_size))
            body_core = cv2.erode(binary * 255, body_kernel, iterations=1)
            body_protect = cv2.dilate(body_core, body_kernel, iterations=2)
            lower_rows = np.zeros_like(binary, dtype=np.uint8)
            lower_rows[int(height * 0.38) :, :] = 255
            side_cols = np.zeros_like(binary, dtype=np.uint8)
            side_margin = int(round(width * 0.08))
            side_cols[:, :side_margin] = 255
            side_cols[:, width - side_margin :] = 255
            remove_horizontal = (horizontal > 0) & (body_protect == 0) & (
                (lower_rows > 0) | (side_cols > 0)
            )
            if np.any(remove_horizontal):
                remove_horizontal = cv2.dilate(
                    remove_horizontal.astype(np.uint8) * 255,
                    np.ones((9, 9), np.uint8),
                    iterations=1,
                )
                cleaned[remove_horizontal > 0] = 0

        min_area = max(250, int(alpha.size * 0.000025))
        max_thin_height = height * (0.075 + (0.015 * (1.0 - aggression)))
        min_aspect = 4.8 - (1.1 * aggression)
        for label in range(1, component_count):
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            w = int(stats[label, cv2.CC_STAT_WIDTH])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_area or h <= 0:
                continue
            aspect = w / max(1, h)
            touches_side = x <= width * 0.025 or (x + w) >= width * 0.975
            lower_band = y >= height * 0.40
            long_thin = aspect >= min_aspect and h <= max_thin_height
            if long_thin and (touches_side or lower_band):
                cleaned[labels == label] = 0

        return cleaned

    def _u2net_human_alpha(self, source: Image.Image):
        try:
            import numpy as np
            import onnxruntime as ort
        except Exception as exc:
            raise RuntimeError("faltan onnxruntime/numpy") from exc

        model_path = self._u2net_human_model_path()
        if model_path is None:
            raise RuntimeError("no se encontro u2net_human_seg.onnx")

        self._u2net_human_session_for(model_path, ort)

        input_meta = self._u2net_human_session.get_inputs()[0]
        input_size = int(input_meta.shape[2] or 320)
        resized = source.convert("RGB").resize((input_size, input_size), Image.Resampling.LANCZOS)
        arr = np.asarray(resized, dtype=np.float32) / 255.0
        arr = (arr - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array(
            [0.229, 0.224, 0.225],
            dtype=np.float32,
        )
        raw = self._u2net_human_session.run(
            None,
            {input_meta.name: arr.transpose(2, 0, 1)[None, :, :, :]},
        )[0][0, 0]
        raw = raw - raw.min()
        max_value = float(raw.max())
        if max_value <= 0:
            raise RuntimeError("U2Net devolvio mascara vacia")
        raw = (raw / max_value * 255.0).astype(np.uint8)
        return np.asarray(
            Image.fromarray(raw, "L").resize(source.size, Image.Resampling.LANCZOS),
            dtype=np.uint8,
        )

    def _cuda_is_available(self, torch_module=None) -> bool:
        try:
            torch_module = torch_module or self._import_torch()
            return bool(torch_module.cuda.is_available())
        except Exception:
            return False

    def _warn_cpu_processing(self) -> None:
        if not self._cpu_processing_warned:
            self._cpu_processing_warned = True
            self.logger.warning(
                "CPU_PROCESSING_NOTICE: No hay aceleracion CUDA disponible. "
                "Se procesara mediante CPU y puede tardar bastante mas."
            )

    def _u2net_human_session_for(self, model_path: Path, ort):
        if self._u2net_human_session is not None:
            return self._u2net_human_session

        cache_key = str(model_path.resolve()).casefold()
        cached = _U2NET_SESSION_CACHE.get(cache_key)
        if cached is not None:
            self._u2net_human_session, self._u2net_human_provider = cached
            return self._u2net_human_session

        with _U2NET_SESSION_LOCK:
            if self._u2net_human_session is not None:
                return self._u2net_human_session
            cached = _U2NET_SESSION_CACHE.get(cache_key)
            if cached is not None:
                self._u2net_human_session, self._u2net_human_provider = cached
                return self._u2net_human_session

            available = set(ort.get_available_providers())
            cuda_available = self._cuda_is_available()
            if not cuda_available:
                self._warn_cpu_processing()
            if "CUDAExecutionProvider" in available and cuda_available:
                try:
                    preload = getattr(ort, "preload_dlls", None)
                    if callable(preload):
                        preload()
                    session = ort.InferenceSession(
                        str(model_path),
                        providers=["CUDAExecutionProvider", "CPUExecutionProvider"],
                    )
                    if "CUDAExecutionProvider" not in set(session.get_providers()):
                        raise RuntimeError("CUDAExecutionProvider no quedo activo")
                    self._u2net_human_session = session
                    self._u2net_human_provider = "CUDAExecutionProvider"
                    _U2NET_SESSION_CACHE[cache_key] = (session, self._u2net_human_provider)
                    self.logger.info("U2Net ONNX activo en GPU CUDA.")
                    return session
                except Exception as exc:
                    self.logger.warning(
                        "U2Net no pudo iniciar CUDA; se usara CPU: %s",
                        exc,
                    )

            session = ort.InferenceSession(
                str(model_path),
                providers=["CPUExecutionProvider"],
            )
            self._u2net_human_session = session
            self._u2net_human_provider = "CPUExecutionProvider"
            _U2NET_SESSION_CACHE[cache_key] = (session, self._u2net_human_provider)
            self.logger.info("U2Net ONNX activo en CPU.")
            return session

    def _combine_ben2_with_u2net_veto(self, alpha, u2_alpha, strength: float, cv2, np):
        threshold = int(round(148 + (30 * strength)))
        repaired = alpha.copy()
        original = alpha.copy()

        repaired[(original < 232) & (u2_alpha < threshold)] = 0
        repaired[(original < 205) & (u2_alpha < threshold + 18)] = 0

        strong_u2 = (u2_alpha >= threshold + 45) & (original >= 8)
        repaired[strong_u2] = np.maximum(repaired[strong_u2], 230)
        supported_u2 = (u2_alpha >= threshold + 18) & (original >= 18)
        repaired[supported_u2] = np.maximum(repaired[supported_u2], 190)
        repaired[original >= 235] = 255

        repaired = cv2.morphologyEx(
            repaired,
            cv2.MORPH_OPEN,
            np.ones((3, 3), np.uint8),
            iterations=1,
        )
        return cv2.GaussianBlur(repaired, (3, 3), 0)

    def _alpha_curve_repair(self, alpha, strength: float, cv2, np):
        low = int(round(40 - (22 * strength)))
        full = int(round(180 - (42 * strength)))
        repaired = np.zeros_like(alpha, dtype=np.float32)
        keep = alpha > low
        repaired[keep] = (alpha[keep].astype(np.float32) - low) * (
            255.0 / max(1, full - low)
        )
        repaired[alpha >= full] = 255.0
        repaired = np.clip(repaired, 0, 255).astype(np.uint8)
        repaired = cv2.morphologyEx(
            repaired,
            cv2.MORPH_OPEN,
            np.ones((3, 3), np.uint8),
            iterations=1,
        )
        return cv2.GaussianBlur(repaired, (3, 3), 0)

    def _restore_supported_weak_detail(self, raw_alpha, repaired_alpha, strength: float, cv2, np):
        if strength < 0.70:
            return repaired_alpha

        weak_threshold = max(5, int(round(24 - (15 * strength))))
        raw_weak = (raw_alpha >= weak_threshold).astype(np.uint8)
        repaired_core = (repaired_alpha >= max(112, int(round(160 - 42 * strength)))).astype(np.uint8)
        if not np.any(raw_weak) or not np.any(repaired_core):
            return repaired_alpha

        height, width = raw_alpha.shape[:2]
        support_size = _odd_kernel(max(13, int(round(min(width, height) * (0.012 + 0.014 * strength)))))
        support_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (support_size, support_size))
        support = cv2.dilate(repaired_core, support_kernel, iterations=1)

        candidate = ((raw_weak > 0) & (repaired_alpha < 96)).astype(np.uint8)
        if not np.any(candidate):
            return repaired_alpha

        bridge_size = _odd_kernel(max(3, int(round(min(width, height) * (0.0025 + 0.0025 * strength)))))
        bridge_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (bridge_size, bridge_size))
        candidate = cv2.morphologyEx(candidate * 255, cv2.MORPH_CLOSE, bridge_kernel, iterations=1)

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats((candidate > 0).astype(np.uint8), 8)
        if component_count <= 1:
            return repaired_alpha

        keep = np.zeros_like(raw_alpha, dtype=np.uint8)
        min_area = max(70, int(raw_alpha.size * 0.000012))
        support_edge = cv2.dilate(repaired_core, np.ones((5, 5), np.uint8), iterations=1)
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_area:
                continue
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            w = int(stats[label, cv2.CC_STAT_WIDTH])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            if w <= 1 or h <= 1:
                continue
            component = labels == label
            max_alpha = int(raw_alpha[component].max())
            if max_alpha < weak_threshold + 4:
                continue
            edge_touch = int(np.count_nonzero(support_edge[component]))
            close_touch = int(np.count_nonzero(support[component]))
            if edge_touch < max(4, int(area * 0.01)) and close_touch < max(18, int(area * 0.10)):
                continue
            if area < min_area * 2 and max(w, h) < max(12, int(min(width, height) * 0.006)):
                continue
            if y + h < height * 0.18:
                continue
            keep[component] = 255

        if not np.any(keep):
            return repaired_alpha

        close_size = _odd_kernel(max(3, int(round(min(width, height) * 0.0035))))
        close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_size, close_size))
        keep = cv2.morphologyEx(keep, cv2.MORPH_CLOSE, close_kernel, iterations=1)
        keep = _fill_mask_holes(keep, cv2, np)

        fill_alpha = int(round(182 + 58 * min(1.0, strength)))
        restored = repaired_alpha.copy()
        restored[keep > 0] = np.maximum(restored[keep > 0], fill_alpha)
        return cv2.GaussianBlur(restored, (3, 3), 0)

    def _trim_soft_edge_noise(self, rgba: Image.Image) -> Image.Image:
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        raw_strength = _mask_conserve_slider_value(self.settings)
        max_cleanup = raw_strength <= 0
        core_threshold = 150 if max_cleanup else 135
        noise_threshold = 118 if max_cleanup else 80
        component_threshold = 64 if max_cleanup else 32
        support_size = 5 if max_cleanup else 9

        core = alpha >= core_threshold
        if not np.any(core):
            return rgba

        support = cv2.dilate(
            core.astype(np.uint8),
            np.ones((support_size, support_size), np.uint8),
            iterations=1,
        ).astype(bool)
        cleaned = alpha.copy()
        cleaned[(cleaned < noise_threshold) & ~support] = 0

        binary = (cleaned >= component_threshold).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(binary, 8)
        if component_count <= 1:
            return rgba

        keep = np.zeros_like(binary, dtype=bool)
        min_area = max(80, int(binary.size * 0.00002))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            component = labels == label
            core_pixels = int(np.count_nonzero(core[component]))
            if max_cleanup:
                if core_pixels >= max(8, int(area * 0.006)):
                    keep[component] = True
            elif core_pixels > 0 or area >= min_area * 8:
                keep[component] = True

        if not np.any(keep):
            return rgba

        cleaned[~keep] = 0
        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.15)))
        return result

    def _remove_ultra_conservative_artifacts(self, rgba: Image.Image) -> Image.Image:
        try:
            import cv2
            import numpy as np
        except Exception:
            return rgba

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        height, width = alpha.shape[:2]
        visible = (alpha >= 18).astype(np.uint8)
        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(visible, 8)
        if component_count <= 1:
            return rgba

        largest_area = int(max(stats[1:, cv2.CC_STAT_AREA]))
        keep = np.zeros_like(visible, dtype=bool)
        min_keep_area = max(90, int(alpha.size * 0.000035))
        for label in range(1, component_count):
            x = int(stats[label, cv2.CC_STAT_LEFT])
            y = int(stats[label, cv2.CC_STAT_TOP])
            w = int(stats[label, cv2.CC_STAT_WIDTH])
            h = int(stats[label, cv2.CC_STAT_HEIGHT])
            area = int(stats[label, cv2.CC_STAT_AREA])
            bottom = y + h
            component = labels == label
            max_alpha = int(alpha[component].max())
            strong_pixels = int(np.count_nonzero(component & (alpha >= 165)))
            touches_side = x <= width * 0.018 or (x + w) >= width * 0.982
            touches_top = y <= height * 0.035
            thin_line = max(w, h) / max(1, min(w, h)) >= 8.0 and area < largest_area * 0.08
            upper_small = bottom < height * 0.38 and area < largest_area * 0.18
            border_artifact = (touches_side or touches_top) and area < largest_area * 0.30

            if area < min_keep_area:
                continue
            if thin_line or upper_small or border_artifact:
                continue
            if max_alpha >= 230 or strong_pixels >= max(18, int(area * 0.018)) or area >= largest_area * 0.16:
                keep[component] = True

        if not np.any(keep):
            return rgba

        cleaned = alpha.copy()
        cleaned[~keep] = 0
        result = rgba.copy()
        result.putalpha(Image.fromarray(cleaned, "L").filter(ImageFilter.GaussianBlur(0.08)))
        return result

    def _antialias_alpha_edges(self, rgba: Image.Image) -> Image.Image:
        try:
            import cv2
            import numpy as np
        except Exception:
            result = rgba.copy()
            result.putalpha(rgba.getchannel("A").filter(ImageFilter.GaussianBlur(0.55)))
            return result

        alpha = np.asarray(rgba.getchannel("A").convert("L"), dtype=np.uint8)
        if not np.any(alpha > 0):
            return rgba

        visible = (alpha >= 8).astype(np.uint8)
        solid = (alpha >= 236).astype(np.uint8)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        default_split_edge = _mask_conserve_slider_value(self.settings) == _MASK_RESCUE_START
        outer = (
            visible.astype(bool)
            if default_split_edge
            else cv2.dilate(visible, kernel, iterations=2).astype(bool)
        )
        inner = cv2.erode(solid, kernel, iterations=1).astype(bool)
        edge_band = outer & ~inner
        if not np.any(edge_band):
            return rgba

        blur_sigma = 0.58 if default_split_edge else 0.85
        blurred = cv2.GaussianBlur(alpha, (0, 0), blur_sigma)
        antialiased = alpha.copy()
        antialiased[edge_band] = blurred[edge_band]
        antialiased[inner] = np.maximum(antialiased[inner], alpha[inner])
        antialiased[~outer] = 0

        result = rgba.copy()
        result.putalpha(Image.fromarray(antialiased, "L"))
        return result

    def _filter_confident_subject_alpha(self, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        weak_threshold = max(10, int(round(34 - (14 * strength))))
        core_threshold = max(95, int(round(168 - (58 * strength))))
        weak = (alpha >= weak_threshold).astype(np.uint8)
        core = (alpha >= core_threshold).astype(np.uint8) * 255
        if not np.any(weak) or not np.any(core):
            return alpha

        bridge_size = _odd_kernel(max(7, int(round(min(width, height) * (0.008 + (0.004 * strength))))))
        bridge_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (bridge_size, bridge_size))
        core = cv2.morphologyEx(core, cv2.MORPH_CLOSE, bridge_kernel, iterations=1)
        core = cv2.dilate(core, bridge_kernel, iterations=1)

        component_count, labels, stats, _centroids = cv2.connectedComponentsWithStats(weak, 8)
        if component_count <= 2:
            return alpha

        original_area = int(np.count_nonzero(weak))
        filtered = np.zeros_like(alpha, dtype=np.uint8)
        min_component = max(90, int(alpha.size * 0.00005))
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < min_component:
                continue
            y = int(stats[label, cv2.CC_STAT_TOP])
            comp_height = int(stats[label, cv2.CC_STAT_HEIGHT])
            bottom = y + comp_height
            component = labels == label
            core_pixels = int(np.count_nonzero(component & (core > 0)))
            max_alpha = int(alpha[component].max()) if area else 0
            tall_body = comp_height >= height * 0.20 and bottom >= height * 0.40
            anchored = core_pixels >= max(32, int(area * (0.005 + (0.006 * (1.0 - strength)))))
            if anchored or max_alpha >= 235 or (tall_body and core_pixels >= 10):
                filtered[component] = alpha[component]

        kept_area = int(np.count_nonzero(filtered >= weak_threshold))
        if kept_area < original_area * 0.45:
            return alpha
        return filtered

    def _filter_face_supported_alpha(self, rgba: Image.Image, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        cascade_path = Path(cv2.data.haarcascades) / "haarcascade_frontalface_default.xml"
        cascade = cv2.CascadeClassifier(str(cascade_path))
        if cascade.empty():
            return alpha

        gray = cv2.cvtColor(np.asarray(rgba.convert("RGB")), cv2.COLOR_RGB2GRAY)
        gray = cv2.equalizeHist(gray)
        min_face = max(18, min(width, height) // 90)
        faces = cascade.detectMultiScale(
            gray,
            scaleFactor=1.08,
            minNeighbors=4,
            minSize=(min_face, min_face),
        )
        if len(faces) == 0:
            return alpha

        faces = [(int(x), int(y), int(w), int(h)) for x, y, w, h in faces]
        median_face_area = float(np.median([w * h for _x, _y, w, h in faces]))
        faces = [face for face in faces if face[2] * face[3] >= median_face_area * 0.25]
        if not faces:
            return alpha

        support = np.zeros_like(alpha, dtype=np.uint8)
        for x, y, w, h in faces:
            cx = x + w // 2
            body_w = int(w * (4.6 + (2.0 * strength)))
            body_h = int(h * (9.0 + (3.0 * strength)))
            top = max(0, y - int(h * 0.8))
            left = max(0, cx - body_w // 2)
            right = min(width, cx + body_w // 2)
            bottom = min(height, y + body_h)
            cv2.rectangle(support, (left, top), (right, bottom), 255, -1)

            shoulder_w = int(w * (6.5 + (2.0 * strength)))
            shoulder_h = int(h * (1.8 + (0.5 * strength)))
            shoulder_top = max(0, y + int(h * 1.1))
            shoulder_left = max(0, cx - shoulder_w // 2)
            shoulder_right = min(width, cx + shoulder_w // 2)
            shoulder_bottom = min(height, shoulder_top + shoulder_h)
            cv2.rectangle(
                support,
                (shoulder_left, shoulder_top),
                (shoulder_right, shoulder_bottom),
                255,
                -1,
            )

        close_size = _odd_kernel(max(35, int(min(width, height) * (0.035 + (0.025 * strength)))))
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (close_size, close_size))
        support = cv2.morphologyEx(support, cv2.MORPH_CLOSE, kernel, iterations=1)
        support = cv2.dilate(support, kernel, iterations=1)

        min_alpha = max(8, int(round(24 - (10 * strength))))
        original_area = int(np.count_nonzero(alpha >= min_alpha))
        if original_area == 0:
            return alpha

        subject = (alpha >= min_alpha).astype(np.uint8)
        component_count, labels, stats, _centroids = cv2.connectedComponentsWithStats(subject, 8)
        filtered = np.zeros_like(alpha, dtype=np.uint8)
        for label in range(1, component_count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < max(50, original_area * 0.0003):
                continue
            component = labels == label
            overlap = int(np.count_nonzero(component & (support > 0)))
            if overlap > 0 or area >= original_area * 0.22:
                filtered[component] = alpha[component]

        kept_area = int(np.count_nonzero(filtered >= min_alpha))
        if kept_area < original_area * 0.35:
            return alpha
        return filtered

    def _filter_subject_core_alpha(self, alpha, strength: float, cv2, np):
        height, width = alpha.shape[:2]
        weak_threshold = max(24, int(round(76 - (42 * strength))))
        weak = (alpha >= weak_threshold).astype(np.uint8) * 255
        if not np.any(weak):
            return alpha

        bridge_size = _odd_kernel(7 + int(round(16 * strength)))
        bridge_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (bridge_size, bridge_size),
        )
        core = cv2.erode(weak, bridge_kernel, iterations=1)
        core = cv2.morphologyEx(core, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8), iterations=1)

        component_count, labels, stats, _ = cv2.connectedComponentsWithStats(core, 8)
        if component_count <= 2:
            return alpha

        min_area = max(1500, int(alpha.size * (0.00055 + (0.00035 * strength))))
        min_height = max(80, int(height * (0.11 + (0.05 * strength))))
        valid = []
        for label in range(1, component_count):
            x = stats[label, cv2.CC_STAT_LEFT]
            y = stats[label, cv2.CC_STAT_TOP]
            comp_width = stats[label, cv2.CC_STAT_WIDTH]
            comp_height = stats[label, cv2.CC_STAT_HEIGHT]
            area = stats[label, cv2.CC_STAT_AREA]
            bottom = y + comp_height
            if area < min_area:
                continue
            if comp_height < min_height and bottom < (height * 0.72):
                continue
            if bottom < (height * 0.42) and area < (alpha.size * 0.018):
                continue
            score = area * (0.65 + (0.55 * (bottom / height)))
            valid.append((score, label, area, x, y, comp_width, comp_height, bottom))

        if not valid:
            return alpha

        valid.sort(reverse=True)
        largest_area = max(item[2] for item in valid)
        selected = np.zeros_like(alpha, dtype=np.uint8)
        for _score, label, area, _x, _y, _w, comp_height, bottom in valid:
            large_enough = area >= (largest_area * (0.055 + (0.055 * strength)))
            body_like = comp_height >= min_height and bottom >= (height * (0.50 + (0.10 * strength)))
            if large_enough and body_like:
                selected[labels == label] = 255

        if not np.any(selected):
            return alpha

        restore_size = _odd_kernel(bridge_size + 6)
        restore_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (restore_size, restore_size),
        )
        support = cv2.dilate(selected, restore_kernel, iterations=1)
        support = cv2.morphologyEx(support, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8), iterations=1)
        kept = np.zeros_like(alpha)
        kept[(support > 0) & (alpha >= max(12, weak_threshold - 18))] = alpha[
            (support > 0) & (alpha >= max(12, weak_threshold - 18))
        ]
        return kept

    def _working_image(self, image: Image.Image) -> tuple[Image.Image, float]:
        max_side = int(self.settings.max_processing_side or 0)
        if max_side <= 0:
            return image.convert("RGB"), 1.0

        width, height = image.size
        longest = max(width, height)
        if longest <= max_side:
            return image.convert("RGB"), 1.0

        scale = max_side / longest
        size = (max(1, int(width * scale)), max(1, int(height * scale)))
        self.logger.info(
            "BEN2 preview/downscale: %sx%s -> %sx%s",
            width,
            height,
            size[0],
            size[1],
        )
        return image.convert("RGB").resize(size, Image.Resampling.LANCZOS), scale

    def _birefnet_enabled(self) -> bool:
        return bool(getattr(self.settings, "birefnet_enabled", False)) and (
            self._birefnet_model_path() is not None
        )

    def _birefnet_hybrid_enabled(self) -> bool:
        return self._birefnet_enabled() and bool(
            getattr(self.settings, "birefnet_hybrid_ben2", False)
        )

    def _birefnet_model_path(self) -> Path | None:
        configured = str(
            getattr(
                self.settings,
                "birefnet_model",
                "models/BiRefNet-portrait",
            )
            or "models/BiRefNet-portrait"
        )
        path = Path(configured)
        if not path.is_absolute():
            path = Path.cwd() / path
        required = (
            path / "config.json",
            path / "BiRefNet_config.py",
            path / "birefnet.py",
            path / "model.safetensors",
        )
        return path if all(candidate.is_file() for candidate in required) else None

    def _birefnet_input_size(self) -> int:
        requested = int(getattr(self.settings, "birefnet_input_size", 2048) or 2048)
        return max(1024, min(2048, requested))

    def _birefnet_backend_name(self) -> str:
        model_path = self._birefnet_model_path()
        if model_path is not None and model_path.name.casefold() == "birefnet_dynamic":
            return "birefnet-dynamic"
        return "birefnet-portrait"

    def _birefnet_inference_size(self, image: Image.Image) -> tuple[int, int]:
        model_path = self._birefnet_model_path()
        if model_path is None or model_path.name.casefold() != "birefnet_dynamic":
            input_size = self._birefnet_input_size()
            return input_size, input_size

        width, height = image.size
        input_size = self._birefnet_input_size()
        scale = min(1.0, float(input_size) / max(width, height))
        width = max(32, int(round(width * scale / 32.0)) * 32)
        height = max(32, int(round(height * scale / 32.0)) * 32)
        return width, height

    def _birefnet_torch_device(self, torch_module):
        requested = str(
            getattr(self.settings, "birefnet_device", "auto") or "auto"
        ).lower()
        if requested in {"cuda", "gpu"}:
            if not torch_module.cuda.is_available():
                raise ConfigurationError(
                    "BiRefNet pidio CUDA, pero Torch no tiene GPU disponible."
                )
            return torch_module.device("cuda")
        if requested == "cpu":
            return torch_module.device("cpu")
        if not self._cuda_is_available(torch_module):
            self._warn_cpu_processing()
            raise ConfigurationError(
                "BiRefNet requiere CUDA en modo automatico."
            )
        return torch_module.device("cuda")

    def _ensure_birefnet_model(self, torch_module=None) -> None:
        if self._birefnet_model is not None:
            return
        torch_module = torch_module or self._import_torch()
        self._configure_torch_acceleration(torch_module)
        model_path = self._birefnet_model_path()
        if model_path is None:
            raise ConfigurationError(
                "No se encontro el modelo local configurado para BiRefNet."
            )
        device = self._birefnet_torch_device(torch_module)
        cache_key = (str(model_path.resolve()).casefold(), str(device))
        cached = _BIREFNET_MODEL_CACHE.get(cache_key)
        if cached is not None:
            self._birefnet_model, self._birefnet_device = cached
            return

        with _BIREFNET_MODEL_CACHE_LOCK:
            cached = _BIREFNET_MODEL_CACHE.get(cache_key)
            if cached is not None:
                self._birefnet_model, self._birefnet_device = cached
                return
            try:
                from transformers import AutoModelForImageSegmentation
            except ModuleNotFoundError as exc:
                raise ConfigurationError(
                    "Falta Transformers para BiRefNet."
                ) from exc
            self.logger.info(
                "Loading BiRefNet model '%s' on %s",
                model_path,
                device,
            )
            model = AutoModelForImageSegmentation.from_pretrained(
                str(model_path),
                trust_remote_code=True,
                local_files_only=True,
            ).to(device).eval()
            if getattr(device, "type", "") == "cuda":
                model = model.half()
            _BIREFNET_MODEL_CACHE[cache_key] = (model, device)
            self._birefnet_model = model
            self._birefnet_device = device
            self.logger.info("BiRefNet activo en %s.", device)

    def _remove_with_birefnet(self, image: Image.Image) -> Image.Image:
        import numpy as np

        torch = self._import_torch()
        self._ensure_birefnet_model(torch)
        inference_size = self._birefnet_inference_size(image)
        resized = image.convert("RGB").resize(
            inference_size,
            Image.Resampling.BILINEAR,
        )
        values = np.asarray(resized, dtype=np.float32) / 255.0
        tensor = torch.from_numpy(values).permute(2, 0, 1).unsqueeze(0)
        mean = torch.tensor(
            (0.485, 0.456, 0.406),
            dtype=tensor.dtype,
        ).view(1, 3, 1, 1)
        std = torch.tensor(
            (0.229, 0.224, 0.225),
            dtype=tensor.dtype,
        ).view(1, 3, 1, 1)
        tensor = (tensor - mean) / std
        dtype = (
            torch.float16
            if getattr(self._birefnet_device, "type", "") == "cuda"
            else torch.float32
        )
        tensor = tensor.to(self._birefnet_device, dtype=dtype)
        with _BIREFNET_INFERENCE_LOCK, torch.inference_mode():
            output = self._birefnet_model(tensor)
            prediction = output[-1].sigmoid()[0, 0]
        alpha_values = prediction.float().cpu().numpy()
        alpha = Image.fromarray(
            np.rint(np.clip(alpha_values, 0.0, 1.0) * 255.0).astype(np.uint8),
            "L",
        ).resize(image.size, Image.Resampling.LANCZOS)
        rgba = image.convert("RGBA")
        rgba.putalpha(alpha)
        return rgba

    def _fuse_birefnet_ben2_masks(
        self,
        biref_mask: Image.Image,
        ben2_mask: Image.Image,
        human_alpha,
    ) -> tuple[Image.Image, bool, dict[str, int]]:
        """Keep BiRefNet edges and restore only BEN2/U2Net consensus losses."""
        import cv2
        import numpy as np

        base = np.asarray(biref_mask.convert("L"), dtype=np.uint8)
        ben2 = np.asarray(
            ben2_mask.convert("L").resize(
                biref_mask.size,
                Image.Resampling.LANCZOS,
            ),
            dtype=np.uint8,
        )
        human = np.asarray(human_alpha, dtype=np.uint8)
        if human.shape != base.shape:
            human = np.asarray(
                Image.fromarray(human, "L").resize(
                    biref_mask.size,
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.uint8,
            )

        # A pixel is eligible only when BEN2 sees solid subject, BiRefNet has
        # materially lost it, and U2Net independently agrees that it is human.
        candidate = (
            (ben2 >= 128)
            & (base <= 112)
            & (ben2.astype(np.int16) >= base.astype(np.int16) + 36)
            & (human >= 72)
        ).astype(np.uint8)
        if not np.any(candidate):
            return biref_mask, False, {"components": 0, "pixels": 0}

        height, width = base.shape
        image_area = height * width
        bridge = max(5, min(19, _odd_kernel(min(height, width) // 150)))
        broad_bridge = max(bridge, min(31, _odd_kernel(min(height, width) // 70)))
        base_core = (base >= 96).astype(np.uint8)
        near_base = cv2.dilate(
            base_core,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (bridge, bridge)),
            iterations=1,
        )
        broadly_near_base = cv2.dilate(
            base_core,
            cv2.getStructuringElement(
                cv2.MORPH_ELLIPSE,
                (broad_bridge, broad_bridge),
            ),
            iterations=1,
        )

        count, labels, stats, _ = cv2.connectedComponentsWithStats(candidate, 8)
        minimum_area = max(96, int(round(image_area * 0.00006)))
        major_area = max(700, int(round(image_area * 0.00045)))
        person_area = max(5000, int(round(image_area * 0.0040)))
        accepted = np.zeros_like(candidate, dtype=np.uint8)
        accepted_components = 0
        for label in range(1, count):
            area = int(stats[label, cv2.CC_STAT_AREA])
            if area < minimum_area:
                continue
            component = labels == label
            touches_subject = bool(np.any(near_base[component] > 0))
            broadly_connected = bool(np.any(broadly_near_base[component] > 0))
            human_confidence = float(human[component].mean()) / 255.0
            keep = touches_subject
            if not keep and area >= major_area and broadly_connected:
                keep = human_confidence >= 0.42
            # This final branch recovers a whole person missing from BiRefNet,
            # but requires strong agreement between BEN2 and U2Net.
            if not keep and area >= person_area:
                keep = human_confidence >= 0.62
            if not keep:
                continue
            accepted[component] = 1
            accepted_components += 1

        if accepted_components == 0:
            return biref_mask, False, {"components": 0, "pixels": 0}

        accepted = cv2.morphologyEx(
            accepted,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)),
            iterations=1,
        )
        support = cv2.dilate(
            accepted,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)),
            iterations=1,
        )
        eligible = (
            (support > 0)
            & (human >= 36)
            & (ben2 >= 24)
            & (ben2.astype(np.int16) > base.astype(np.int16) + 6)
            & (base < 176)
        )
        feather = cv2.GaussianBlur(
            accepted.astype(np.float32),
            (0, 0),
            sigmaX=1.15,
            sigmaY=1.15,
        )
        feather = np.clip(feather, 0.0, 1.0)
        feather[~eligible] = 0.0
        target = np.maximum(base, ben2).astype(np.float32)
        merged = np.maximum(
            base.astype(np.float32),
            base.astype(np.float32) * (1.0 - feather) + target * feather,
        )
        merged = np.rint(np.clip(merged, 0, 255)).astype(np.uint8)
        added_pixels = int(
            np.count_nonzero(
                merged.astype(np.int16) > base.astype(np.int16) + 2
            )
        )
        if added_pixels == 0:
            return biref_mask, False, {"components": 0, "pixels": 0}
        return (
            Image.fromarray(merged, "L"),
            True,
            {"components": accepted_components, "pixels": added_pixels},
        )

    @staticmethod
    def _selective_dynamic_background_veto(primary_mask, fused_mask, ben2_mask, human_alpha):
        """Reject gross extra scenery only with two agreeing foreground guides.

        This is deliberately not an unconditional intersection: normal Dynamic
        details and recoveries remain unchanged when the gate is closed.
        """
        import numpy as np

        base = np.asarray(primary_mask, dtype=np.uint8)
        fused = np.asarray(fused_mask, dtype=np.uint8)
        ben = np.asarray(ben2_mask, dtype=np.uint8)
        human = np.asarray(human_alpha, dtype=np.uint8)
        if not (base.shape == fused.shape == ben.shape == human.shape):
            raise ValueError("Selective fusion masks must have matching dimensions")
        bc, hc = ben >= 128, human >= 128
        support = np.maximum(ben, human)
        union = int(np.count_nonzero(bc | hc))
        intersection = int(np.count_nonzero(bc & hc))
        area = int(np.count_nonzero(base >= 128))
        disputed = int(np.count_nonzero((base >= 128) & (support < 32)))
        agreement = intersection / max(1, union)
        active = (union >= max(96, base.size * 0.005)
                  and agreement >= 0.55 and area > union * 1.6
                  and disputed > base.size * 0.05)
        stats = {"active": active, "removed_pixels": 0,
                 "disputed_pixels": disputed, "guide_agreement": agreement}
        if not active:
            return fused_mask, stats
        result = np.minimum(fused, support)
        stats["removed_pixels"] = int(np.count_nonzero(
            result.astype(np.int16) < fused.astype(np.int16) - 2))
        return Image.fromarray(result), stats

    def _validate_dynamic_hybrid_additions(self, image, base_mask, fused_mask):
        """Validate disputed additions locally; never subtract primary subject."""
        import cv2
        import numpy as np
        if self._birefnet_backend_name() != "birefnet-dynamic":
            return fused_mask, {"checks": 0, "rejected_pixels": 0}
        base = np.asarray(base_mask, dtype=np.uint8)
        fused = np.asarray(fused_mask, dtype=np.uint8)
        additions = (fused.astype(np.int16) > base.astype(np.int16) + 2).astype(np.uint8)
        count, labels, stats, _ = cv2.connectedComponentsWithStats(additions, 8)
        order = sorted(range(1, count), key=lambda k: int(stats[k, cv2.CC_STAT_AREA]), reverse=True)
        checked = fused.copy()
        checks = 0
        # Bound additional GPU cost to four fixed-size contextual patches.
        for label in order[:4]:
            x, y, w, h, area = (int(v) for v in stats[label])
            if area < 96:
                continue
            side = max(512, 4 * max(w, h))
            cx, cy = x + w // 2, y + h // 2
            left = max(0, min(image.width - min(side, image.width), cx - side // 2))
            top = max(0, min(image.height - min(side, image.height), cy - side // 2))
            right, bottom = min(image.width, left + side), min(image.height, top + side)
            crop = image.crop((left, top, right, bottom))
            crop.thumbnail((512, 512), Image.Resampling.LANCZOS)
            patch = Image.new("RGB", (512, 512))
            px, py = (512 - crop.width) // 2, (512 - crop.height) // 2
            patch.paste(crop, (px, py))
            local = self._remove_with_birefnet(patch).getchannel("A")
            local = local.crop((px, py, px + crop.width, py + crop.height))
            local = np.asarray(local.resize((right-left, bottom-top), Image.Resampling.LANCZOS))
            component = labels[top:bottom, left:right] == label
            approval = np.clip((local.astype(np.float32) - 24.0) / 104.0, 0.0, 1.0)
            region_base = base[top:bottom, left:right].astype(np.float32)
            region_fused = fused[top:bottom, left:right].astype(np.float32)
            validated = np.rint(region_base + (region_fused-region_base) * approval).astype(np.uint8)
            checked[top:bottom, left:right][component] = validated[component]
            checks += 1
        rejected = int(np.count_nonzero(checked.astype(np.int16) < fused.astype(np.int16) - 2))
        return Image.fromarray(checked, "L"), {"checks": checks, "rejected_pixels": rejected}

    def _refine_selective_dynamic_veto(self, image, mask, human_alpha):
        """Adjudicate residual BEN-only detail after a gross-background veto."""
        import cv2
        import numpy as np

        human = np.asarray(human_alpha, dtype=np.uint8)
        base = Image.fromarray(np.minimum(np.asarray(mask), human))
        refined, stats = self._validate_dynamic_hybrid_additions(image, base, mask)
        values = np.asarray(refined).copy()
        # A subject-centred view excludes most of the vehicle context. Only
        # adjudicate BEN-only additions; never erase the supported human base.
        yy, xx = np.where(human >= 128)
        if xx.size:
            pad = int(round(max(xx.max()-xx.min(), yy.max()-yy.min()) * 0.15))
            left, top = max(0, int(xx.min())-pad), max(0, int(yy.min())-pad)
            right = min(image.width, int(xx.max())+pad+1)
            bottom = min(image.height, int(yy.max())+pad+1)
            crop = image.crop((left, top, right, bottom))
            crop.thumbnail((768, 768), Image.Resampling.LANCZOS)
            local = self._remove_with_birefnet(crop).getchannel("A").resize(
                (right-left, bottom-top), Image.Resampling.LANCZOS)
            region = values[top:bottom, left:right]
            protected = np.minimum(region, human[top:bottom, left:right])
            cleaned = np.maximum(protected, np.minimum(region, np.asarray(local)))
            stats["rejected_pixels"] += int(np.count_nonzero(
                cleaned.astype(np.int16) < region.astype(np.int16)-2))
            region[:] = cleaned
            stats["checks"] += 1
        # Remove small isolated fragments with no human support. Never remove
        # a major component or anything near the confident human silhouette.
        radius = max(8, int(round(min(image.size) * 0.008)))
        near = cv2.dilate((human >= 128).astype(np.uint8),
                          cv2.getStructuringElement(cv2.MORPH_ELLIPSE,
                                                   (2 * radius + 1, 2 * radius + 1)))
        count, labels, components, _ = cv2.connectedComponentsWithStats(
            (values > 2).astype(np.uint8), 8)
        islands = 0
        for label in range(1, count):
            if int(components[label, cv2.CC_STAT_AREA]) > max(128, values.size * 0.01):
                continue
            component = labels == label
            if (not np.any(near[component])
                    and int(human[component].max()) < 32):
                values[component] = 0
                islands += 1
        return Image.fromarray(values), {**stats, "unsupported_islands": islands}

    @staticmethod
    def _dynamic_ultra_tile_boxes(
        size: tuple[int, int],
    ) -> tuple[tuple[int, int, int, int], ...]:
        width, height = size
        tile_width = min(width, max(64, int(round(width * 0.75))))
        tile_height = min(height, max(64, int(round(height * 0.75))))
        xs = (0, max(0, width - tile_width))
        ys = (0, max(0, height - tile_height))
        return tuple(
            dict.fromkeys(
                (x, y, x + tile_width, y + tile_height)
                for y in ys
                for x in xs
            )
        )

    def _repair_dynamic_with_tiles(
        self,
        image: Image.Image,
        base_mask: Image.Image,
        strength: float = 1.0,
    ) -> tuple[Image.Image, bool, dict[str, int]]:
        """Recover weak whole people with focused passes of the same Dynamic model."""
        import cv2
        import numpy as np

        strength = max(0.0, min(1.0, float(strength)))
        if strength <= 0.0:
            return base_mask, False, {"tiles": 0, "pixels": 0}
        model_path = self._birefnet_model_path()
        if model_path is None or model_path.name.casefold() != "birefnet_dynamic":
            return base_mask, False, {"tiles": 0, "pixels": 0}

        base = np.asarray(base_mask.convert("L"), dtype=np.uint8).copy()
        before = base.copy()
        accepted_tiles = 0
        width, height = image.size
        for left, top, right, bottom in self._dynamic_ultra_tile_boxes(image.size):
            local_rgba = self._remove_with_birefnet(
                image.crop((left, top, right, bottom))
            )
            local = np.asarray(
                local_rgba.getchannel("A").resize(
                    (right - left, bottom - top),
                    Image.Resampling.LANCZOS,
                ),
                dtype=np.uint8,
            )
            current = base[top:bottom, left:right]
            core = (local >= 96).astype(np.uint8)
            count, labels, stats, _ = cv2.connectedComponentsWithStats(core, 8)
            accepted = np.zeros_like(core, dtype=np.uint8)
            for label in range(1, count):
                area = int(stats[label, cv2.CC_STAT_AREA])
                if area < max(96, local.size // 12000):
                    continue
                component = labels == label
                overlap = int(np.count_nonzero(component & (current >= 96)))
                if overlap < max(24, min(400, int(round(area * 0.002)))):
                    continue
                accepted[component] = 1
            if not np.any(accepted):
                continue

            support = cv2.dilate(
                accepted,
                cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7)),
                iterations=1,
            ) > 0
            eligible = (
                support
                & (local >= 12)
                & (
                    local.astype(np.int16)
                    > current.astype(np.int16) + 4
                )
            )
            if not np.any(eligible):
                continue

            tile_width = right - left
            tile_height = bottom - top
            margin = max(8, min(64, min(tile_width, tile_height) // 16))
            x_weight = np.ones(tile_width, dtype=np.float32)
            y_weight = np.ones(tile_height, dtype=np.float32)
            ramp = np.linspace(0.0, 1.0, margin, dtype=np.float32)
            if left > 0:
                x_weight[:margin] = ramp
            if right < width:
                x_weight[-margin:] = ramp[::-1]
            if top > 0:
                y_weight[:margin] = ramp
            if bottom < height:
                y_weight[-margin:] = ramp[::-1]
            weight = y_weight[:, None] * x_weight[None, :]
            weight[~eligible] = 0.0
            weight *= strength

            target = np.maximum(current, local).astype(np.float32)
            merged = np.maximum(
                current.astype(np.float32),
                current.astype(np.float32) * (1.0 - weight)
                + target * weight,
            )
            current[:] = np.rint(np.clip(merged, 0, 255)).astype(np.uint8)
            accepted_tiles += 1

        added_pixels = int(
            np.count_nonzero(
                base.astype(np.int16) > before.astype(np.int16) + 2
            )
        )
        if added_pixels == 0:
            return base_mask, False, {"tiles": 0, "pixels": 0}
        return (
            Image.fromarray(base, "L"),
            True,
            {"tiles": accepted_tiles, "pixels": added_pixels},
        )

    def _finish_birefnet_background_removal(
        self,
        image: Image.Image,
        prepared: PreparedBackgroundRemoval,
    ) -> RemovalResult:
        import numpy as np

        timings = list(prepared.timings)
        phase_start = time.perf_counter()
        mask = prepared.rgba.getchannel("A")
        if prepared.scale != 1.0:
            mask = mask.resize(image.size, Image.Resampling.LANCZOS)
        slider = _mask_conserve_slider_value(self.settings)
        dynamic_tile_strength = max(
            0.0,
            min(
                1.0,
                (slider - _MASK_RESCUE_START)
                / float(100 - _MASK_RESCUE_START),
            ),
        )
        dynamic_tiled = False
        dynamic_tile_stats = {"tiles": 0, "pixels": 0}
        if dynamic_tile_strength > 0.0:
            tile_started = time.perf_counter()
            try:
                mask, dynamic_tiled, dynamic_tile_stats = (
                    self._repair_dynamic_with_tiles(
                        image,
                        mask,
                        dynamic_tile_strength,
                    )
                )
                timings.append(
                    ("dynamic_tiles", time.perf_counter() - tile_started)
                )
            except Exception as exc:
                timings.append(
                    ("dynamic_tiles_failed", time.perf_counter() - tile_started)
                )
                if not self._dynamic_tile_warning:
                    self.logger.warning(
                        "Reparacion Dynamic por teselas desactivada: %s",
                        exc,
                    )
                    self._dynamic_tile_warning = True
        phase_start = time.perf_counter()
        if slider != _MASK_RESCUE_START:
            values = np.asarray(mask.convert("L"), dtype=np.uint8)
            if slider < _MASK_RESCUE_START:
                strength = min(
                    1.0,
                    (_MASK_RESCUE_START - slider)
                    / float(_MASK_RESCUE_START - _MASK_SLIDER_MIN),
                )
                cutoff = int(round(28.0 * strength))
                adjusted = np.clip(
                    (values.astype(np.float32) - cutoff)
                    * (255.0 / max(1, 255 - cutoff)),
                    0,
                    255,
                )
            else:
                strength = min(
                    1.0,
                    (slider - _MASK_RESCUE_START)
                    / float(100 - _MASK_RESCUE_START),
                )
                gamma = 1.0 - (0.35 * strength)
                adjusted = (
                    np.power(values.astype(np.float32) / 255.0, gamma) * 255.0
                )
            mask = Image.fromarray(
                np.rint(adjusted).astype(np.uint8),
                "L",
            )
        timings.append(("birefnet_slider", time.perf_counter() - phase_start))
        hybrid_changed = False
        hybrid_stats = {"components": 0, "pixels": 0}
        if prepared.ben2_rgba is not None:
            ben2_mask = prepared.ben2_rgba.getchannel("A")
            if prepared.ben2_scale != 1.0 or ben2_mask.size != image.size:
                ben2_mask = ben2_mask.resize(image.size, Image.Resampling.LANCZOS)
            human_start = time.perf_counter()
            try:
                human_alpha = self._u2net_human_alpha(image)
                timings.append(
                    ("hybrid_u2net", time.perf_counter() - human_start)
                )
                fusion_start = time.perf_counter()
                primary_mask = mask
                mask, hybrid_changed, hybrid_stats = (
                    self._fuse_birefnet_ben2_masks(
                        mask,
                        ben2_mask,
                        human_alpha,
                    )
                )
                timings.append(
                    ("hybrid_fusion", time.perf_counter() - fusion_start)
                )
                if hybrid_changed:
                    validation_start = time.perf_counter()
                    try:
                        mask, validation_stats = self._validate_dynamic_hybrid_additions(image, primary_mask, mask)
                    except Exception:
                        self.logger.exception("Dynamic no pudo validar recuperaciones; conservando mascara principal")
                        mask = primary_mask
                        validation_stats = {"checks": 0, "rejected_pixels": 0}
                    timings.append(("hybrid_validation", time.perf_counter() - validation_start))
                    hybrid_stats["pixels"] = int(np.count_nonzero(
                        np.asarray(mask, dtype=np.int16) > np.asarray(primary_mask, dtype=np.int16) + 2
                    ))
                    hybrid_changed = hybrid_stats["pixels"] > 0
                    self.logger.info("Dynamic fusion validation: checks=%s rejected_pixels=%s retained_pixels=%s",
                                     validation_stats["checks"], validation_stats["rejected_pixels"], hybrid_stats["pixels"])
                if self._birefnet_backend_name() == "birefnet-dynamic":
                    veto_start = time.perf_counter()
                    mask, veto_stats = self._selective_dynamic_background_veto(
                        primary_mask, mask, ben2_mask, human_alpha)
                    timings.append(("hybrid_selective_veto", time.perf_counter() - veto_start))
                    if veto_stats["active"]:
                        hybrid_changed = True
                        edge_start = time.perf_counter()
                        mask, edge_stats = self._refine_selective_dynamic_veto(image, mask, human_alpha)
                        timings.append(("hybrid_selective_edges", time.perf_counter() - edge_start))
                        self.logger.info("Selective Dynamic edges: checks=%s rejected_pixels=%s unsupported_islands=%s",
                                         edge_stats["checks"], edge_stats["rejected_pixels"], edge_stats["unsupported_islands"])
                    self.logger.info("Selective Dynamic fusion: active=%s removed_pixels=%s disputed_pixels=%s guide_agreement=%.3f",
                                     veto_stats["active"], veto_stats["removed_pixels"],
                                     veto_stats["disputed_pixels"], veto_stats["guide_agreement"])
            except Exception as exc:
                timings.append(
                    ("hybrid_u2net_failed", time.perf_counter() - human_start)
                )
                if not self._u2net_human_warning:
                    self.logger.warning(
                        "Fusion BiRefNet+BEN2 omitida: U2Net no disponible: %s",
                        exc,
                    )
                    self._u2net_human_warning = True
        rgba = image.convert("RGBA")
        rgba.putalpha(mask)
        total = sum(seconds for _name, seconds in timings)
        parts = " ".join(
            f"{name}={seconds:.3f}s" for name, seconds in timings
        )
        if dynamic_tiled and hybrid_changed:
            backend_used = "birefnet-dynamic-tiled-ben2-hybrid"
        elif dynamic_tiled:
            backend_used = "birefnet-dynamic-tiled"
        elif hybrid_changed:
            backend_used = "birefnet-ben2-hybrid"
        else:
            backend_used = prepared.backend_used
        self.logger.info(
            "Mask timing: backend=%s total=%.3fs slider=%s "
            "hybrid_components=%s hybrid_pixels=%s "
            "dynamic_tile_strength=%.3f dynamic_tiles=%s dynamic_pixels=%s %s",
            backend_used,
            total,
            slider,
            hybrid_stats["components"],
            hybrid_stats["pixels"],
            dynamic_tile_strength,
            dynamic_tile_stats["tiles"],
            dynamic_tile_stats["pixels"],
            parts,
        )
        return RemovalResult(
            rgba,
            rgba.getchannel("A"),
            backend_used,
        )

    def _remove_with_ben2(self, image: Image.Image) -> Image.Image:
        torch = self._import_torch()
        self._ensure_ben2_model(torch=torch)
        self._configure_torch_acceleration(torch)

        with _BEN2_INFERENCE_LOCK:
            with torch.inference_mode():
                rgba = self._ben2_model.inference(
                    image.convert("RGB"),
                    refine_foreground=self.settings.ben2_refine_foreground,
                )
        if not isinstance(rgba, Image.Image):
            raise TypeError("BEN2 no devolvio una imagen PIL")
        return rgba.convert("RGBA")

    def _ensure_ben2_model(self, torch=None) -> None:
        if self._ben2_model is not None:
            return
        torch = torch or self._import_torch()
        self._configure_torch_acceleration(torch)
        BEN_Base = self._import_ben2()
        device = self._torch_device(torch)
        model_name = self._model_name()
        cache_key = (model_name, str(device))
        cached = _BEN2_MODEL_CACHE.get(cache_key)
        if cached is not None:
            self._ben2_model, self._ben2_device = cached
            self._configure_torch_acceleration(torch)
            return

        with _BEN2_MODEL_CACHE_LOCK:
            cached = _BEN2_MODEL_CACHE.get(cache_key)
            if cached is not None:
                self._ben2_model, self._ben2_device = cached
                self._configure_torch_acceleration(torch)
                return

            self.logger.info("Loading BEN2 model '%s' on %s", model_name, device)
            model = self._load_ben2_model(BEN_Base, model_name)

            if model is None:
                raise ConfigurationError(f"BEN2 no devolvio modelo: {model_name}")

            loaded = model.to(device).eval()
            _BEN2_MODEL_CACHE[cache_key] = (loaded, device)

        self._ben2_model = loaded
        self._ben2_device = device
        self._configure_torch_acceleration(torch)

    def _load_ben2_model(self, BEN_Base, model_name: str):
        if hasattr(BEN_Base, "from_pretrained"):
            try:
                return BEN_Base.from_pretrained(model_name, local_files_only=True)
            except TypeError:
                return BEN_Base.from_pretrained(model_name)
            except Exception as exc:
                raise ConfigurationError(
                    f"No se pudo cargar BEN2 desde '{model_name}'. "
                    "Comprueba que existe models/BEN2 y que las dependencias BEN2/Torch estan instaladas."
                ) from exc

        checkpoint = self._local_ben2_checkpoint(model_name)
        if checkpoint is None:
            raise ConfigurationError(
                f"BEN2 local no tiene from_pretrained y no se encontro BEN2_Base.pth en '{model_name}'."
            )
        try:
            model = BEN_Base()
            model.loadcheckpoints(str(checkpoint))
            return model
        except Exception as exc:
            raise ConfigurationError(f"No se pudo cargar BEN2 local desde '{checkpoint}'.") from exc

    def _local_ben2_checkpoint(self, model_name: str) -> Path | None:
        candidates = [
            Path(model_name) / "BEN2_Base.pth",
            Path.cwd() / "models" / "BEN2" / "BEN2_Base.pth",
        ]
        for candidate in candidates:
            if candidate.exists():
                return candidate
        return None

    def _model_name(self) -> str:
        configured = self.settings.ben2_model or self.settings.model or "models/BEN2"
        path = Path(configured)
        if not path.is_absolute():
            path = Path.cwd() / path
        if path.exists():
            return str(path)
        return configured

    def _torch_device(self, torch_module):
        requested = (self.settings.ben2_device or "auto").lower()
        if requested in {"cuda", "gpu"}:
            if not torch_module.cuda.is_available():
                raise ConfigurationError("BEN2 pidio CUDA, pero Torch no tiene GPU disponible.")
            return torch_module.device("cuda")
        if requested == "cpu":
            return torch_module.device("cpu")
        cuda_available = self._cuda_is_available(torch_module)
        if not cuda_available:
            self._warn_cpu_processing()
        return torch_module.device("cuda" if cuda_available else "cpu")

    def _import_torch(self):
        try:
            import torch
        except ModuleNotFoundError as exc:
            raise ConfigurationError(
                "Falta Torch para BEN2. Instala dependencias con install_dependencies.bat."
            ) from exc
        return torch

    def _import_ben2(self):
        model_dir = Path.cwd() / "models" / "BEN2"
        model_file = model_dir / "BEN2.py"
        if model_file.exists():
            if str(model_dir) not in sys.path:
                sys.path.insert(0, str(model_dir))
            try:
                return import_module("BEN2").BEN_Base
            except Exception as exc:
                raise ConfigurationError("No se pudo importar BEN2 local.") from exc

        try:
            from ben2 import BEN_Base

            return BEN_Base
        except ModuleNotFoundError:
            raise ConfigurationError(
                "No se encontro BEN2 instalado ni models/BEN2/BEN2.py."
            )

    def _configure_torch_acceleration(self, torch_module) -> None:
        try:
            if not torch_module.cuda.is_available():
                return
            torch_module.backends.cudnn.deterministic = False
            torch_module.backends.cudnn.benchmark = True
            try:
                torch_module.backends.cuda.matmul.allow_tf32 = True
            except Exception:
                pass
            try:
                torch_module.backends.cudnn.allow_tf32 = True
            except Exception:
                pass
            try:
                torch_module.set_float32_matmul_precision("high")
            except Exception:
                pass
        except Exception as exc:
            self.logger.debug("Torch acceleration tuning skipped: %s", exc)


def _mask_filter_size(amount: int) -> int:
    radius = max(1, min(3, int(round(amount / 20))))
    return (radius * 2) + 1


def _odd_kernel(size: int) -> int:
    size = max(3, min(31, int(size)))
    return size if size % 2 else size + 1


def _mask_box_overlap(mask, box: tuple[int, int, int, int]) -> float:
    x1, y1, x2, y2 = box
    x1 = max(0, min(mask.shape[1], int(x1)))
    x2 = max(0, min(mask.shape[1], int(x2)))
    y1 = max(0, min(mask.shape[0], int(y1)))
    y2 = max(0, min(mask.shape[0], int(y2)))
    if x2 <= x1 or y2 <= y1:
        return 0.0
    return float(mask[y1:y2, x1:x2].mean())


def _calibrated_mask_repair_amount(value: int | str | float) -> int:
    value = max(0, min(100, int(value)))
    return value


def _mask_human_rescue_amount(raw_strength: int | str | float) -> int:
    value = max(float(_MASK_SLIDER_MIN), min(100.0, float(raw_strength or 0)))
    if value < _MASK_RESCUE_START:
        return 0
    if value <= _MASK_LOW_CONSERVE_VETO_END:
        return _legacy_low_rescue_amount(value)
    return int(round(value))


def _legacy_low_rescue_amount(value: int | str | float) -> int:
    value = max(0.0, min(100.0, float(value or 0)))
    if value <= 0:
        return 0
    if value <= 10:
        return max(1, int(round(value * 0.45)))

    progress = (value - 10.0) / 90.0
    return min(100, int(round(5.0 + (95.0 * (progress ** 1.35)))))


def _mask_slider_raw(value: int | str | float) -> int:
    return max(_MASK_SLIDER_MIN, min(100, int(value or 0)))


def _mask_raw_values(settings: BackgroundRemovalSettings) -> tuple[int, int]:
    protection = _mask_slider_raw(getattr(settings, "mask_protection", 0))
    antighost = _mask_slider_raw(getattr(settings, "mask_antighost", 0))
    return protection, antighost


def _mask_uses_unified_slider(settings: BackgroundRemovalSettings) -> bool:
    protection, antighost = _mask_raw_values(settings)
    return protection == antighost


def _mask_cleanup_amount(settings: BackgroundRemovalSettings) -> int:
    protection, antighost = _mask_raw_values(settings)
    if _mask_uses_unified_slider(settings):
        return max(0, min(100, int(round(100 - (protection * 0.82)))))
    return _calibrated_mask_repair_amount(antighost)


def _mask_protection_amount(settings: BackgroundRemovalSettings) -> int:
    protection, _antighost = _mask_raw_values(settings)
    return _calibrated_mask_repair_amount(protection)


def _mask_conserve_slider_value(settings: BackgroundRemovalSettings) -> int:
    protection, antighost = _mask_raw_values(settings)
    if _mask_uses_unified_slider(settings):
        return protection
    return max(protection, antighost)


def _negative_mask_extra_aggression(raw_strength: int | float) -> float:
    if raw_strength >= 0:
        return 0.0
    base = max(0.0, -float(raw_strength) / abs(_MASK_DEEP_AGGRESSION_START))
    return min(1.0, base ** 1.15)


def _structural_cleanup_aggression(raw_strength: int | float) -> float:
    base = max(0.0, min(1.0, (70.0 - float(raw_strength)) / 70.0))
    if raw_strength >= 0:
        return base
    return base + (0.75 * _negative_mask_extra_aggression(raw_strength))


def _mask_rescue_alpha_scale(raw_strength: int | float) -> float:
    raw_value = float(raw_strength)
    if raw_value < _MASK_RESCUE_START:
        return 0.0
    return 1.0


def _fill_mask_holes(mask, cv2, np):
    flood = mask.copy()
    h, w = flood.shape[:2]
    padded = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, padded, (0, 0), 255)
    holes = cv2.bitwise_not(flood)
    return cv2.bitwise_or(mask, holes)


def _alpha_lut(cutoff: int, full: int) -> list[int]:
    if full <= cutoff:
        return [0 if value <= cutoff else 255 for value in range(256)]
    return [
        0
        if value <= cutoff
        else 255
        if value >= full
        else int(round(((value - cutoff) * 255) / (full - cutoff)))
        for value in range(256)
    ]


def _alpha_boost_lut(strength: float) -> list[int]:
    boost = 0.04 + (0.52 * max(0.0, min(1.0, strength)))
    return [
        0 if value <= 0 else min(255, int(round(value + ((255 - value) * boost))))
        for value in range(256)
    ]
