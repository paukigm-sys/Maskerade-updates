from __future__ import annotations

import numpy as np
from PIL import Image

try:
    import cv2
except Exception:  # pragma: no cover - fallback for minimal installs
    cv2 = None


HARMONIZE_RESPONSE_GAIN = 1.45
HARMONIZE_MAX_STRENGTH = 3.0
LATE_HARMONIZE_WORK_MAX_SIDE = 1200


NEUTRAL_HARMONIZE_PROFILE: dict[str, float | tuple[float, float, float]] = {
    "subject_exposure_ev": 0.0,
    "subject_contrast": 0.0,
    "subject_whites": 0.0,
    "white_luma_max": 0.98,
    "shadow_tint_strength": 0.32,
    "highlight_tint_strength": 0.26,
    "skin_tint_multiplier": 0.35,
    "edge_wrap_strength": 0.0,
    "red_saturation": 0.0,
    "red_luminance": 0.0,
    "shadow_tint": (1.0, 1.0, 1.0),
    "highlight_tint": (1.0, 1.0, 1.0),
}


def _public_harmonize_strength(strength: float) -> float:
    return _clamp_harmonize_strength(float(strength or 0.0) * HARMONIZE_RESPONSE_GAIN)


def _clamp_harmonize_strength(strength: float) -> float:
    return max(0.0, min(HARMONIZE_MAX_STRENGTH, float(strength or 0.0)))


def _fast_profile_for(size: tuple[int, int]) -> dict[str, float | tuple[float, float, float]]:
    # Orientation never selects a colour treatment. Scene statistics do.
    return NEUTRAL_HARMONIZE_PROFILE


def harmonize_subject_layer(
    background: Image.Image,
    subject_rgba: Image.Image,
    strength: float,
) -> Image.Image:
    """Blend the BEN2 subject visually into the selected background.

    This keeps the subject alpha untouched. It only adjusts the visible RGB
    pixels, so it does not redraw faces or damage the overlay layer.
    """
    strength = _public_harmonize_strength(strength)
    if strength <= 0.001 or cv2 is None:
        return subject_rgba.convert("RGBA")

    background = background.convert("RGB")
    subject_rgba = subject_rgba.convert("RGBA")
    if subject_rgba.size != background.size:
        subject_rgba = subject_rgba.resize(background.size, Image.LANCZOS)

    subject = np.asarray(subject_rgba).astype(np.float32)
    bg = np.asarray(background).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return subject_rgba

    # RGB here is an uncomposited layer: alpha is applied by the compositor.
    fg_rgb = subject[..., :3]
    profile = _scene_profile_for(bg / 255.0, fg_rgb / 255.0, alpha[..., 0])
    adjusted_rgb = _fast_harmonize_rgb(fg_rgb / 255.0, mask.astype(np.float32), profile, strength)
    adjusted_rgb = _scene_edge_wrap(bg / 255.0, adjusted_rgb, alpha[..., 0], strength)
    output_rgb = _restore_subject_detail(fg_rgb, adjusted_rgb * 255.0, alpha[..., 0], strength)
    output_rgb = np.where(mask[..., None], output_rgb, fg_rgb)
    output = np.dstack([output_rgb.clip(0, 255), subject[..., 3:4]]).astype(np.uint8)
    return Image.fromarray(output, "RGBA")


def harmonize_composited_subject(
    background: Image.Image,
    composite: Image.Image,
    subject_rgba: Image.Image,
    strength: float,
    _allow_downsample: bool = True,
    _strength_is_public: bool = False,
) -> Image.Image:
    """Apply harmonization to the subject pixels after the full photo enhancement.

    This keeps enhancer/autotune analysis independent from harmonize while still
    nudging the composited people toward the selected background at the end.
    """
    strength = (
        _clamp_harmonize_strength(strength)
        if _strength_is_public
        else _public_harmonize_strength(strength)
    )
    if strength <= 0.001 or cv2 is None:
        return composite.convert("RGB")

    composite = composite.convert("RGB")
    background = background.convert("RGB")
    subject_rgba = subject_rgba.convert("RGBA")
    if background.size != composite.size:
        background = background.resize(composite.size, Image.LANCZOS)
    if subject_rgba.size != composite.size:
        subject_rgba = subject_rgba.resize(composite.size, Image.LANCZOS)

    max_side = max(composite.size)
    if _allow_downsample and max_side > LATE_HARMONIZE_WORK_MAX_SIDE and cv2 is not None:
        scale = LATE_HARMONIZE_WORK_MAX_SIDE / max_side
        work_size = (
            max(1, int(round(composite.width * scale))),
            max(1, int(round(composite.height * scale))),
        )
        composite_small = composite.resize(work_size, Image.Resampling.BILINEAR)
        background_small = background.resize(work_size, Image.Resampling.BILINEAR)
        subject_small = subject_rgba.resize(work_size, Image.Resampling.BILINEAR)
        harmonized_small = harmonize_composited_subject(
            background_small,
            composite_small,
            subject_small,
            strength,
            _allow_downsample=False,
            _strength_is_public=True,
        )
        base_small = np.asarray(composite_small, dtype=np.float32)
        adjusted_small = np.asarray(harmonized_small.convert("RGB"), dtype=np.float32)
        delta = adjusted_small - base_small
        delta = cv2.resize(delta, composite.size, interpolation=cv2.INTER_LINEAR)
        comp = np.asarray(composite, dtype=np.float32)
        alpha = np.asarray(subject_rgba.getchannel("A").convert("L"), dtype=np.float32) / 255.0
        output_rgb = comp + delta
        output_rgb = np.where((alpha > 0.03)[..., None], output_rgb, comp)
        return Image.fromarray(output_rgb.clip(0, 255).astype(np.uint8), "RGB")

    comp = np.asarray(composite).astype(np.float32)
    subject = np.asarray(subject_rgba).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return composite

    bg_rgb = np.asarray(background).astype(np.float32) / 255.0
    profile = _scene_profile_for(bg_rgb, comp / 255.0, alpha[..., 0])
    adjusted_rgb = _fast_harmonize_rgb(comp / 255.0, alpha[..., 0], profile, strength)
    output_rgb = _scene_edge_wrap(bg_rgb, adjusted_rgb, alpha[..., 0], strength) * 255.0

    output_rgb = _restore_subject_detail(comp, output_rgb, alpha[..., 0], strength)
    output_rgb = np.where(mask[..., None], output_rgb, comp)
    return Image.fromarray(output_rgb.clip(0, 255).astype(np.uint8), "RGB")


def _scene_profile_for(
    bg: np.ndarray, rgb: np.ndarray, alpha: np.ndarray,
) -> dict[str, float | tuple[float, float, float]]:
    """Estimate bounded ambient light, without matching clothing to scenery colours."""
    profile = dict(_fast_profile_for((bg.shape[1], bg.shape[0])))
    # Statistics need coverage, not print resolution. Keep processing cost stable.
    step = max(1, int(np.ceil(max(alpha.shape) / 320)))
    if step > 1 and (alpha[::step, ::step] > 0.03).any():
        bg, rgb, alpha = bg[::step, ::step], rgb[::step, ::step], alpha[::step, ::step]
    mask = alpha > 0.03
    if not mask.any():
        return profile
    # The selected background is clean: also sample the area BEHIND the person.
    # A ring alone is unreliable for close-ups and subjects filling the frame.
    region = mask | _background_sample_mask(mask, bg.shape[:2])
    sample = bg[region]
    sample_luma = _rgb_luma(sample)
    interior = alpha > 0.9
    fg_luma = _rgb_luma(rgb[interior if interior.any() else mask])
    scene_light = float(np.percentile(sample_luma, 70))
    person_light = float(np.percentile(fg_luma, 70))
    profile["subject_exposure_ev"] = float(np.clip(
        0.40 * np.log2((scene_light + 0.12) / (person_light + 0.12)), -0.40, 0.25,
    ))
    # Preserve garment contrast rather than transferring the variance of rocks,
    # sky, foliage, etc. into skin and fabric.
    profile["subject_contrast"] = 0.0
    profile["subject_whites"] = 0.20 * float(np.clip((0.8 - scene_light) / 0.6, 0, 1))
    profile["white_luma_max"] = 0.92 + 0.06 * scene_light
    valid = (sample_luma > 0.06) & (sample_luma < 0.94)
    lit = sample[valid]
    if len(lit) < 16:
        return profile
    lit_luma = _rgb_luma(lit)
    saturation = (lit.max(axis=1) - lit.min(axis=1)) / np.maximum(lit.max(axis=1), 0.01)
    # Prefer plausible illuminant samples over highly saturated objects.
    weights = np.maximum(0.05, (1.0 - saturation) ** 3)
    low, high = np.percentile(lit_luma, [45, 65])
    for key, selection in (("shadow_tint", lit_luma <= low), ("highlight_tint", lit_luma >= high)):
        colour = np.average(lit[selection], axis=0, weights=weights[selection])
        chroma = colour / max(0.03, float(_rgb_luma(colour))) - 1.0
        confidence = float(np.clip(np.average(1.0 - saturation, weights=weights), 0.2, 1.0))
        tint = np.clip(1.0 + chroma * (0.40 * confidence), 0.82, 1.18)
        profile[key] = tuple(float(v) for v in tint)
    return profile


def _scene_edge_wrap(bg: np.ndarray, rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    # A narrow inner edge receives the actual local ambient colour. Match its
    # luminance to the person to avoid a bright outline on dark hair/clothing.
    scale = min(1.0, 320.0 / max(alpha.shape))
    work = bg
    if scale < 1.0:
        work_size = (max(1, round(bg.shape[1] * scale)), max(1, round(bg.shape[0] * scale)))
        work = cv2.resize(bg, work_size, interpolation=cv2.INTER_AREA)
    ambient = cv2.GaussianBlur(work, (0, 0), max(1.0, max(work.shape[:2]) / 100.0))
    if scale < 1.0:
        ambient = cv2.resize(ambient, (bg.shape[1], bg.shape[0]), interpolation=cv2.INTER_LINEAR)
    ambient_luma = _rgb_luma(ambient)
    colour = np.clip(ambient / np.maximum(ambient_luma[..., None], 0.04), 0.65, 1.35)
    target = rgb * colour
    amount = _edge_alpha(alpha) * alpha * min(0.18, 0.07 * strength)
    amount *= 1.0 - 0.65 * _cheap_skin_mask(rgb)
    amount *= _smoothstep(0.04, 0.12, ambient_luma)
    return np.clip(rgb + (target - rgb) * amount[..., None], 0.0, 1.0)


def _fast_harmonize_rgb(
    rgb: np.ndarray,
    alpha: np.ndarray,
    profile: dict[str, float | tuple[float, float, float]],
    strength: float,
) -> np.ndarray:
    strength = _clamp_harmonize_strength(strength)
    subject = np.clip(alpha, 0.0, 1.0)
    if subject.max() <= 0.001:
        return rgb

    out = rgb.copy()
    luma = _rgb_luma(out)
    skin = _cheap_skin_mask(out) * subject

    exposure = float(profile["subject_exposure_ev"]) * min(1.5, strength)
    exposed = np.clip(out * (2.0 ** exposure), 0.0, 1.0)
    out += (exposed - out) * subject[..., None]
    luma = _rgb_luma(out)

    contrast = float(profile["subject_contrast"]) * min(1.0, strength)
    if contrast:
        contrasted = np.clip((out - 0.50) * (1.0 + contrast) + 0.50, 0.0, 1.0)
        out = out * (1.0 - subject[..., None]) + contrasted * subject[..., None]
        luma = _rgb_luma(out)

    hot = np.clip(_smoothstep(0.86, 1.0, luma) * subject, 0.0, 1.0)
    max_luma = float(profile["white_luma_max"])
    target_luma = np.minimum(luma, 0.86 + (luma - 0.86) * ((max_luma - 0.86) / 0.14))
    scale = np.divide(target_luma, np.maximum(luma, 0.001))
    recovered = np.clip(out * scale[..., None], 0.0, 1.0)
    white_strength = min(0.85, float(profile["subject_whites"]) * strength)
    out = out * (1.0 - hot[..., None] * white_strength) + recovered * (hot[..., None] * white_strength)
    luma = _rgb_luma(out)

    shadow_weight = (1.0 - _smoothstep(0.25, 0.75, luma)) * subject
    highlight_weight = _smoothstep(0.25, 0.85, luma) * subject
    tint_skin_hold = 1.0 - skin * (1.0 - float(profile["skin_tint_multiplier"]))
    shadow_tint = np.asarray(profile["shadow_tint"], dtype=np.float32)
    highlight_tint = np.asarray(profile["highlight_tint"], dtype=np.float32)
    shadow_blend = shadow_weight * float(profile["shadow_tint_strength"]) * strength * tint_skin_hold
    highlight_blend = highlight_weight * float(profile["highlight_tint_strength"]) * strength * tint_skin_hold
    out = out * (1.0 - shadow_blend[..., None]) + np.clip(out * shadow_tint, 0.0, 1.0) * shadow_blend[..., None]
    out = out * (1.0 - highlight_blend[..., None]) + np.clip(out * highlight_tint, 0.0, 1.0) * highlight_blend[..., None]

    if profile["red_saturation"] or profile["red_luminance"]:
        out = _reduce_red_dominance(out, subject, float(profile["red_saturation"]), float(profile["red_luminance"]) * strength)

    if profile["edge_wrap_strength"]:
        edge = _edge_alpha(subject)
        edge_blend = edge * float(profile["edge_wrap_strength"]) * strength
        edge_tint = shadow_tint * 0.55 + highlight_tint * 0.45
        out = out * (1.0 - edge_blend[..., None]) + np.clip(out * edge_tint, 0.0, 1.0) * edge_blend[..., None]
    return np.clip(out, 0.0, 1.0)


def _reduce_red_dominance(rgb: np.ndarray, subject: np.ndarray, saturation_delta: float, value_delta: float) -> np.ndarray:
    if cv2 is None:
        return rgb
    hsv = cv2.cvtColor(np.clip(rgb * 255.0, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    hue = hsv[..., 0]
    sat = hsv[..., 1]
    red = (((hue < 12.0) | (hue > 168.0)) & (sat > 70.0)).astype(np.float32) * subject
    if red.max() <= 0.001:
        return rgb
    hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + saturation_delta * red), 0, 255)
    hsv[..., 2] = np.clip(hsv[..., 2] + value_delta * 255.0 * red, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32) / 255.0


def _cheap_skin_mask(rgb: np.ndarray) -> np.ndarray:
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    return (
        (r > 0.22) & (g > 0.13) & (b > 0.08)
        & ((maxc - minc) > 0.045)
        & (r > g * 1.04)
        & (r > b * 1.10)
    ).astype(np.float32)


def _rgb_luma(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _background_sample_mask(subject_mask: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    ys, xs = np.where(subject_mask)
    x1, x2 = max(0, xs.min() - w // 12), min(w, xs.max() + w // 12)
    y1, y2 = max(0, ys.min() - h // 12), min(h, ys.max() + h // 12)
    sample = np.zeros(shape, dtype=bool)
    sample[y1:y2, x1:x2] = True
    dilated = cv2.dilate(subject_mask.astype(np.uint8), np.ones((35, 35), np.uint8), iterations=1).astype(bool)
    return sample & ~dilated


def _edge_alpha(alpha: np.ndarray) -> np.ndarray:
    mask = (alpha > 0.03).astype(np.uint8)
    dilated = cv2.dilate(mask, np.ones((21, 21), np.uint8), iterations=1).astype(np.float32)
    eroded = cv2.erode(mask, np.ones((13, 13), np.uint8), iterations=1).astype(np.float32)
    edge = np.clip(dilated - eroded, 0, 1)
    edge = cv2.GaussianBlur(edge, (0, 0), 6)
    return np.clip(edge, 0, 1)


def _restore_subject_detail(source_rgb: np.ndarray, adjusted_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    if cv2 is None:
        return adjusted_rgb

    mask = (alpha > 0.14).astype(np.uint8)
    if not mask.any():
        return adjusted_rgb

    interior = cv2.erode(mask, np.ones((5, 5), np.uint8), iterations=1).astype(np.float32)
    if interior.max() <= 0:
        return adjusted_rgb
    detail_mask = cv2.GaussianBlur(interior, (0, 0), 1.1)[..., None]

    source = source_rgb.astype(np.float32)
    adjusted = adjusted_rgb.astype(np.float32)
    source_detail = source - cv2.GaussianBlur(source, (0, 0), 0.85)
    adjusted_detail = adjusted - cv2.GaussianBlur(adjusted, (0, 0), 0.85)
    missing_detail = source_detail - adjusted_detail
    amount = min(0.58, 0.22 + 0.13 * _clamp_harmonize_strength(strength))
    return np.clip(adjusted + missing_detail * (amount * detail_mask), 0, 255)
