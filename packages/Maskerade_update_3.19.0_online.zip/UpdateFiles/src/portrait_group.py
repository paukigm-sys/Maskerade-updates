"""Conservative automatic removal of an occluded rear person in small groups.

The existing matte stays authoritative. SAM2 proposes individual silhouettes;
face, body and hair anchors must survive every subtraction candidate.
No generative fill, per-file coordinates, or changes to the general cutout.
"""
from collections import OrderedDict
from contextlib import nullcontext
from pathlib import Path
import hashlib
import logging

import cv2
import numpy as np
from PIL import Image

_LOG = logging.getLogger(__name__)
_CACHE = OrderedDict()
_HAIR = None


def _hair_probability(rgb):
    """Semantic hair evidence prevents cups, clothing and hands being deleted."""
    global _HAIR
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision
    if _HAIR is None:
        path = Path(__file__).resolve().parents[1]/'models/MediaPipe/selfie_multiclass_256x256.tflite'
        _HAIR = vision.ImageSegmenter.create_from_options(vision.ImageSegmenterOptions(
            base_options=python.BaseOptions(model_asset_path=str(path)),
            running_mode=vision.RunningMode.IMAGE, output_confidence_masks=True))
    result = _HAIR.segment(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb)))
    hair = np.asarray(result.confidence_masks[1].numpy_view(), np.float32).copy()
    return cv2.resize(hair, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)


def _has_head_evidence(candidate, hair, side):
    strong = (candidate > 0) & (hair >= .35)
    _LOG.debug('Portrait hair evidence: strong=%d required=%.1f ratio=%.3f',
               strong.sum(), max(80, side*side*.07), strong.sum()/max(1, candidate.sum()))
    return np.count_nonzero(strong) >= max(80, side*side*.07) and strong.sum() >= candidate.sum()*.06


def _primary_hair_points(hair, faces):
    points = []
    h, w = hair.shape
    for cx, cy, side in faces:
        for dx, dy in ((0,-.65),(-.4,-.6),(.4,-.6),(-.45,-.2),(.45,-.2),(-.45,.6),(.45,.6),(-.5,1.1),(.5,1.1)):
            px, py = round(cx+side*dx), round(cy+side*dy)
            radius = max(1, round(side*.10))
            x0, y0 = max(0, px-radius), max(0, py-radius)
            x1, y1 = min(w, px+radius+1), min(h, py+radius+1)
            patch = hair[y0:y1, x0:x1]
            if patch.size and patch.max() >= .65:
                yy, xx = np.indices(patch.shape)
                distance = (xx+x0-cx)**2+(yy+y0-cy)**2
                distance = np.where(patch >= .65, distance, np.inf)
                yy, xx = np.unravel_index(distance.argmin(), patch.shape)
                points.append([int(xx+x0), int(yy+y0)])
    return points


def _core(shape, faces, radius=.30):
    result = np.zeros(shape, np.uint8)
    for cx, cy, side in faces:
        cv2.ellipse(result, (round(cx), round(cy)),
                    (max(1, round(side*radius)),)*2, 0, 0, 360, 1, -1)
    return result > 0


def _component(mask, point):
    """Discard unrelated islands; fill only holes of this same object."""
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    _, labels = cv2.connectedComponents(mask)
    x, y = map(round, point)
    label = labels[min(max(y, 0), mask.shape[0]-1), min(max(x, 0), mask.shape[1]-1)]
    if label == 0:
        return None
    result = (labels == label).astype(np.uint8)
    contours, _ = cv2.findContours(result, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(result, contours, -1, 1, cv2.FILLED)
    return result


def _primary_faces(detections, alpha):
    """Never discard a small confident head, or a lower child, by size alone."""
    measured = []
    unsupported = []
    for detection in detections:
        box = detection.bounding_box
        side = max(box.width, box.height)
        face = (box.origin_x+box.width*.5, box.origin_y+box.height*.5, float(side))
        support = _core(alpha.shape, [face])
        coverage = float(alpha[support].mean()) if support.any() else 0.
        if coverage < .04:
            unsupported.append(face)
        if coverage >= .04:
            measured.append((face, float(detection.categories[0].score), coverage))
    strong = [face for face, score, coverage in measured if score >= .65 and coverage >= .70]
    if not 2 <= len(strong) <= 6:
        return [], []
    side = float(np.median([face[2] for face in strong]))
    row = float(np.median([face[1] for face in strong]))
    primary, other = [], []
    for face, score, coverage in measured:
        # Only a weak, smaller head at/above the main row is a possible rear
        # anchor. All other supported detections remain protected, including
        # small heads lower in the frame (children and babies).
        rear = score < .65 and face[2] < side*.75 and face[1] < row+side*.25
        (other if rear else primary).append(face)
    return (primary, other+unsupported) if len(primary) <= 6 else ([], [])


def _body_points(face, alpha, other_faces, offsets):
    cx, cy, side = face
    h, w = alpha.shape
    points = [[cx, cy]]
    for offset in offsets:
        px, py = min(w-2, max(1, cx)), min(h-2, max(1, cy+side*offset))
        if any(abs(px-fx) < fs*.6 and abs(py-fy) < fs*.6 for fx, fy, fs in other_faces):
            continue
        if alpha[round(py), round(px)] >= .70:
            if all(np.hypot(px-x, py-y) > side*.15 for x, y in points):
                points.append([px, py])
    return points


def _residual_groups(alpha, foreground, faces):
    side = float(np.median([face[2] for face in faces]))
    row = float(np.median([face[1] for face in faces]))
    residual = ((alpha > .8) & (cv2.dilate(foreground, np.ones((7, 7), np.uint8)) == 0)).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(residual)
    parts = []
    minimum = max(side*side*.03, alpha.size*.0006)
    for label in range(1, count):
        x, y, width, height, area = stats[label]
        # Lower hands, cropped limbs and foreground objects are never cleanup
        # seeds. Residuals must fit behind the group's upper body.
        if area >= minimum and y < row+side*.75 and y+height < alpha.shape[0]*.8:
            parts.append([label])

    def nearby(a, b):
        ax, ay, aw, ah = stats[a, :4]
        bx, by, bw, bh = stats[b, :4]
        dx = max(0, max(ax, bx)-min(ax+aw, bx+bw))
        dy = max(0, max(ay, by)-min(ay+ah, by+bh))
        return dx < side*.5 and dy < side*.7

    changed = True
    while changed:
        changed = False
        for a in range(len(parts)):
            for b in range(a+1, len(parts)):
                if any(nearby(i, j) for i in parts[a] for j in parts[b]):
                    parts[a] += parts.pop(b)
                    changed = True
                    break
            if changed:
                break
    groups = []
    for part in parts:
        region = np.isin(labels, part).astype(np.uint8)
        ys, xs = np.nonzero(region)
        if (ys.max()-ys.min() < side*.8 or xs.max()-xs.min() > side*2.5
                or region.sum() < side*side*.15):
            continue
        points = []
        for label in part:
            component = (labels == label).astype(np.uint8)
            distance = cv2.distanceTransform(component, cv2.DIST_L2, 5)
            py, px = np.unravel_index(distance.argmax(), distance.shape)
            points.append([px, py])
            if stats[label, 3] > side:
                component[int(stats[label, 1]+stats[label, 3]*.4):] = 0
                distance = cv2.distanceTransform(component, cv2.DIST_L2, 5)
                py, px = np.unravel_index(distance.argmax(), distance.shape)
                points.append([px, py])
        groups.append((region, points))
    return groups[:6]


def _select_rear_candidate(masks, scores, positive, region, alpha, hair, side,
                           protected, body_prompts, foreground):
    """Rank geometric/hair-safe hypotheses before considering model score."""
    valid = []
    for raw, score in zip(masks, scores):
        if score < .20:
            continue
        candidate = _component(raw, positive[0])
        _LOG.debug('Portrait proposal: score=%.3f pixels=%s residual_coverage=%s face_overlap=%s',
            score, None if candidate is None else candidate.sum(),
            None if candidate is None else candidate[region > 0].mean(),
            None if candidate is None else candidate[protected].sum())
        if candidate is None or not alpha.size*.001 < candidate.sum() < alpha.size*.18:
            continue
        if np.count_nonzero((candidate>0)&(alpha>.1)) > region.sum()*5:
            continue
        if not _has_head_evidence(candidate, hair, side):
            continue
        if np.any(candidate[protected]) or any(candidate[round(y), round(x)] for x, y in body_prompts):
            continue
        if candidate[region > 0].mean() < .85:
            continue
        valid.append((np.count_nonzero((candidate>0)&(foreground>0)&(alpha>.5)), float(score), candidate))
    if not valid:
        return None
    return min(valid, key=lambda item: (item[0], item[2].sum(), -item[1]))[2]


def _detect(rgb, alpha):
    import mediapipe as mp
    import torch
    from .bokeh_scene import _models
    detector, (predictor, device) = _models()
    found = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))).detections
    faces, others = _primary_faces(found, alpha)
    _LOG.debug('Portrait anchors: primary=%s other=%s', faces, others)
    empty = np.zeros_like(alpha)
    if not faces:
        return empty
    all_faces = faces+others
    protected = _core(alpha.shape, faces, .38)
    foreground = np.zeros_like(alpha, np.uint8)
    body_prompts = []
    context = torch.autocast('cuda', dtype=torch.bfloat16) if device == 'cuda' else nullcontext()
    with torch.inference_mode(), context:
        predictor.set_image(rgb)
        for face in faces:
            other = [f for f in all_faces if f != face]
            positive = _body_points(face, alpha, other, (.9, 1.8, 2.7))
            if len(positive) < 3:
                return empty
            negative = [[cx, cy] for cx, cy, _ in other]
            masks, scores, _ = predictor.predict(
                point_coords=np.asarray(positive+negative, np.float32),
                point_labels=np.asarray([1]*len(positive)+[0]*len(negative)), multimask_output=True)
            valid = []
            for raw, score in zip(masks, scores):
                if score < .60:
                    continue
                candidate = _component(raw, positive[0])
                if candidate is None or not face[2]**2*3 < candidate.sum() < alpha.size*.55:
                    continue
                if any(not candidate[round(y), round(x)] for x, y in positive):
                    continue
                if np.any(candidate[_core(alpha.shape, other, .20)]):
                    continue
                if candidate[_core(alpha.shape, [face], .30)].mean() < .99:
                    continue
                valid.append(candidate)
            if not valid:
                return empty
            foreground = np.maximum(foreground, max(valid, key=lambda mask: mask.sum()))
            body_prompts += _body_points(face, alpha, [f for f in faces if f != face], (1.2, 2.5))

        exclusions = np.zeros_like(alpha, np.uint8)
        groups = _residual_groups(alpha, foreground, faces)
        if not groups:
            return empty
        hair = _hair_probability(rgb)
        side = float(np.median([face[2] for face in faces]))
        hair_points = _primary_hair_points(hair, faces)
        _LOG.debug('Portrait protected hair anchors: %s', hair_points)
        for px, py in hair_points:
            cv2.circle(protected.view(np.uint8), (px, py), max(2, round(side*.06)), 1, -1)
        for region, positive in groups:
            # A residual at the main hair cap can be a missing foreground
            # strand, not another person. Never use it as a removal prompt.
            positive = [p for p in positive if not any(
                ((p[0]-cx)/(s*.65))**2+((p[1]-cy+s*.4)/(s*.95))**2 < 1
                for cx,cy,s in faces)]
            if not positive:
                continue
            _LOG.debug('Portrait residual: pixels=%d seeds=%s', region.sum(), positive)
            nearby_hair = sorted(hair_points, key=lambda p: min(np.hypot(p[0]-x, p[1]-y) for x, y in positive))
            nearby_hair = [p for p in nearby_hair if min(np.hypot(p[0]-x, p[1]-y) for x, y in positive) < side*.9][:2]
            negative = body_prompts+nearby_hair
            masks, scores, _ = predictor.predict(
                point_coords=np.asarray(positive+negative, np.float32),
                point_labels=np.asarray([1]*len(positive)+[0]*len(negative)), multimask_output=True)
            _LOG.debug('Portrait rear scores: %s', scores)
            selected = _select_rear_candidate(masks, scores, positive, region, alpha, hair,
                                                side, protected, body_prompts, foreground)
            if selected is not None:
                exclusions = np.maximum(exclusions, selected)
    if not exclusions.any():
        return empty
    # A subtraction may leave detached flecks of the same rear silhouette.
    # Restrict cleanup to small upper remnants beside this accepted exclusion;
    # never prune the main connected people, hands, props or protected anchors.
    remainder = ((alpha > .05) & (exclusions == 0)).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(remainder)
    side = float(np.median([face[2] for face in faces]))
    row = float(np.median([face[1] for face in faces]))
    radius = max(3, round(side*.2))
    nearby = cv2.dilate(exclusions, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (radius*2+1,)*2))
    for label in range(1, count):
        x, y, width, height, area = stats[label]
        if area > alpha.size*.002 or y+height > row+side*.95:
            continue
        region = labels == label
        if not protected[region].any() and nearby[region].mean() > .65:
            exclusions[region] = 1
    # Do not dilate: growing an exclusion can eat the neighbouring person's
    # hair. Subpixel feathering blends the existing boundary only.
    softened = cv2.GaussianBlur(exclusions.astype(np.float32), (0, 0), .6)
    softened[protected] = 0
    _LOG.info('Automatic rear-person refinement: primary_faces=%d removed_pixels=%d',
              len(faces), np.count_nonzero((softened>.5)&(alpha>.1)))
    return softened


def portrait_exclusion(source, alpha, *, alpha_floor=0.0):
    """Return only a validated exclusion; uncertainty returns an empty mask."""
    h, w = alpha.shape
    if min(h, w) < 320 or max(h, w) < 480 or not np.isfinite(alpha).all():
        return np.zeros_like(alpha)
    scale = min(1.,1100/max(h, w))
    size = (round(w*scale), round(h*scale))
    rgb = np.asarray(Image.fromarray(np.asarray(source, np.uint8)).resize(size, Image.Resampling.LANCZOS)).copy()
    small_alpha = np.asarray(Image.fromarray(np.rint(np.clip(alpha,0,1)*255).astype('uint8')).resize(
        size, Image.Resampling.LANCZOS),np.float32)/255
    if alpha_floor:
        small_alpha=np.clip((small_alpha-alpha_floor)/(1-alpha_floor),0,1)
    key = hashlib.sha256(rgb.tobytes()+np.rint(small_alpha*255).astype(np.uint8).tobytes()).digest()
    # SAM2's current image embedding is mutable and shared with table selection.
    from .bokeh_scene import _LOCK
    with _LOCK:
        if key not in _CACHE:
            try:
                _CACHE[key] = _detect(rgb, small_alpha)
            except Exception:
                _LOG.exception('Portrait group selection unavailable; retaining validated foreground')
                _CACHE[key] = np.zeros_like(small_alpha)
            while len(_CACHE) > 8:
                _CACHE.popitem(last=False)
        _CACHE.move_to_end(key)
        removed = cv2.resize(_CACHE[key], (w, h), interpolation=cv2.INTER_LINEAR)
    return removed


def refine_portrait_group(source, alpha):
    """Keep the input on uncertainty/failure; preserve opaque primary RGB."""
    return np.minimum(alpha, 1-portrait_exclusion(source, alpha))


def prepare_portrait_exclusion(image, mask):
    """Compute once from the full source, independently of preview/blur size."""
    if min(image.size)<320:
        return None
    canonical=image.convert('RGB')
    canonical.thumbnail((1100,1100),Image.Resampling.BICUBIC)
    # Match the automatic foreground/table guards at a fixed source scale.
    # This call has no selection metadata, so it cannot recurse into refinement.
    from .background_bokeh import background_bokeh
    try:
        _,base=background_bokeh(canonical,mask.convert('L').resize(canonical.size,Image.Resampling.LANCZOS),
                                35,alpha_floor=.65,style='black')
    except ValueError:
        return None
    alpha=np.asarray(base,np.float32)/255
    removed=portrait_exclusion(np.asarray(canonical),alpha)
    if not removed.any():
        return None
    return Image.fromarray(np.rint(np.clip(removed,0,1)*255).astype('uint8')).resize(image.size,Image.Resampling.BILINEAR)


def resize_portrait_subject(subject, size):
    """Resize pixels and the corresponding selection metadata together."""
    result=subject.resize(size,Image.Resampling.LANCZOS) if subject.size!=size else subject.copy()
    exclusion=subject.info.get('portrait_exclusion')
    if exclusion is not None:
        result.info['portrait_exclusion']=exclusion.resize(size,Image.Resampling.BILINEAR)
    return result
