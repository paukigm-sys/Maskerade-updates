"""Clean the legacy Puli code line at its fixed location before composition.

Validate the whole text line rather than requiring seven disconnected glyphs:
JPEG joins letters and reuploads can produce overlapping or fragmented codes.
"""
from __future__ import annotations
import logging
import numpy as np
from PIL import Image


def _code_bounds(crop: np.ndarray, w: int, h: int, x0: int, y0: int):
    import cv2
    neutral=(crop.min(axis=2)>170)&(np.ptp(crop,axis=2)<55)
    _,_,stats,_=cv2.connectedComponentsWithStats(neutral.astype(np.uint8))
    candidates=[]
    for x,y,cw,ch,area in stats[1:]:
        if (.011*h<=ch<=.022*h and .001*w<=cw<=.10*w
                and area>=.12*cw*ch and .932*h<=y0+y<=.94*h):
            candidates.append(tuple(int(v) for v in (x,y,cw,ch,area)))
    candidates.sort()
    for start in range(len(candidates)):
        first=candidates[start]
        if not .87*w<=x0+first[0]<=.895*w:
            continue
        group=[first]
        right=first[0]+first[2]
        for item in candidates[start+1:]:
            x,y,cw,ch,area=item
            if x-right>max(4,w*.008) or abs(y-first[1])>max(2,h*.002):
                break
            group.append(item);right=max(right,x+cw)
        left=first[0];top=min(c[1] for c in group)
        bottom=max(c[1]+c[3] for c in group)
        density=sum(c[4] for c in group)/max(1,(right-left)*(bottom-top))
        if (.925*w<=x0+right<=.958*w and .045*w<=right-left<=.09*w
                and max(c[3] for c in group)-min(c[3] for c in group)<=max(2,h*.005)
                and .15<=density<=.85):
            return left,top,right,bottom
    return None


def remove_puli_code(image: Image.Image) -> Image.Image:
    # A physically rotated portrait (EXIF already applied) places the same
    # sideways stamp at top right. Normalize only for detection and repair.
    if image.width<image.height:
        landscape=image.transpose(Image.Transpose.ROTATE_270)
        cleaned=remove_puli_code(landscape)
        if cleaned is landscape:
            return image
        return cleaned.transpose(Image.Transpose.ROTATE_90)
    w,h=image.size
    if w<=h or h<480:
        return image
    import cv2
    rgb=np.asarray(image.convert('RGB'))
    x0,y0=int(w*.84),int(h*.925)
    crop=rgb[y0:int(h*.965),x0:int(w*.975)]
    bounds=_code_bounds(crop,w,h,x0,y0)
    if bounds is None:
        return image
    left,top,right,bottom=bounds
    radius=max(2,round(h*.0033))
    mask=np.zeros(crop.shape[:2],np.uint8)
    # Include all strokes/fragments of the identified line, including pieces
    # too small to qualify as glyphs. Close gaps and cover black outlines.
    neutral=(crop.min(axis=2)>170)&(np.ptp(crop,axis=2)<55)
    mask[top:bottom,left:right]=neutral[top:bottom,left:right].astype(np.uint8)*255
    mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    mask=cv2.dilate(mask,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,radius*2+1)))
    cleaned=cv2.inpaint(crop,mask,max(3,round(h*.003)),cv2.INPAINT_NS)
    result=rgb.copy()
    result[y0:y0+crop.shape[0],x0:x0+crop.shape[1]]=cleaned
    logging.getLogger(__name__).info('Removed legacy Puli code line (%sx%s)',w,h)
    return Image.fromarray(result)
