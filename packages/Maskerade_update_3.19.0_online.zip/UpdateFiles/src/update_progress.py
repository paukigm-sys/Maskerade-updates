"""Best-effort installer telemetry; never alter installation success or failure."""
import os
from pathlib import Path


def report(phase: str, completed: int, total: int) -> None:
    destination = os.environ.get("MASKERADE_UPDATE_PROGRESS")
    if not destination or total <= 0:
        return
    percent = max(0, min(100, completed * 100 // total))
    path = Path(destination)
    temporary = path.with_name(path.name + "." + str(os.getpid()) + ".tmp")
    try:
        temporary.write_text(f"{phase}|{percent}", encoding="ascii")
        os.replace(temporary, path)
    except OSError:
        # A closed splash or a busy status file must not interrupt migration.
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass
