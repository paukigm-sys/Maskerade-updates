from __future__ import annotations

import logging
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont

from .config import ContactShadowSettings, OverlaySettings, ParkSettings, PersonPlacementSettings, TextLayerSettings
from .harmonizer import harmonize_composited_subject, harmonize_subject_layer
from .image_utils import LANCZOS, alpha_composite_at, resize_cover


@dataclass(frozen=True)
class PreparedCompositionAssets:
    background: Image.Image
    background_source_size: tuple[int, int]
    output_size: tuple[int, int]
    overlay: Image.Image | None = None
    overlay_xy: tuple[int, int] = (0, 0)
    logo: Image.Image | None = None
    logo_xy: tuple[int, int] = (0, 0)


def apply_background_brightness(image: Image.Image, brightness: float | int | None) -> Image.Image:
    try:
        factor = float(brightness if brightness is not None else 1.0)
    except (TypeError, ValueError):
        factor = 1.0
    factor = max(0.5, min(2.5, factor))
    if abs(factor - 1.0) < 0.001:
        return image
    return ImageEnhance.Brightness(image).enhance(factor)


def compose_image(
    original: Image.Image,
    person_rgba: Image.Image | None,
    park: ParkSettings,
    logger: logging.Logger | None = None,
    apply_harmonize: bool = True,
    prepared_assets: PreparedCompositionAssets | None = None,
    prepared_subject_canvas: Image.Image | None = None,
) -> Image.Image:
    logger = logger or logging.getLogger(__name__)
    assets = prepared_assets or prepare_composition_assets(original, park, logger=logger)
    background = assets.background
    output_size = assets.output_size
    canvas = background.convert("RGBA")
    from .mask_correction import INFO_KEY, corrected_subject
    correction = person_rgba.info.get(INFO_KEY) if person_rgba is not None else None
    if correction is not None and not park.background_bokeh:
        person_rgba = corrected_subject(person_rgba)
        prepared_subject_canvas = None

    if getattr(park, "background_bokeh", 0) > 0:
        if person_rgba is None:
            raise ValueError("Bokeh requires the final subject mask")
        from .background_bokeh import background_bokeh
        exclusion = person_rgba.info.get("portrait_exclusion")
        blurred, _ = background_bokeh(original, person_rgba.getchannel("A"),
                                      park.background_bokeh, alpha_floor=0.65,
                                      lights=True, style=park.background_bokeh_style,
                                      **({"portrait_exclusion": exclusion} if exclusion is not None else {}),
                                      **({"correction": correction} if correction is not None else {}))
        canvas = blurred.convert("RGBA")
    elif person_rgba is not None:
        subject_canvas = prepared_subject_canvas or _prepare_subject_canvas(person_rgba, park, output_size)
        if apply_harmonize and park.harmonize_strength > 0:
            subject_canvas = harmonize_subject_layer(background, subject_canvas, park.harmonize_strength)
        _apply_contact_shadow(canvas, subject_canvas, park.contact_shadow)
        alpha_composite_at(canvas, subject_canvas, (0, 0))

    if assets.overlay is not None:
        alpha_composite_at(canvas, assets.overlay, assets.overlay_xy)

    if assets.logo is not None:
        alpha_composite_at(canvas, assets.logo, assets.logo_xy)

    _apply_text_layer(canvas, park.text_layer)

    return canvas.convert("RGB")


def harmonize_composed_image(
    image: Image.Image,
    original: Image.Image,
    person_rgba: Image.Image | None,
    park: ParkSettings,
    logger: logging.Logger | None = None,
    prepared_assets: PreparedCompositionAssets | None = None,
    prepared_subject_canvas: Image.Image | None = None,
) -> Image.Image:
    logger = logger or logging.getLogger(__name__)
    if getattr(park, "background_bokeh", 0) > 0 or person_rgba is None or park.background_path is None or park.harmonize_strength <= 0:
        return image.convert("RGB")
    try:
        assets = prepared_assets or prepare_composition_assets(original, park, logger=logger)
        from .mask_correction import INFO_KEY, corrected_subject
        if person_rgba.info.get(INFO_KEY) is not None:
            person_rgba = corrected_subject(person_rgba)
            prepared_subject_canvas = None
        subject_canvas = prepared_subject_canvas or _prepare_subject_canvas(person_rgba, park, assets.output_size)
        background = assets.background
        return harmonize_composited_subject(background, image, subject_canvas, park.harmonize_strength)
    except Exception as exc:
        logger.warning("Late harmonize failed; keeping enhanced composite: %s", exc)
        return image.convert("RGB")


def prepare_composition_assets(
    original: Image.Image,
    park: ParkSettings,
    logger: logging.Logger | None = None,
) -> PreparedCompositionAssets:
    logger = logger or logging.getLogger(__name__)
    background, background_source_size, output_size = _prepare_scene_background(original, park)
    overlay: Image.Image | None = None
    overlay_xy = (0, 0)
    logo: Image.Image | None = None
    logo_xy = (0, 0)

    if park.overlay_path:
        if park.overlay_path.exists():
            with Image.open(park.overlay_path) as overlay_source:
                overlay, overlay_xy = prepare_overlay_layer(
                    overlay_source.convert("RGBA"),
                    park.overlay_settings,
                    output_size,
                    background_source_size,
                )
        else:
            logger.info("Overlay not found, skipping: %s", park.overlay_path)

    if park.logo_path:
        if park.logo_path.exists():
            logo_settings = _map_settings_from_background(
                park.logo_settings,
                output_size,
                background_source_size,
            )
            with Image.open(park.logo_path) as logo_source:
                logo, logo_xy = prepare_overlay_layer(
                    logo_source.convert("RGBA"),
                    logo_settings,
                    output_size,
                    background_source_size,
                )
        else:
            logger.info("Logo not found, skipping: %s", park.logo_path)

    return PreparedCompositionAssets(
        background=background,
        background_source_size=background_source_size,
        output_size=output_size,
        overlay=overlay,
        overlay_xy=overlay_xy,
        logo=logo,
        logo_xy=logo_xy,
    )


def prepare_subject_canvas(
    person_rgba: Image.Image,
    park: ParkSettings,
    output_size: tuple[int, int],
) -> Image.Image:
    return _prepare_subject_canvas(person_rgba, park, output_size)


def _prepare_scene_background(
    original: Image.Image,
    park: ParkSettings,
) -> tuple[Image.Image, tuple[int, int], tuple[int, int]]:
    if park.background_path is None or getattr(park, "background_bokeh", 0) > 0:
        output_size = original.size
        background_source_size = original.size
        background = original.convert("RGB")
    else:
        with Image.open(park.background_path) as background_source_raw:
            background_source = background_source_raw.convert("RGB")
        background_source_size = background_source.size
        output_size = _target_size(original, park.output_size, background_source_size)
        background = resize_cover(background_source, output_size).convert("RGB")
        background = apply_background_brightness(background, park.background_brightness).convert("RGB")
    return background, background_source_size, output_size


def _prepare_subject_canvas(
    person_rgba: Image.Image,
    park: ParkSettings,
    output_size: tuple[int, int],
) -> Image.Image:
    subject = _prepare_subject(person_rgba, park.person, output_size)
    left, top = _placement_for(subject.size, park.person)
    subject_canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    alpha_composite_at(subject_canvas, subject, (left, top))
    return subject_canvas


def _apply_text_layer(canvas: Image.Image, settings: TextLayerSettings) -> None:
    text = (settings.text or "").strip()
    if not settings.enabled or not text:
        return

    out_w, out_h = canvas.size
    draw = ImageDraw.Draw(canvas)
    base_size = max(18, int(round(out_w * 0.065 * max(0.35, min(3.0, float(settings.scale))))))
    font = _load_text_font(base_size, getattr(settings, "font", "Segoe UI"))

    max_width = int(out_w * 0.88)
    while base_size > 16:
        bbox = draw.textbbox((0, 0), text, font=font, stroke_width=max(2, base_size // 18))
        if bbox[2] - bbox[0] <= max_width:
            break
        base_size -= 2
        font = _load_text_font(base_size, getattr(settings, "font", "Segoe UI"))

    stroke = max(2, base_size // 18)
    bbox = draw.textbbox((0, 0), text, font=font, stroke_width=stroke)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    color = _parse_hex_color(settings.color, (255, 255, 255, 255))

    pad = max(8, stroke * 4)
    text_image = Image.new("RGBA", (text_w + pad * 2, text_h + pad * 2), (0, 0, 0, 0))
    text_draw = ImageDraw.Draw(text_image)
    text_draw.text(
        (pad - bbox[0], pad - bbox[1]),
        text,
        font=font,
        fill=color,
        stroke_width=stroke,
        stroke_fill=(0, 0, 0, 190),
    )
    rotation = max(-180.0, min(180.0, float(getattr(settings, "rotation", 0.0) or 0.0)))
    if abs(rotation) > 0.01:
        text_image = text_image.rotate(rotation, resample=Image.Resampling.BICUBIC, expand=True)

    center_x = out_w / 2.0 + int(settings.x)
    center_y = out_h * 0.065 + int(settings.y) + text_h / 2.0
    x = int(round(center_x - text_image.width / 2.0))
    y = int(round(center_y - text_image.height / 2.0))
    alpha_composite_at(canvas, text_image, (x, y))


def _load_text_font(size: int, font_name: str = "Segoe UI") -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    font_files = {
        "segoe ui": "segoeuib.ttf",
        "arial": "arialbd.ttf",
        "calibri": "calibrib.ttf",
        "impact": "impact.ttf",
        "times new roman": "timesbd.ttf",
        "georgia": "georgiab.ttf",
        "verdana": "verdanab.ttf",
        "tahoma": "tahomabd.ttf",
        "courier new": "courbd.ttf",
        "comic sans ms": "comicbd.ttf",
        "bahnschrift": "bahnschrift.ttf",
    }
    selected = font_files.get(str(font_name or "Segoe UI").strip().lower(), "segoeuib.ttf")
    candidates = [
        Path("C:/Windows/Fonts") / selected,
        Path("C:/Windows/Fonts/segoeuib.ttf"),
        Path("C:/Windows/Fonts/arialbd.ttf"),
        Path("C:/Windows/Fonts/calibrib.ttf"),
    ]
    for path in candidates:
        try:
            if path.exists():
                return ImageFont.truetype(str(path), size=size)
        except Exception:
            pass
    try:
        return ImageFont.truetype("DejaVuSans-Bold.ttf", size=size)
    except Exception:
        return ImageFont.load_default()


def _parse_hex_color(value: str, fallback: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    raw = (value or "").strip().lstrip("#")
    if len(raw) not in {6, 8}:
        return fallback
    try:
        r = int(raw[0:2], 16)
        g = int(raw[2:4], 16)
        b = int(raw[4:6], 16)
        a = int(raw[6:8], 16) if len(raw) == 8 else 255
        return (r, g, b, a)
    except ValueError:
        return fallback


def _apply_contact_shadow(
    canvas: Image.Image,
    subject_canvas: Image.Image,
    settings: ContactShadowSettings,
) -> None:
    if not settings.enabled or settings.strength <= 0:
        return

    canvas_size = canvas.size
    out_w, out_h = canvas_size
    max_side = max(out_w, out_h)
    work_scale = min(1.0, 1200.0 / max(1, max_side))
    work_size = (
        max(1, int(round(out_w * work_scale))),
        max(1, int(round(out_h * work_scale))),
    )
    if work_scale < 0.999:
        alpha = subject_canvas.getchannel("A").resize(work_size, Image.Resampling.BILINEAR)
    else:
        alpha = subject_canvas.getchannel("A")

    solid_alpha = alpha.point(lambda value: 255 if value > 32 else 0)
    bbox = solid_alpha.getbbox()
    if not bbox:
        return

    out_w, out_h = work_size
    left, top, right, bottom = bbox
    subject_w = max(1, right - left)
    subject_h = max(1, bottom - top)
    strength = max(0.0, min(2.0, float(settings.strength)))
    slider_curve = (min(strength, 1.0) * 1.35) ** 0.65
    above_100 = max(0.0, strength - 1.0)
    broad_strength = min(1.05, slider_curve * 0.48 + above_100 * 0.28)
    contact_mask_strength = min(1.85, min(1.0, slider_curve * 1.08) + above_100 * 0.68)

    base_floor_y = bottom + out_h * float(settings.y_offset_ratio)
    center_x = int(round((left + right) / 2))
    broad_w = max(8, int(round(subject_w * max(0.1, float(settings.width_ratio)) * 0.34 * (1.0 + above_100 * 0.03))))
    broad_h = max(4, int(round(out_h * max(0.002, float(settings.height_ratio)) * 0.20 * (1.0 + above_100 * 0.02))))
    floor_y = max(0, min(out_h - 1, int(round(base_floor_y - broad_h * 0.72))))

    shadow_mask = Image.new("L", work_size, 0)
    draw = ImageDraw.Draw(shadow_mask)
    draw.ellipse(
        (
            center_x - broad_w // 2,
            floor_y - broad_h // 2,
            center_x + broad_w // 2,
            floor_y + broad_h // 2,
        ),
        fill=min(255, int(round(42 * broad_strength * (1.0 + above_100 * 0.70)))),
    )
    blur = max(0, int(round(out_w * max(0.0, float(settings.blur_ratio)))))
    if blur > 0:
        shadow_mask = shadow_mask.filter(ImageFilter.GaussianBlur(blur))

    contact = _build_contact_shadow_from_feet(
        solid_alpha,
        bbox,
        output_size=work_size,
        strength=contact_mask_strength,
        contact_strength=max(0.0, min(2.4, float(settings.contact_strength))),
        spread_strength=strength,
    )
    shadow_mask = ImageChops.lighter(shadow_mask, contact)
    boost = 1.0 + broad_strength * 0.05 + above_100 * 0.28
    shadow_mask = shadow_mask.point(lambda value: min(255, int(round(value * boost))))
    if shadow_mask.size != canvas_size:
        shadow_mask = shadow_mask.resize(canvas_size, Image.Resampling.BILINEAR)

    shadow = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    shadow.putalpha(shadow_mask)
    canvas.alpha_composite(shadow)


def _build_contact_shadow_from_feet(
    solid_alpha: Image.Image,
    bbox: tuple[int, int, int, int],
    output_size: tuple[int, int],
    strength: float,
    contact_strength: float,
    spread_strength: float = 1.0,
    _split_components: bool = True,
    _include_secondary: bool = True,
) -> Image.Image:
    out_w, out_h = output_size
    left, top, right, bottom = bbox
    subject_w = max(1, right - left)
    subject_h = max(1, bottom - top)
    arr = np.asarray(solid_alpha.crop(bbox))
    if arr.size == 0:
        return Image.new("L", output_size, 0)

    lower_start = int(subject_h * 0.50)
    lower = arr[lower_start:, :]
    cols = np.where(lower > 0)[1]
    if cols.size == 0:
        return Image.new("L", output_size, 0)

    profile = np.full(subject_w, -1, dtype=np.int32)
    occupied = lower > 0
    present = occupied.any(axis=0)
    profile[present] = subject_h - 1 - np.argmax(occupied[::-1, present], axis=0)

    valid = profile >= 0
    valid_x = np.where(valid)[0]
    if valid_x.size < 3:
        return Image.new("L", output_size, 0)

    lowest_support_y = int(profile[valid_x].max())
    # Each support has its own depth. A shared band measured from the lowest
    # shoe excluded rear shoes and shorter people in a group.
    foot_min_y = int(subject_h * 0.60)
    # Suppress coat hems and the underside of shorts using nearby deeper
    # silhouette support. The distance penalty keeps a higher rear shoe rather
    # than comparing every person to the lowest shoe in the whole photograph.
    local_floor = profile.astype(np.float32)
    for col in range(1, subject_w):
        local_floor[col] = max(local_floor[col], local_floor[col - 1] - 1.8)
    for col in range(subject_w - 2, -1, -1):
        local_floor[col] = max(local_floor[col], local_floor[col + 1] - 1.8)
    foot_x = valid_x[(profile[valid_x] >= foot_min_y) &
                     (profile[valid_x] >= local_floor[valid_x] - max(3, out_h * 0.025))]
    if foot_x.size < 3:
        return Image.new("L", output_size, 0)

    # Several broad silhouettes ending on exactly the same scanline usually
    # indicate a photograph cropped through the legs, rather than visible soles.
    # A tight contact there would draw a dark underline across the cut edges.
    shared_cut = np.count_nonzero(profile[foot_x] >= lowest_support_y - 1)
    if shared_cut > foot_x.size * 0.60 and shared_cut > subject_w * 0.35:
        return Image.new("L", output_size, 0)

    secondary = Image.new("L", output_size, 0)
    if _include_secondary:
        import cv2

        # A broom may connect to the person through its handle. Components alone
        # then still hide the shoe above it. Keep supported lower contours with
        # a real transparent gap beneath them, separately from the last contour.
        binary = (arr > 0).astype(np.uint8)
        gap = max(4, int(round(out_h * 0.018)))
        run = max(3, int(round(out_h * 0.006)))
        integral = np.pad(np.cumsum(binary, axis=0, dtype=np.int32), ((1, 0), (0, 0)))
        yy = np.arange(subject_h)[:, None]
        below = integral[np.minimum(subject_h, np.arange(subject_h) + gap + 1)] - integral[1:]
        above = integral[1:] - integral[np.maximum(0, np.arange(subject_h) - run + 1)]
        edges = ((binary > 0) & (below == 0) & (above >= run) &
                 (yy >= subject_h * 0.74) & (yy < subject_h - gap) &
                 (profile[None, :] - yy > gap * 1.5))
        if edges.any():
            grouped = cv2.dilate(edges.astype(np.uint8), np.ones((3, 5), np.uint8))
            count, labels, stats, _ = cv2.connectedComponentsWithStats(grouped, 8)
            for component in range(1, count):
                x, y, width, height, _ = stats[component]
                if width < max(5, subject_w * 0.006) or width > max(subject_w * 0.25, out_h * 0.22) or height > out_h * 0.10:
                    continue
                rows, cols = np.where(edges & (labels == component))
                if cols.size < max(4, subject_w * 0.004):
                    continue
                layer = Image.new("L", output_size, 0)
                draw = ImageDraw.Draw(layer)
                for row, col in zip(rows, cols):
                    draw.line((left + int(col), top + int(row) - run,
                               left + int(col), top + int(row)), fill=255)
                part = _build_contact_shadow_from_feet(
                    layer, bbox, output_size, strength, contact_strength,
                    spread_strength, _split_components=False, _include_secondary=False)
                secondary = ImageChops.lighter(secondary, part)

    if _split_components:
        import cv2

        # A prop below a shoe in the same columns must not replace that shoe's
        # floor. Work on separate lower silhouettes, keeping the original
        # subject coordinates and thresholds for every component.
        foreground = (arr > 0).astype(np.uint8)
        foreground[:foot_min_y] = 0
        count, labels, stats, _ = cv2.connectedComponentsWithStats(foreground, 8)
        minimum_area = max(6, int(round(out_w * out_h * 0.000015)))
        components = [i for i in range(1, count) if stats[i, cv2.CC_STAT_AREA] >= minimum_area]
        if len(components) > 1:
            combined = secondary
            for component in sorted(components, key=lambda i: stats[i, cv2.CC_STAT_AREA], reverse=True)[:64]:
                layer = Image.new("L", output_size, 0)
                layer.paste(Image.fromarray((labels == component).astype(np.uint8) * 255), (left, top))
                part = _build_contact_shadow_from_feet(
                    layer, bbox, output_size, strength, contact_strength,
                    spread_strength, _split_components=False, _include_secondary=False)
                combined = ImageChops.lighter(combined, part)
            return combined

    cast_values = np.zeros((out_h, out_w), dtype=np.uint8)
    soft_mask = Image.new("L", output_size, 0)
    core_mask = Image.new("L", output_size, 0)
    soft_draw = ImageDraw.Draw(soft_mask)
    core_draw = ImageDraw.Draw(core_mask)
    max_gap = max(3, subject_w // 140)
    min_segment = max(2, int(round(subject_w * 0.005)))
    max_segment = max(min_segment + 1, int(round(subject_w * 0.080)))
    foot_band = max(6, int(round(out_h * 0.028)))
    spread = 0.88 + 0.34 * max(0.0, min(2.0, spread_strength))
    blob_h = max(5, int(round(out_h * 0.026 * spread)))
    # Keep a narrow occlusion at the actual sole, then a much softer falloff.
    # The previous lifted, uniformly filled projection hid the contact itself.
    core_h = max(1.2, out_h * 0.0034 * spread)
    cast_len = max(10, int(round(out_h * 0.080 * spread)))
    soft_fill = min(175, int(98 * strength * contact_strength))
    cast_fill = min(205, int(118 * strength * contact_strength))
    core_fill = min(220, int(145 * strength * contact_strength))

    # Split at depth changes before measuring the local sole. Otherwise one
    # front shoe can suppress the rear shoe in the same horizontal chunk.
    depth_jump = max(4, int(round(out_h * 0.018)))
    breaks = np.where((np.diff(foot_x) > max_gap) |
                      (np.abs(np.diff(profile[foot_x])) > depth_jump))[0]
    starts = np.concatenate(([0], breaks + 1))
    ends = np.concatenate((breaks, [foot_x.size - 1]))
    support_segments = [(int(foot_x[start]), int(foot_x[end]))
                        for start, end in zip(starts, ends)
                        if foot_x[end] - foot_x[start] + 1 >= min_segment]
    if not support_segments:
        return Image.new("L", output_size, 0)

    widest_support = max(end - start + 1 for start, end in support_segments)
    min_real_support = max(min_segment, int(round(widest_support * 0.055)))

    for start, end in support_segments:
        if end - start + 1 < min_real_support:
            continue
        for chunk_start in range(start, end + 1, max_segment):
            chunk_end = min(end, chunk_start + max_segment - 1)
            chunk = np.arange(chunk_start, chunk_end + 1)
            segment_floor_y = max(foot_min_y, int(profile[chunk].max()) - foot_band)
            chunk = chunk[profile[chunk] >= segment_floor_y]
            if chunk.size < min_segment:
                continue

            local_x = int(round(float(np.median(chunk))))
            local_y = int(round(float(np.percentile(profile[chunk], 98))))
            foot_span = chunk_end - chunk_start + 1
            width = max(int(round(out_h * 0.032 * spread)), int(round(foot_span * (1.30 + spread * 0.20))))
            x = left + local_x
            y = top + local_y + 1

            # Follow each supported column, including shoes at different depths.
            # Do not bridge the empty floor between shoes with an opaque line.
            for col in chunk:
                sole_y = top + int(profile[col]) + 1
                for dy in range(-int(core_h), int(round(core_h * 3)) + 1):
                    opacity = int(core_fill * np.exp(-0.5 * ((dy - core_h * 0.35) / core_h) ** 2))
                    core_draw.point((left + int(col), sole_y + dy), fill=opacity)

            # Union feathered local projections. Drawing one filled stripe over
            # another used to overwrite overlaps and leave stepped dark edges.
            local_cast_len = max(out_h * 0.012, min(cast_len, width * 0.40))
            x0, x1 = max(0, x - width), min(out_w, x + width + 1)
            y0 = max(0, int(y - local_cast_len * 0.8))
            y1 = min(out_h, int(y + local_cast_len * 1.5) + 1)
            if x0 < x1 and y0 < y1:
                yy, xx = np.ogrid[y0:y1, x0:x1]
                dx = (xx - x) / max(2.0, width * 0.48)
                dy = (yy - y - local_cast_len * 0.10) / max(2.0, local_cast_len * 0.40)
                patch = np.rint(cast_fill * np.exp(-0.5 * (dx * dx + dy * dy))).astype(np.uint8)
                np.maximum(cast_values[y0:y1, x0:x1], patch, out=cast_values[y0:y1, x0:x1])
            soft_draw.ellipse(
                (
                    x - width // 2,
                    y - int(blob_h * 0.35),
                    x + width // 2,
                    y + int(blob_h * 0.85),
                ),
                fill=soft_fill,
            )

    core_mask = core_mask.filter(ImageFilter.GaussianBlur(max(0.6, out_h * 0.0008)))
    cast_mask = Image.fromarray(cast_values)
    soft_mask = soft_mask.filter(ImageFilter.GaussianBlur(max(1.5, blob_h * 0.36)))
    return ImageChops.lighter(secondary, ImageChops.lighter(core_mask, ImageChops.lighter(cast_mask, soft_mask)))


def _contiguous_segments(values: np.ndarray, max_gap: int) -> list[tuple[int, int]]:
    if values.size == 0:
        return []
    values = np.asarray(sorted(set(int(value) for value in values)), dtype=np.int32)
    breaks = np.where(np.diff(values) > max_gap)[0]
    starts = np.concatenate(([0], breaks + 1))
    ends = np.concatenate((breaks, [values.size - 1]))
    return [(int(values[start]), int(values[end])) for start, end in zip(starts, ends)]


def _target_size(
    original: Image.Image,
    configured_size: tuple[int, int] | str,
    background_size: tuple[int, int] | None = None,
) -> tuple[int, int]:
    if isinstance(configured_size, str):
        if configured_size.lower() in {"background", "selected_background", "fondo"}:
            if background_size is not None:
                return background_size
            return original.size
        if configured_size.lower() in {"input", "original", "source", "same_as_input"}:
            return original.size
        raise ValueError(f"Unsupported output_size value: {configured_size}")
    return configured_size


def _prepare_subject(
    subject: Image.Image,
    placement: PersonPlacementSettings,
    output_size: tuple[int, int],
) -> Image.Image:
    subject = subject.convert("RGBA")
    if placement.anchor.lower() in {"original", "source", "source_canvas"}:
        return _fit_source_canvas(subject, output_size, placement.scale, placement.x, placement.y)

    subject = _crop_to_alpha(subject)

    max_w = max(1, int(output_size[0] * placement.max_width_ratio))
    max_h = max(1, int(output_size[1] * placement.max_height_ratio))
    fit = min(max_w / subject.width, max_h / subject.height)
    scale = max(0.01, fit * placement.scale)
    new_size = (
        max(1, int(subject.width * scale)),
        max(1, int(subject.height * scale)),
    )
    return _sharpen_resized_subject(subject.resize(new_size, LANCZOS), scale)


def _fit_source_canvas(
    subject: Image.Image,
    output_size: tuple[int, int],
    scale: float,
    offset_x_percent: int = 0,
    offset_y_percent: int = 0,
) -> Image.Image:
    out_w, out_h = output_size
    if out_w <= 0 or out_h <= 0:
        return subject

    fit = min(out_w / max(1, subject.width), out_h / max(1, subject.height))
    scale = max(0.2, min(2.0, float(scale or 1.0)))
    resize_scale = fit * scale
    fitted = subject.resize(
        (
            max(1, int(round(subject.width * resize_scale))),
            max(1, int(round(subject.height * resize_scale))),
        ),
        LANCZOS,
    )
    fitted = _sharpen_resized_subject(fitted, resize_scale)
    canvas = Image.new("RGBA", output_size, (0, 0, 0, 0))
    x = int(round((out_w - fitted.width) / 2 + (out_w * float(offset_x_percent or 0) / 100.0)))
    y = int(round((out_h - fitted.height) / 2 + (out_h * float(offset_y_percent or 0) / 100.0)))
    alpha_composite_at(canvas, fitted, (x, y))
    return canvas


def _scale_source_canvas(subject: Image.Image, scale: float, offset_x_percent: int = 0, offset_y_percent: int = 0) -> Image.Image:
    scale = max(0.2, min(2.0, float(scale or 1.0)))
    if abs(scale - 1.0) < 0.001:
        return subject

    width, height = subject.size
    scaled = subject.resize(
        (max(1, int(round(width * scale))), max(1, int(round(height * scale)))),
        LANCZOS,
    )
    scaled = _sharpen_resized_subject(scaled, scale)
    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    x = int(round((width - scaled.width) / 2 + (width * float(offset_x_percent or 0) / 100.0)))
    y = int(round((height - scaled.height) / 2 + (height * float(offset_y_percent or 0) / 100.0)))
    alpha_composite_at(canvas, scaled, (x, y))
    return canvas


def _crop_to_alpha(image: Image.Image) -> Image.Image:
    alpha = image.getchannel("A")
    bbox = alpha.getbbox()
    if not bbox:
        return image

    pad_x = max(8, int((bbox[2] - bbox[0]) * 0.025))
    pad_y = max(8, int((bbox[3] - bbox[1]) * 0.025))
    left = max(0, bbox[0] - pad_x)
    top = max(0, bbox[1] - pad_y)
    right = min(image.width, bbox[2] + pad_x)
    bottom = min(image.height, bbox[3] + pad_y)
    return image.crop((left, top, right, bottom))


def _sharpen_resized_subject(subject: Image.Image, scale: float) -> Image.Image:
    if abs(float(scale or 1.0) - 1.0) < 0.003:
        return subject
    alpha = subject.getchannel("A")
    sharpened_rgb = subject.convert("RGB").filter(
        ImageFilter.UnsharpMask(radius=0.55, percent=85, threshold=2)
    )
    result = sharpened_rgb.convert("RGBA")
    result.putalpha(alpha)
    return result


def _placement_for(
    subject_size: tuple[int, int],
    placement: PersonPlacementSettings,
) -> tuple[int, int]:
    width, height = subject_size
    anchor = placement.anchor.lower()

    if anchor in {"original", "source", "source_canvas"}:
        return 0, 0
    if anchor == "bottom_center":
        return int(placement.x - width / 2), int(placement.y - height)
    if anchor == "center":
        return int(placement.x - width / 2), int(placement.y - height / 2)
    if anchor == "top_left":
        return int(placement.x), int(placement.y)
    if anchor == "bottom_left":
        return int(placement.x), int(placement.y - height)
    if anchor == "bottom_right":
        return int(placement.x - width), int(placement.y - height)

    raise ValueError(f"Unsupported person anchor: {placement.anchor}")


def prepare_overlay_layer(
    overlay: Image.Image,
    settings: OverlaySettings,
    output_size: tuple[int, int],
    background_source_size: tuple[int, int] | None = None,
) -> tuple[Image.Image, tuple[int, int]]:
    if _is_full_scene_overlay(overlay.size, background_source_size, settings):
        mapped_settings = _map_settings_from_background(
            replace(settings, mode="original"),
            output_size,
            background_source_size,
        )
        return _prepare_overlay(overlay, mapped_settings, output_size)
    return _prepare_overlay(overlay, settings, output_size)


def _map_settings_from_background(
    settings: OverlaySettings,
    output_size: tuple[int, int],
    background_source_size: tuple[int, int] | None,
) -> OverlaySettings:
    if background_source_size is None:
        return settings
    if settings.mode.lower() not in {"original", "source", "native"}:
        return settings

    bg_w, bg_h = background_source_size
    out_w, out_h = output_size
    if bg_w <= 0 or bg_h <= 0 or out_w <= 0 or out_h <= 0:
        return settings

    cover_scale = max(out_w / bg_w, out_h / bg_h)
    crop_x = max(0.0, (bg_w * cover_scale - out_w) / 2.0)
    crop_y = max(0.0, (bg_h * cover_scale - out_h) / 2.0)
    return replace(
        settings,
        x=int(round(settings.x * cover_scale - crop_x)),
        y=int(round(settings.y * cover_scale - crop_y)),
        scale=settings.scale * cover_scale,
    )


def _is_full_scene_overlay(
    overlay_size: tuple[int, int],
    background_source_size: tuple[int, int] | None,
    settings: OverlaySettings,
) -> bool:
    if background_source_size is None:
        return False
    if settings.mode.lower() not in {"original", "source", "native", "cover"}:
        return False
    return overlay_size == background_source_size


def _prepare_overlay(
    overlay: Image.Image,
    settings: OverlaySettings,
    output_size: tuple[int, int],
) -> tuple[Image.Image, tuple[int, int]]:
    mode = settings.mode.lower()
    if mode in {"original", "source", "native"}:
        scale = max(0.01, settings.scale)
        if abs(scale - 1.0) < 0.001:
            prepared = overlay.convert("RGBA")
        else:
            prepared = overlay.resize(
                (max(1, int(overlay.width * scale)), max(1, int(overlay.height * scale))),
                LANCZOS,
            ).convert("RGBA")
        xy = (settings.x, settings.y)
    elif mode == "cover":
        prepared = resize_cover(overlay, output_size).convert("RGBA")
        scale = max(0.01, settings.scale)
        if abs(scale - 1.0) >= 0.001:
            prepared = prepared.resize(
                (max(1, int(prepared.width * scale)), max(1, int(prepared.height * scale))),
                LANCZOS,
            )
        xy = (settings.x, settings.y)
    elif mode == "stretch":
        scale = max(0.01, settings.scale)
        target_size = (
            max(1, int(round(output_size[0] * scale))),
            max(1, int(round(output_size[1] * scale))),
        )
        prepared = overlay.resize(target_size, LANCZOS)
        xy = (settings.x, settings.y)
    elif mode == "contain":
        prepared = _resize_contain(overlay, output_size)
        xy = _overlay_position(prepared.size, output_size, settings)
    else:
        scale = max(0.01, settings.scale)
        prepared = overlay.resize(
            (max(1, int(overlay.width * scale)), max(1, int(overlay.height * scale))),
            LANCZOS,
        )
        xy = _overlay_position(prepared.size, output_size, settings)

    prepared = _apply_overlay_opacity(prepared, settings.opacity)

    return prepared, xy


def _apply_overlay_opacity(overlay: Image.Image, opacity: float) -> Image.Image:
    prepared = overlay.convert("RGBA")
    if opacity < 1.0:
        alpha = prepared.getchannel("A")
        alpha = alpha.point(lambda value: int(value * max(0.0, min(1.0, opacity))))
        prepared.putalpha(alpha)
    return prepared


def _resize_contain(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    target_w, target_h = size
    scale = min(target_w / image.width, target_h / image.height)
    return image.resize((max(1, int(image.width * scale)), max(1, int(image.height * scale))), LANCZOS)


def _overlay_position(
    overlay_size: tuple[int, int],
    output_size: tuple[int, int],
    settings: OverlaySettings,
) -> tuple[int, int]:
    width, height = overlay_size
    out_w, out_h = output_size
    anchor = settings.anchor.lower()
    if anchor == "bottom_center":
        return int(out_w / 2 - width / 2 + settings.x), int(out_h - height + settings.y)
    if anchor == "bottom_left":
        return int(settings.x), int(out_h - height + settings.y)
    if anchor == "bottom_right":
        return int(out_w - width + settings.x), int(out_h - height + settings.y)
    if anchor == "top_left":
        return int(settings.x), int(settings.y)
    return int(out_w / 2 - width / 2 + settings.x), int(out_h / 2 - height / 2 + settings.y)
