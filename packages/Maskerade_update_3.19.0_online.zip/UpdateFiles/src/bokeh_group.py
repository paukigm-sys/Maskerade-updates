"""Exclude confidently separated rear people only in detected full-table scenes."""
from pathlib import Path
from collections import OrderedDict
from contextlib import nullcontext
import hashlib
import logging
import threading
import cv2
import numpy as np

_LOCK=threading.RLock()
_CACHE=OrderedDict()
_MODELS=None
_FACE=None


def _iou(a,b):
    x,y,w,h=a;u,v,s,t=b
    overlap=max(0,min(x+w,u+s)-max(x,u))*max(0,min(y+h,v+t)-max(y,v))
    return overlap/max(1,w*h+s*t-overlap)


def _rear_candidates(rgb,front):
    h,w=rgb.shape[:2]
    if len(front)<3:return []
    left=[f for f in front if f[0]+f[2]/2<w/2]
    right=[f for f in front if f[0]+f[2]/2>=w/2]
    if not left or not right:return []
    inner_left=max(f[0]+f[2]/2 for f in left)
    inner_right=min(f[0]+f[2]/2 for f in right)
    gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
    cascade=cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    direct=cascade.detectMultiScale(gray,scaleFactor=1.08,minNeighbors=4,minSize=(35,35))
    mirrored=cascade.detectMultiScale(cv2.flip(gray,1),scaleFactor=1.08,minNeighbors=4,minSize=(35,35))
    mirrored=[(w-int(x)-int(cw),int(y),int(cw),int(ch)) for x,y,cw,ch in mirrored]
    result=[]
    for raw in direct:
        box=tuple(int(v) for v in raw);x,y,cw,ch=box;cx=x+cw/2
        if not inner_left<cx<inner_right:continue
        if any(_iou(box,f)>.15 for f in front):continue
        if not any(_iou(box,m)>.6 for m in mirrored):continue
        nearest=min(front,key=lambda f:abs(f[0]+f[2]/2-cx))
        if y+ch/2>nearest[1]+nearest[3]*.7:continue
        if cw>max(f[2] for f in front)*1.05:continue
        result.append(box)
    return result


def rear_people_mask(source):
    """Return a source-sized exclusion; no-model or uncertain cases remain unchanged."""
    h,w=source.shape[:2]
    scale=min(1.,1400/w);size=(round(w*scale),round(h*scale))
    rgb=cv2.resize(source.astype(np.uint8),size,interpolation=cv2.INTER_AREA)
    key=hashlib.sha256(rgb.tobytes()).digest()
    with _LOCK:
        if key in _CACHE:
            small=_CACHE[key];_CACHE.move_to_end(key)
            return cv2.resize(small,(w,h),interpolation=cv2.INTER_LINEAR)
        try:
            small=_detect_and_segment(rgb)
        except Exception:
            logging.getLogger(__name__).exception('Rear group selection unavailable; retaining original mask')
            small=np.zeros(rgb.shape[:2],np.float32)
        _CACHE[key]=small
        while len(_CACHE)>8:_CACHE.popitem(last=False)
        return cv2.resize(small,(w,h),interpolation=cv2.INTER_LINEAR)


def _confident_faces(detected, scale=1.):
    """Small frontal diners stay protected; low-confidence detections do not."""
    return [(round(d.bounding_box.origin_x/scale),round(d.bounding_box.origin_y/scale),
             round(d.bounding_box.width/scale),round(d.bounding_box.height/scale))
            for d in detected if d.categories[0].score >= .45]


def _detect_and_segment(rgb):
    global _FACE,_MODELS
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision
    root=Path(__file__).resolve().parents[1]
    if _FACE is None:
        options=vision.FaceDetectorOptions(base_options=python.BaseOptions(model_asset_path=str(root/'models/MediaPipe/blaze_face_full_range.tflite')),min_detection_confidence=.3,min_suppression_threshold=.3)
        _FACE=vision.FaceDetector.create_from_options(options)
    face_scale=min(1.,1100/rgb.shape[1])
    face_rgb=cv2.resize(rgb,(round(rgb.shape[1]*face_scale),round(rgb.shape[0]*face_scale))) if face_scale<1 else rgb
    detected=_FACE.detect(mp.Image(image_format=mp.ImageFormat.SRGB,data=np.ascontiguousarray(face_rgb))).detections
    # Preserve every confident frontal detection, including small diners.
    # Low-confidence profile detections must not override the rear consensus.
    front=_confident_faces(detected, face_scale)
    candidates=_rear_candidates(rgb,front)
    excluded=np.zeros(rgb.shape[:2],np.uint8)
    if not candidates:return excluded.astype(np.float32)
    import torch
    if _MODELS is None:
        from sam2.build_sam import build_sam2
        from sam2.sam2_image_predictor import SAM2ImagePredictor
        device='cuda' if torch.cuda.is_available() else 'cpu'
        script=torch.jit.script
        try:
            torch.jit.script=lambda value:value
            model=build_sam2('configs/sam2.1/sam2.1_hiera_t.yaml',str(root/'models/SAM2/sam2.1_hiera_tiny.pt'),device=device)
            predictor=SAM2ImagePredictor(model)
        finally:torch.jit.script=script
        _MODELS=(predictor,device)
    predictor,device=_MODELS
    context=lambda:torch.autocast('cuda',dtype=torch.bfloat16) if device=='cuda' else nullcontext()
    with torch.inference_mode(),context():
        predictor.set_image(rgb)
        for x,y,cw,ch in candidates:
            points=[[x+cw*.5,y+ch*.5]]+[[u+s*.5,v+t*.5] for u,v,s,t in front]
            masks,scores,_=predictor.predict(point_coords=np.array(points,np.float32),point_labels=np.array([1]+[0]*len(front)),multimask_output=True)
            accepted=[]
            for m,score in zip(masks,scores):
                m=m.astype(np.uint8)
                if score<.25 or not 2*cw*ch<m.sum()<rgb.shape[0]*rgb.shape[1]*.25:continue
                if any(m[max(0,v):v+t,max(0,u):u+s].mean()>.12 for u,v,s,t in front):continue
                n,labels,stats,_=cv2.connectedComponentsWithStats(m)
                label=labels[min(m.shape[0]-1,y+ch//2),min(m.shape[1]-1,x+cw//2)]
                if label==0:continue
                m=(labels==label).astype(np.uint8)*255
                contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(m,contours,-1,255,cv2.FILLED)
                accepted.append(m)
            if accepted:
                chosen=max(accepted,key=lambda m:np.count_nonzero(m))
                # Remove segmentation crumbs at rear clothing edges.
                chosen=cv2.dilate(chosen,np.ones((5,5),np.uint8))
                excluded=np.maximum(excluded,chosen)
    logging.getLogger(__name__).info('Table rear-person exclusion: candidates=%s pixels=%s',len(candidates),np.count_nonzero(excluded))
    return excluded.astype(np.float32)/255
