"""Install verified auxiliary models, preserving already valid local weights."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ALLOWED = {"models/SAM2/sam2.1_hiera_tiny.pt", "models/MediaPipe/blaze_face_full_range.tflite",
           "models/MediaPipe/selfie_multiclass_256x256.tflite", "models/MediaPipe/efficientdet_lite0.tflite"}


def install_bokeh_resources(root: Path) -> None:
    from .updater import _download_file, _sha256, _require_https_url
    from .update_progress import report
    root = root.resolve()
    manifest = root / "updates/bokeh-resources.json"
    if not manifest.is_file():
        return
    spec = json.loads(manifest.read_text(encoding="utf-8"))
    files = spec.get("files", [])
    if len(files) != len(ALLOWED) or {f["path"] for f in files} != ALLOWED:
        raise RuntimeError("Invalid bokeh resource inventory")
    report("models", 0, 100)
    completed = 0
    total = sum(item["size"] for item in files)
    for item in files:
        target = root / item["path"]
        if not target.resolve().is_relative_to(root):
            raise RuntimeError("Unsafe model destination")
        if not re.fullmatch(r"[0-9a-f]{64}", item["sha256"]) or not 0 < item["size"] <= 256 * 1024**2:
            raise RuntimeError("Invalid model hash or size")
        if not 1 <= len(item["parts"]) <= 4 or sum(p["size"] for p in item["parts"]) != item["size"]:
            raise RuntimeError("Invalid model parts")
        for part in item["parts"]:
            _require_https_url(part["url"], "modelo bokeh")
            if not 0 < part["size"] <= 64 * 1024**2 or not re.fullmatch(r"[0-9a-f]{64}", part["sha256"]):
                raise RuntimeError("Invalid model part")
        if target.is_file() and target.stat().st_size == item["size"] and _sha256(target) == item["sha256"]:
            print("Modelo conservado: " + item["path"], flush=True)
            completed += item["size"]
            report("models", completed * 90, total * 100)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if shutil.disk_usage(target.parent).free < item["size"] * 2 + 64 * 1024**2:
            raise RuntimeError("Not enough disk space for bokeh models")
        with tempfile.TemporaryDirectory(prefix=".bokeh-install-", dir=target.parent) as temporary:
            assembled = Path(temporary) / "model"
            with assembled.open("wb") as stream:
                for part in item["parts"]:
                    chunk = Path(temporary) / "part"
                    _download_file(part["url"], chunk)
                    if chunk.stat().st_size != part["size"] or _sha256(chunk) != part["sha256"]:
                        raise RuntimeError("Bokeh model download integrity failure")
                    with chunk.open("rb") as source:
                        shutil.copyfileobj(source, stream)
                    chunk.unlink()
                    completed += part["size"]
                    report("models", completed * 90, total * 100)
            if _sha256(assembled) != item["sha256"]:
                raise RuntimeError("Bokeh assembled model integrity failure")
            os.replace(assembled, target)
        print("Modelo instalado: " + item["path"], flush=True)
    # Do not accept a silent fallback as successful installation.
    code = (
        "import sys;from pathlib import Path;sys.path.insert(0,sys.argv[1]);"
        "from src.bokeh_scene import _models;_models();"
        "from mediapipe.tasks import python;from mediapipe.tasks.python import vision;"
        "base=Path(sys.argv[1])/'models/MediaPipe';"
        "hair=vision.ImageSegmenter.create_from_options(vision.ImageSegmenterOptions("
        "base_options=python.BaseOptions(model_asset_path=str(base/'selfie_multiclass_256x256.tflite')),"
        "running_mode=vision.RunningMode.IMAGE,output_confidence_masks=True));hair.close();"
        "vehicles=vision.ObjectDetector.create_from_options(vision.ObjectDetectorOptions("
        "base_options=python.BaseOptions(model_asset_path=str(base/'efficientdet_lite0.tflite')),"
        "running_mode=vision.RunningMode.IMAGE));vehicles.close();print('Bokeh models ready')"
    )
    subprocess.run([str(root / ".runtime/python311/python.exe"), "-I", "-c", code, str(root)],
                   cwd=root, check=True, timeout=240)
    report("models", 100, 100)
