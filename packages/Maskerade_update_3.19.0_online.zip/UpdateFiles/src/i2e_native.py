"""Resident Win32 host for the licensed I2E DLL, with lossless RGB transport."""
from __future__ import annotations

import atexit
import json
import queue
import subprocess
import tempfile
import threading
import time
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
NATIVE_ENGINE = "i2e_native"


class I2ENativeError(RuntimeError):
    pass


class I2EClient:
    def __init__(self, root: Path = ROOT, timeout: float = 30.0):
        self.root = Path(root)
        self.timeout = timeout
        self._lock = threading.Lock()
        self._process = None
        self._responses = None
        self._signature = None
        self._reader = None

    def _start(self):
        files = [self.root / ".runtime/i2e/I2EHost.exe",
                 self.root / "config/i2e/channel.json",
                 self.root / "config/i2e/license.bin"]
        for path in files:
            if not path.is_file():
                raise I2ENativeError(f"Falta recurso del motor I2E: {path.name}")
        signature = tuple((p.stat().st_mtime_ns, p.stat().st_size) for p in files)
        if self._process is not None and self._process.poll() is None and signature == self._signature:
            return
        self._stop()
        scratch = self.root / "tmp/i2e"
        scratch.mkdir(parents=True, exist_ok=True)
        process = subprocess.Popen(
            [str(files[0]), str(files[0].parent), str(files[1]), str(files[2]), str(scratch)],
            cwd=str(self.root), stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        responses = queue.Queue()

        def read_responses():
            try:
                for line in process.stdout:
                    responses.put(line)
            finally:
                responses.put(None)

        reader = threading.Thread(target=read_responses, name="i2e-response", daemon=True)
        reader.start()
        self._reader = reader
        self._process, self._responses, self._signature = process, responses, signature

    def _stop(self):
        process, self._process = self._process, None
        if process is not None:
            try:
                if process.stdin:
                    process.stdin.close()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                process.kill()
                process.wait(timeout=2)
            finally:
                if self._reader:
                    self._reader.join(timeout=1)
                    self._reader = None
                if process.stdout:
                    process.stdout.close()

    def close(self):
        with self._lock:
            self._stop()

    def enhance(self, image: Image.Image, settings=None) -> tuple[Image.Image, dict]:
        sharpening = None if settings is None else native_sharpening(settings)
        with self._lock:
            started = time.perf_counter()
            self._start()
            with tempfile.TemporaryDirectory(prefix="job-", dir=self.root / "tmp/i2e") as directory:
                source, output = Path(directory) / "input.bmp", Path(directory) / "output.bmp"
                image.convert("RGB").save(source, format="BMP")
                try:
                    request = {"input": str(source), "output": str(output)}
                    if sharpening is not None:
                        request["sharpening"] = sharpening
                    self._process.stdin.write(json.dumps(request) + "\n")
                    self._process.stdin.flush()
                    line = self._responses.get(timeout=self.timeout)
                    if line is None:
                        raise I2ENativeError("El motor I2E se ha cerrado sin generar la foto")
                    response = json.loads(line)
                    if not response.get("ok"):
                        raise I2ENativeError(str(response.get("error") or "Fallo del motor I2E"))
                    if response.get("engine") != NATIVE_ENGINE or response.get("version") != "07.00.02":
                        raise I2ENativeError("Respuesta de motor I2E no validada")
                    with Image.open(output) as saved:
                        result = saved.convert("RGB")
                    if result.size != image.size:
                        raise I2ENativeError("I2E ha cambiado las dimensiones de la foto")
                except (OSError, ValueError, queue.Empty, I2ENativeError) as exc:
                    self._stop()
                    if isinstance(exc, I2ENativeError):
                        raise
                    raise I2ENativeError(f"No se pudo procesar con I2E: {exc}") from exc
                result.info.update(image.info)
                response["total_ms"] = round((time.perf_counter() - started) * 1000)
                return result, response


_client = I2EClient()
atexit.register(_client.close)


def native_sharpening(settings) -> dict:
    """Use the same slider scales as the vendor's UMSharpen call."""
    ranges = {"sharpness": (0, 100, 50), "radius": (0, 10, 0),
              "threshold": (0, 100, 2), "limit": (0, 100, 20)}
    values = {}
    for name, (low, high, default) in ranges.items():
        value = getattr(settings, "i2e_" + name, default)
        try:
            number = float(value)
            if not low <= number <= high or not number.is_integer():
                raise ValueError(name)
        except (TypeError, ValueError, OverflowError) as exc:
            raise I2ENativeError(f"Ajuste de enfoque I2E invalido: {name}") from exc
        values[name] = int(number)
    return {"radius": values["radius"], "factor": values["sharpness"] * 0.02,
            "threshold": values["threshold"] * 0.01, "limit": values["limit"] * 0.01}


def enhance_native(image: Image.Image, settings=None) -> tuple[Image.Image, dict]:
    return _client.enhance(image, settings)
