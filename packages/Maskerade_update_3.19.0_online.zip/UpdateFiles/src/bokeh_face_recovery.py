"""Recover omitted group members without copying unrelated hybrid foreground."""
from collections import OrderedDict
from contextlib import nullcontext
import hashlib
import time
import cv2
import numpy as np
from PIL import Image

_PLAN_CACHE = OrderedDict()


def face_recovery_plan(image, base_mask):
    """Find partly selected, confirmed faces in small foreground groups.

    Fully excluded background faces are not rescue requests. Existing table
    guards remain responsible for other unsafe masks and larger groups.
    """
    from . import bokeh_scene as scene
    empty = {'confirmed_faces': (), 'missing_faces': ()}
    if min(image.size) < 320:
        return empty
    scale = min(1., 1100 / max(image.size))
    size = (round(image.width * scale), round(image.height * scale))
    rgb = np.asarray(image.convert('RGB').resize(size, Image.Resampling.LANCZOS)).copy()
    raw = np.asarray(base_mask.convert('L').resize(size, Image.Resampling.LANCZOS))
    key = hashlib.sha256(rgb.tobytes() + raw.tobytes()).digest()
    with scene._LOCK:
        if key in _PLAN_CACHE:
            _PLAN_CACHE.move_to_end(key)
            return _PLAN_CACHE[key]
        import mediapipe as mp
        detector = scene._face_detector()
        found = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)).detections
        faces = []
        for detection in found:
            if detection.categories[0].score < .65:
                continue
            box = detection.bounding_box
            face = (box.origin_x + box.width / 2, box.origin_y + box.height / 2,
                    float(max(box.width, box.height)))
            if not (0 <= face[0] < size[0] and 0 <= face[1] < size[1]):
                continue
            if scene._confirm_local_face(rgb, face, detector):
                faces.append(face)
        base = raw.astype(np.float32) / 255
        visible = (base >= .65).astype(np.float32)
        missing, supported = [], 0
        for face in faces:
            if scene._face_interior_supported(visible, *face)[0]:
                supported += 1
            else:
                x, y, side = face
                core = np.zeros_like(raw)
                cv2.circle(core, (round(x), round(y)), max(1, round(side * .25)), 1, -1)
                # Some incoming foreground evidence is required: a confident
                # face in the distant background must not become a new diner.
                if core.any() and base[core > 0].mean() >= .15:
                    missing.append(face)
        plan = {'confirmed_faces': tuple(faces),
                'missing_faces': tuple(missing) if 2 <= supported and len(faces) <= 6 else ()}
        _PLAN_CACHE[key] = plan
        while len(_PLAN_CACHE) > 8:
            _PLAN_CACHE.popitem(last=False)
        return plan


def recover_face_regions(image, base_mask, hybrid_mask, plan=None):
    """Only add hybrid pixels associated with a confirmed incomplete frontal face.

    All prompts are inferred from image/matte content; no file names, manual
    coordinates, rectangular cutouts or changes to known background pixels.
    """
    from . import bokeh_scene as scene
    from .portrait_group import _component, _core
    started=time.perf_counter()
    scale=min(1.,1100/max(image.size))
    size=(round(image.width*scale),round(image.height*scale))
    rgb=np.asarray(image.convert('RGB').resize(size,Image.Resampling.LANCZOS)).copy()
    base=np.asarray(base_mask.convert('L').resize(size,Image.Resampling.LANCZOS),np.float32)/255
    plan = plan if plan is not None else face_recovery_plan(image, base_mask)
    faces, missing = plan['confirmed_faces'], plan['missing_faces']
    info={'confirmed_faces':faces,'missing_faces':missing,'accepted_faces':[],'sam_calls':0,'seconds':0.}
    if not missing or hybrid_mask is None:
        info['seconds']=time.perf_counter()-started
        return base_mask.copy(),info
    import torch
    guide=np.asarray(hybrid_mask.convert('L').resize(size,Image.Resampling.LANCZOS),np.float32)/255
    association=np.zeros_like(base)
    with scene._LOCK:
        _,(predictor,device)=scene._models()
        context=torch.autocast('cuda',dtype=torch.bfloat16) if device=='cuda' else nullcontext()
        with torch.inference_mode(),context:
            predictor.set_image(rgb)
            for face in missing:
                x,y,side=face
                own=np.zeros_like(base,np.uint8)
                cv2.circle(own,(round(x),round(y)),max(1,round(side*.25)),1,-1)
                other_faces=[f for f in faces if f!=face]
                other=np.zeros_like(own)
                for u,v,z in other_faces:
                    cv2.circle(other,(round(u),round(v)),max(1,round(z*.25)),1,-1)
                if guide[own>0].mean()<.95:
                    continue
                negatives=[[u,v] for u,v,z in other_faces]
                accepted=[]
                for body in (False,True):
                    positive=[[x,y]]
                    if body:
                        for offset in (.8,1.6,2.4):
                            px,py=round(x),round(min(size[1]-2,y+side*offset))
                            if guide[py,px]>.9 and not any(np.hypot(px-u,py-v)<z*.7 for u,v,z in other_faces):
                                positive.append([px,py])
                    masks,scores,_=predictor.predict(point_coords=np.asarray(positive+negatives,np.float32),
                        point_labels=np.asarray([1]*len(positive)+[0]*len(negatives)),multimask_output=True)
                    info['sam_calls']+=1
                    for raw,score in zip(masks,scores):
                        if score<.6:
                            continue
                        candidate=_component(raw,positive[0])
                        if candidate is None or not side*side*2<candidate.sum()<candidate.size*.28:
                            continue
                        if candidate[own>0].mean()<.98 or candidate[other>0].any():
                            continue
                        accepted.append((candidate.sum(),float(score),candidate))
                if not accepted:
                    continue
                # Face-only proposals can score higher than the complete person.
                # Prefer the complete connected body after identity checks.
                chosen=max(accepted,key=lambda item:(item[0],item[1]))[2]
                association=np.maximum(association,chosen)
                info['accepted_faces'].append(face)
    if association.any():
        # SAM proposes identity/body regions; the hybrid matte supplies hair
        # and glasses contours. A head-linked connected component avoids
        # truncating the crown to the coarser SAM contour.
        yy,xx=np.indices(base.shape)
        for face in info['accepted_faces']:
            x,y,side=face
            domain=(((xx-x)/(side*.82))**2+((yy-y+side*.15)/(side*1.25))**2<=1)
            component=_component(domain & (guide>.05),(x,y))
            if component is None:
                continue
            other=[f for f in faces if f!=face]
            if component[_core(base.shape,other,.25)].any():
                continue
            association=np.maximum(association,component)
    if not association.any():
        result=base_mask.copy()
    else:
        soft=cv2.GaussianBlur(association,(0,0),.5)
        soft=cv2.resize(soft,image.size,interpolation=cv2.INTER_LINEAR)
        original=np.asarray(base_mask.convert('L'),np.float32)/255
        guide=np.asarray(hybrid_mask.convert('L'),np.float32)/255
        recovered=np.maximum(original,guide*soft)
        result=Image.fromarray(np.rint(recovered*255).astype(np.uint8))
    info['seconds']=time.perf_counter()-started
    return result,info
