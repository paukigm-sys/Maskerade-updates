"""Photo-specific, explicit mask corrections. Original JPEGs are never changed."""
from collections import OrderedDict
from dataclasses import dataclass, field, replace
from pathlib import Path
import hashlib
import json
import tempfile
import uuid

import cv2
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
CORRECTIONS_DIR = ROOT/'config/mask_corrections'
_SESSIONS = OrderedDict()
INFO_KEY = 'maskerade_mask_correction'


def source_key(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load_correction(path, size):
    target = CORRECTIONS_DIR/(source_key(path)+'.png')
    if not target.is_file():
        return None
    with Image.open(target) as saved:
        image = saved.convert('RGB')
    # R = erase, G = restore. Coordinates follow the original photo, not the
    # currently selected background or its output dimensions.
    return image.resize(size, Image.Resampling.BILINEAR) if image.size != size else image


def attach_correction(subject, path):
    if subject is None:
        return None
    correction = load_correction(path, subject.size)
    if correction is None:
        return subject
    result = subject.copy()
    result.info[INFO_KEY] = correction
    return result


def corrected_alpha(alpha, correction):
    if correction is None:
        return alpha
    if correction.size != (alpha.shape[1], alpha.shape[0]):
        correction = correction.resize((alpha.shape[1], alpha.shape[0]), Image.Resampling.BILINEAR)
    values = np.asarray(correction, np.float32)/255
    return np.clip(alpha*(1-values[..., 0])*(1-values[..., 1])+values[..., 1], 0, 1)


def corrected_subject(subject):
    correction = subject.info.get(INFO_KEY)
    if correction is None:
        return subject
    result = subject.copy()
    alpha = corrected_alpha(np.asarray(subject.getchannel('A'), np.float32)/255, correction)
    result.putalpha(Image.fromarray(np.rint(alpha*255).astype('uint8')))
    result.info.pop(INFO_KEY, None)
    return result


def alpha_proposal(base, proposed):
    erase = np.clip((base-proposed)/np.maximum(base, 1e-6), 0, 1)
    keep = np.clip((proposed-base)/np.maximum(1-base, 1e-6), 0, 1)
    return Image.fromarray(np.rint(np.stack((erase, keep, np.zeros_like(base)), axis=2)*255).astype('uint8'))


def paint(correction, points, radius, keep):
    """A stroke replaces earlier instructions only where the brush touches."""
    if not points or len(points) > 10000 or not .0005 <= radius <= .15:
        raise ValueError('Trazo o tamaño de pincel no válido.')
    if any(len(p) != 2 or not all(np.isfinite(v) and 0 <= v <= 1 for v in p) for p in points):
        raise ValueError('El trazo debe estar dentro de la foto.')
    width, height = correction.size
    xy = [(round(x*(width-1)), round(y*(height-1))) for x, y in points]
    size = max(1, round(radius*min(width, height)))
    stamp = Image.new('L', correction.size)
    draw = ImageDraw.Draw(stamp)
    if len(xy) > 1:
        draw.line(xy, fill=255, width=size*2, joint='curve')
    for x, y in xy:
        draw.ellipse((x-size, y-size, x+size, y+size), fill=255)
    result = correction.copy()
    result.paste((0, 255, 255) if keep else (255, 0, 0), (0, 0, width, height), stamp)
    return result


def erase_polygon(correction, points):
    if not 3 <= len(points) <= 10000 or any(len(p) != 2 or not all(np.isfinite(v) and 0 <= v <= 1 for v in p) for p in points):
        raise ValueError('Traza un contorno cerrado dentro de la foto.')
    width, height = correction.size
    result = correction.copy()
    ImageDraw.Draw(result).polygon([(round(x*(width-1)), round(y*(height-1))) for x,y in points], fill=(255,0,0))
    return result


def select_person(original, point, correction):
    """Segment only the explicitly clicked object; other faces stay protected."""
    from contextlib import nullcontext
    from .bokeh_scene import _models, _LOCK
    import mediapipe as mp
    import torch
    if len(point) != 2 or not all(np.isfinite(v) and 0 <= v <= 1 for v in point):
        raise ValueError('Marca a la persona dentro de la foto.')
    scale = min(1., 1100/max(original.size))
    size = (round(original.width*scale), round(original.height*scale))
    rgb = np.asarray(original.convert('RGB').resize(size, Image.Resampling.LANCZOS)).copy()
    px, py = point[0]*(size[0]-1), point[1]*(size[1]-1)
    protected = np.zeros((size[1], size[0]), np.uint8)
    negative = []
    with _LOCK:
        detector, (predictor, device) = _models()
        found = detector.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)).detections
        for detection in found:
            box = detection.bounding_box
            if box.origin_x <= px <= box.origin_x+box.width and box.origin_y <= py <= box.origin_y+box.height:
                continue
            if detection.categories[0].score >= .55:
                cx, cy = box.origin_x+box.width*.5, box.origin_y+box.height*.5
                negative.append([cx, cy])
                cv2.ellipse(protected, (round(cx), round(cy)),
                            (max(1, round(box.width*.30)), max(1, round(box.height*.30))), 0, 0, 360, 1, -1)
                # A face-only negative can leave the same person's clothing in
                # a much larger proposal. Protect their torso anchors as well.
                for offset in (1.2, 2.5):
                    bx, by = cx, min(size[1]-2, cy+max(box.width, box.height)*offset)
                    if abs(bx-px) < box.width*.25 and abs(by-py) < box.height*.25:
                        continue
                    negative.append([bx, by])
                    cv2.circle(protected, (round(bx), round(by)), max(1, round(box.width*.16)), 1, -1)
        # Explicit keep brush strokes guide SAM2 as well as overriding the result.
        keep = np.asarray(correction.resize(size, Image.Resampling.NEAREST))[..., 2] > 127
        if keep.any():
            yy, xx = np.nonzero(keep)
            for index in np.linspace(0, len(xx)-1, min(6, len(xx))).astype(int):
                negative.append([float(xx[index]), float(yy[index])])
        context = torch.autocast('cuda', dtype=torch.bfloat16) if device == 'cuda' else nullcontext()
        with torch.inference_mode(), context:
            predictor.set_image(rgb)
            masks, scores, _ = predictor.predict(point_coords=np.asarray([[px, py]]+negative, np.float32),
                point_labels=np.asarray([1]+[0]*len(negative)), multimask_output=True)
        valid = []
        for raw, score in zip(masks, scores):
            if score < .20:
                continue
            mask = cv2.morphologyEx(raw.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
            _, labels = cv2.connectedComponents(mask)
            label = labels[round(py), round(px)]
            if label == 0:
                continue
            mask = (labels == label).astype(np.uint8)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(mask, contours, -1, 1, cv2.FILLED)
            if not size[0]*size[1]*.0002 < mask.sum() < size[0]*size[1]*.60:
                continue
            if np.any(mask[protected > 0]):
                continue
            valid.append(mask)
        if not valid:
            raise ValueError('No se ha podido separar sin alcanzar a otra persona. Usa el pincel o el lazo para precisar el recorte.')
        selected = max(valid, key=lambda mask: mask.sum())
    selected = Image.fromarray(selected*255).resize(original.size, Image.Resampling.BILINEAR)
    values = np.asarray(correction).copy()
    erase = np.asarray(selected)
    # Only explicit keep brush strokes protect a later person selection. A
    # BEN2 proposal may also restore pixels, but is still editable by a click.
    removal = erase*(1-values[..., 2]/255)
    values[..., 0] = np.maximum(values[..., 0], removal).astype('uint8')
    values[..., 1] = np.rint(values[..., 1]*(1-removal/255)).astype('uint8')
    return Image.fromarray(values)


@dataclass
class EditSession:
    source: Path
    digest: str
    original: Image.Image
    scene_original: Image.Image
    subject: Image.Image
    park: object
    pre_enhanced: bool
    directory: object
    history: list = field(default_factory=list)
    removal_settings: object = None
    preview_revision: object = None
    preview_result: object = None

    @property
    def correction(self):
        with Image.open(self.history[-1]) as image:
            return image.convert('RGB')

    def push(self, image):
        path = Path(self.directory.name)/(uuid.uuid4().hex+'.png')
        image.save(path, 'PNG')
        self.history.append(path)


def begin_session(source, original, scene_original, subject, park, pre_enhanced, cache_root, removal_settings=None, expected_digest=None):
    digest = source_key(source)
    if expected_digest is not None and digest != expected_digest:
        raise ValueError('La foto original ha cambiado mientras se preparaba el recorte. Abre de nuevo el editor.')
    # Keep only the current editor. Previous closed/cancelled drafts cannot leak
    # into another photo and temporary files never become committed edits.
    for session in _SESSIONS.values():
        session.directory.cleanup()
    _SESSIONS.clear()
    cache_root = Path(cache_root)
    cache_root.mkdir(parents=True, exist_ok=True)
    directory = tempfile.TemporaryDirectory(prefix='mask_edit_', dir=cache_root)
    session = EditSession(Path(source), digest, original.copy(), scene_original.copy(),
                          subject.copy(), park, pre_enhanced, directory)
    session.removal_settings = removal_settings
    session.push(load_correction(source, original.size) or Image.new('RGB', original.size))
    token = uuid.uuid4().hex
    _SESSIONS[token] = session
    return token


def edit_session(token, action, values):
    session = _SESSIONS.get(token)
    if session is None:
        raise ValueError('La sesión de recorte ha terminado. Abre de nuevo el editor.')
    if action == 'person':
        point = [float(values['x']), float(values['y'])]
        session.push(select_person(session.original, point, session.correction))
    elif action == 'ben2':
        from .background_removal import BackgroundRemover
        from .background_bokeh import background_bokeh
        if session.removal_settings is None:
            raise ValueError('No hay configuración de BEN2 en esta sesión.')
        cfg = replace(session.removal_settings, backend='ben2', birefnet_enabled=False, birefnet_hybrid_ben2=False)
        prepared = BackgroundRemover(cfg).prepare_background_removal(session.scene_original)
        proposed = prepared.rgba.getchannel('A').resize(session.original.size, Image.Resampling.LANCZOS)
        baseline = session.subject.getchannel('A')
        if session.park.background_bokeh > 0:
            kwargs = dict(alpha_floor=.65, style=session.park.background_bokeh_style)
            _, baseline = background_bokeh(session.scene_original, baseline, session.park.background_bokeh, **kwargs)
            _, proposed = background_bokeh(session.scene_original, proposed, session.park.background_bokeh, **kwargs)
        session.push(alpha_proposal(np.asarray(baseline, np.float32)/255, np.asarray(proposed, np.float32)/255))
    elif action in {'keep', 'erase'}:
        session.push(paint(session.correction, json.loads(values['points']), float(values['radius']), action == 'keep'))
    elif action == 'polygon':
        session.push(erase_polygon(session.correction, json.loads(values['points'])))
    elif action == 'undo':
        if len(session.history) > 1:
            session.history.pop()
    elif action == 'reset':
        session.push(Image.new('RGB', session.original.size))
    elif action == 'commit':
        if source_key(session.source) != session.digest:
            raise ValueError('La foto original ha cambiado. No se ha guardado la corrección.')
        CORRECTIONS_DIR.mkdir(parents=True, exist_ok=True)
        target = CORRECTIONS_DIR/(session.digest+'.png')
        temporary = target.with_name(target.stem+'.'+uuid.uuid4().hex+'.tmp')
        try:
            session.correction.save(temporary, 'PNG')
            temporary.replace(target)
        finally:
            temporary.unlink(missing_ok=True)
    elif action == 'cancel':
        session.directory.cleanup()
        del _SESSIONS[token]
        return None
    elif action != 'begin':
        raise ValueError('Acción de recorte no válida.')
    return session


def render_session(session):
    if session.preview_revision == session.history[-1] and session.preview_result is not None:
        return session.preview_result
    from .compositor import compose_image, harmonize_composed_image
    from .photo_enhancer import enhance_photo, should_apply_photo_retouch
    correction = session.correction
    subject = session.subject.copy()
    subject.info[INFO_KEY] = correction
    overlay = session.original.convert('RGB')
    overlay.thumbnail((1400, 1400), Image.Resampling.LANCZOS)
    colors = np.asarray(correction.resize(overlay.size, Image.Resampling.BILINEAR), np.float32)/255
    pixels = np.asarray(overlay, np.float32)
    erase, keep = colors[..., 0:1]*.50, colors[..., 1:2]*.45
    pixels = pixels*(1-erase)+np.array([255, 65, 85])*erase
    pixels = pixels*(1-keep)+np.array([60, 220, 165])*keep
    marked = Image.fromarray(np.rint(np.clip(pixels, 0, 255)).astype('uint8'))
    revision = uuid.uuid4().hex
    root = Path(session.directory.name)
    marked_path, final_path = root/(revision+'_marked.jpg'), root/(revision+'_final.jpg')
    marked.save(marked_path, quality=93)
    try:
        final = compose_image(session.scene_original, subject, session.park, apply_harmonize=False)
        if not session.pre_enhanced and should_apply_photo_retouch(session.park):
            final = enhance_photo(final, session.park.photo_enhance)
        final = harmonize_composed_image(final, session.scene_original, subject, session.park)
    except Exception as exc:
        return marked_path, None, str(exc)
    final.thumbnail((1400, 1400), Image.Resampling.LANCZOS)
    final.save(final_path, quality=95)
    session.preview_revision = session.history[-1]
    session.preview_result = (marked_path, final_path, '')
    return session.preview_result
