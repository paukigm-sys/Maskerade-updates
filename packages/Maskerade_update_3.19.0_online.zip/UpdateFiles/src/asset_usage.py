"""Persistent asset activity; refresh/navigation never count as usage."""
from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import threading
import time
import uuid

_LOCK = threading.Lock()


def _number(value, default=0):
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError, OverflowError):
        return default


def asset_usage_path(root):
    return Path(root) / 'config' / 'asset_usage.json'


@contextmanager
def _file_lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_suffix('.lock').open('a+b') as stream:
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        deadline = time.monotonic() + 1
        while True:
            try:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise TimeoutError('El historial de fichas esta ocupado.')
                time.sleep(.01)
        try:
            yield
        finally:
            if os.name == 'nt':
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


def record_assets_used(root, paths, *, now=None):
    """One use per distinct existing asset in this explicit action/export."""
    assets = {}
    for path in paths:
        if path is None or not str(path).strip():
            continue
        path = Path(path).resolve()
        if not path.is_file():
            continue
        stat = path.stat()
        assets[os.path.normcase(str(path))] = max(stat.st_ctime, stat.st_mtime)
    if not assets:
        return
    target = asset_usage_path(root)
    used = time.time() if now is None else float(now)
    with _LOCK, _file_lock(target):
        try:
            payload = json.loads(target.read_text(encoding='utf-8'))
            entries = payload['assets']
            if not isinstance(entries, dict):
                raise ValueError('Invalid asset history')
        except (FileNotFoundError, ValueError, KeyError, TypeError):
            entries = {}
        for key, added in assets.items():
            previous = entries.get(key, {})
            if not isinstance(previous, dict):
                previous = {}
            entries[key] = {'added_utc': _number(previous.get('added_utc'), added),
                            'last_used_utc': max(used, _number(previous.get('last_used_utc'))),
                            'use_count': min(2**63-1, max(0, int(_number(previous.get('use_count')))) + 1)}
        temporary = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
        try:
            temporary.write_text(json.dumps({'version': 1, 'assets': entries}, ensure_ascii=False), encoding='utf-8')
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
