"""Conservative foreground preservation for a light table between seated groups."""
import cv2
import numpy as np


def table_foreground(source: np.ndarray, people: np.ndarray) -> np.ndarray:
    h, w = people.shape
    empty = np.zeros((h,w), np.float32)
    if w <= h or min(w,h)<120:
        return empty
    scale = min(1.,1024./w)
    sw,sh=round(w*scale),round(h*scale)
    rgb=cv2.resize(source,(sw,sh),interpolation=cv2.INTER_AREA)
    person=cv2.resize(people,(sw,sh),interpolation=cv2.INTER_AREA)
    # Require subjects on both sides of a central table, not a single portrait.
    band=person[int(sh*.25):int(sh*.9)]
    if np.mean(band[:,:int(sw*.35)]>.7)<.08 or np.mean(band[:,int(sw*.65):]>.7)<.08:
        return empty
    bright=rgb.mean(axis=2)
    neutral=(np.ptp(rgb,axis=2)<45)&(bright>125)&(person<.5)
    neutral[:int(sh*.38)]=False
    binary=neutral.astype(np.uint8)*255
    binary=cv2.morphologyEx(binary,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    n,labels,stats,_=cv2.connectedComponentsWithStats(binary)
    best=None
    for label in range(1,n):
        x,y,cw,ch,area=stats[label]
        region=labels==label
        # A visible dark rim/chair below the cloth must not reject the table.
        # Measure a sustained broad near-camera surface, not the last 3% alone.
        near=region[int(sh*.82):]
        widths=near.sum(axis=1)
        broad=widths>=sw*.18
        runs=np.diff(np.r_[False,broad,False].astype(np.int8))
        starts=np.flatnonzero(runs==1);ends=np.flatnonzero(runs==-1)
        if not len(starts) or np.max(ends-starts)<sh*.06:
            continue
        bottom=near[broad]
        center=bottom[:,int(sw*.35):int(sw*.65)]
        if area<sw*sh*.10 or y>sh*.7 or ch<sh*.28 or y+ch<sh*.93 or not center.any():
            continue
        if np.mean(bottom)<.18 or cw<sw*.30 or cw>sw*.85:
            continue
        # The table must broaden towards the camera; a wall is not a table.
        upper=region[y:min(sh,y+max(4,int(sh*.1)))].sum(axis=1)
        lower=bottom.sum(axis=1)
        if np.median(lower)<np.median(upper)*1.25:
            continue
        if best is None or area>best[0]: best=(area,region)
    if best is None:
        return empty
    region=best[1].astype(np.uint8)*255
    # Grow the confirmed cloth into its shaded far end. Require connection to
    # the bright table seed and reject growth into a wide/large wall region.
    shaded=((np.ptp(rgb,axis=2)<45)&(bright>85)&(person<.5)).astype(np.uint8)*255
    shaded[:int(sh*.25)]=0
    shaded=cv2.morphologyEx(shaded,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    _, shade_labels, shade_stats, _=cv2.connectedComponentsWithStats(shaded)
    overlap=np.bincount(shade_labels[region>0].ravel(),minlength=len(shade_stats))
    overlap[0]=0
    seed_label=int(np.argmax(overlap))
    if seed_label:
        gx,gy,gw,gh,ga=shade_stats[seed_label]
        if overlap[seed_label]>=np.count_nonzero(region)*.9 and gw<=sw*.85 and ga<=sw*sh*.45:
            region=(shade_labels==seed_label).astype(np.uint8)*255
    # Fill enclosed objects (menus, cutlery, glasses), following the actual outer
    # edge instead of a convex hull that would also retain the wall behind it.
    contours,_=cv2.findContours(region,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    preserved=np.zeros_like(region)
    cv2.drawContours(preserved,contours,-1,255,cv2.FILLED)
    # Objects touching the near image border are open holes, not contours.
    # Fill only between the measured table edges on broad rows.
    for row in range(int(sh*.5), sh):
        xs=np.flatnonzero(preserved[row])
        if len(xs) and xs[-1]-xs[0] >= sw*.18:
            preserved[row,xs[0]:xs[-1]+1]=255
    mask=cv2.resize(preserved.astype(np.float32)/255,(w,h),interpolation=cv2.INTER_LINEAR)
    return mask
