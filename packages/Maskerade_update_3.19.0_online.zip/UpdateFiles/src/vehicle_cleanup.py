"""Conservative vehicle-only veto for replacement-background hybrid mattes.

Detection proposes a region, never a rectangle to erase. The existing negative
hybrid guide decides which pixels in that region are unsupported scenery.
"""
from pathlib import Path
from threading import Lock
import logging
import time

import cv2
import numpy as np
from PIL import Image

_LOCK = Lock()
_DETECTOR = None
_UNAVAILABLE = False
_LOG = logging.getLogger(__name__)
MODEL_PATH = Path(__file__).resolve().parents[1] / "models/MediaPipe/efficientdet_lite0.tflite"


def _detect(image):
    global _DETECTOR, _UNAVAILABLE
    if _UNAVAILABLE:
        return []
    import mediapipe as mp
    from mediapipe.tasks import python
    from mediapipe.tasks.python import vision
    with _LOCK:
        if _DETECTOR is None:
            if not MODEL_PATH.is_file():
                _UNAVAILABLE = True
                _LOG.warning("Limpieza de vehiculos omitida: falta %s", MODEL_PATH.name)
                return []
            _DETECTOR = vision.ObjectDetector.create_from_options(vision.ObjectDetectorOptions(
                base_options=python.BaseOptions(model_asset_path=str(MODEL_PATH)),
                running_mode=vision.RunningMode.IMAGE, score_threshold=.45, max_results=30))
        view = image.convert("RGB")
        view.thumbnail((640, 640), Image.Resampling.LANCZOS)
        rgb = np.ascontiguousarray(view)
        detections = _DETECTOR.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)).detections
        sx, sy = image.width / view.width, image.height / view.height
        return [(d.categories[0].category_name, float(d.categories[0].score),
                 (d.bounding_box.origin_x*sx, d.bounding_box.origin_y*sy,
                  d.bounding_box.width*sx, d.bounding_box.height*sy)) for d in detections]


def _face_regions(image):
    # Reuse the installed face detector, without loading SAM2 or another matte.
    import mediapipe as mp
    from .bokeh_scene import _LOCK as face_lock, _face_detector
    view = image.convert("RGB")
    view.thumbnail((960, 960), Image.Resampling.LANCZOS)
    with face_lock:
        detections = _face_detector().detect(mp.Image(
            image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(view))).detections
    sx, sy = image.width / view.width, image.height / view.height
    return [(d.bounding_box.origin_x*sx, d.bounding_box.origin_y*sy,
             d.bounding_box.width*sx, d.bounding_box.height*sy)
            for d in detections if d.categories[0].score >= .65]


def _bounds(box, shape, margin):
    x, y, width, height = box
    h, w = shape
    return (max(0, int(x-width*margin)), max(0, int(y-height*margin)),
            min(w, int(np.ceil(x+width*(1+margin)))),
            min(h, int(np.ceil(y+height*(1+margin)))))


def _subject_guide(image, human, infer):
    yy, xx = np.where(human >= 128)
    pad = round(max(int(xx.max()-xx.min()), int(yy.max()-yy.min()))*.12)
    box = (max(0, int(xx.min())-pad), max(0, int(yy.min())-pad),
           min(image.width, int(xx.max())+pad+1), min(image.height, int(yy.max())+pad+1))
    crop = image.crop(box)
    view = crop.copy()
    view.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
    local = infer(view).getchannel("A").resize(crop.size, Image.Resampling.LANCZOS)
    guide = Image.new("L", image.size)
    guide.paste(local, box[:2])
    return np.asarray(guide, dtype=np.uint8)


def clean_vehicle(image, mask, ben2_mask, human_alpha, negative_cut, *, slider, infer_subject=None):
    """Return the original object on any uncertainty; never run for manual cuts."""
    stats = {"active": False, "vehicles": 0, "removed_pixels": 0, "reason": "not_needed"}
    if not 0 <= slider <= 25:
        return mask, stats
    base = np.asarray(mask, dtype=np.uint8)
    ben = np.asarray(ben2_mask, dtype=np.uint8)
    human = np.asarray(human_alpha, dtype=np.uint8)
    if base.shape != ben.shape or base.shape != human.shape or mask.size != image.size:
        raise ValueError("Vehicle cleanup masks must match the source image")
    if np.count_nonzero(human >= 128) < max(16, base.size*.0001):
        return mask, {**stats, "reason": "no_human_support"}
    # BEN2 can also retain the car, attached to a shoulder. Semantic detection
    # must therefore not require BEN2 to reject it in advance.
    disputed = (base >= 128) & (human < 24)
    # No semantic inference for ordinary edge disagreement or clean silhouettes.
    if np.count_nonzero(disputed) < max(96, base.size*.02):
        return mask, stats
    started = time.perf_counter()
    try:
        vehicles = [box for name, score, box in _detect(image)
                    if name in {"car", "truck", "bus"} and score >= .45
                    and box[2]*box[3] >= base.size*.05]
        if not vehicles:
            return mask, {**stats, "reason": "no_vehicle", "seconds": time.perf_counter()-started}
        roi = np.zeros(base.shape, np.uint8)
        for box in vehicles:
            left, top, right, bottom = _bounds(box, base.shape, .22)
            region = disputed[top:bottom, left:right]
            if region.size and np.count_nonzero(region) >= max(96, base.size*.015, region.size*.12):
                roi[top:bottom, left:right] = 1
                stats["vehicles"] += 1
        if not roi.any():
            return mask, {**stats, "reason": "vehicle_supported"}
        candidate, cut_stats = negative_cut(mask, ben2_mask, human_alpha, -12)
        if not cut_stats["human_available"]:
            return mask, {**stats, "reason": "no_human_support"}
        target = np.asarray(candidate, dtype=np.uint8)
        vehicle_scenery = (roi > 0) & disputed
        retained = (target >= 128) & vehicle_scenery
        stats["subject_check"] = False
        if np.count_nonzero(retained) > np.count_nonzero(vehicle_scenery)*.45:
            if infer_subject is None:
                return mask, {**stats, "reason": "vehicle_supported"}
            local = _subject_guide(image, human, infer_subject)
            # If the contextual view fails to recognise the same human core,
            # abandon subtraction instead of trusting a blank crop.
            core = human >= 192
            if not core.any() or np.mean(local[core] >= 128) < .98:
                return mask, {**stats, "reason": "subject_guard"}
            # A weak U2Net halo can contain the car immediately above the hair.
            # The local BEN2 matte preserves hair/props; retain every confident
            # human pixel as a separate non-negotiable lower bound.
            target = np.minimum(base, np.maximum(local, np.where(human >= 192, human, 0)))
            stats["subject_check"] = True
        result = np.where(roi > 0, np.minimum(base, target), base).astype(np.uint8)
        # Protect all human evidence and its nearby outline, not just the biggest
        # face. Props attached to that evidence are protected by the BEN2 guide.
        threshold = 192 if stats["subject_check"] else 24
        radius = max(1, round(min(base.shape)*(.002 if stats["subject_check"] else .006)))
        support = cv2.dilate((human >= threshold).astype(np.uint8), cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (2*radius+1,)*2)) > 0
        result[support] = base[support]
        removed = (result.astype(np.int16) < base.astype(np.int16)-2)
        if np.count_nonzero(removed) < max(96, base.size*.01):
            return mask, {**stats, "reason": "no_safe_subtraction"}
        for box in _face_regions(image):
            left, top, right, bottom = _bounds(box, base.shape, 0)
            region = removed[top:bottom, left:right]
            if region.size and np.count_nonzero(region) > max(2, region.size*.005):
                return mask, {**stats, "reason": "face_guard"}
        stats.update(active=True, removed_pixels=int(np.count_nonzero(removed)),
                     reason="vehicle_removed", seconds=time.perf_counter()-started)
        return Image.fromarray(result, "L"), stats
    except Exception:
        _LOG.exception("Limpieza de vehiculos omitida; se conserva el recorte original")
        return mask, {**stats, "reason": "unavailable"}
