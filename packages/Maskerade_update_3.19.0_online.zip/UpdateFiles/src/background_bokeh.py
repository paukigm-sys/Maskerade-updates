"""Background blur and portrait backdrops using Maskerade's final alpha."""
from __future__ import annotations

import logging
import hashlib
import weakref
from collections import OrderedDict
from threading import Lock
from functools import lru_cache
from pathlib import Path
import numpy as np
import cv2
from PIL import Image

_LOG = logging.getLogger(__name__)


class UnsafeForegroundMaskError(ValueError):
    """A typed guard failure, so only incomplete faces trigger model rescue."""

    def __init__(self, message: str, *, reason: str = "face"):
        super().__init__(message)
        self.reason = reason


STUDIO_BACKGROUND_PATH = Path(__file__).resolve().parents[1] / "assets" / "portrait_studio_v2.png"


@lru_cache(maxsize=1)
def _studio_background_source() -> Image.Image:
    with Image.open(STUDIO_BACKGROUND_PATH) as image:
        return image.convert("RGB")


def studio_background(size: tuple[int, int]) -> Image.Image:
    """Cover landscape or portrait frames without stretching the studio texture."""
    from .image_utils import resize_cover
    return resize_cover(_studio_background_source(), size)


def validate_effect_faces(image: Image.Image, mask: Image.Image) -> None:
    """Run the renderer's face guard at source size, also for blur effects.

    Blur normally keeps the original on unsafe masks. The shared strict guard
    exposes that same face rejection before choosing the automatic engine.
    Other uncertainty (such as a missing table contour) is not a face rescue.
    """
    if min(image.size) < 320:
        return
    try:
        _foreground_alpha_cached(image.convert("RGB"), mask, .65, 1.0)
    except UnsafeForegroundMaskError as exc:
        if exc.reason == "face":
            raise UnsafeForegroundMaskError(
                "La mascara no conserva todas las caras principales.", reason="face",
            ) from exc


def _enhance_existing_lights(background: np.ndarray, source: np.ndarray,
                             alpha: np.ndarray, sigma: float) -> np.ndarray:
    """Expand compact existing highlights at their measured source positions.

    No seeded/random lights, no decorative overlay and no invented light sources.
    Broad windows/signs remain part of ordinary background blur.
    """
    height, width = alpha.shape
    scale = min(1.0, 720.0 / max(width, height))
    size = (max(1, round(width * scale)), max(1, round(height * scale)))
    rgb = cv2.resize(source / 255.0, size, interpolation=cv2.INTER_AREA)
    foreground = cv2.resize(alpha, size, interpolation=cv2.INTER_LINEAR)
    bright = rgb.max(axis=2)
    local = cv2.GaussianBlur(bright, (0, 0), max(1.0, min(size) * 0.018))
    # Light candidates must be bright AND locally brighter than their surroundings.
    candidates = ((bright > 0.68) & (bright-local > 0.12) & (foreground < 0.015)).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(candidates, 8)
    sources = []
    for label in range(1, count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area < 1 or area > max(4, int(size[0]*size[1]*0.0015)):
            continue
        region = labels == label
        energy = bright[region]
        yy, xx = np.nonzero(region)
        total = float(energy.sum())
        x = float((xx*energy).sum()/total) / scale
        y = float((yy*energy).sum()/total) / scale
        color = (rgb[region]*energy[:, None]).sum(axis=0)/total
        peak = float(energy.max())
        sources.append((total, x, y, area / (scale*scale), peak, color))
    sources.sort(key=lambda item:item[0], reverse=True)
    result = background.copy()
    selected = []
    base_radius = max(2.0, min(sigma * 1.2, min(width,height) * 0.026))
    for _, x, y, area, peak, color in sources:
        extent = np.sqrt(area) / max(1.0, min(width,height) * 0.024)
        radius = max(2.0, base_radius * (0.5 + 0.7 * min(1.0, extent)))
        if any((x-px)**2 + (y-py)**2 < (radius*2.2)**2 for px,py in selected):
            continue
        selected.append((x,y))
        reach = int(np.ceil(radius * 3.0))
        left, top = max(0,int(x)-reach),max(0,int(y)-reach)
        right,bottom = min(width,int(x)+reach+1),min(height,int(y)+reach+1)
        yy,xx = np.ogrid[top:bottom,left:right]
        distance = np.sqrt((xx-x)**2+(yy-y)**2)/radius
        disk = 1/(1+np.exp(np.clip((distance-.85)*10,-30,30)))
        halo = np.exp(-.5*(distance/1.25)**2)
        # Source energy controls visibility; a dark/flat scene produces no disks.
        strength = 0.68 * (1.0 - np.exp(-1.8 * peak * np.sqrt(area/(np.pi*radius*radius))))
        light = (disk + halo*.06)*strength
        light *= np.clip(1-alpha[top:bottom,left:right]*12,0,1)
        patch = result[top:bottom,left:right]
        result[top:bottom,left:right] = 255-(255-patch)*(1-light[...,None]*color)
        if len(selected)==6:
            break
    return result


def _blur_fraction(intensity: float) -> float:
    """Give gentle blur 75% of slider travel: new 75 is exactly old 25.

    A quadratic remap joins with the same slope at 75 and reaches old 100
    at new 100. Keep the previous upper-range compression and maximum.
    """
    if not 0 <= intensity <= 100:
        raise ValueError("Bokeh intensity must be 0..100")
    if intensity <= 75:
        return intensity / 300.0
    t = (intensity - 75.0) / 25.0
    delta = (25.0 / 3.0) * t + (200.0 / 3.0) * t * t
    return (25.0 + delta / (1.0 + delta / 65.625)) / 100.0



def _opaque_subject_interiors(alpha: np.ndarray, confidence: np.ndarray, scale: float) -> np.ndarray:
    """Model confidence is not skin/clothing transparency; keep the edge matte.

    Restore the interior of the already selected silhouette, not just pixels
    above a second confidence threshold: that would leave mottled holes in
    otherwise opaque faces. The discarded background and edge matte stay put.
    """
    supported = ((confidence > .65) & (alpha > .01)).astype(np.uint8)
    distance = cv2.distanceTransform(supported, cv2.DIST_L2, 5)
    interior = np.clip((distance - 1.0) / max(1.0, 2.0 * scale), 0, 1)
    interior = interior * interior * (3 - 2 * interior)
    return np.maximum(alpha, interior)


def _refine_bokeh_edge(rgb: Image.Image, alpha: np.ndarray, confidence: np.ndarray,
                       scale: float) -> np.ndarray:
    """Antialias the matte along camera edges, keeping opaque subject RGB exact.

    A local linear luminance guide smooths segmentation steps while following
    hair/cloth contrast. A plain blur would spread a grey rim across that edge.
    This is render-only; model selection and later exclusions stay unchanged.
    """
    if not np.any(alpha > 0) or np.all(alpha >= .999):
        return alpha
    guide = cv2.cvtColor(np.asarray(rgb), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0
    radius = max(1, round(5.0 * scale))
    kernel = (radius * 2 + 1,) * 2
    mean_guide = cv2.boxFilter(guide, -1, kernel)
    mean_alpha = cv2.boxFilter(alpha, -1, kernel)
    variance = np.maximum(cv2.boxFilter(guide * guide, -1, kernel) - mean_guide * mean_guide, 0)
    covariance = cv2.boxFilter(guide * alpha, -1, kernel) - mean_guide * mean_alpha
    slope = covariance / (variance + .0016)
    offset = mean_alpha - slope * mean_guide
    refined = np.clip(cv2.boxFilter(slope, -1, kernel) * guide
                      + cv2.boxFilter(offset, -1, kernel), 0, 1)
    # Exact opaque interiors include the restored skin and selected tables.
    # Refinement affects only their transition into the blurred background.
    refined[alpha >= .999] = 1.0
    # Genuine background (including tiny holes between hair/objects) must stay
    # available to the background sampler. Never paint it from its neighbours.
    background = confidence <= .02
    refined[background] = alpha[background]
    return refined


def _blur_render_alpha(rgb: Image.Image, mask: Image.Image, alpha: np.ndarray,
                       scale: float) -> np.ndarray:
    """Reuse render refinement for the same immutable analysis, before erasures."""
    with _FOREGROUND_CACHE_LOCK:
        # The analysis key already contains source/mask hashes and its options;
        # reusing it avoids hashing the photo a second time on every slider move.
        key = next((key for key, value in _FOREGROUND_CACHE.items() if value is alpha), None)
        if key is not None:
            cached = _BOKEH_EDGE_CACHE.get(key)
            if cached is not None and cached[0]() is alpha:
                _BOKEH_EDGE_CACHE.move_to_end(key)
                return cached[1]
    confidence = np.asarray(mask.convert("L"), np.float32) / 255.0
    result = _refine_bokeh_edge(rgb, _opaque_subject_interiors(alpha, confidence, scale),
                                confidence, scale)
    if key is not None and result.nbytes <= 32 * 1024 * 1024:
        result.setflags(write=False)
        with _FOREGROUND_CACHE_LOCK:
            _BOKEH_EDGE_CACHE[key] = (weakref.ref(alpha), result)
            _BOKEH_EDGE_CACHE.move_to_end(key)
            while (len(_BOKEH_EDGE_CACHE) > 2 or
                   sum(entry[1].nbytes for entry in _BOKEH_EDGE_CACHE.values()) > 32 * 1024 * 1024):
                _BOKEH_EDGE_CACHE.popitem(last=False)
    return result


def _background_sampling_weight(mask: Image.Image, alpha: np.ndarray) -> np.ndarray:
    # The alpha-floor removes faint foreground remnants from the final image;
    # it must not make those same mixed source pixels valid background samples.
    confidence = np.asarray(mask.convert("L"), np.float32) / 255.0
    return ((confidence <= .02) & (alpha <= .02)).astype(np.float32)


def _soft_background_fallback(source: np.ndarray, weight: np.ndarray, sigma: float,
                              unsupported: np.ndarray) -> np.ndarray:
    """Avoid foreign-colour polygons where the matte has no nearby support.

    True background pinholes use wider background-only filters. Uncertain
    subject pixels instead keep a local blur of their camera colours: replacing
    a half-selected blue shirt with distant black scenery would punch holes in
    the clothing. This exception is restricted to unsupported pixels; normal
    contour blur still excludes foreground colour.
    """
    h, w = weight.shape
    scale = min(1.0, 360.0 / max(h, w))
    size = (max(1, round(w * scale)), max(1, round(h * scale)))
    local = cv2.GaussianBlur(cv2.resize(source, size, interpolation=cv2.INTER_AREA),
                             (0, 0), max(.01, sigma * scale))
    local = cv2.resize(local, (w, h), interpolation=cv2.INTER_LINEAR)
    # Most unsupported pixels are uncertain matte interiors. Avoid building a
    # second pyramid unless a true background pinhole actually needs it.
    if not np.any(unsupported & (weight > 0)):
        return local
    small_weight = cv2.resize(weight, size, interpolation=cv2.INTER_AREA)
    small_numer = cv2.resize(source * weight[..., None], size, interpolation=cv2.INTER_AREA)
    mean = small_numer.sum(axis=(0, 1)) / max(float(small_weight.sum()), 1e-8)
    fallback = np.broadcast_to(mean, (*small_weight.shape, 3)).copy()
    for multiplier in (8.0, 4.0, 2.0):
        radius = max(1.0, sigma * scale * multiplier)
        support = cv2.GaussianBlur(small_weight, (0, 0), radius)
        colors = cv2.GaussianBlur(small_numer, (0, 0), radius)
        colors /= np.maximum(support[..., None], 1e-8)
        blend = np.clip(support / .01, 0, 1)
        blend = (blend * blend * (3 - 2 * blend))[..., None]
        fallback = colors * blend + fallback * (1 - blend)
    extended = cv2.resize(fallback, (w, h), interpolation=cv2.INTER_LINEAR)
    ambiguous = unsupported & (weight == 0)
    extended[ambiguous] = local[ambiguous]
    return extended


def _foreground_alpha(rgb: Image.Image, mask: Image.Image, alpha_floor: float,
                      feather: float, correction: Image.Image | None = None) -> np.ndarray:
    """Shared face/table analysis, before optional rear-person exclusions."""
    def unsafe_mask(reason="face"):
        raise UnsafeForegroundMaskError("La mascara no conserva el primer plano.", reason=reason)
    alpha = np.asarray(mask.convert('L'), dtype=np.float32) / 255.0
    if correction is not None:
        # Explicit keep strokes may mend a face before the safety checks.
        # Erasures are applied after all automatic table/face preservation.
        keep = np.asarray(correction.resize(rgb.size, Image.Resampling.BILINEAR), np.float32)[..., 1]/255
        alpha = np.maximum(alpha, keep)
    from .bokeh_scene import (has_possible_table_layout, has_possible_front_table_layout,
                             is_front_table_scene, is_long_table_scene, front_table_mask_safe)
    from .bokeh_table import table_foreground
    from .bokeh_scene import dense_group_mask_safe, preserve_table_scene
    original_alpha = alpha.copy()
    source_rgb = np.asarray(rgb)
    confirmed = table_foreground(np.asarray(rgb, dtype=np.float32), alpha)
    strong_table = np.count_nonzero(confirmed > .9) > confirmed.size * .08
    possible_front = has_possible_front_table_layout(alpha)
    front_table = is_front_table_scene(source_rgb, alpha)
    long_table = is_long_table_scene(source_rgb, alpha)
    table_scene = (strong_table or possible_front or has_possible_table_layout(alpha)
                   or long_table or front_table)
    front_table_protection = False
    scene = None
    if table_scene:
        # Validate people before adding any surface: a tabletop must never hide
        # a missing face in the incoming segmentation.
        if front_table:
            if not front_table_mask_safe(source_rgb, original_alpha, include_rear_faces=long_table):
                _LOG.info('Bokeh skipped: incomplete foreground face mask')
                return unsafe_mask()
            front_table_protection = True
        elif long_table and not dense_group_mask_safe(source_rgb, original_alpha):
            return unsafe_mask()
        # Use the actual surface contour, including the far end and its objects.
        # There is deliberately no horizontal foreground band.
        scene, group_size = preserve_table_scene(source_rgb, alpha, include_group_size=True)
        if scene is None and long_table and not strong_table:
            _LOG.info('Bokeh skipped: long table surface could not be selected')
            return unsafe_mask("table")
        alpha = np.maximum(alpha, confirmed if scene is None else np.maximum(scene, confirmed))
        table = np.zeros_like(alpha)
    else:
        scene, group_size = preserve_table_scene(source_rgb, alpha, include_group_size=True)
        if scene is not None:
            alpha = scene
            table = np.zeros_like(alpha)
        else:
            table = confirmed
    if not table_scene and group_size < 7 and (scene is not None or np.count_nonzero(table > .9) > table.size * .08):
        from .bokeh_group import rear_people_mask
        rear = rear_people_mask(np.asarray(rgb, dtype=np.float32))
        alpha = np.minimum(alpha, 1 - rear)
        if rear.any():
            # Prune tiny disconnected remnants near an excluded body, not the
            # main connected foreground or objects on the table.
            radius=max(3,round(min(rgb.size)*.02))
            nearby=cv2.dilate((rear>.1).astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,radius*2+1)))
            count, labels, stats, _=cv2.connectedComponentsWithStats((alpha>.05).astype(np.uint8))
            for label in range(1,count):
                if stats[label,cv2.CC_STAT_AREA]>alpha.size*.001:
                    continue
                region=labels==label
                if nearby[region].mean()>.75:
                    alpha[region]=0
        table = np.minimum(table, 1 - rear)
    alpha = np.maximum(alpha, table)
    surface = np.where((alpha > .95) & (original_alpha < .5), 1., 0.).astype(np.float32)
    # Model quantization commonly returns 254 for solid subject interiors.
    # Treat these as opaque to avoid a global background tint over skin/clothes.
    alpha[alpha >= 254.0 / 255.0] = 1.0
    alpha = np.clip((alpha - alpha_floor) / (1 - alpha_floor), 0, 1)
    scale = min(rgb.size) / 1520.0
    if feather:
        softened = cv2.GaussianBlur(alpha, (0, 0), max(0.01, feather * scale))
        # Preserve confident interiors and avoid broadening the foreground.
        alpha = np.where(alpha >= 0.999, 1.0, np.minimum(alpha, softened))
        # A short transition outside the selected tabletop contour keeps its
        # interior sharp without a visible pasted edge against the background.
        if surface.any():
            alpha = np.maximum(alpha, cv2.GaussianBlur(surface, (0,0), max(.01,feather*scale)))
    from .bokeh_scene import protect_supported_face_cores
    alpha = protect_supported_face_cores(np.asarray(rgb), original_alpha, alpha)
    if front_table_protection:
        alpha = np.maximum(alpha, original_alpha)
    if group_size >= 7:
        if not dense_group_mask_safe(np.asarray(rgb), alpha):
            return unsafe_mask()
    return alpha


_FOREGROUND_CACHE: OrderedDict = OrderedDict()
_BOKEH_EDGE_CACHE: OrderedDict = OrderedDict()
_FOREGROUND_CACHE_LOCK = Lock()


def _foreground_alpha_cached(rgb: Image.Image, mask: Image.Image, alpha_floor: float,
                             feather: float, correction: Image.Image | None = None) -> np.ndarray:
    """Reuse successful guards across validation/rendering; retain float precision."""
    if correction is not None:
        return _foreground_alpha(rgb, mask, alpha_floor, feather, correction)
    digest = hashlib.sha256(rgb.tobytes())
    digest.update(mask.convert("L").tobytes())
    key = (rgb.size, digest.digest(), alpha_floor, feather)
    with _FOREGROUND_CACHE_LOCK:
        cached = _FOREGROUND_CACHE.get(key)
        if cached is not None:
            _FOREGROUND_CACHE.move_to_end(key)
            return cached
    alpha = _foreground_alpha(rgb, mask, alpha_floor, feather)
    alpha.setflags(write=False)
    with _FOREGROUND_CACHE_LOCK:
        _FOREGROUND_CACHE[key] = alpha
        _FOREGROUND_CACHE.move_to_end(key)
        while len(_FOREGROUND_CACHE) > 4:
            _FOREGROUND_CACHE.popitem(last=False)
    return alpha


def background_bokeh(image: Image.Image, mask: Image.Image, intensity: float = 50,
                     max_sigma: float = 70, feather: float = 1.0,
                     alpha_floor: float = 0.0, lights: bool = False,
                     style: str = "blur", correction: Image.Image | None = None,
                     portrait_exclusion: Image.Image | None = None) -> tuple[Image.Image, Image.Image]:
    """Sigma calibration/feather are pixels at 1520px short side. Opaque RGB is unchanged.
    The softened slider curve reaches 0.6 * max_sigma at intensity 100.

    Normalized convolution samples only background pixels to prevent foreground
    color bleeding. Where there is no local background support, colours are extended
    with wider filters. Uncertain matte interiors retain local camera blur
    instead of sampling distant scenery. No generative fill or subject dilation.
    alpha_floor optionally suppresses low-opacity segmentation ghosts.
    """
    if not 0 <= intensity <= 100 or max_sigma <= 0 or feather < 0:
        raise ValueError('Invalid intensity, sigma or feather')
    if not 0 <= alpha_floor < 1 or image.size != mask.size:
        raise ValueError('Invalid alpha floor or mask dimensions')
    rgb = image if image.mode == 'RGB' else image.convert('RGB')
    if style not in {"blur", "black", "studio"}:
        raise ValueError("Unknown background style")

    def unsafe_mask(reason="face"):
        if style in {"black", "studio"}:
            name = "Fondo negro" if style == "black" else "Fondo de estudio"
            message = ("la mascara automatica no conserva todas las caras principales. Se ha detenido para proteger a los protagonistas."
                       if reason == "face" else "no se ha podido conservar con seguridad la superficie de la mesa.")
            raise UnsafeForegroundMaskError(f"{name}: {message}", reason=reason)
        return rgb.copy(), mask.convert('L').copy()
    if intensity == 0:
        return rgb.copy(), mask.convert('L').copy()
    try:
        alpha = _foreground_alpha_cached(rgb, mask, alpha_floor, feather, correction)
    except UnsafeForegroundMaskError as exc:
        return unsafe_mask(exc.reason)
    scale = min(rgb.size) / 1520.0
    if style == "blur":
        # Rendering-only opacity: canonical black renders are also used by
        # portrait selection/validation. Keep those decisions and their model
        # work unchanged, then honor exclusions/corrections after this step.
        alpha = _blur_render_alpha(rgb, mask, alpha, scale)
    source = np.asarray(rgb, dtype=np.float32)
    if portrait_exclusion is not None:
        # Apply the full-source automatic decision after every table/face
        # preservation pass, so a rear silhouette cannot be restored later.
        excluded=np.asarray(portrait_exclusion.resize(rgb.size,Image.Resampling.BILINEAR),np.float32)/255
        alpha=np.minimum(alpha,1-excluded)
    if correction is not None:
        from .mask_correction import corrected_alpha
        alpha = corrected_alpha(alpha, correction)
    if style in {"black", "studio"}:
        # Reuse the exact validated foreground, framing and edge transition.
        # Unlike blur, these replacement backdrops never sample the old scene.
        background = np.asarray(studio_background(rgb.size), dtype=np.float32) if style == "studio" else 0.0
        result = source * alpha[..., None] + background * (1 - alpha[..., None])
        return (Image.fromarray(np.clip(np.rint(result), 0, 255).astype('uint8')),
                Image.fromarray(np.rint(alpha * 255).astype('uint8')))
    # Fully exclude even translucent foreground from background color sampling.
    weight = _background_sampling_weight(mask, alpha)
    sigma = max(0.01, max_sigma * scale * _blur_fraction(intensity))
    # Separable Gaussian filter keeps large radii practical on full-size photos.
    denom = cv2.GaussianBlur(weight, (0, 0), sigma)
    numer = cv2.GaussianBlur(source * weight[..., None], (0, 0), sigma)
    background = (np.divide(numer, np.maximum(denom[..., None], 1e-8))
                  if weight.any() else cv2.GaussianBlur(source, (0, 0), sigma))
    unsupported = (denom < .001) & (alpha < 1)
    if unsupported.any() and weight.any():
        fallback = _soft_background_fallback(source, weight, sigma, unsupported)
        blend = np.clip(denom[unsupported] / .001, 0, 1)
        blend = (blend * blend * (3 - 2 * blend))[:, None]
        background[unsupported] = (background[unsupported] * blend
                                   + fallback[unsupported] * (1 - blend))
    # Legacy lights argument is retained for preset/API compatibility only.
    # Bokeh is spatial blur: no exposure, saturation, gamma or bloom changes.
    # An entirely opaque mask has no visible background.
    result = source * alpha[..., None] + background * (1 - alpha[..., None])
    return (Image.fromarray(np.clip(np.rint(result), 0, 255).astype('uint8')),
            Image.fromarray(np.rint(alpha * 255).astype('uint8')))

