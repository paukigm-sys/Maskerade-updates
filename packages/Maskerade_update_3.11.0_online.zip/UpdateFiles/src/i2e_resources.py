"""Prepare licensed I2E from an authorized private bundle or local vendor install."""
from pathlib import Path
import os
import json
import subprocess
import shutil
import tempfile


def preflight_i2e_resources(root: Path, payload: Path) -> None:
    """Fail before closing the app when the native engine cannot be prepared."""
    if not (payload / "updates/i2e-resources.json").is_file():
        return
    # Prove native initialization before stopping/replacing the working app.
    with tempfile.TemporaryDirectory(prefix="maskerade-i2e-preflight-") as directory:
        stage = Path(directory)
        for relative in (".runtime/i2e", "config/i2e"):
            source = Path(root) / relative
            if source.is_dir():
                shutil.copytree(source, stage / relative)
        install_i2e_resources(stage, payload_root=Path(payload))
        # Keep a newly entered, verified DPAPI license so migration never asks twice.
        license_path = Path(root) / "config/i2e/license.bin"
        activated = stage / "config/i2e/license.bin"
        spec = json.loads((Path(payload) / "updates/i2e-resources.json").read_text(encoding="utf-8-sig"))
        if spec.get("bundled") is True and not license_path.exists() and activated.is_file():
            license_path.parent.mkdir(parents=True, exist_ok=True)
            with license_path.open("xb") as destination:
                destination.write(activated.read_bytes())


def install_i2e_resources(root: Path, payload_root: Path | None = None) -> None:
    root = Path(root).resolve()
    payload = Path(payload_root).resolve() if payload_root is not None else root
    script = payload / "tools/install_i2e.ps1"
    if not script.is_file() or not (payload / "updates/I2EHost.exe").is_file():
        raise RuntimeError("El update no incluye el preparador I2E completo")
    powershell = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    license_path = root / "config/i2e/license.bin"
    had_license = license_path.is_file()
    result = subprocess.run(
        [str(powershell), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(script), "-InstallationRoot", str(root)],
        cwd=root, capture_output=True, text=True, errors="replace", timeout=300,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if result.returncode:
        raise RuntimeError("No se pudo preparar I2E desde el paquete privado o Q-Enhancer local: " + result.stderr.strip())
    from PIL import Image
    from src.i2e_native import I2EClient

    client = I2EClient(root)
    try:
        image = Image.effect_noise((280, 200), 40).convert("RGB")
        output, report = client.enhance(image)
        if output.size != image.size or report.get("version") != "07.00.02":
            raise RuntimeError("La prueba del motor I2E instalado no es valida")
    except Exception:
        if not had_license:
            license_path.unlink(missing_ok=True)
        raise
    finally:
        client.close()
    print("I2E local validado con procesamiento real.")
