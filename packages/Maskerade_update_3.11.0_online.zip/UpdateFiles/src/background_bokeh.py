"""Experimental, non-generative background blur using Maskerade's final alpha."""
from __future__ import annotations

import logging
import numpy as np
import cv2
from PIL import Image

_LOG = logging.getLogger(__name__)


def _enhance_existing_lights(background: np.ndarray, source: np.ndarray,
                             alpha: np.ndarray, sigma: float) -> np.ndarray:
    """Expand compact existing highlights at their measured source positions.

    No seeded/random lights, no decorative overlay and no invented light sources.
    Broad windows/signs remain part of ordinary background blur.
    """
    height, width = alpha.shape
    scale = min(1.0, 720.0 / max(width, height))
    size = (max(1, round(width * scale)), max(1, round(height * scale)))
    rgb = cv2.resize(source / 255.0, size, interpolation=cv2.INTER_AREA)
    foreground = cv2.resize(alpha, size, interpolation=cv2.INTER_LINEAR)
    bright = rgb.max(axis=2)
    local = cv2.GaussianBlur(bright, (0, 0), max(1.0, min(size) * 0.018))
    # Light candidates must be bright AND locally brighter than their surroundings.
    candidates = ((bright > 0.68) & (bright-local > 0.12) & (foreground < 0.015)).astype(np.uint8)
    count, labels, stats, _ = cv2.connectedComponentsWithStats(candidates, 8)
    sources = []
    for label in range(1, count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area < 1 or area > max(4, int(size[0]*size[1]*0.0015)):
            continue
        region = labels == label
        energy = bright[region]
        yy, xx = np.nonzero(region)
        total = float(energy.sum())
        x = float((xx*energy).sum()/total) / scale
        y = float((yy*energy).sum()/total) / scale
        color = (rgb[region]*energy[:, None]).sum(axis=0)/total
        peak = float(energy.max())
        sources.append((total, x, y, area / (scale*scale), peak, color))
    sources.sort(key=lambda item:item[0], reverse=True)
    result = background.copy()
    selected = []
    base_radius = max(2.0, min(sigma * 1.2, min(width,height) * 0.026))
    for _, x, y, area, peak, color in sources:
        extent = np.sqrt(area) / max(1.0, min(width,height) * 0.024)
        radius = max(2.0, base_radius * (0.5 + 0.7 * min(1.0, extent)))
        if any((x-px)**2 + (y-py)**2 < (radius*2.2)**2 for px,py in selected):
            continue
        selected.append((x,y))
        reach = int(np.ceil(radius * 3.0))
        left, top = max(0,int(x)-reach),max(0,int(y)-reach)
        right,bottom = min(width,int(x)+reach+1),min(height,int(y)+reach+1)
        yy,xx = np.ogrid[top:bottom,left:right]
        distance = np.sqrt((xx-x)**2+(yy-y)**2)/radius
        disk = 1/(1+np.exp(np.clip((distance-.85)*10,-30,30)))
        halo = np.exp(-.5*(distance/1.25)**2)
        # Source energy controls visibility; a dark/flat scene produces no disks.
        strength = 0.68 * (1.0 - np.exp(-1.8 * peak * np.sqrt(area/(np.pi*radius*radius))))
        light = (disk + halo*.06)*strength
        light *= np.clip(1-alpha[top:bottom,left:right]*12,0,1)
        patch = result[top:bottom,left:right]
        result[top:bottom,left:right] = 255-(255-patch)*(1-light[...,None]*color)
        if len(selected)==6:
            break
    return result


def _blur_fraction(intensity: float) -> float:
    """Give gentle blur 75% of slider travel: new 75 is exactly old 25.

    A quadratic remap joins with the same slope at 75 and reaches old 100
    at new 100. Keep the previous upper-range compression and maximum.
    """
    if not 0 <= intensity <= 100:
        raise ValueError("Bokeh intensity must be 0..100")
    if intensity <= 75:
        return intensity / 300.0
    t = (intensity - 75.0) / 25.0
    delta = (25.0 / 3.0) * t + (200.0 / 3.0) * t * t
    return (25.0 + delta / (1.0 + delta / 65.625)) / 100.0



def background_bokeh(image: Image.Image, mask: Image.Image, intensity: float = 50,
                     max_sigma: float = 70, feather: float = 1.0,
                     alpha_floor: float = 0.0, lights: bool = False) -> tuple[Image.Image, Image.Image]:
    """Sigma calibration/feather are pixels at 1520px short side. Opaque RGB is unchanged.
    The softened slider curve reaches 0.6 * max_sigma at intensity 100.

    Normalized convolution samples only background pixels to prevent foreground
    color bleeding. Where there is no local background support, nearest background color is used
    as a deterministic fallback. No generative fill or subject dilation.
    alpha_floor optionally suppresses low-opacity segmentation ghosts.
    """
    if not 0 <= intensity <= 100 or max_sigma <= 0 or feather < 0:
        raise ValueError('Invalid intensity, sigma or feather')
    if not 0 <= alpha_floor < 1 or image.size != mask.size:
        raise ValueError('Invalid alpha floor or mask dimensions')
    rgb = image if image.mode == 'RGB' else image.convert('RGB')
    alpha = np.asarray(mask.convert('L'), dtype=np.float32) / 255.0
    if intensity == 0:
        return rgb.copy(), mask.convert('L').copy()
    from .bokeh_scene import (has_possible_table_layout, has_possible_front_table_layout,
                             is_front_table_scene, is_long_table_scene, front_table_mask_safe)
    from .bokeh_table import table_foreground
    from .bokeh_scene import dense_group_mask_safe, preserve_table_scene
    original_alpha = alpha.copy()
    source_rgb = np.asarray(rgb)
    confirmed = table_foreground(np.asarray(rgb, dtype=np.float32), alpha)
    strong_table = np.count_nonzero(confirmed > .9) > confirmed.size * .08
    possible_front = has_possible_front_table_layout(alpha)
    front_table = is_front_table_scene(source_rgb, alpha)
    long_table = is_long_table_scene(source_rgb, alpha)
    table_scene = (strong_table or possible_front or has_possible_table_layout(alpha)
                   or long_table or front_table)
    front_table_protection = False
    scene = None
    if table_scene:
        # Validate people before adding any surface: a tabletop must never hide
        # a missing face in the incoming segmentation.
        if front_table:
            if not front_table_mask_safe(source_rgb, original_alpha, include_rear_faces=long_table):
                _LOG.info('Bokeh skipped: incomplete foreground face mask')
                return rgb.copy(), mask.convert('L').copy()
            front_table_protection = True
        elif long_table and not dense_group_mask_safe(source_rgb, original_alpha):
            return rgb.copy(), mask.convert('L').copy()
        # Use the actual surface contour, including the far end and its objects.
        # There is deliberately no horizontal foreground band.
        scene, group_size = preserve_table_scene(source_rgb, alpha, include_group_size=True)
        if scene is None and long_table and not strong_table:
            _LOG.info('Bokeh skipped: long table surface could not be selected')
            return rgb.copy(), mask.convert('L').copy()
        alpha = np.maximum(alpha, confirmed if scene is None else np.maximum(scene, confirmed))
        table = np.zeros_like(alpha)
    else:
        scene, group_size = preserve_table_scene(source_rgb, alpha, include_group_size=True)
        if scene is not None:
            alpha = scene
            table = np.zeros_like(alpha)
        else:
            table = confirmed
    if not table_scene and group_size < 7 and (scene is not None or np.count_nonzero(table > .9) > table.size * .08):
        from .bokeh_group import rear_people_mask
        rear = rear_people_mask(np.asarray(rgb, dtype=np.float32))
        alpha = np.minimum(alpha, 1 - rear)
        if rear.any():
            # Prune tiny disconnected remnants near an excluded body, not the
            # main connected foreground or objects on the table.
            radius=max(3,round(min(image.size)*.02))
            nearby=cv2.dilate((rear>.1).astype(np.uint8),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,radius*2+1)))
            count, labels, stats, _=cv2.connectedComponentsWithStats((alpha>.05).astype(np.uint8))
            for label in range(1,count):
                if stats[label,cv2.CC_STAT_AREA]>alpha.size*.001:
                    continue
                region=labels==label
                if nearby[region].mean()>.75:
                    alpha[region]=0
        table = np.minimum(table, 1 - rear)
    alpha = np.maximum(alpha, table)
    surface = np.where((alpha > .95) & (original_alpha < .5), 1., 0.).astype(np.float32)
    # Model quantization commonly returns 254 for solid subject interiors.
    # Treat these as opaque to avoid a global background tint over skin/clothes.
    alpha[alpha >= 254.0 / 255.0] = 1.0
    alpha = np.clip((alpha - alpha_floor) / (1 - alpha_floor), 0, 1)
    scale = min(image.size) / 1520.0
    if feather:
        softened = cv2.GaussianBlur(alpha, (0, 0), max(0.01, feather * scale))
        # Preserve confident interiors and avoid broadening the foreground.
        alpha = np.where(alpha >= 0.999, 1.0, np.minimum(alpha, softened))
        # A short transition outside the selected tabletop contour keeps its
        # interior sharp without a visible pasted edge against the background.
        if surface.any():
            alpha = np.maximum(alpha, cv2.GaussianBlur(surface, (0,0), max(.01,feather*scale)))
    from .bokeh_scene import protect_supported_face_cores
    alpha = protect_supported_face_cores(np.asarray(rgb), original_alpha, alpha)
    if front_table_protection:
        alpha = np.maximum(alpha, original_alpha)
    if group_size >= 7:
        if not dense_group_mask_safe(np.asarray(rgb), alpha):
            return rgb.copy(), mask.convert('L').copy()
    source = np.asarray(rgb, dtype=np.float32)
    # Fully exclude even translucent foreground from background color sampling.
    weight = (alpha <= 0.02).astype(np.float32)
    sigma = max(0.01, max_sigma * scale * _blur_fraction(intensity))
    # Separable Gaussian filter keeps large radii practical on full-size photos.
    denom = cv2.GaussianBlur(weight, (0, 0), sigma)
    numer = cv2.GaussianBlur(source * weight[..., None], (0, 0), sigma)
    background = (np.divide(numer, np.maximum(denom[..., None], 1e-8))
                  if weight.any() else cv2.GaussianBlur(source, (0, 0), sigma))
    unsupported = (denom <= 1e-6) & (alpha < 1)
    if unsupported.any() and weight.any():
        from scipy.ndimage import distance_transform_edt
        indices = distance_transform_edt(weight == 0, return_distances=False, return_indices=True)
        background[unsupported] = source[indices[0][unsupported], indices[1][unsupported]]
    # Legacy lights argument is retained for preset/API compatibility only.
    # Bokeh is spatial blur: no exposure, saturation, gamma or bloom changes.
    # An entirely opaque mask has no visible background.
    result = source * alpha[..., None] + background * (1 - alpha[..., None])
    return (Image.fromarray(np.clip(np.rint(result), 0, 255).astype('uint8')),
            Image.fromarray(np.rint(alpha * 255).astype('uint8')))

