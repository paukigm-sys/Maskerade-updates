param([string]$VendorDirectory = "", [string]$InstallationRoot = "", [switch]$ValidateOnly)

$ErrorActionPreference = "Stop"
$PayloadRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Root = $PayloadRoot
if ($InstallationRoot) { $Root = [IO.Path]::GetFullPath($InstallationRoot) }
$Native = Join-Path $Root ".runtime\i2e"
$Config = Join-Path $Root "config\i2e"
function Get-Sha256([string]$Path) {
    $Stream = [IO.File]::OpenRead($Path)
    $Hasher = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($Hasher.ComputeHash($Stream)).Replace("-", "").ToLowerInvariant() }
    finally { $Hasher.Dispose(); $Stream.Dispose() }
}
if (-not $VendorDirectory) {
    foreach ($Base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($Base -and (Test-Path -LiteralPath (Join-Path $Base "Q-Enhancer\Qenhancer.ini"))) {
            $VendorDirectory = Join-Path $Base "Q-Enhancer"
            break
        }
    }
}
$Spec = Get-Content -LiteralPath (Join-Path $PayloadRoot "updates\i2e-resources.json") -Raw | ConvertFrom-Json
$Names = @("I2E_CINT.dll", "I2E_CIIO.dll", "_ISource40.dll", "borlndmm.dll", "ISJPG12.dll")
if ($Spec.version -ne "07.00.02" -or $Spec.files.Count -ne $Names.Count -or @($Spec.files.name | Select-Object -Unique).Count -ne $Names.Count) { throw "Contrato I2E invalido" }
$PrivateDirectory = Join-Path $PayloadRoot "updates\i2e-private"
$EngineSource = $VendorDirectory
if ($Spec.private -eq $true) { $EngineSource = $PrivateDirectory }
elseif ($Spec.bundled -eq $true) { $EngineSource = Join-Path $PayloadRoot "updates\i2e-engine" }
# Validate every source before modifying the installed engine.
foreach ($Record in $Spec.files) {
    $Name = $Record.name
    if ($Name -notin $Names -or $Record.sha256 -notmatch '^[0-9a-f]{64}$') { throw "Recurso I2E invalido" }
    $Destination = Join-Path $Native $Name
    if (-not (Test-Path -LiteralPath $Destination) -or
        (Get-Sha256 $Destination) -ne $Record.sha256) {
        if (-not $EngineSource) { throw "Falta el paquete privado de I2E o un Q-Enhancer local activado" }
        $Source = Join-Path $EngineSource $Name
        if (-not (Test-Path -LiteralPath $Source) -or
            (Get-Sha256 $Source) -ne $Record.sha256) {
            throw "Q-Enhancer local no contiene la version validada de I2E: $Name"
        }
    }
}
$License = Join-Path $Config "license.bin"
$SeedLicense = Join-Path $PrivateDirectory "license.seed"
Add-Type -AssemblyName System.Security
function Test-ProtectedLicense([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $TestBytes = $null
    try {
        $TestBytes = [Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($Path), $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        return ($TestBytes.Length -gt 0)
    } catch { return $false }
    finally { if ($TestBytes) { [Array]::Clear($TestBytes, 0, $TestBytes.Length) } }
}
if ((Test-Path -LiteralPath $License) -and -not (Test-ProtectedLicense $License)) {
    throw "La licencia I2E guardada no corresponde al usuario de Windows actual. No se sobrescribira."
}
if (-not (Test-Path -LiteralPath $License)) {
    if ($Spec.private -eq $true) {
        if ($Spec.license_sha256 -notmatch '^[0-9a-f]{64}$' -or -not (Test-Path -LiteralPath $SeedLicense) -or (Get-Sha256 $SeedLicense) -ne $Spec.license_sha256) { throw "Licencia privada I2E ausente o dañada" }
    } else {
    $Section = ""
    $Password = ""
    $Lines = @()
    if ($VendorDirectory) { $Lines = [IO.File]::ReadAllLines((Join-Path $VendorDirectory "Qenhancer.ini")) }
    foreach ($Line in $Lines) {
        if ($Line.Trim() -match '^\[(.+)\]$') { $Section = $Matches[1]; continue }
        if ($Section -ieq "MAIN" -and $Line -match '^\s*Password\s*=(.*)$') { $Password = $Matches[1].Trim() }
    }
    if (-not $Password) {
        if ($Spec.bundled -eq $true) {
            $Profile = Join-Path $Config "channel.json"
            if (-not (Test-Path -LiteralPath $Profile)) { $Profile = Join-Path $PayloadRoot "config\i2e-channel.example.json" }
            & (Join-Path $PayloadRoot "updates\I2EHost.exe") --activate $EngineSource $Profile $License
            if ($LASTEXITCODE -ne 0 -or -not (Test-ProtectedLicense $License)) {
                throw "Activacion I2E cancelada. La aplicacion instalada se conserva."
            }
        } else {
        throw "Activa Q-Enhancer con la licencia de este PC antes de actualizar I2E"
        }
    }
    }
}
if ($ValidateOnly) {
    $Password = $null
    $Lines = $null
    Write-Output "Recursos I2E locales disponibles."
    exit 0
}
New-Item -ItemType Directory -Path $Native, $Config -Force | Out-Null
function Copy-Changed([string]$Source, [string]$Destination) {
    if ((Test-Path -LiteralPath $Destination) -and
        (Get-Sha256 $Source) -eq (Get-Sha256 $Destination)) { return }
    Copy-Item -LiteralPath $Source -Destination $Destination -Force
    if ((Get-Sha256 $Source) -ne (Get-Sha256 $Destination)) {
        throw "No se pudo verificar recurso I2E"
    }
}
Copy-Changed (Join-Path $PayloadRoot "updates\I2EHost.exe") (Join-Path $Native "I2EHost.exe")
foreach ($Record in $Spec.files) {
    $Destination = Join-Path $Native $Record.name
    if ((Test-Path -LiteralPath $Destination) -and
        (Get-Sha256 $Destination) -eq $Record.sha256) { continue }
    Copy-Changed (Join-Path $EngineSource $Record.name) $Destination
}
if (-not (Test-Path -LiteralPath $License)) {
    if ($Spec.private -eq $true) {
        $Bytes = [IO.File]::ReadAllBytes($SeedLicense)
        try {
            if ($Bytes.Length -eq 0 -or $Bytes.Length -gt 4096) { throw "Licencia privada I2E invalida" }
            $Protected = [Security.Cryptography.ProtectedData]::Protect($Bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
            [IO.File]::WriteAllBytes($License, $Protected)
        } finally { [Array]::Clear($Bytes, 0, $Bytes.Length) }
    } else {
    Add-Type -AssemblyName System.Security
    $Bytes = [Text.Encoding]::UTF8.GetBytes($Password)
    $Password = $null
    try {
        $Protected = [Security.Cryptography.ProtectedData]::Protect($Bytes, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        [IO.File]::WriteAllBytes($License, $Protected)
    } finally {
        [Array]::Clear($Bytes, 0, $Bytes.Length)
        $Lines = $null
    }
    }
}
$Channel = Join-Path $Config "channel.json"
if (-not (Test-Path -LiteralPath $Channel)) {
    Copy-Item -LiteralPath (Join-Path $PayloadRoot "config\i2e-channel.example.json") -Destination $Channel
}
Write-Output "I2E preparado con recursos locales; licencia protegida."
