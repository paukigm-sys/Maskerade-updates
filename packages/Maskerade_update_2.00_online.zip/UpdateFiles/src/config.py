from __future__ import annotations

import ast
import os
from dataclasses import dataclass, field, fields, replace
from pathlib import Path
from typing import Any

from .secure_settings import ensure_settings_storage, load_raw_settings, save_raw_settings, secure_settings_path


SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg"}


class ConfigurationError(RuntimeError):
    """Raised when settings are missing or invalid."""


@dataclass(frozen=True)
class BackgroundRemovalSettings:
    backend: str = "ben2"
    model: str = "models/BEN2"
    max_processing_side: int = 0
    ben2_model: str = "models/BEN2"
    ben2_device: str = "auto"
    ben2_refine_foreground: bool = False
    mask_protection: int = 55
    mask_antighost: int = 0


@dataclass(frozen=True)
class DesktopSettings:
    mask_protection: int = 55
    mask_antighost: int = 0
    person_zoom: int = 70
    person_vertical: int = 10


@dataclass(frozen=True)
class FileStabilitySettings:
    interval_seconds: float = 0.5
    stable_checks: int = 2
    timeout_seconds: float = 90.0


@dataclass(frozen=True)
class ProcessingSettings:
    move_failed_to_failed: bool = True
    process_existing_on_watch_start: bool = True
    watch_poll_interval_seconds: float = 0.5
    perf_monitor: bool = False
    perf_monitor_interval_seconds: float = 1.0


@dataclass(frozen=True)
class CloudSettings:
    enabled: bool = False
    mode: str = "upload_only"
    upload_endpoint: str = ""
    watermark_endpoint: str = ""
    qr_endpoint: str = ""
    api_endpoint: str = ""
    aws_region: str = ""
    identity_user_pool: str = ""
    identity_client: str = ""
    identity_pool: str = ""
    photo_events_table: str = ""
    photo_bucket: str = ""
    download_dir: Path | None = None
    processed_dir: Path | None = None
    park: str = ""
    user_group: str = ""
    username: str = ""
    auth_username: str = ""
    auth_password: str = ""
    timeout_seconds: float = 90.0
    max_parallel_jobs: int = 2


@dataclass(frozen=True)
class FolderPresetRule:
    pattern: str
    preset: str
    enabled: bool = True
    photo_enhance: PhotoEnhanceSettings | None = None


@dataclass(frozen=True)
class LogSettings:
    directory: Path
    jsonl_file: str = "processing.jsonl"

    @property
    def jsonl_path(self) -> Path:
        return self.directory / self.jsonl_file


@dataclass(frozen=True)
class PersonPlacementSettings:
    anchor: str = "bottom_center"
    x: int = 1200
    y: int = 1500
    scale: float = 0.92
    max_width_ratio: float = 0.86
    max_height_ratio: float = 0.95


@dataclass(frozen=True)
class OverlaySettings:
    mode: str = "cover"
    anchor: str = "center"
    x: int = 0
    y: int = 0
    scale: float = 1.0
    opacity: float = 1.0


@dataclass(frozen=True)
class TextLayerSettings:
    text: str = ""
    enabled: bool = False
    anchor: str = "top_center"
    x: int = 0
    y: int = 0
    scale: float = 1.0
    rotation: float = 0.0
    font: str = "Segoe UI"
    color: str = "#FFFFFF"


@dataclass(frozen=True)
class ContactShadowSettings:
    enabled: bool = True
    strength: float = 0.55
    width_ratio: float = 0.72
    height_ratio: float = 0.075
    blur_ratio: float = 0.018
    y_offset_ratio: float = -0.006
    contact_strength: float = 0.85


@dataclass(frozen=True)
class PhotoEnhanceSettings:
    enabled: bool = True
    engine: str = "qenhancer_cuevas"
    preset: str = "C_Channel 1.qes"
    recipe: str = "custom"
    autotune: bool = False
    save_logs: bool = True
    strength: float = 1.0
    brightness: int = 0
    shadow_contrast: int = 0
    highlight_contrast: int = 0
    saturation: int = 0
    red: int = 0
    green: int = 0
    blue: int = 0
    auto_brightness: int = 0
    auto_color: int = 0
    memory_color: int = 0
    shadows: int = 0
    lights: int = 0
    global_sharpen: int = 0
    local_sharpen: int = 0
    denoise: int = 0
    desaturate_shadows: int = 0
    hue_rotation: int = 0
    manual_exposure: int = 0
    manual_contrast: int = 0
    manual_fill_light: int = 0
    manual_gamma: int = 0
    manual_highlights: int = 0
    manual_black_point: int = 0
    manual_sharpness: int = 0
    manual_saturation: int = 0
    manual_temperature: int = 0
    manual_vibrance: int = 0
    manual_red: int = 0
    manual_green: int = 0
    manual_blue: int = 0


@dataclass(frozen=True)
class ParkSettings:
    name: str
    input_dir: Path
    output_dir: Path
    background_path: Path | None
    overlay_path: Path | None
    logo_path: Path | None
    output_size: tuple[int, int] | str
    person: PersonPlacementSettings
    overlay_settings: OverlaySettings
    logo_settings: OverlaySettings
    text_layer: TextLayerSettings
    jpg_quality: int = 94
    harmonize_strength: float = 0.0
    contact_shadow: ContactShadowSettings = field(default_factory=ContactShadowSettings)
    photo_enhance: PhotoEnhanceSettings = field(default_factory=PhotoEnhanceSettings)
    move_original_to_processed: bool = True
    overwrite_output: bool = False
    unique_output_names: bool = True
    suffix: str = ""
    mirror_input_folders: bool = True
    preserve_output_filename: bool = True


@dataclass(frozen=True)
class AppSettings:
    root_dir: Path
    config_path: Path
    background_removal: BackgroundRemovalSettings
    file_stability: FileStabilitySettings
    processing: ProcessingSettings
    cloud: CloudSettings
    logs: LogSettings
    processed_dir: Path
    failed_dir: Path
    parks: dict[str, ParkSettings]
    desktop: DesktopSettings
    active_preset: str = ""
    manual_composition_override: bool = False
    folder_preset_rules: tuple[FolderPresetRule, ...] = ()

    def get_park(self, name: str) -> ParkSettings:
        try:
            return self.parks[name]
        except KeyError as exc:
            available = ", ".join(sorted(self.parks))
            raise ConfigurationError(
                f"Unknown profile '{name}'. Available profiles: {available}"
            ) from exc

    def ensure_runtime_directories(self) -> None:
        self.logs.directory.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.failed_dir.mkdir(parents=True, exist_ok=True)
        if self.cloud.download_dir is not None:
            self.cloud.download_dir.mkdir(parents=True, exist_ok=True)
        if self.cloud.processed_dir is not None:
            self.cloud.processed_dir.mkdir(parents=True, exist_ok=True)
        for park in self.parks.values():
            park.input_dir.mkdir(parents=True, exist_ok=True)
            park.output_dir.mkdir(parents=True, exist_ok=True)


def load_settings(path: str | Path = "config/settings.json") -> AppSettings:
    config_path = Path(path).resolve()
    ensure_settings_storage(config_path)
    if not config_path.exists() and not secure_settings_path(config_path).exists():
        raise ConfigurationError(f"Settings file not found: {config_path}")

    root_dir = _guess_root_dir(config_path)
    raw = load_raw_settings(config_path)
    if _migrate_cloud_config(raw, root_dir):
        save_raw_settings(config_path, raw)

    background_removal = BackgroundRemovalSettings(
        **_known_dataclass_values(BackgroundRemovalSettings, raw.get("background_removal", {}))
    )
    desktop = DesktopSettings(**_known_dataclass_values(DesktopSettings, raw.get("desktop", {})))
    background_removal = replace(
        background_removal,
        mask_protection=_clamp_int(desktop.mask_protection, -100, 100),
        mask_antighost=_clamp_int(desktop.mask_antighost, -100, 100),
    )
    file_stability = FileStabilitySettings(**raw.get("file_stability", {}))
    processing = ProcessingSettings(**raw.get("processing", {}))
    cloud_raw = _cloud_raw(raw)
    cloud_values = _known_dataclass_values(CloudSettings, cloud_raw)
    cloud_download_dir = cloud_raw.get("download_dir", "cloud_downloads")
    cloud_processed_dir = cloud_raw.get("processed_dir", "processed/cloud processed")
    cloud_values["download_dir"] = _resolve_path(root_dir, cloud_download_dir) if cloud_download_dir else None
    cloud_values["processed_dir"] = _resolve_path(root_dir, cloud_processed_dir) if cloud_processed_dir else None
    cloud = CloudSettings(**cloud_values)

    logs_raw = raw.get("logs", {})
    logs = LogSettings(
        directory=_resolve_path(root_dir, logs_raw.get("directory", "logs")),
        jsonl_file=logs_raw.get("jsonl_file", "processing.jsonl"),
    )

    parks_raw = raw.get("parks", {})
    if not parks_raw:
        raise ConfigurationError("No processing profiles configured in settings.json")

    parks = {
        name: _park_from_dict(name, data, root_dir)
        for name, data in parks_raw.items()
    }

    settings = AppSettings(
        root_dir=root_dir,
        config_path=config_path,
        background_removal=background_removal,
        file_stability=file_stability,
        processing=processing,
        cloud=cloud,
        logs=logs,
        processed_dir=_resolve_path(root_dir, raw.get("processed_dir", "processed")),
        failed_dir=_resolve_path(root_dir, raw.get("failed_dir", "failed")),
        parks=parks,
        desktop=desktop,
        active_preset=str(raw.get("active_preset") or "").strip(),
        manual_composition_override=_as_bool(raw.get("manual_composition_override", False)),
        folder_preset_rules=_folder_preset_rules_from_raw(raw),
    )
    settings.ensure_runtime_directories()
    return settings


def _legacy_cloud_key() -> str:
    return "".join(chr(code) for code in (110, 117, 118, 111, 108))


def _text_from_codes(codes: tuple[int, ...]) -> str:
    return "".join(chr(code) for code in codes)


def _cloud_raw(raw: dict[str, Any]) -> dict[str, Any]:
    cloud = raw.get("cloud", {})
    selected = cloud if isinstance(cloud, dict) else raw.get(_legacy_cloud_key(), {})
    if not isinstance(selected, dict):
        return {}
    migrated = dict(selected)
    legacy_identity_keys = (
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 117, 115, 101, 114, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_user_pool"),
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 99, 108, 105, 101, 110, 116, 95, 105, 100)), "identity_client"),
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 105, 100, 101, 110, 116, 105, 116, 121, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_pool"),
    )
    for old_key, new_key in legacy_identity_keys:
        if migrated.get(old_key) and not migrated.get(new_key):
            migrated[new_key] = migrated[old_key]
    return migrated


def _migrate_cloud_config(raw: dict[str, Any], root_dir: Path) -> bool:
    changed = False
    legacy_key = _legacy_cloud_key()
    legacy = raw.get(legacy_key)
    if isinstance(legacy, dict) and not isinstance(raw.get("cloud"), dict):
        raw["cloud"] = dict(legacy)
        changed = True
    if legacy_key in raw:
        raw.pop(legacy_key, None)
        changed = True

    cloud = raw.setdefault("cloud", {})
    if not isinstance(cloud, dict):
        raw["cloud"] = {}
        cloud = raw["cloud"]
        changed = True

    legacy_identity_keys = (
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 117, 115, 101, 114, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_user_pool"),
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 99, 108, 105, 101, 110, 116, 95, 105, 100)), "identity_client"),
        (_text_from_codes((99, 111, 103, 110, 105, 116, 111, 95, 105, 100, 101, 110, 116, 105, 116, 121, 95, 112, 111, 111, 108, 95, 105, 100)), "identity_pool"),
    )
    for old_key, new_key in legacy_identity_keys:
        if cloud.get(old_key) and not cloud.get(new_key):
            cloud[new_key] = cloud[old_key]
            changed = True
        if old_key in cloud:
            cloud.pop(old_key, None)
            changed = True

    legacy_download = f"{legacy_key}_downloads"
    if str(cloud.get("download_dir") or "") == legacy_download:
        cloud["download_dir"] = "cloud_downloads"
        changed = True
    legacy_processed = f"processed/{legacy_key} processed"
    if str(cloud.get("processed_dir") or "").replace("\\", "/") == legacy_processed:
        cloud["processed_dir"] = "processed/cloud processed"
        changed = True

    return _merge_legacy_cloud_defaults(cloud, root_dir) or changed


def _merge_legacy_cloud_defaults(cloud: dict[str, Any], root_dir: Path) -> bool:
    wanted = {
        "upload_endpoint",
        "watermark_endpoint",
        "qr_endpoint",
        "api_endpoint",
        "aws_region",
        "identity_user_pool",
        "identity_client",
        "identity_pool",
        "photo_events_table",
        "photo_bucket",
    }
    if all(str(cloud.get(key) or "").strip() for key in wanted):
        return False

    changed = False
    defaults: dict[str, str] = {}
    for src_dir in _legacy_source_dirs(root_dir):
        defaults.update(_legacy_dataclass_defaults(src_dir / "config.py"))
        defaults.update(_legacy_module_defaults(src_dir / f"{_legacy_cloud_key()}_module.py"))
        for key, value in defaults.items():
            if key in wanted and value and not str(cloud.get(key) or "").strip():
                cloud[key] = value
                changed = True
        if all(str(cloud.get(key) or "").strip() for key in wanted):
            break
    return changed


def _legacy_source_dirs(root_dir: Path) -> list[Path]:
    candidates: list[Path] = []
    env_value = os.environ.get("MASKERADE_LEGACY_SRC", "")
    if env_value:
        candidates.append(Path(env_value))
    candidates.append(root_dir / "src")
    try:
        backups = sorted(
            (path for path in root_dir.iterdir() if path.is_dir() and path.name.startswith("_backup")),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        backups = []
    candidates.extend(path / "src" for path in backups)

    unique: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        try:
            resolved = candidate.resolve()
        except OSError:
            resolved = candidate
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(candidate)
    return unique


def _legacy_dataclass_defaults(path: Path) -> dict[str, str]:
    names = {"upload_endpoint", "watermark_endpoint", "qr_endpoint", "api_endpoint"}
    defaults: dict[str, str] = {}
    tree = _parse_python_source(path)
    if tree is None:
        return defaults
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        for item in node.body:
            name = ""
            value_node = None
            if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
                name = item.target.id
                value_node = item.value
            elif isinstance(item, ast.Assign) and item.targets and isinstance(item.targets[0], ast.Name):
                name = item.targets[0].id
                value_node = item.value
            if name in names and value_node is not None:
                value = _literal_string(value_node)
                if value:
                    defaults[name] = value
    return defaults


def _legacy_module_defaults(path: Path) -> dict[str, str]:
    old_to_new = {
        _text_from_codes((65, 87, 83, 95, 82, 69, 71, 73, 79, 78)): "aws_region",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 85, 83, 69, 82, 95, 80, 79, 79, 76, 95, 73, 68)): "identity_user_pool",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 67, 76, 73, 69, 78, 84, 95, 73, 68)): "identity_client",
        _text_from_codes((67, 79, 71, 78, 73, 84, 79, 95, 73, 68, 69, 78, 84, 73, 84, 89, 95, 80, 79, 79, 76, 95, 73, 68)): "identity_pool",
        _text_from_codes((80, 72, 79, 84, 79, 95, 69, 86, 69, 78, 84, 83, 95, 84, 65, 66, 76, 69)): "photo_events_table",
        _text_from_codes((80, 72, 79, 84, 79, 95, 66, 85, 67, 75, 69, 84)): "photo_bucket",
    }
    defaults: dict[str, str] = {}
    tree = _parse_python_source(path)
    if tree is None:
        return defaults
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        value = _literal_string(node.value)
        if not value:
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in old_to_new:
                defaults[old_to_new[target.id]] = value
    return defaults


def _parse_python_source(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError, UnicodeDecodeError):
        return None


def _literal_string(node: ast.AST | None) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value.strip()
    return ""




def _bootstrap_settings_file(config_path: Path) -> None:
    example_path = config_path.with_name("settings.example.json")
    if not example_path.exists():
        return
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_bytes(example_path.read_bytes())


def _park_from_dict(name: str, data: dict[str, Any], root_dir: Path) -> ParkSettings:
    required = ["input_dir", "output_dir"]
    missing = [key for key in required if key not in data]
    if missing:
        raise ConfigurationError(
            f"Profile '{name}' is missing required keys: {', '.join(missing)}"
        )

    output_size_raw = data.get("output_size", "input")
    if isinstance(output_size_raw, str):
        output_size: tuple[int, int] | str = output_size_raw
    else:
        if len(output_size_raw) != 2:
            raise ConfigurationError(f"Profile '{name}' output_size must contain width/height")
        output_size = (int(output_size_raw[0]), int(output_size_raw[1]))

    overlay_raw = data.get("overlay")
    overlay_path = _resolve_path(root_dir, overlay_raw) if overlay_raw else None
    logo_raw = data.get("logo")
    logo_path = _resolve_path(root_dir, logo_raw) if logo_raw else None
    background_raw = data.get("background")
    background_path = _resolve_path(root_dir, background_raw) if background_raw else None

    return ParkSettings(
        name=name,
        input_dir=_resolve_path(root_dir, data["input_dir"]),
        output_dir=_resolve_path(root_dir, data["output_dir"]),
        background_path=background_path,
        overlay_path=overlay_path,
        logo_path=logo_path,
        output_size=output_size,
        person=PersonPlacementSettings(**_known_dataclass_values(PersonPlacementSettings, data.get("person", {}))),
        overlay_settings=OverlaySettings(**_known_dataclass_values(OverlaySettings, data.get("overlay_settings", {}))),
        logo_settings=OverlaySettings(**_known_dataclass_values(OverlaySettings, data.get("logo_settings", {"mode": "original", "anchor": "top_left"}))),
        text_layer=TextLayerSettings(**_known_dataclass_values(TextLayerSettings, data.get("text_layer", {}))),
        jpg_quality=int(data.get("jpg_quality", 94)),
        harmonize_strength=float(data.get("harmonize_strength", 0.0)),
        contact_shadow=ContactShadowSettings(**_known_dataclass_values(ContactShadowSettings, data.get("contact_shadow", {}))),
        photo_enhance=PhotoEnhanceSettings(**_known_dataclass_values(PhotoEnhanceSettings, data.get("photo_enhance", {}))),
        move_original_to_processed=bool(data.get("move_original_to_processed", True)),
        overwrite_output=bool(data.get("overwrite_output", False)),
        unique_output_names=bool(data.get("unique_output_names", True)),
        suffix=str(data.get("suffix", f"_{name}")),
        mirror_input_folders=bool(data.get("mirror_input_folders", True)),
        preserve_output_filename=bool(data.get("preserve_output_filename", True)),
    )


def _guess_root_dir(config_path: Path) -> Path:
    if config_path.parent.name.lower() == "config":
        return config_path.parent.parent
    return config_path.parent


def _folder_preset_rules_from_raw(raw: dict[str, Any]) -> tuple[FolderPresetRule, ...]:
    rules_raw = raw.get("folder_presets", raw.get("folder_preset_rules", []))
    if isinstance(rules_raw, dict):
        rules_raw = [
            {"pattern": pattern, "preset": preset}
            for pattern, preset in rules_raw.items()
        ]
    if not isinstance(rules_raw, list):
        return ()

    rules: list[FolderPresetRule] = []
    for item in rules_raw:
        if not isinstance(item, dict):
            continue
        pattern = str(
            item.get("pattern")
            or item.get("folder")
            or item.get("prefix")
            or ""
        ).strip()
        preset = str(item.get("preset") or "").strip()
        if not pattern or not preset:
            continue
        rules.append(
            FolderPresetRule(
                pattern=pattern,
                preset=preset,
                enabled=bool(item.get("enabled", True)),
                photo_enhance=(
                    PhotoEnhanceSettings(
                        **_known_dataclass_values(PhotoEnhanceSettings, item.get("photo_enhance", {}))
                    )
                    if isinstance(item.get("photo_enhance"), dict)
                    else None
                ),
            )
        )
    return tuple(rules)


def _resolve_path(root_dir: Path, value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return root_dir / path


def _clamp_int(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(max_value, int(value)))


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().casefold() in {"1", "true", "yes", "si", "sí", "on"}


def _known_dataclass_values(cls, data: dict[str, Any]) -> dict[str, Any]:
    allowed = {field.name for field in fields(cls)}
    return {key: value for key, value in data.items() if key in allowed}


