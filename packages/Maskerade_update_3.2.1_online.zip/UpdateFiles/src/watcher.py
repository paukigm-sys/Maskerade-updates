from __future__ import annotations

import logging
import time
from datetime import datetime
from pathlib import Path

from .config import SUPPORTED_IMAGE_EXTENSIONS, load_settings
from .hotfolder_ledger import HotfolderLedger
from .image_utils import list_images
from .processor import PhotoProcessor, ProcessingBusyError

FileSignature = tuple[int, int, int, int]


class WatchService:
    FAILED_RETRY_DELAY_SECONDS = 5.0
    MAX_FAILED_ATTEMPTS = 3
    TEMP_PLACEHOLDER_TIMEOUT_SECONDS = 60
    UNREADY_TIMEOUT_SECONDS = 30
    INFRASTRUCTURE_RETRY_MAX_SECONDS = 60.0

    def __init__(
        self,
        processor: PhotoProcessor,
        logger: logging.Logger,
        stop_file: Path | None = None,
    ) -> None:
        self.processor = processor
        self.logger = logger
        self.stop_file = Path(stop_file).resolve() if stop_file is not None else None
        self._stability: dict[Path, tuple[FileSignature, float]] = {}
        self._processed_signatures: dict[Path, FileSignature] = {}
        self._failed_retries: dict[Path, tuple[FileSignature, float, int]] = {}
        self._unready_since: dict[Path, float] = {}
        self._waiting_for_files_log = False
        self._busy_path: Path | None = None
        self._busy_next_log_at = 0.0
        self._stop_notice_logged = False
        self._rolling_observed_paths: set[Path] = set()
        self._rolling_done_paths: set[Path] = set()
        self._last_progress_total = 0
        self._received_count = 0
        self._done_count = 0
        self._present_entries: dict[Path, FileSignature | None] = {}
        self._metrics_count = 0
        self._metrics_seconds = 0.0
        self._ledger_cleanup_day = None
        self.ledger: HotfolderLedger | None = None
        park = getattr(processor, "park", None)
        settings = getattr(processor, "settings", None)
        input_dir = getattr(park, "input_dir", None)
        root_dir = getattr(settings, "root_dir", None)
        if input_dir is not None and root_dir is not None:
            root = Path(root_dir).resolve()
            self.ledger = HotfolderLedger(
                root / "data" / "hotfolder_ledger.sqlite3",
                root / "recovery" / "hotfolder",
                Path(input_dir),
                str(getattr(park, "name", "photo")),
            )

    def run(self, process_existing: bool = True) -> None:
        self.processor.ensure_ready()
        self.logger.info("Hotfolder input: %s", self.processor.park.input_dir)

        self.logger.info("Hotfolder will process existing and repeated JPG files recursively")

        # Polling is deliberately used on Windows because folders often arrive
        # through copy/sync operations in bursts. Readiness is nevertheless
        # decided per file so an active batch never blocks already-complete JPGs.
        try:
            self._run_polling()
        finally:
            if self.ledger is not None:
                self.ledger.close()

    def _run_watchdog(self) -> None:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        service = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.src_path)
                service._note_event(path, event.is_directory)

            def on_moved(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.dest_path)
                service._note_event(path, event.is_directory)

        observer = Observer()
        observer.schedule(Handler(), str(self.processor.park.input_dir), recursive=True)
        observer.start()
        self.logger.info("Watching %s recursively", self.processor.park.input_dir)

        try:
            while not self._stop_requested():
                self._process_new_files()
                time.sleep(self.processor.settings.processing.watch_poll_interval_seconds)
        except KeyboardInterrupt:
            self.logger.info("Stopping watcher")
        finally:
            observer.stop()
            observer.join()

    def _run_polling(self) -> None:
        interval = self.processor.settings.processing.watch_poll_interval_seconds
        self.logger.info(
            "Polling %s every %.1fs",
            self.processor.park.input_dir,
            interval,
        )
        try:
            while not self._stop_requested():
                try:
                    self._process_new_files()
                except Exception:
                    self.logger.exception(
                        "Hotfolder cycle failed unexpectedly; retrying on the next poll"
                    )
                time.sleep(interval)
        except KeyboardInterrupt:
            self.logger.info("Stopping polling watcher")

    def _stop_requested(self) -> bool:
        requested = self._restart_requested()
        if requested and not self._stop_notice_logged:
            self.logger.info("Hotfolder restart requested; finishing active Cloud work")
            self._stop_notice_logged = True
        return requested

    def _restart_requested(self) -> bool:
        return self.stop_file is not None and self.stop_file.exists()

    def _note_event(self, path: Path, is_directory: bool) -> None:
        if is_directory:
            self.logger.info("Detected new folder: %s", path)
            return
        if path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            self.logger.info("Detected new file: %s", path)

    def _process_new_files(self) -> None:
        self._reload_processor_settings()
        retry_pending_cloud = getattr(self.processor, "retry_pending_cloud_outputs", None)
        if callable(retry_pending_cloud):
            retry_pending_cloud()
        retry_failed_cloud = getattr(self.processor, "retry_failed_cloud_outputs", None)
        if callable(retry_failed_cloud):
            retry_failed_cloud()
        self._recover_interrupted_inputs()
        current_images = list_images(self.processor.park.input_dir)
        self._observe_in_entries(current_images)
        if self.ledger is not None:
            self.ledger.observe_many(current_images)
        current_set = set(current_images)
        for path in list(self._processed_signatures):
            if path not in current_set:
                self._processed_signatures.pop(path, None)
        for path in list(self._failed_retries):
            if path not in current_set:
                self._failed_retries.pop(path, None)
        for path in list(self._unready_since):
            if path not in current_set:
                self._unready_since.pop(path, None)
        candidates = [
            path
            for path in current_images
            if self._needs_processing(path)
        ]
        if not candidates:
            self._stability.clear()
            self._waiting_for_files_log = False
            self._reset_busy_state()
            self.processor.poll_cloud()
            self.processor.cleanup_empty_input_dirs()
            self._emit_idle_batch_status()
            return

        ready_candidates = [path for path in candidates if self._is_ready(path)]
        if not ready_candidates:
            self._log_waiting_once()
            self.processor.poll_cloud()
            self._emit_idle_batch_status()
            return
        self._waiting_for_files_log = False

        handled_any = False
        completed_all = True
        ready_to_process = self._protect_ready_candidates(
            path for path in ready_candidates if self._needs_processing(path)
        )

        if ready_to_process:
            print(f"HOTPROGRESS start {len(ready_to_process)}", flush=True)
            observed_total = self._report_progress_total()
            completed_total = self._progress_done_count()
            if completed_total > 0:
                print(
                    f"HOTPROGRESS tally {completed_total} {observed_total}",
                    flush=True,
                )

        total_ready = len(ready_to_process)
        if ready_to_process:
            try:
                processing_signatures = {
                    path: self._file_signature(path) for path in ready_to_process
                }

                def item_started(index: int, path: Path) -> None:
                    if self.ledger is not None:
                        self.ledger.mark_processing(path)
                    print(f"HOTPROGRESS item {index} {total_ready} {path.name}", flush=True)

                def item_done(index: int, path: Path, result) -> None:  # type: ignore[no-untyped-def]
                    self._record_candidate_result(
                        path,
                        result,
                        processing_signatures.get(path),
                    )
                    print(f"HOTPROGRESS done {index} {total_ready} {path.name}", flush=True)
                    if self._is_terminal_result(path, result):
                        self._rolling_done_paths.add(path.resolve())
                        self._done_count += 1
                    latest_images = list_images(self.processor.park.input_dir)
                    self._observe_in_entries(latest_images)
                    observed_total = self._report_progress_total()
                    completed_total = self._progress_done_count()
                    print(
                        f"HOTPROGRESS tally {completed_total} {observed_total}",
                        flush=True,
                    )

                batch_processing_started = time.perf_counter()
                results = self.processor.process_files_pipelined(
                    ready_to_process,
                    archive_failed=False,
                    on_item_start=item_started,
                    on_item_done=item_done,
                    should_continue=lambda: not self._restart_requested(),
                )
                batch_processing_seconds = time.perf_counter() - batch_processing_started
                processed_count = sum(
                    1 for result in results if getattr(result, "status", "") == "processed"
                )
                self._metrics_count += processed_count
                self._metrics_seconds += batch_processing_seconds
                handled_any = bool(results)
                completed_all = len(results) == total_ready
                self._reset_busy_state()
            except ProcessingBusyError:
                self._log_busy_retry(ready_to_process[0])
                completed_all = False

        active = set(candidates)
        for path in list(self._stability):
            if path not in active:
                self._stability.pop(path, None)

        self.processor.cleanup_empty_input_dirs()
        if handled_any:
            processed_ready = len(results)
            remaining = list_images(self.processor.park.input_dir)
            if self.ledger is not None:
                self.ledger.observe_many(remaining)
            remaining_pending = [path for path in remaining if self._needs_processing(path)]

            # Cloud delivery runs in its own executor. If more input is already
            # present, do not hold the hotfolder behind uploads/downloads from
            # the previous group: collect completed jobs and let the next poll
            # pick up the newly complete files. We only wait for Cloud when IN
            # is currently drained (or during an orderly configuration restart).
            restart_requested = self._restart_requested()
            if completed_all and remaining_pending and not restart_requested:
                self.processor.poll_cloud()
            else:
                print(f"HOTPROGRESS cloud_wait {processed_ready}", flush=True)
                self.processor.wait_for_cloud()
                remaining = list_images(self.processor.park.input_dir)
                if self.ledger is not None:
                    self.ledger.observe_many(remaining)
                remaining_pending = [
                    path for path in remaining if self._needs_processing(path)
                ]

            self._observe_in_entries(remaining)
            reconciliation_paths = self._rolling_observed_paths | set(remaining_pending)
            batches = self._batch_names(reconciliation_paths)
            summary = self.ledger.summary(paths=reconciliation_paths) if self.ledger is not None else None
            pending = summary.pending if summary is not None else len(remaining_pending)
            failed = summary.failed if summary is not None else 0
            missing = summary.missing if summary is not None else 0
            skipped = summary.skipped if summary is not None else 0
            extra = 0
            cloud_failed = self._cloud_failed_count(batches)
            integrity_failure = failed > 0 or missing > 0 or skipped > 0 or cloud_failed > 0
            has_pending = bool(remaining_pending) or pending > 0
            batch_complete = not has_pending and not integrity_failure
            if completed_all and batch_complete:
                completed_total = self._progress_done_count()
                self._emit_batch_metrics()
                print(f"HOTPROGRESS complete {completed_total}", flush=True)
                self.logger.info("Hotfolder batch complete after Cloud finished")
                self._reset_rolling_progress()
            elif completed_all and has_pending:
                print(f"HOTPROGRESS continue {pending}", flush=True)
                self.logger.info(
                    "Hotfolder batch continues: %s newly arrived, expected or pending file(s)",
                    pending,
                )
            elif completed_all and integrity_failure:
                print(
                    f"HOTINTEGRITY incomplete pending={pending} failed={failed} "
                    f"missing={missing} skipped={skipped} extra={extra} "
                    f"cloud_failed={cloud_failed}"
                    + f" processed={self._progress_done_count()} expected={self._progress_total()}",
                    flush=True,
                )
                self.logger.error(
                    "Hotfolder batch INCOMPLETE: pending=%s failed=%s missing=%s "
                    "skipped=%s extra=%s cloud_failed=%s",
                    pending,
                    failed,
                    missing,
                    skipped,
                    extra,
                    cloud_failed,
                )
                self._reset_rolling_progress()
            else:
                self._stop_requested()
                print(f"HOTPROGRESS restart {processed_ready} {total_ready}", flush=True)
                self.logger.info(
                    "Hotfolder batch paused after %s/%s files for configuration restart",
                    processed_ready,
                    total_ready,
                )
        else:
            self.processor.poll_cloud()

    def _cloud_enabled(self) -> bool:
        cloud = getattr(getattr(self.processor, "settings", None), "cloud", None)
        return bool(getattr(cloud, "enabled", False))

    def _batch_names(self, paths) -> set[str]:  # type: ignore[no-untyped-def]
        names: set[str] = set()
        input_root = Path(self.processor.park.input_dir).resolve()
        for path in paths:
            try:
                relative = Path(path).resolve().relative_to(input_root)
            except ValueError:
                continue
            if len(relative.parts) > 1:
                names.add(relative.parts[0])
        return names

    def _observe_in_entries(self, paths) -> None:
        current = {Path(path).resolve() for path in paths}
        for path in set(self._present_entries) - current:
            self._present_entries.pop(path, None)
            self._processed_signatures.pop(path, None)
        for path in current:
            signature = self._file_signature(path)
            if signature is None:
                continue
            previous = self._present_entries.get(path)
            new_entry = path not in self._present_entries or (
                path in self._rolling_done_paths and signature != previous
            )
            if new_entry:
                # A new delivery is work even if its name/content was processed before.
                if path not in self._processed_signatures or self._needs_processing(path):
                    self._received_count += 1
                    self._rolling_observed_paths.add(path)
                    self._rolling_done_paths.discard(path)
            self._present_entries[path] = signature

    def _progress_total(self) -> int:
        return max(self._received_count, len(self._rolling_observed_paths))

    def _progress_done_count(self) -> int:
        return max(self._done_count, len(self._rolling_done_paths))

    def _cloud_failed_count(self, batches: set[str]) -> int:
        if not self._cloud_enabled() or not batches:
            return 0
        failed_root = Path(self.processor.settings.failed_dir) / "cloud"
        count = 0
        for batch in batches:
            directory = failed_root / batch
            if not directory.is_dir():
                continue
            try:
                count += sum(
                    1
                    for path in directory.iterdir()
                    if path.is_file() and path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS
                )
            except OSError:
                # An unreadable failed folder must prevent a false success.
                return max(1, count)
        return count

    def _report_progress_total(self) -> int:
        total = self._progress_total()
        if total != self._last_progress_total:
            print(f"HOTPROGRESS observed {total}", flush=True)
            self._last_progress_total = total
        return total

    def _emit_idle_batch_status(self) -> None:
        if not self._rolling_observed_paths or self.ledger is None:
            return
        batches = self._batch_names(self._rolling_observed_paths)
        summary = self.ledger.summary(paths=self._rolling_observed_paths)
        expected = self._progress_total()
        detected = expected
        processed = max(self._progress_done_count(), summary.processed)
        pending = summary.pending
        failed = summary.failed
        missing = summary.missing
        skipped = summary.skipped
        extra = 0
        complete = summary.complete and skipped == 0

        pending_cloud = 0
        if self._cloud_enabled():
            pending_counter = getattr(self.processor, "pending_cloud_count", None)
            if callable(pending_counter):
                pending_cloud = max(0, int(pending_counter()))
            if processed > 0:
                completed_cloud = max(0, min(processed, processed - pending_cloud))
                print(
                    f"HOTPROGRESS cloud_tally {completed_cloud} {processed}",
                    flush=True,
                )
            if pending_cloud > 0:
                return

        cloud_failed = self._cloud_failed_count(batches)
        if complete and cloud_failed == 0:
            self._emit_batch_metrics()
            print(f"HOTPROGRESS complete {processed}", flush=True)
            self.logger.info("Hotfolder batch complete after durable reconciliation")
            self._reset_rolling_progress()
            return
        if pending > 0:
            return
        print(
            f"HOTINTEGRITY incomplete pending={pending} failed={failed} "
            f"missing={missing} skipped={skipped} extra={extra} "
            f"cloud_failed={cloud_failed} processed={processed} expected={expected}",
            flush=True,
        )
        self.logger.error(
            "Hotfolder batch INCOMPLETE: expected=%s detected=%s processed=%s "
            "pending=%s failed=%s missing=%s skipped=%s extra=%s cloud_failed=%s",
            expected,
            detected,
            processed,
            pending,
            failed,
            missing,
            skipped,
            extra,
            cloud_failed,
        )
        self._reset_rolling_progress()

    def _emit_batch_metrics(self) -> None:
        if self._metrics_count:
            average = self._metrics_seconds / self._metrics_count
            print(f"HOTMETRICS {self._metrics_count} {self._metrics_seconds:.3f} {average:.3f}", flush=True)

    def _reset_rolling_progress(self) -> None:
        self._metrics_count = 0
        self._metrics_seconds = 0.0
        self._received_count = 0
        self._done_count = 0
        self._present_entries.clear()
        self._rolling_observed_paths.clear()
        self._rolling_done_paths.clear()
        self._last_progress_total = 0

    def _log_waiting_once(self) -> None:
        if self._waiting_for_files_log:
            return
        self.logger.info(
            "Hotfolder waiting only for each pending file to finish writing"
        )
        self._waiting_for_files_log = True

    def _is_ready(self, path: Path) -> bool:
        try:
            stat = path.stat()
        except FileNotFoundError:
            self._stability.pop(path, None)
            return False

        if stat.st_size <= 0:
            self._handle_persistently_unready(path, "archivo vacio")
            return False

        self._unready_since.pop(path, None)

        signature = self._signature_from_stat(stat)
        now = time.monotonic()
        previous = self._stability.get(path)

        if previous is None:
            self._stability[path] = (signature, now)
            return False

        previous_signature, stable_since = previous
        if signature != previous_signature:
            self._stability[path] = (signature, now)
            return False

        interval = max(0.5, self.processor.settings.file_stability.interval_seconds)
        checks = max(1, self.processor.settings.file_stability.stable_checks)
        required_seconds = interval * checks

        return (now - stable_since) >= required_seconds

    def _handle_candidate(self, path: Path) -> bool:
        if not path.exists():
            self.logger.warning("Hotfolder skipped disappeared file: %s", path)
            self._stability.pop(path, None)
            return True

        if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
            self._mark_current_signature(path)
            return True

        try:
            processed_signature = self._file_signature(path)
            self._reload_processor_settings()
            result = self.processor.process_file(
                path,
                wait_for_stability=False,
                archive_failed=False,
            )
            self._record_candidate_result(path, result, processed_signature)
            self._reset_busy_state(path)
            return True
        except ProcessingBusyError:
            self._log_busy_retry(path)
            return False

    def _record_candidate_result(
        self,
        path: Path,
        result,
        processed_signature: FileSignature | None = None,
    ) -> None:  # type: ignore[no-untyped-def]
        if result.status == "processed":
            if self.ledger is not None:
                self.ledger.mark_processed(
                    path,
                    getattr(result, "output_path", None),
                    getattr(result, "archived_path", None),
                )
            if bool(getattr(result, "input_replaced", False)):
                # The completed job belongs to the file identity captured at
                # start. A new identity now occupies the same path and must be
                # observed and processed as an independent job.
                self._processed_signatures.pop(path, None)
                if self.ledger is not None and path.exists():
                    self.ledger.observe(path)
            elif (
                processed_signature is not None
                and path.exists()
                and self._file_signature(path) != processed_signature
            ):
                self._processed_signatures.pop(path, None)
                if self.ledger is not None:
                    self.ledger.observe(path)
            else:
                self._mark_current_signature(path)
            self._failed_retries.pop(path, None)
            self._unready_since.pop(path, None)
            self._stability.pop(path, None)
        elif result.status == "skipped":
            disappeared = not path.exists() or "eliminad" in str(result.message or "").casefold()
            if disappeared:
                reason = result.message or "Archivo desaparecido durante el lote"
                if self.ledger is not None:
                    self.ledger.mark_missing(path, reason)
                self.logger.critical(
                    "Hotfolder input disappeared; safety copy kept for manual recovery: %s",
                    path,
                )
                print(f"HOTINTEGRITY missing\t{path.name}", flush=True)
                self._processed_signatures.pop(path, None)
                self._stability.pop(path, None)
                return
            if self.ledger is not None:
                self.ledger.mark_skipped(path, result.message)
            self._mark_current_signature(path)
        elif result.status == "failed":
            failed_path = getattr(result, "failed_path", None)
            if failed_path is not None:
                if self.ledger is not None:
                    self.ledger.mark_failed(
                        path,
                        Path(failed_path),
                        result.message or "archivo corrupto",
                    )
                self._failed_retries.pop(path, None)
                self._unready_since.pop(path, None)
                self._stability.pop(path, None)
                self._announce_failed_move(
                    path,
                    Path(failed_path),
                    result.message or "archivo corrupto",
                )
                return
            self._schedule_failed_retry(path, result.message)
            if self.ledger is not None and path.exists():
                self.ledger.mark_retry(path, result.message)
            self._stability.pop(path, None)

    def _reload_processor_settings(self) -> None:
        if self.processor.settings.config_path.name.startswith("settings_snapshot_"):
            self.processor.refresh_live_automatic_settings()
            return
        try:
            settings = load_settings(self.processor.settings.config_path)
        except Exception as exc:
            self.logger.warning(
                "Hotfolder could not reload settings; keeping previous config: %s",
                exc,
            )
            return
        park_name = self.processor.park.name
        if park_name not in settings.parks:
            park_name = next(iter(settings.parks))
        self.processor.update_settings(settings, settings.get_park(park_name))

    def _log_busy_retry(self, path: Path) -> None:
        now = time.monotonic()
        if self._busy_path != path:
            self._busy_path = path
            self._busy_next_log_at = 0.0

        if now < self._busy_next_log_at:
            return

        self.logger.warning(
            "Hotfolder ocupado: hay otro proceso activo. Esperando turno para %s",
            path,
        )
        self._busy_next_log_at = now + 15.0

    def _reset_busy_state(self, path: Path | None = None) -> None:
        if path is not None and self._busy_path is not None and self._busy_path != path:
            return
        self._busy_path = None
        self._busy_next_log_at = 0.0

    def _file_signature(self, path: Path) -> FileSignature | None:
        try:
            stat = path.stat()
        except FileNotFoundError:
            return None
        return self._signature_from_stat(stat)

    def _signature_from_stat(self, stat) -> FileSignature:  # type: ignore[no-untyped-def]
        return (
            int(stat.st_size),
            int(stat.st_mtime_ns),
            int(stat.st_ctime_ns),
            int(getattr(stat, "st_ino", 0)),
        )

    def _needs_processing(self, path: Path) -> bool:
        signature = self._file_signature(path)
        if signature is None:
            return False
        if self._processed_signatures.get(path) == signature:
            return False

        failed_retry = self._failed_retries.get(path)
        if failed_retry is None:
            return True

        failed_signature, retry_at, _attempts = failed_retry
        if failed_signature != signature:
            self._failed_retries.pop(path, None)
            self._unready_since.pop(path, None)
            return True
        return time.monotonic() >= retry_at

    def _schedule_failed_retry(self, path: Path, message: str | None = None) -> None:
        signature = self._file_signature(path)
        if signature is None:
            self._failed_retries.pop(path, None)
            return

        previous = self._failed_retries.get(path)
        attempts = previous[2] + 1 if previous is not None and previous[0] == signature else 1
        now = time.monotonic()

        if self._is_incomplete_input_failure(message):
            self._archive_after_failed_retry(
                path,
                "JPEG truncado o corrupto; sin reintentos",
            )
            return

        if self._is_infrastructure_failure(message):
            exponent = min(max(0, attempts - 1), 4)
            delay = min(
                self.INFRASTRUCTURE_RETRY_MAX_SECONDS,
                self.FAILED_RETRY_DELAY_SECONDS * (2**exponent),
            )
            self._failed_retries[path] = (signature, now + delay, attempts)
            detail = f": {message}" if message else ""
            self.logger.error(
                "Hotfolder conserva %s en IN por fallo temporal de GPU/sistema; "
                "reintento en %.0fs%s",
                path,
                delay,
                detail,
            )
            return

        if attempts >= self.MAX_FAILED_ATTEMPTS:
            if self._archive_after_failed_retry(path, f"{attempts} intentos fallidos"):
                return
            attempts = self.MAX_FAILED_ATTEMPTS - 1

        self._failed_retries[path] = (
            signature,
            now + self.FAILED_RETRY_DELAY_SECONDS,
            attempts,
        )
        detail = f": {message}" if message else ""
        self.logger.warning(
            "Hotfolder reintentara %s en %.0fs (intento %d/%d)%s",
            path,
            self.FAILED_RETRY_DELAY_SECONDS,
            attempts + 1,
            self.MAX_FAILED_ATTEMPTS,
            detail,
        )

    def _archive_after_failed_retry(self, path: Path, reason: str) -> bool:
        try:
            archived = self.processor.archive_failed_input(path, force=True)
        except Exception as exc:
            archived = None
            self.logger.warning(
                "Hotfolder no pudo apartar %s en failed; lo reintentara: %s",
                path,
                exc,
            )
        self._failed_retries.pop(path, None)
        self._unready_since.pop(path, None)
        if archived is None:
            return False
        if self.ledger is not None:
            self.ledger.mark_failed(path, archived, reason)
        self._announce_failed_move(path, archived, reason)
        self.logger.error(
            "Hotfolder aparto %s en failed (%s): %s",
            path,
            reason,
            archived,
        )
        return True

    @staticmethod
    def _is_incomplete_input_failure(message: str | None) -> bool:
        return bool(message and "jpeg truncado o corrupto" in message.casefold())

    @staticmethod
    def _is_infrastructure_failure(message: str | None) -> bool:
        if not message:
            return False
        normalized = message.casefold()
        return any(
            marker in normalized
            for marker in (
                "cuda",
                "cudnn",
                "cublas",
                "out of memory",
                "gpu",
                "controlador grafico",
            )
        )

    def _unready_timeout(self, path: Path) -> float:
        configured_timeout = max(
            1.0,
            float(self.processor.settings.file_stability.timeout_seconds or 30.0),
        )
        if path.name.casefold().startswith("temp_"):
            return float(self.TEMP_PLACEHOLDER_TIMEOUT_SECONDS)
        return min(float(self.UNREADY_TIMEOUT_SECONDS), configured_timeout)

    def _handle_persistently_unready(self, path: Path, reason: str) -> None:
        now = time.monotonic()
        first_seen = self._unready_since.setdefault(path, now)
        timeout = self._unready_timeout(path)
        elapsed = max(0.0, now - first_seen)
        if elapsed < timeout:
            self._announce_unready_wait(path, reason, elapsed, timeout)
            return

        try:
            archived = self.processor.archive_failed_input(path, force=True)
        except Exception as exc:
            archived = None
            self.logger.warning(
                "Hotfolder no pudo apartar %s en failed; lo reintentara: %s",
                path,
                exc,
            )
        self._unready_since.pop(path, None)
        if archived is not None:
            if self.ledger is not None:
                self.ledger.mark_failed(path, archived, f"{reason} tras {timeout:.0f}s")
            self._announce_failed_move(path, archived, f"{reason} tras {timeout:.0f}s")
            self.logger.error(
                "Hotfolder aparto %s en failed tras %.0fs (%s): %s",
                path,
                timeout,
                reason,
                archived,
            )

    @staticmethod
    def _announce_unready_wait(
        path: Path,
        reason: str,
        elapsed: float,
        timeout: float,
    ) -> None:
        safe_name = path.name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_reason = reason.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        elapsed_seconds = max(0, int(elapsed))
        timeout_seconds = max(1, int(round(timeout)))
        print(
            f"HOTWAIT\t{safe_name}\t{safe_reason}\t"
            f"{elapsed_seconds}\t{timeout_seconds}",
            flush=True,
        )

    def _announce_failed_move(self, source: Path, archived: Path, reason: str) -> None:
        safe_name = source.name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_reason = reason.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_target = str(archived).replace("\t", " ").replace("\r", " ").replace("\n", " ")
        print(f"HOTFAILED\t{safe_name}\t{safe_reason}\t{safe_target}", flush=True)

    def _mark_current_signature(self, path: Path) -> None:
        signature = self._file_signature(path)
        if signature is None:
            self._processed_signatures.pop(path, None)
            return
        self._processed_signatures[path] = signature

    def _protect_ready_candidates(self, paths) -> list[Path]:  # type: ignore[no-untyped-def]
        selected: list[Path] = []
        for path in paths:
            if self.ledger is None:
                selected.append(path)
                continue
            try:
                self.ledger.ensure_backup(path)
            except Exception as exc:
                self.ledger.mark_retry(path, f"Safety copy failed: {exc}")
                self.logger.exception(
                    "Hotfolder will not process %s because its safety copy failed: %s",
                    path,
                    exc,
                )
                print(f"HOTINTEGRITY backup_failed\t{path.name}", flush=True)
                continue
            selected.append(path)
        return selected

    @staticmethod
    def _is_terminal_result(path: Path, result) -> bool:  # type: ignore[no-untyped-def]
        if result.status == "processed":
            return True
        if result.status == "failed":
            return getattr(result, "failed_path", None) is not None
        if result.status != "skipped":
            return False
        message = str(getattr(result, "message", "") or "").casefold()
        return path.exists() and "eliminad" not in message

    def _recover_interrupted_inputs(self) -> None:
        if self.ledger is None:
            return
        today = datetime.now().astimezone().date()
        if self._ledger_cleanup_day != today:
            expired = self.ledger.expire_previous_day_absent()
            self._ledger_cleanup_day = today
            if expired:
                self.logger.info("Hotfolder daily cleanup: %d old absent inputs expired; backups retained", expired)
        restored, missing = self.ledger.recover_interrupted()
        for path in restored:
            self.logger.warning("Hotfolder recovered interrupted input from safety copy: %s", path)
            print(f"HOTINTEGRITY restored\t{path.name}", flush=True)
        for path in missing:
            self.logger.critical(
                "Hotfolder detected removed input; it will not restore it automatically: %s",
                path,
            )
            print(f"HOTINTEGRITY missing\t{path.name}", flush=True)

    def _handle_directory(self, path: Path) -> None:
        if not path.exists() or not path.is_dir():
            return
        for image_path in list_images(path):
            self._handle_candidate(image_path)
