from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import shutil
import ssl
import stat
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Callable


DEFAULT_RESOURCE_MANIFEST_URL = (
    "https://api.github.com/repos/paukigm-sys/Maskerade-updates/contents/"
    "resources/3.1.1/birefnet-dynamic.json?ref=main"
)
RESOURCE_ID = "birefnet-dynamic"
RESOURCE_TARGET = Path("models/BiRefNet_dynamic")
MARKER_NAME = ".maskerade-resource.json"

MAX_MANIFEST_BYTES = 512 * 1024
MAX_PARTS = 32
MAX_PART_BYTES = 96 * 1024 * 1024
MAX_ARCHIVE_BYTES = 1280 * 1024 * 1024
MAX_ZIP_ENTRIES = 256
MAX_ZIP_MEMBER_BYTES = 1024 * 1024 * 1024
MAX_ZIP_TOTAL_BYTES = 1280 * 1024 * 1024
MAX_ZIP_COMPRESSION_RATIO = 1000.0
FREE_SPACE_MARGIN_BYTES = 512 * 1024 * 1024

ProgressCallback = Callable[[int, str, str], None]


class ResourceNetworkError(RuntimeError):
    """A recoverable network failure while fetching a runtime resource."""


@dataclass(frozen=True)
class ResourcePart:
    index: int
    name: str
    url: str
    size: int
    sha256: str


@dataclass(frozen=True)
class ResourceFile:
    path: str
    size: int
    sha256: str


@dataclass(frozen=True)
class ResourceManifest:
    resource: str
    version: str
    archive_name: str
    archive_size: int
    archive_sha256: str
    installed_path: str
    parts: tuple[ResourcePart, ...]
    files: tuple[ResourceFile, ...]
    manifest_url: str


def resource_manifest_url() -> str:
    return os.environ.get("MASKERADE_RESOURCE_URL", "").strip() or DEFAULT_RESOURCE_MANIFEST_URL


def load_resource_manifest(
    url: str | None = None,
    *,
    expected_version: str | None = None,
    timeout_seconds: int = 20,
) -> ResourceManifest:
    selected_url = (url or resource_manifest_url()).strip()
    _require_https_url(selected_url, "manifest de recursos")
    payload = _download_text(_cache_busted_url(selected_url), timeout_seconds)
    return _parse_manifest(_decode_manifest_payload(payload), selected_url, expected_version)


def resource_status(app_dir: Path, manifest: ResourceManifest) -> str:
    target = _target_path(Path(app_dir).resolve(), manifest)
    try:
        marker = json.loads((target / MARKER_NAME).read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return "missing"
    if not isinstance(marker, dict):
        return "missing"
    if (
        marker.get("resource") != manifest.resource
        or marker.get("version") != manifest.version
        or str(marker.get("archive_sha256") or "").lower() != manifest.archive_sha256
    ):
        return "missing"
    for required in manifest.files:
        path = target / Path(required.path)
        if not path.is_file() or path.stat().st_size != required.size:
            return "missing"
    return "installed"


def install_resource(
    app_dir: Path,
    manifest: ResourceManifest,
    *,
    progress: ProgressCallback | None = None,
) -> Path:
    app_dir = Path(app_dir).resolve()
    target = _target_path(app_dir, manifest)
    if resource_status(app_dir, manifest) == "installed":
        _activate_hybrid_settings(app_dir)
        _emit(progress, 100, "ready", "Motor hibrido preparado")
        return target

    required_free = manifest.archive_size + sum(item.size for item in manifest.files)
    required_free += FREE_SPACE_MARGIN_BYTES
    free = shutil.disk_usage(app_dir).free
    if free < required_free:
        raise RuntimeError(
            "Espacio insuficiente para instalar el motor: "
            f"se necesitan {required_free / (1024**3):.1f} GB y hay {free / (1024**3):.1f} GB libres."
        )

    work_dir = app_dir / "tmp" / "resources" / manifest.resource / manifest.version
    parts_dir = work_dir / "parts"
    parts_dir.mkdir(parents=True, exist_ok=True)
    _emit(progress, 1, "manifest", "Preparando descarga del motor hibrido")

    total_bytes = sum(item.size for item in manifest.parts)
    completed = sum(
        item.size
        for item in manifest.parts
        if _file_matches(parts_dir / item.name, item.size, item.sha256)
    )
    for part in manifest.parts:
        part_path = parts_dir / part.name
        if _file_matches(part_path, part.size, part.sha256):
            continue

        def on_part_bytes(current: int, *, base: int = completed, item: ResourcePart = part) -> None:
            percent = 2 + int(((base + current) / max(1, total_bytes)) * 78)
            _emit(
                progress,
                min(80, percent),
                "download",
                f"Descargando parte {item.index}/{len(manifest.parts)}",
            )

        _download_part(part, part_path, on_part_bytes)
        completed += part.size

    archive_path = work_dir / manifest.archive_name
    _emit(progress, 82, "assemble", "Uniendo partes descargadas")
    _assemble_archive(manifest, parts_dir, archive_path)

    models_dir = target.parent
    models_dir.mkdir(parents=True, exist_ok=True)
    stage_dir = models_dir / f".{target.name}.staging-{os.getpid()}"
    backup_dir = models_dir / f".{target.name}.backup-{int(time.time())}"
    shutil.rmtree(stage_dir, ignore_errors=True)
    _emit(progress, 88, "extract", "Descomprimiendo y validando el motor")
    candidate = _extract_resource_archive(archive_path, stage_dir, target.name)
    _validate_required_files(candidate, manifest.files, verify_hash=True)
    _write_marker(candidate, manifest)

    moved_existing = False
    try:
        if target.exists():
            if backup_dir.exists():
                shutil.rmtree(backup_dir)
            os.replace(target, backup_dir)
            moved_existing = True
        os.replace(candidate, target)
        _validate_required_files(target, manifest.files, verify_hash=False)
        if moved_existing:
            shutil.rmtree(backup_dir, ignore_errors=True)
    except Exception:
        if not target.exists() and moved_existing and backup_dir.exists():
            os.replace(backup_dir, target)
        raise
    finally:
        shutil.rmtree(stage_dir, ignore_errors=True)

    _activate_hybrid_settings(app_dir)
    shutil.rmtree(work_dir, ignore_errors=True)
    _emit(progress, 100, "ready", "Motor hibrido instalado")
    return target


def _parse_manifest(
    data: dict[str, Any], manifest_url: str, expected_version: str | None
) -> ResourceManifest:
    if data.get("schema") != 1:
        raise RuntimeError("El manifest de recursos usa un esquema no compatible.")
    resource = str(data.get("resource") or "").strip()
    version = str(data.get("version") or "").strip()
    archive_name = str(data.get("archive_name") or "").strip()
    installed_path = str(data.get("installed_path") or "").replace("\\", "/").strip("/")
    archive_sha256 = _valid_sha256(data.get("archive_sha256"), "archivo completo")
    archive_size = _positive_int(data.get("archive_size"), "tamano del archivo completo")
    if resource != RESOURCE_ID:
        raise RuntimeError("El manifest no corresponde al motor BiRefNet esperado.")
    if expected_version and version != expected_version:
        raise RuntimeError(f"El motor publicado es para Maskerade {version}, no para {expected_version}.")
    if installed_path.casefold() != RESOURCE_TARGET.as_posix().casefold():
        raise RuntimeError("El manifest intenta instalar el motor en una ruta no permitida.")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.zip", archive_name):
        raise RuntimeError("El nombre del archivo de recursos no es valido.")
    if archive_size > MAX_ARCHIVE_BYTES:
        raise RuntimeError("El archivo de recursos supera el tamano permitido.")

    raw_parts = data.get("parts")
    if not isinstance(raw_parts, list) or not raw_parts or len(raw_parts) > MAX_PARTS:
        raise RuntimeError("El manifest no contiene una lista valida de partes.")
    parts: list[ResourcePart] = []
    for expected_index, raw in enumerate(raw_parts, start=1):
        if not isinstance(raw, dict):
            raise RuntimeError("El manifest contiene una parte no valida.")
        index = _positive_int(raw.get("index"), "indice de parte")
        name = str(raw.get("name") or "").strip()
        part_url = str(raw.get("url") or "").strip()
        size = _positive_int(raw.get("size"), "tamano de parte")
        sha256 = _valid_sha256(raw.get("sha256"), "parte")
        if index != expected_index or not re.fullmatch(r"[A-Za-z0-9_.-]+\.part\d{3}", name):
            raise RuntimeError("El orden o nombre de una parte no es valido.")
        if size > MAX_PART_BYTES:
            raise RuntimeError("Una parte del motor supera el tamano permitido.")
        _require_https_url(part_url, "parte del motor")
        parts.append(ResourcePart(index, name, part_url, size, sha256))
    if sum(item.size for item in parts) != archive_size:
        raise RuntimeError("La suma de las partes no coincide con el archivo completo.")

    raw_files = data.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise RuntimeError("El manifest no declara los archivos obligatorios del motor.")
    files: list[ResourceFile] = []
    seen: set[str] = set()
    for raw in raw_files:
        if not isinstance(raw, dict):
            raise RuntimeError("El manifest contiene un archivo obligatorio no valido.")
        relative = _safe_relative_path(str(raw.get("path") or ""))
        key = relative.casefold()
        if key in seen:
            raise RuntimeError("El manifest repite un archivo obligatorio.")
        seen.add(key)
        files.append(
            ResourceFile(
                relative,
                _positive_int(raw.get("size"), "tamano de archivo"),
                _valid_sha256(raw.get("sha256"), "archivo"),
            )
        )
    if "model.safetensors" not in seen or "config.json" not in seen:
        raise RuntimeError("El manifest no contiene los archivos esenciales de BiRefNet.")
    return ResourceManifest(
        resource, version, archive_name, archive_size, archive_sha256,
        installed_path, tuple(parts), tuple(files), manifest_url
    )


def _download_part(
    part: ResourcePart, destination: Path, on_bytes: Callable[[int], None] | None
) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(1, 4):
        current = destination.stat().st_size if destination.exists() else 0
        if current > part.size:
            destination.unlink(missing_ok=True)
            current = 0
        headers = {"User-Agent": "Maskerade-Resource-Installer"}
        if current:
            headers["Range"] = f"bytes={current}-"
        request = urllib.request.Request(part.url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=90, context=_ssl_context()) as response:
                _require_https_response(response, "parte del motor")
                status = int(getattr(response, "status", 200) or 200)
                append = current > 0 and status == 206
                if append:
                    content_range = str(getattr(response, "headers", {}).get("Content-Range") or "")
                    if not content_range.startswith(f"bytes {current}-"):
                        raise RuntimeError("El servidor devolvio un rango de descarga no valido.")
                else:
                    current = 0
                downloaded = current
                with destination.open("ab" if append else "wb") as handle:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        downloaded += len(chunk)
                        if downloaded > part.size:
                            raise RuntimeError("Una parte descargada supera el tamano publicado.")
                        handle.write(chunk)
                        if on_bytes is not None:
                            on_bytes(downloaded)
            if destination.stat().st_size != part.size:
                raise ResourceNetworkError("La descarga de una parte quedo incompleta.")
            if _sha256(destination) != part.sha256:
                destination.unlink(missing_ok=True)
                raise RuntimeError("Una parte descargada no coincide con su SHA256.")
            return
        except urllib.error.HTTPError as exc:
            if exc.code == 416:
                destination.unlink(missing_ok=True)
            if attempt >= 3:
                raise ResourceNetworkError(
                    "No se pudo descargar el motor hibrido. Comprueba Internet y vuelve a intentarlo."
                ) from exc
        except (urllib.error.URLError, TimeoutError, OSError, ResourceNetworkError) as exc:
            if attempt >= 3:
                raise ResourceNetworkError(
                    "No se pudo descargar el motor hibrido. Comprueba Internet y vuelve a intentarlo."
                ) from exc
        time.sleep(float(attempt))


def _assemble_archive(manifest: ResourceManifest, parts_dir: Path, archive_path: Path) -> None:
    assembling = archive_path.with_suffix(archive_path.suffix + ".assembling")
    assembling.unlink(missing_ok=True)
    with assembling.open("wb") as output:
        for part in manifest.parts:
            path = parts_dir / part.name
            if not _file_matches(path, part.size, part.sha256):
                raise RuntimeError(f"La parte {part.index} no esta completa o es invalida.")
            with path.open("rb") as source:
                shutil.copyfileobj(source, output, length=1024 * 1024)
    if assembling.stat().st_size != manifest.archive_size:
        assembling.unlink(missing_ok=True)
        raise RuntimeError("El archivo reconstruido tiene un tamano incorrecto.")
    if _sha256(assembling) != manifest.archive_sha256:
        assembling.unlink(missing_ok=True)
        raise RuntimeError("El archivo reconstruido no coincide con su SHA256.")
    assembling.replace(archive_path)


def _extract_resource_archive(archive_path: Path, stage_dir: Path, root_name: str) -> Path:
    try:
        with zipfile.ZipFile(archive_path) as archive:
            _validate_zip_entries(archive, stage_dir, root_name)
            archive.extractall(stage_dir)
    except zipfile.BadZipFile as exc:
        raise RuntimeError("El archivo del motor no es un ZIP valido.") from exc
    candidate = stage_dir / root_name
    if not candidate.is_dir():
        raise RuntimeError("El ZIP del motor no contiene la carpeta BiRefNet esperada.")
    return candidate


def _validate_zip_entries(archive: zipfile.ZipFile, root: Path, root_name: str) -> None:
    entries = archive.infolist()
    if not entries or len(entries) > MAX_ZIP_ENTRIES:
        raise RuntimeError("El ZIP del motor contiene una cantidad de archivos no permitida.")
    resolved_root = root.resolve()
    seen: set[str] = set()
    total_size = 0
    for entry in entries:
        raw_name = entry.filename
        if not raw_name or "\\" in raw_name or "\x00" in raw_name:
            raise RuntimeError("El ZIP del motor contiene una ruta no valida.")
        path = PurePosixPath(raw_name)
        if (
            path.is_absolute() or not path.parts
            or path.parts[0].casefold() != root_name.casefold()
            or any(part in {"", ".", ".."} or ":" in part for part in path.parts)
        ):
            raise RuntimeError("El ZIP del motor contiene una ruta no segura.")
        key = "/".join(path.parts).rstrip("/").casefold()
        if key in seen:
            raise RuntimeError("El ZIP del motor contiene rutas duplicadas.")
        seen.add(key)
        target = (resolved_root / Path(*path.parts)).resolve()
        try:
            target.relative_to(resolved_root)
        except ValueError as exc:
            raise RuntimeError("El ZIP del motor intenta escribir fuera de su carpeta.") from exc
        mode = (entry.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(mode) or entry.flag_bits & 0x1:
            raise RuntimeError("El ZIP del motor contiene enlaces o archivos cifrados.")
        if entry.is_dir():
            continue
        if entry.file_size < 0 or entry.file_size > MAX_ZIP_MEMBER_BYTES:
            raise RuntimeError("El ZIP del motor contiene un archivo demasiado grande.")
        total_size += entry.file_size
        if total_size > MAX_ZIP_TOTAL_BYTES:
            raise RuntimeError("El ZIP del motor supera el tamano descomprimido permitido.")
        if entry.file_size and entry.compress_size == 0:
            raise RuntimeError("El ZIP del motor contiene una compresion no valida.")
        if entry.compress_size and entry.file_size / entry.compress_size > MAX_ZIP_COMPRESSION_RATIO:
            raise RuntimeError("El ZIP del motor contiene una compresion sospechosa.")


def _validate_required_files(
    root: Path, files: tuple[ResourceFile, ...], *, verify_hash: bool
) -> None:
    for required in files:
        path = root / Path(required.path)
        if not path.is_file() or path.stat().st_size != required.size:
            raise RuntimeError(f"Falta un archivo obligatorio del motor: {required.path}")
        if verify_hash and _sha256(path) != required.sha256:
            raise RuntimeError(f"Un archivo del motor no coincide con su SHA256: {required.path}")


def hybrid_settings_active(app_dir: Path) -> bool:
    from .secure_settings import load_raw_settings

    config_path = Path(app_dir).resolve() / "config" / "settings.json"
    try:
        raw = load_raw_settings(config_path)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError):
        return False
    removal = raw.get("background_removal")
    if not isinstance(removal, dict):
        return False
    return (
        removal.get("birefnet_enabled") is True
        and removal.get("birefnet_hybrid_ben2") is True
        and removal.get("birefnet_fallback_ben2", True) is True
        and str(removal.get("birefnet_model") or "").replace("\\", "/").casefold()
        == RESOURCE_TARGET.as_posix().casefold()
    )


def _activate_hybrid_settings(app_dir: Path) -> None:
    from .secure_settings import ensure_settings_storage, load_raw_settings, save_raw_settings

    config_path = app_dir / "config" / "settings.json"
    ensure_settings_storage(config_path)
    raw = load_raw_settings(config_path)
    removal = raw.setdefault("background_removal", {})
    if not isinstance(removal, dict):
        removal = {}
        raw["background_removal"] = removal
    removal.update(
        {
            "birefnet_enabled": True,
            "birefnet_model": RESOURCE_TARGET.as_posix(),
            "birefnet_device": "auto",
            "birefnet_input_size": 2048,
            "birefnet_fallback_ben2": True,
            "birefnet_hybrid_ben2": True,
        }
    )
    save_raw_settings(config_path, raw)


def _target_path(app_dir: Path, manifest: ResourceManifest) -> Path:
    target = (app_dir / Path(manifest.installed_path)).resolve()
    try:
        target.relative_to(app_dir)
    except ValueError as exc:
        raise RuntimeError("La ruta de instalacion del motor sale de Maskerade.") from exc
    return target


def _write_marker(path: Path, manifest: ResourceManifest) -> None:
    marker = {
        "schema": 1,
        "resource": manifest.resource,
        "version": manifest.version,
        "archive_sha256": manifest.archive_sha256,
    }
    (path / MARKER_NAME).write_text(json.dumps(marker, indent=2) + "\n", encoding="utf-8")


def _download_text(url: str, timeout_seconds: int) -> str:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Maskerade-Resource-Installer", "Cache-Control": "no-cache", "Pragma": "no-cache"},
    )
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds, context=_ssl_context()) as response:
                _require_https_response(response, "manifest de recursos")
                payload = response.read(MAX_MANIFEST_BYTES + 1)
                if len(payload) > MAX_MANIFEST_BYTES:
                    raise RuntimeError("El manifest de recursos es demasiado grande.")
                return payload.decode("utf-8-sig")
        except urllib.error.HTTPError:
            raise
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            if attempt >= 3:
                raise ResourceNetworkError(
                    "No se pudo consultar el motor hibrido. Comprueba Internet y vuelve a intentarlo."
                ) from exc
            time.sleep(float(attempt))
    raise AssertionError("Bucle de descarga inalcanzable")


def _decode_manifest_payload(payload: str) -> dict[str, Any]:
    data = json.loads(payload)
    if not isinstance(data, dict):
        raise RuntimeError("El manifest de recursos no contiene un objeto JSON valido.")
    if str(data.get("encoding") or "").casefold() == "base64" and "content" in data:
        encoded = str(data.get("content") or "").replace("\n", "").strip()
        try:
            data = json.loads(base64.b64decode(encoded, validate=True).decode("utf-8-sig"))
        except (binascii.Error, UnicodeError, json.JSONDecodeError) as exc:
            raise RuntimeError("La API devolvio un manifest de recursos no valido.") from exc
        if not isinstance(data, dict):
            raise RuntimeError("El manifest de recursos no contiene un objeto JSON valido.")
    return data


def _require_https_url(url: str, label: str) -> None:
    parsed = urllib.parse.urlsplit(str(url or "").strip())
    if (
        parsed.scheme.casefold() != "https" or not parsed.hostname
        or parsed.username is not None or parsed.password is not None
    ):
        raise RuntimeError(f"La URL de {label} debe usar HTTPS y no incluir credenciales.")


def _require_https_response(response: Any, label: str) -> None:
    geturl = getattr(response, "geturl", None)
    if callable(geturl):
        final_url = geturl()
        if final_url:
            _require_https_url(str(final_url), label)


def _cache_busted_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    query.append(("maskerade_cache", str(time.time_ns())))
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urllib.parse.urlencode(query), parsed.fragment))


def _ssl_context() -> ssl.SSLContext | None:
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return None


def _valid_sha256(value: Any, label: str) -> str:
    digest = str(value or "").strip().lower()
    if re.fullmatch(r"[0-9a-f]{64}", digest) is None:
        raise RuntimeError(f"El SHA256 de {label} no es valido.")
    return digest


def _positive_int(value: Any, label: str) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"El {label} no es valido.") from exc
    if number <= 0:
        raise RuntimeError(f"El {label} no es valido.")
    return number


def _safe_relative_path(value: str) -> str:
    raw = value.replace("\\", "/").strip("/")
    path = PurePosixPath(raw)
    if not raw or path.is_absolute() or any(part in {"", ".", ".."} or ":" in part for part in path.parts):
        raise RuntimeError("El manifest contiene una ruta de archivo no segura.")
    return "/".join(path.parts)


def _file_matches(path: Path, size: int, sha256: str) -> bool:
    try:
        return path.is_file() and path.stat().st_size == size and _sha256(path) == sha256
    except OSError:
        return False


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _emit(progress: ProgressCallback | None, percent: int, phase: str, message: str) -> None:
    if progress is not None:
        progress(max(0, min(100, int(percent))), phase, message)
