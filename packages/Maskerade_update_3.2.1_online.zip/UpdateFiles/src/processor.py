from __future__ import annotations

import fnmatch
import json
import logging
import os
import threading
import time
import uuid
from concurrent.futures import Future, ThreadPoolExecutor
from contextlib import contextmanager
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any, Callable

from PIL import Image, ImageOps

from .background_removal import (
    BackgroundRemover,
    PreparedBackgroundRemoval,
    _mask_cleanup_amount,
    _mask_human_rescue_amount,
    _mask_protection_amount,
    _mask_raw_values,
    _mask_rescue_alpha_scale,
    _mask_uses_unified_slider,
    _negative_mask_extra_aggression,
    _structural_cleanup_aggression,
)
from .compositor import (
    PreparedCompositionAssets,
    compose_image,
    harmonize_composed_image,
    prepare_composition_assets,
    prepare_subject_canvas,
)
from .config import AppSettings, BackgroundRemovalSettings, ConfigurationError, ParkSettings, load_settings
from .image_utils import (
    list_images,
    move_to_directory,
    open_image,
    unique_path,
    wait_for_stable_file,
)
from .logger import ProcessingLogger
from .photo_enhancer import QENHANCER_CUEVAS_ENGINES, enhance_photo
from .cloud_delivery import RetryableCloudError, process_output_photo
from .performance_monitor import PerformanceSampler
from .secure_settings import secure_settings_path


@dataclass(frozen=True)
class ProcessResult:
    status: str
    input_path: Path
    output_path: Path | None
    duration_seconds: float
    backend_used: str | None = None
    message: str | None = None
    failed_path: Path | None = None
    archived_path: Path | None = None
    input_replaced: bool = False
    approval_output_path: Path | None = None


@dataclass(frozen=True)
class BatchStats:
    total: int
    processed: int
    failed: int
    skipped: int
    average_seconds: float
    results: list[ProcessResult]


@dataclass(frozen=True)
class CloudJobRequest:
    output_path: Path
    input_path: Path
    settings: Any
    root_dir: Path
    processed_dir: Path
    output_dir: Path
    attempt: int = 1
    preserve_on_failure: bool = False
    job_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    origin: str = "live_input"


@dataclass(frozen=True)
class CloudJobResult:
    status: str
    output_path: Path
    archived_path: Path | None = None
    message: str | None = None
    retry_request: CloudJobRequest | None = None
    job_id: str = ""
    input_path: Path | None = None
    download_path: Path | None = None
    attempt: int = 1
    delivery_status: str | None = None
    origin: str = "live_input"


@dataclass(frozen=True)
class ProcessingContext:
    park: ParkSettings
    background_removal: BackgroundRemovalSettings
    preset_name: str | None = None
    folder_name: str | None = None


@dataclass(frozen=True)
class PreparedPhoto:
    input_path: Path
    context: ProcessingContext
    original: Image.Image
    pre_enhanced: bool
    prepared_removal: PreparedBackgroundRemoval | None
    removal_prepare_seconds: float
    backend_used: str
    phase_times: dict[str, float]
    preparation_seconds: float
    source_identity: tuple[int, int, int, int]
    person_rgba: Image.Image | None = None
    removal_finished: bool = False


class ProcessingBusyError(RuntimeError):
    """Raised when another batch/process is already touching the input folder."""


_CLOUD_QUEUE_ATTEMPTS = 3
_FAILED_CLOUD_RETRY_DELAY_SECONDS = 60.0


def _cloud_download_required(settings: Any) -> bool:
    mode = str(getattr(settings, "mode", "upload_only") or "upload_only").strip().lower()
    return mode in {
        "upload_download",
        "upload_and_download",
        "download",
        "subir_descargar",
    }


def _source_identity(path: Path) -> tuple[int, int, int, int] | None:
    try:
        stat = path.stat()
    except OSError:
        return None
    return (
        int(stat.st_size),
        int(stat.st_mtime_ns),
        int(stat.st_ctime_ns),
        int(getattr(stat, "st_ino", 0)),
    )


def _mask_processing_log_values(settings: BackgroundRemovalSettings) -> dict[str, Any]:
    protection, antighost = _mask_raw_values(settings)
    unified = _mask_uses_unified_slider(settings)
    return {
        "mask_slider": protection if unified else None,
        "mask_protection": protection,
        "mask_antighost": antighost,
        "mask_unified": unified,
        "mask_effective_cleanup": _mask_cleanup_amount(settings),
        "mask_effective_protection": _mask_protection_amount(settings),
        "mask_negative_aggression": round(_negative_mask_extra_aggression(protection), 4),
        "mask_structural_aggression": round(_structural_cleanup_aggression(protection), 4),
        "mask_rescue_amount": _mask_human_rescue_amount(protection) if unified else None,
        "mask_rescue_alpha_scale": round(_mask_rescue_alpha_scale(protection), 4),
    }


def _read_lock_pid(path: Path) -> int | None:
    try:
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("pid="):
                return int(line.split("=", 1)[1].strip())
    except Exception:
        return None
    return None


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        try:
            import ctypes

            still_active = 259
            exit_code = ctypes.c_ulong()
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if not handle:
                return False
            try:
                if not ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return True
                return exit_code.value == still_active
            finally:
                ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            return True
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _lock_is_stale(path: Path, age_limit_seconds: float) -> bool:
    try:
        age = time.time() - path.stat().st_mtime
    except FileNotFoundError:
        return False
    if age > age_limit_seconds:
        return True

    pid = _read_lock_pid(path)
    if pid is not None and not _pid_is_running(pid):
        return True
    return False


class PhotoProcessor:
    def __init__(
        self,
        settings: AppSettings,
        park: ParkSettings,
        processing_logger: ProcessingLogger,
        force_live_context: bool = False,
        manual_search: bool = False,
        strict_preset_context: bool = False,
        skip_cloud_delivery: bool = False,
        warm_up_before_processing: bool = True,
        repair_output_root: bool = False,
    ) -> None:
        self.settings = settings
        self.park = park
        self.processing_logger = processing_logger
        self.logger = processing_logger.logger
        self.force_live_context = force_live_context
        self.manual_search = manual_search
        self.repair_output_root = repair_output_root
        self.strict_preset_context = strict_preset_context
        self.skip_cloud_delivery = skip_cloud_delivery
        self.warm_up_before_processing = warm_up_before_processing
        self.remover = BackgroundRemover(settings.background_removal, self.logger)
        self._removers: dict[BackgroundRemovalSettings, BackgroundRemover] = {
            settings.background_removal: self.remover
        }
        self._preset_cache: dict[str, dict[str, Any]] = {}
        self._composition_assets_cache: dict[tuple[Any, ...], PreparedCompositionAssets] = {}
        self._warned_missing_preset_backgrounds: set[str] = set()
        self._cloud_executor = ThreadPoolExecutor(
            max_workers=self._cloud_worker_count(settings),
            thread_name_prefix="maskerade-cloud",
        )
        self._cloud_futures: list[Future] = []
        self._cloud_queued_paths: set[Path] = set()
        self._failed_cloud_retry_after: dict[Path, float] = {}
        # Saving and removing empty OUT folders share this lock. Without it a
        # Cloud worker can remove the parent directory between mkdir and save.
        self._output_tree_lock = threading.RLock()
        self._live_automatic_settings_signature: tuple[int, int] | None = None
        self._live_automatic_settings_lock = threading.Lock()
        self._live_move_processed_by_park: dict[str, bool] = {}

    def update_settings(self, settings: AppSettings, park: ParkSettings) -> None:
        reload_remover = settings.background_removal != self.settings.background_removal
        self.settings = settings
        self.park = park
        if reload_remover:
            self.remover = BackgroundRemover(settings.background_removal, self.logger)
        self._removers = {settings.background_removal: self.remover}
        self._preset_cache.clear()
        self._composition_assets_cache.clear()

    def refresh_live_automatic_settings(self) -> None:
        """Refresh operational settings that must remain live during a frozen run."""
        config_path = self.settings.config_path
        if not config_path.name.startswith("settings_snapshot_"):
            return

        live_config = self.settings.root_dir / "config" / "settings.json"
        live_source = secure_settings_path(live_config)
        if not live_source.exists():
            live_source = live_config
        try:
            stat = live_source.stat()
            signature = (int(stat.st_mtime_ns), int(stat.st_size))
        except OSError:
            return

        if signature == self._live_automatic_settings_signature:
            return

        with self._live_automatic_settings_lock:
            if signature == self._live_automatic_settings_signature:
                return
            try:
                live_settings = load_settings(live_config)
            except Exception as exc:
                self.logger.warning(
                    "Hotfolder could not refresh live Cloud/rules settings; keeping previous values: %s",
                    exc,
                )
                return

            previous_cloud = self.settings.cloud
            previous_rules = self.settings.folder_preset_rules
            self.settings = replace(
                self.settings,
                cloud=live_settings.cloud,
                folder_preset_rules=live_settings.folder_preset_rules,
            )
            self._live_move_processed_by_park = {
                name: park.move_original_to_processed
                for name, park in live_settings.parks.items()
            }
            self._live_automatic_settings_signature = signature

            if previous_rules != live_settings.folder_preset_rules:
                self._preset_cache.clear()
                self.logger.info(
                    "Hotfolder synchronized %s live photographer rule(s)",
                    len(live_settings.folder_preset_rules),
                )
            if previous_cloud != live_settings.cloud:
                self.logger.info(
                    "Hotfolder synchronized live Cloud settings: %s",
                    "ON" if live_settings.cloud.enabled else "OFF",
                )

    def ensure_ready(
        self,
        park: ParkSettings | None = None,
        background_removal: BackgroundRemovalSettings | None = None,
    ) -> None:
        selected = park or self.park
        if selected.background_path is not None and (
            not selected.background_path.exists() or not selected.background_path.is_file()
        ):
            raise ConfigurationError("No se ha detectado Fondo, por favor selecciona uno.")
        if self._requires_background_removal(selected):
            remover = self._remover_for(background_removal or self.settings.background_removal)
            warm_up = getattr(remover, "warm_up", None)
            if callable(warm_up) and self.warm_up_before_processing:
                warm_up()

    def process_pending(self, wait_for_stability: bool = True) -> BatchStats:
        with self._processing_lock("batch"):
            images = list_images(self.park.input_dir)
            if not images:
                self.logger.info("No JPG files found in %s", self.park.input_dir)
                self.cleanup_empty_input_dirs()
                return BatchStats(0, 0, 0, 0, 0.0, [])

            results: list[ProcessResult] = []
            self.logger.info("Processing %s file(s)", len(images))
            with PerformanceSampler(
                self.logger,
                enabled=getattr(self.settings.processing, "perf_monitor", False),
                interval_seconds=getattr(
                    self.settings.processing,
                    "perf_monitor_interval_seconds",
                    1.0,
                ),
            ):
                if wait_for_stability:
                    self._wait_for_batch_stability(images)
                self._warm_up_batch_contexts(images)
                batch_processing_start = time.perf_counter()
                results.extend(self._process_images_pipelined(images))
                batch_processing_seconds = time.perf_counter() - batch_processing_start
            processed = sum(1 for result in results if result.status == "processed")
            failed = sum(1 for result in results if result.status == "failed")
            skipped = sum(1 for result in results if result.status == "skipped")
            average = batch_processing_seconds / processed if processed else 0.0
            self.cleanup_empty_input_dirs()
            self.wait_for_cloud()
            return BatchStats(len(images), processed, failed, skipped, average, results)

    def _wait_for_batch_stability(self, images: list[Path]) -> None:
        if not images:
            return

        interval = max(0.0, float(self.settings.file_stability.interval_seconds or 0.0))
        checks = max(1, int(self.settings.file_stability.stable_checks or 1))
        timeout = min(
            30.0,
            max(interval, float(self.settings.file_stability.timeout_seconds or 30.0)),
        )
        if interval <= 0:
            return

        last_signature: tuple[tuple[str, int, int], ...] | None = None
        stable_count = 0
        start = time.monotonic()

        while True:
            signature_items: list[tuple[str, int, int]] = []
            for path in images:
                try:
                    stat = path.stat()
                except FileNotFoundError:
                    continue
                if stat.st_size <= 0:
                    stable_count = 0
                signature_items.append((str(path), stat.st_size, int(stat.st_mtime_ns)))

            if not signature_items:
                return

            signature = tuple(signature_items)
            if signature == last_signature and all(item[1] > 0 for item in signature_items):
                stable_count += 1
                if stable_count >= checks:
                    return
            else:
                stable_count = 0
                last_signature = signature

            if time.monotonic() - start > timeout:
                raise TimeoutError("Batch files did not become stable in time")

            time.sleep(interval)

    def _warm_up_batch_contexts(self, images: list[Path]) -> None:
        warmed: set[tuple[ParkSettings, BackgroundRemovalSettings]] = set()
        for path in images:
            if not path.exists():
                continue
            try:
                context = self._context_for_input(path)
            except FileNotFoundError:
                continue
            key = (context.park, context.background_removal)
            if key in warmed:
                continue
            self.ensure_ready(context.park, context.background_removal)
            warmed.add(key)

    def process_files_pipelined(
        self,
        images: list[Path],
        archive_failed: bool = True,
        on_item_start: Callable[[int, Path], None] | None = None,
        on_item_done: Callable[[int, Path, ProcessResult], None] | None = None,
        should_continue: Callable[[], bool] | None = None,
    ) -> list[ProcessResult]:
        selected = [Path(path) for path in images]
        if not selected:
            return []
        with self._processing_lock("batch"):
            self._warm_up_batch_contexts(selected)
            return self._process_images_pipelined(
                selected,
                archive_failed=archive_failed,
                on_item_start=on_item_start,
                on_item_done=on_item_done,
                should_continue=should_continue,
            )

    def _process_images_pipelined(
        self,
        images: list[Path],
        archive_failed: bool = True,
        on_item_start: Callable[[int, Path], None] | None = None,
        on_item_done: Callable[[int, Path, ProcessResult], None] | None = None,
        should_continue: Callable[[], bool] | None = None,
    ) -> list[ProcessResult]:
        if len(images) <= 1:
            if on_item_start is not None:
                on_item_start(1, images[0])
            result = self.process_file(
                images[0],
                acquire_lock=False,
                wait_for_stability=False,
                archive_failed=archive_failed,
            )
            if on_item_done is not None:
                on_item_done(1, images[0], result)
            return [result]

        results: list[ProcessResult] = []
        with (
            ThreadPoolExecutor(max_workers=1, thread_name_prefix="maskerade-prepare") as prepare_executor,
            ThreadPoolExecutor(max_workers=1, thread_name_prefix="maskerade-mask") as mask_executor,
        ):
            current_path = images[0]
            current_prepare = prepare_executor.submit(self._prepare_photo_for_pipeline, current_path)
            current_future = mask_executor.submit(
                self._finish_photo_for_pipeline,
                current_prepare,
            )
            for index, next_path in enumerate(images[1:], start=1):
                next_prepare = prepare_executor.submit(self._prepare_photo_for_pipeline, next_path)
                next_future = mask_executor.submit(
                    self._finish_photo_for_pipeline,
                    next_prepare,
                )
                if on_item_start is not None:
                    on_item_start(index, current_path)
                result = self._process_prepared_future(
                    current_path,
                    current_future,
                    archive_failed=archive_failed,
                )
                results.append(result)
                if on_item_done is not None:
                    on_item_done(index, current_path, result)
                if should_continue is not None and not should_continue():
                    next_prepare.cancel()
                    next_future.cancel()
                    return results
                current_path = next_path
                current_future = next_future
            final_index = len(images)
            if on_item_start is not None:
                on_item_start(final_index, current_path)
            final_result = self._process_prepared_future(
                current_path,
                current_future,
                archive_failed=archive_failed,
            )
            results.append(final_result)
            if on_item_done is not None:
                on_item_done(final_index, current_path, final_result)
        return results

    def _finish_photo_for_pipeline(self, prepared_future: Future) -> PreparedPhoto:
        prepared = prepared_future.result()
        # Keep test doubles and third-party hooks compatible with the old two-stage pipeline.
        if not isinstance(prepared, PreparedPhoto):
            return prepared
        if prepared.removal_finished:
            return prepared

        phase_times = dict(prepared.phase_times)
        person_rgba = None
        backend_used = prepared.backend_used
        finish_seconds = 0.0
        if prepared.prepared_removal is not None:
            removal_started = time.perf_counter()
            removal = self._remover_for(
                prepared.context.background_removal
            ).finish_background_removal(prepared.original, prepared.prepared_removal)
            finish_seconds = time.perf_counter() - removal_started
            person_rgba = removal.person_rgba
            backend_used = removal.backend_used
            phase_times["background_removal"] = round(
                prepared.removal_prepare_seconds + finish_seconds,
                3,
            )
        else:
            phase_times["background_removal"] = 0.0

        return replace(
            prepared,
            backend_used=backend_used,
            phase_times=phase_times,
            preparation_seconds=prepared.preparation_seconds + finish_seconds,
            person_rgba=person_rgba,
            removal_finished=True,
        )

    def _process_prepared_future(
        self,
        input_path: Path,
        future: Future,
        archive_failed: bool = True,
    ) -> ProcessResult:
        try:
            prepared = future.result()
        except FileNotFoundError:
            return self._missing_input_result(input_path)
        except Exception as exc:
            self.logger.exception(
                "Background preparation failed for %s; falling back to normal processing: %s",
                input_path,
                exc,
            )
            return self.process_file(
                input_path,
                acquire_lock=False,
                wait_for_stability=False,
                archive_failed=archive_failed,
            )
        return self._process_file_unlocked(
            input_path,
            wait_for_stability=False,
            prepared=prepared,
            archive_failed=archive_failed,
        )

    def _prepare_photo_for_pipeline(self, input_path: Path) -> PreparedPhoto:
        start = time.perf_counter()
        input_path = Path(input_path)
        phase_times: dict[str, float] = {"wait_stable": 0.0}
        phase_started = start

        def mark_phase(name: str) -> None:
            nonlocal phase_started
            now = time.perf_counter()
            phase_times[name] = round(now - phase_started, 3)
            phase_started = now

        context = self._context_for_input(input_path)
        mark_phase("context")
        self.logger.info("Preparing file in background: %s", input_path)

        source_identity = _source_identity(input_path)
        if source_identity is None:
            raise FileNotFoundError(str(input_path))
        original = open_image(input_path)
        mark_phase("open")
        pre_enhanced = self._enhance_before_background_removal_enabled(context.park)
        if pre_enhanced:
            original = enhance_photo(original, context.park.photo_enhance, logger=self.logger)
            mark_phase("pre_enhance")

        prepared_removal = None
        removal_prepare_seconds = 0.0
        backend_used = "original"
        if self._requires_background_removal(context.park):
            removal_started = time.perf_counter()
            prepared_removal = self._remover_for(
                context.background_removal
            ).prepare_background_removal(original)
            removal_prepare_seconds = time.perf_counter() - removal_started
            backend_used = "ben2"
            phase_started = time.perf_counter()
        else:
            self.logger.info(
                "No background selected; skipping BEN2 and processing original photo: %s",
                input_path.name,
            )
            mark_phase("background_removal")

        return PreparedPhoto(
            input_path=input_path,
            context=context,
            original=original,
            pre_enhanced=pre_enhanced,
            prepared_removal=prepared_removal,
            removal_prepare_seconds=removal_prepare_seconds,
            backend_used=backend_used,
            phase_times=phase_times,
            preparation_seconds=time.perf_counter() - start,
            source_identity=source_identity,
        )

    def process_file(
        self,
        input_path: Path,
        acquire_lock: bool = True,
        wait_for_stability: bool = True,
        archive_failed: bool = True,
    ) -> ProcessResult:
        if acquire_lock:
            with self._processing_lock("file"):
                return self._process_file_unlocked(
                    input_path,
                    wait_for_stability=wait_for_stability,
                    archive_failed=archive_failed,
                )
        return self._process_file_unlocked(
            input_path,
            wait_for_stability=wait_for_stability,
            archive_failed=archive_failed,
        )

    def _process_file_unlocked(
        self,
        input_path: Path,
        wait_for_stability: bool = True,
        prepared: PreparedPhoto | None = None,
        archive_failed: bool = True,
    ) -> ProcessResult:
        start = time.perf_counter()
        input_path = Path(input_path)
        output_path: Path | None = None
        backend_used: str | None = None
        source_identity: tuple[int, int, int, int] | None = None
        phase_times: dict[str, float] = {}
        phase_started = start

        def mark_phase(name: str) -> None:
            nonlocal phase_started
            now = time.perf_counter()
            phase_times[name] = round(now - phase_started, 3)
            phase_started = now

        try:
            if input_path.suffix.lower() not in {".jpg", ".jpeg"}:
                return ProcessResult("skipped", input_path, None, 0.0, message="Not a JPG")
            if not input_path.exists():
                return self._missing_input_result(input_path)

            if prepared is None:
                if wait_for_stability:
                    wait_for_stable_file(
                        input_path,
                        self.settings.file_stability.interval_seconds,
                        self.settings.file_stability.stable_checks,
                        self.settings.file_stability.timeout_seconds,
                    )
                mark_phase("wait_stable")

                context = self._context_for_input(input_path)
                self.ensure_ready(context.park, context.background_removal)
                mark_phase("context")
                self.logger.info("Processing file: %s", input_path)

                source_identity = _source_identity(input_path)
                if source_identity is None:
                    return self._missing_input_result(input_path)
                original = open_image(input_path)
                mark_phase("open")
                pre_enhanced = self._enhance_before_background_removal_enabled(context.park)
                if pre_enhanced:
                    original = enhance_photo(original, context.park.photo_enhance, logger=self.logger)
                    mark_phase("pre_enhance")
            else:
                input_path = prepared.input_path
                context = prepared.context
                original = prepared.original
                source_identity = prepared.source_identity
                pre_enhanced = prepared.pre_enhanced
                prepared_removal = prepared.prepared_removal
                backend_used = prepared.backend_used
                phase_times.update(prepared.phase_times)
                start -= prepared.preparation_seconds
                phase_started = time.perf_counter()
                self.logger.info("Processing prepared file: %s", input_path)

            if prepared is None:
                person_rgba = None
                backend_used = "original"
                if self._requires_background_removal(context.park):
                    removal = self._remover_for(context.background_removal).remove_background(original)
                    person_rgba = removal.person_rgba
                    backend_used = removal.backend_used
                    mark_phase("background_removal")
                else:
                    self.logger.info(
                        "No background selected; skipping BEN2 and processing original photo: %s",
                        input_path.name,
                    )
                    mark_phase("background_removal")
            else:
                person_rgba = prepared.person_rgba
                if prepared.removal_finished:
                    phase_started = time.perf_counter()
                elif prepared_removal is not None:
                    removal_started = time.perf_counter()
                    removal = self._remover_for(
                        context.background_removal
                    ).finish_background_removal(original, prepared_removal)
                    person_rgba = removal.person_rgba
                    backend_used = removal.backend_used
                    removal_finish_seconds = time.perf_counter() - removal_started
                    phase_times["background_removal"] = round(
                        prepared.removal_prepare_seconds + removal_finish_seconds,
                        3,
                    )
                    phase_started = time.perf_counter()
                else:
                    phase_times["background_removal"] = 0.0
            composition_assets = self._composition_assets_for(original, context.park)
            subject_canvas = None
            if person_rgba is not None:
                subject_canvas = prepare_subject_canvas(
                    person_rgba,
                    context.park,
                    composition_assets.output_size,
                )
            mark_phase("prepare_assets")
            final = compose_image(
                original=original,
                person_rgba=person_rgba,
                park=context.park,
                logger=self.logger,
                apply_harmonize=False,
                prepared_assets=composition_assets,
                prepared_subject_canvas=subject_canvas,
            )
            mark_phase("compose")
            if not pre_enhanced:
                final = enhance_photo(final, context.park.photo_enhance, logger=self.logger)
            mark_phase("enhance")
            final = harmonize_composed_image(
                final,
                original,
                person_rgba,
                context.park,
                logger=self.logger,
                prepared_assets=composition_assets,
                prepared_subject_canvas=subject_canvas,
            )
            mark_phase("harmonize")
            output_path = self._output_path_for(input_path, context.park)
            with self._output_tree_lock:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                self._save_jpeg(final, output_path, input_path, context.park)
            self._announce_processed_preview(input_path, output_path, context.preset_name)
            mark_phase("save")

            if self.strict_preset_context:
                self.refresh_live_automatic_settings()
            cloud_status = None
            cloud_warning = None
            cloud_job_id = None
            if (
                getattr(self.settings, "cloud", None) is not None
                and self.settings.cloud.enabled
                and not self.skip_cloud_delivery
            ):
                cloud_job_id = self._submit_cloud(
                    output_path,
                    input_path,
                    context.park.output_dir,
                )
                cloud_status = "queued"
            mark_phase("cloud")

            moved_to = None
            archive_warning = None
            input_replaced = False
            move_original = self._move_original_to_processed_enabled(context.park)
            if move_original and input_path.exists():
                if source_identity is not None and _source_identity(input_path) != source_identity:
                    input_replaced = True
                    archive_warning = (
                        "Nueva entrada con el mismo nombre detectada en IN; "
                        "se conserva para procesarla como otro trabajo"
                    )
                    self.logger.warning("%s: %s", archive_warning, input_path)
                else:
                    try:
                        moved_to = move_to_directory(
                            input_path,
                            self._archive_dir_for(self.settings.processed_dir, input_path, context.park),
                        )
                    except PermissionError as exc:
                        archive_warning = "Original no movido a processed porque otro proceso lo tiene bloqueado"
                        self.logger.warning("%s: %s (%s)", archive_warning, input_path, exc)
            elif move_original:
                archive_warning = "Original eliminado de IN durante el lote; salida conservada"
                self.logger.info("%s: %s", archive_warning, input_path)
            mark_phase("archive")

            duration = time.perf_counter() - start
            phase_text = " ".join(f"{key}={value:.3f}s" for key, value in phase_times.items())
            self.logger.info("Timing %s: %s total=%.3fs", input_path.name, phase_text, duration)
            self.logger.info(
                "Processed %s -> %s in %.2fs using %s",
                input_path.name,
                output_path.name,
                duration,
                backend_used,
            )
            self.processing_logger.photo_result(
                {
                    "status": "processed",
                    "profile": context.park.name,
                    "folder_preset": context.preset_name,
                    "photo_retouch": str(getattr(context.park.photo_enhance, "recipe", "") or ""),
                    "folder_name": context.folder_name,
                    "move_original_to_processed": move_original,
                    "input": str(input_path),
                    "output": str(output_path),
                    "moved_to": str(moved_to) if moved_to else None,
                    "archive_warning": archive_warning,
                    "cloud_status": cloud_status,
                    "cloud_job_id": cloud_job_id,
                    "cloud_warning": cloud_warning,
                    "duration_seconds": round(duration, 3),
                    "phase_times": phase_times,
                    "backend": backend_used,
                    **_mask_processing_log_values(context.background_removal),
                }
            )
            return ProcessResult(
                "processed",
                input_path,
                output_path,
                duration,
                backend_used,
                message="; ".join([msg for msg in [archive_warning, cloud_warning] if msg]) or None,
                archived_path=moved_to,
                input_replaced=input_replaced,
                approval_output_path=self._canonical_output_path_for(input_path, context.park) if self.repair_output_root else None,
            )

        except FileNotFoundError:
            return self._missing_input_result(
                input_path,
                duration_seconds=time.perf_counter() - start,
            )

        except ConfigurationError as exc:
            duration = time.perf_counter() - start
            self.logger.error("%s", exc)
            self.processing_logger.photo_result(
                {
                    "status": "configuration_error",
                    "profile": self.park.name,
                    "input": str(input_path),
                    "duration_seconds": round(duration, 3),
                    "error": str(exc),
                }
            )
            return ProcessResult(
                "failed",
                input_path,
                output_path,
                duration,
                backend_used,
                str(exc),
            )

        except Exception as exc:
            duration = time.perf_counter() - start
            failed_path = None
            corrupt_input = self._is_corrupt_input_error(exc)
            should_archive = (
                not self.manual_search
                and (self.settings.processing.move_failed_to_failed or corrupt_input)
            )
            if archive_failed and should_archive and input_path.exists():
                try:
                    failed_path = self.archive_failed_input(input_path, force=corrupt_input)
                except Exception:
                    self.logger.exception("Could not move failed file: %s", input_path)

            error_message = (
                "Archivo JPEG truncado o corrupto"
                if corrupt_input
                else str(exc)
            )
            if corrupt_input:
                if failed_path is not None:
                    self.logger.warning(
                        "Corrupt input moved to failed: %s -> %s (%s)",
                        input_path,
                        failed_path,
                        exc,
                    )
                else:
                    self.logger.warning(
                        "Input JPEG is truncated or corrupt; hotfolder will move it directly to failed: %s (%s)",
                        input_path,
                        exc,
                    )
            else:
                self.logger.exception("Failed processing %s: %s", input_path, exc)
            self.processing_logger.photo_result(
                {
                    "status": "failed",
                    "profile": self.park.name,
                    "input": str(input_path),
                    "failed_path": str(failed_path) if failed_path else None,
                    "output": str(output_path) if output_path else None,
                    "duration_seconds": round(duration, 3),
                    "backend": backend_used,
                    "error": error_message,
                }
            )
            return ProcessResult(
                "failed",
                input_path,
                output_path,
                duration,
                backend_used,
                error_message,
                failed_path,
            )

    def _missing_input_result(
        self,
        input_path: Path,
        duration_seconds: float = 0.0,
    ) -> ProcessResult:
        message = "Eliminada de IN durante el lote"
        self.logger.info("Omitida porque fue eliminada de IN: %s", input_path)
        self.processing_logger.photo_result(
            {
                "status": "skipped",
                "profile": self.park.name,
                "input": str(input_path),
                "duration_seconds": round(duration_seconds, 3),
                "message": message,
            }
        )
        return ProcessResult(
            "skipped",
            input_path,
            None,
            duration_seconds,
            message=message,
        )

    @staticmethod
    def _is_corrupt_input_error(exc: Exception) -> bool:
        message = str(exc).casefold()
        return isinstance(exc, OSError) and any(
            marker in message
            for marker in (
                "image file is truncated",
                "truncated file read",
                "cannot identify image file",
                "broken data stream",
                "premature end of jpeg",
                "not a jpeg file",
            )
        )

    def archive_failed_input(self, input_path: Path, force: bool = False) -> Path | None:
        input_path = Path(input_path)
        if (not force and not self.settings.processing.move_failed_to_failed) or not input_path.exists():
            return None
        return move_to_directory(
            input_path,
            self._archive_dir_for(self.settings.failed_dir, input_path, self.park),
        )

    def wait_for_cloud(self) -> None:
        self._collect_cloud_futures(wait=True)

    def deliver_existing_output(self, output_path: Path, input_path: Path) -> CloudJobResult:
        """Deliver an approved OUT file without reprocessing the photograph."""
        output_path = Path(output_path)
        input_path = Path(input_path)
        job_id = uuid.uuid4().hex
        if not output_path.exists() or not output_path.is_file():
            result = CloudJobResult(
                "failed",
                output_path,
                message="Output file does not exist",
                job_id=job_id,
                input_path=input_path,
                delivery_status="missing",
                origin="manual_delivery",
            )
            self._record_cloud_result(result)
            return result
        if getattr(self.settings, "cloud", None) is None or not self.settings.cloud.enabled:
            result = CloudJobResult(
                "failed",
                output_path,
                message="Cloud is disabled",
                job_id=job_id,
                input_path=input_path,
                delivery_status="disabled",
                origin="manual_delivery",
            )
            self._record_cloud_result(result)
            return result

        failed_cloud_root = (self.settings.failed_dir / "cloud").resolve()
        try:
            output_path.resolve().relative_to(failed_cloud_root)
            retrying_failed_output = True
        except ValueError:
            retrying_failed_output = False

        request = CloudJobRequest(
            output_path=output_path,
            input_path=input_path,
            settings=self.settings.cloud,
            root_dir=self.settings.root_dir,
            processed_dir=self.settings.cloud.processed_dir
            or (self.settings.processed_dir / "cloud processed"),
            output_dir=failed_cloud_root if retrying_failed_output else self.park.output_dir,
            preserve_on_failure=retrying_failed_output,
            job_id=job_id,
            origin="failed_cloud_recovery" if retrying_failed_output else "manual_delivery",
        )
        self._record_cloud_queued(request)
        while True:
            result = self._run_cloud_job(request)
            if result.status != "retry" or result.retry_request is None:
                self._record_cloud_result(result)
                self._print_cloud_summary([result])
                return result
            self._record_cloud_retry(result)
            request = result.retry_request
            self._record_cloud_queued(request)

    def _requires_background_removal(self, park: ParkSettings) -> bool:
        return park.background_path is not None

    def _enhance_before_background_removal_enabled(self, park: ParkSettings) -> bool:
        enhance = getattr(park, "photo_enhance", None)
        if enhance is None or not bool(getattr(enhance, "enabled", True)):
            return False
        engine = str(getattr(enhance, "engine", "") or "").strip().lower()
        return engine == "classic" or engine in QENHANCER_CUEVAS_ENGINES

    def _composition_assets_for(
        self,
        original: Image.Image,
        park: ParkSettings,
    ) -> PreparedCompositionAssets:
        key = self._composition_assets_key(original.size, park)
        if key is None:
            return prepare_composition_assets(original, park, logger=self.logger)

        cached = self._composition_assets_cache.get(key)
        if cached is not None:
            return cached

        assets = prepare_composition_assets(original, park, logger=self.logger)
        if len(self._composition_assets_cache) >= 4:
            oldest_key = next(iter(self._composition_assets_cache))
            self._composition_assets_cache.pop(oldest_key, None)
        self._composition_assets_cache[key] = assets
        return assets

    def _composition_assets_key(
        self,
        original_size: tuple[int, int],
        park: ParkSettings,
    ) -> tuple[Any, ...] | None:
        if park.background_path is None:
            return None
        return (
            original_size,
            self._output_size_key(park.output_size),
            self._path_signature(park.background_path),
            round(float(getattr(park, "background_brightness", 1.0) or 1.0), 6),
            self._path_signature(park.overlay_path),
            self._overlay_settings_key(park.overlay_settings),
            self._path_signature(park.logo_path),
            self._overlay_settings_key(park.logo_settings),
        )

    def _output_size_key(self, output_size: tuple[int, int] | str) -> tuple[Any, ...]:
        if isinstance(output_size, str):
            return ("str", output_size.strip().casefold())
        return ("size", int(output_size[0]), int(output_size[1]))

    def _path_signature(self, path: Path | None) -> tuple[Any, ...] | None:
        if path is None:
            return None
        try:
            resolved = path.resolve()
        except OSError:
            resolved = path
        try:
            stat = resolved.stat()
            return (str(resolved).casefold(), int(stat.st_mtime_ns), int(stat.st_size))
        except OSError:
            return (str(resolved).casefold(), None, None)

    def _overlay_settings_key(self, settings: Any) -> tuple[Any, ...]:
        return (
            str(getattr(settings, "mode", "")).casefold(),
            str(getattr(settings, "anchor", "")).casefold(),
            int(getattr(settings, "x", 0) or 0),
            int(getattr(settings, "y", 0) or 0),
            round(float(getattr(settings, "scale", 1.0) or 1.0), 6),
            round(float(getattr(settings, "opacity", 1.0) or 1.0), 6),
        )

    def poll_cloud(self) -> None:
        self._collect_cloud_futures(wait=False)

    def pending_cloud_count(self) -> int:
        """Return Cloud jobs still queued or running after the latest poll."""
        return len(self._cloud_futures)

    def retry_pending_cloud_outputs(self) -> int:
        """Recover safe OUT files left behind by an interrupted process."""
        if getattr(self.settings, "cloud", None) is None or not self.settings.cloud.enabled:
            return 0

        output_root = self.park.output_dir.resolve()
        if not output_root.exists():
            return 0

        queued = 0
        for output_path in list_images(output_root):
            resolved = output_path.resolve()
            if resolved in self._cloud_queued_paths:
                continue
            try:
                relative = resolved.relative_to(output_root)
            except ValueError:
                continue
            request = CloudJobRequest(
                output_path=output_path,
                input_path=self.park.input_dir / relative,
                settings=self.settings.cloud,
                root_dir=self.settings.root_dir,
                processed_dir=self.settings.cloud.processed_dir
                or (self.settings.processed_dir / "cloud processed"),
                output_dir=output_root,
                preserve_on_failure=False,
                origin="out_recovery",
            )
            if self._enqueue_cloud_request(request):
                queued += 1

        if queued:
            self.logger.warning(
                "Cloud crash recovery queued %s safe file(s) left in OUT",
                queued,
            )
            print(
                f"AVISO - Cloud: recuperando automaticamente {queued} foto(s) seguras de OUT",
                flush=True,
            )
        return queued

    def retry_failed_cloud_outputs(self) -> int:
        """Queue safe copies from failed/cloud again when their cooldown expires."""
        if getattr(self.settings, "cloud", None) is None or not self.settings.cloud.enabled:
            return 0

        failed_cloud_root = self.settings.failed_dir / "cloud"
        if not failed_cloud_root.exists():
            return 0

        now = time.monotonic()
        queued = 0
        for output_path in list_images(failed_cloud_root):
            resolved = output_path.resolve()
            if resolved in self._cloud_queued_paths:
                continue
            if now < self._failed_cloud_retry_after.get(resolved, 0.0):
                continue
            try:
                relative = resolved.relative_to(failed_cloud_root.resolve())
            except ValueError:
                continue
            input_path = self.settings.root_dir / "input" / relative
            request = CloudJobRequest(
                output_path=output_path,
                input_path=input_path,
                settings=self.settings.cloud,
                root_dir=self.settings.root_dir,
                processed_dir=self.settings.cloud.processed_dir
                or (self.settings.processed_dir / "cloud processed"),
                output_dir=failed_cloud_root,
                preserve_on_failure=True,
                origin="failed_cloud_recovery",
            )
            if self._enqueue_cloud_request(request):
                queued += 1

        if queued:
            self.logger.warning(
                "Cloud recovery queued %s safe file(s) from %s",
                queued,
                failed_cloud_root,
            )
            print(
                f"AVISO - Cloud: reintentando automaticamente {queued} foto(s) de failed/cloud",
                flush=True,
            )
        return queued

    def shutdown(self, wait: bool = True) -> None:
        if wait:
            self.wait_for_cloud()
        self._cloud_executor.shutdown(wait=wait, cancel_futures=not wait)

    def _submit_cloud(self, output_path: Path, input_path: Path, output_dir: Path) -> str:
        settings = self.settings.cloud
        request = CloudJobRequest(
            output_path=Path(output_path),
            input_path=Path(input_path),
            settings=settings,
            root_dir=self.settings.root_dir,
            processed_dir=settings.processed_dir or (self.settings.processed_dir / "cloud processed"),
            output_dir=Path(output_dir),
        )
        if not self._enqueue_cloud_request(request):
            message = "Cloud queue rejected a new live-input job because its OUT path is already active"
            result = self._cloud_job_result(
                request,
                "failed",
                message=message,
                delivery_status="queue_rejected",
            )
            self._record_cloud_result(result)
            raise RuntimeError(message)
        self.poll_cloud()
        return request.job_id

    def _enqueue_cloud_request(self, job: CloudJobRequest, *, already_tracked: bool = False) -> bool:
        resolved = job.output_path.resolve()
        if not already_tracked:
            if resolved in self._cloud_queued_paths:
                return False
            self._cloud_queued_paths.add(resolved)
        try:
            future = self._cloud_executor.submit(self._run_cloud_job, job)
        except Exception as exc:
            if not already_tracked:
                self._cloud_queued_paths.discard(resolved)
            result = self._cloud_job_result(
                job,
                "failed",
                message=f"Cloud queue submission failed: {exc}",
                delivery_status="queue_failed",
            )
            self._record_cloud_result(result)
            raise
        self._cloud_futures.append(future)
        self._record_cloud_queued(job)
        return True

    @staticmethod
    def _cloud_job_result(
        job: CloudJobRequest,
        status: str,
        *,
        archived_path: Path | None = None,
        download_path: Path | None = None,
        message: str | None = None,
        retry_request: CloudJobRequest | None = None,
        delivery_status: str | None = None,
    ) -> CloudJobResult:
        return CloudJobResult(
            status=status,
            output_path=job.output_path,
            archived_path=archived_path,
            message=message,
            retry_request=retry_request,
            job_id=job.job_id,
            input_path=job.input_path,
            download_path=download_path,
            attempt=job.attempt,
            delivery_status=delivery_status,
            origin=job.origin,
        )

    def _run_cloud_job(self, job: CloudJobRequest) -> CloudJobResult:
        output_path = job.output_path
        try:
            result = process_output_photo(
                output_path,
                job.input_path,
                job.settings,
                job.root_dir,
                self.logger,
            )
            if result.status in {"downloaded", "downloaded_unmarked"}:
                download_path = Path(result.download_path) if result.download_path is not None else None
                if (
                    download_path is None
                    or not download_path.is_file()
                    or download_path.stat().st_size <= 0
                ):
                    raise RuntimeError(
                        "Cloud reported a local download, but cloud_downloads has no valid file"
                    )
            if result.status == "uploaded" and _cloud_download_required(job.settings):
                raise RuntimeError(
                    "Cloud upload succeeded, but upload-and-download mode did not produce "
                    "a file in cloud_downloads"
                )
            if result.status in {"uploaded", "downloaded", "downloaded_unmarked"}:
                archived = None
                try:
                    archived = self._archive_output_after_cloud(
                        output_path,
                        job.processed_dir,
                        job.output_dir,
                    )
                except PermissionError as exc:
                    self.logger.warning(
                        "Could not archive completed Cloud output in processed; moving to failed/cloud: %s (%s)",
                        output_path,
                        exc,
                    )
                    failed_archived = self._archive_failed_cloud_output(
                        output_path,
                        job.output_dir,
                        preserve=job.preserve_on_failure,
                    )
                    return self._cloud_job_result(
                        job,
                        "failed",
                        archived_path=failed_archived,
                        download_path=getattr(result, "download_path", None),
                        message=str(exc),
                        delivery_status="archive_failed",
                    )
                self.cleanup_empty_output_dirs(job.output_dir)
                status = "warning" if result.status == "downloaded_unmarked" else "processed"
                message = getattr(result, "message", None)
                if result.status == "uploaded":
                    message = (
                        "Cloud upload-only mode completed; no file in cloud_downloads is expected"
                        + (f" ({message})" if message else "")
                    )
                return self._cloud_job_result(
                    job,
                    status,
                    archived_path=archived,
                    download_path=getattr(result, "download_path", None),
                    message=message,
                    delivery_status=result.status,
                )
            failed_archived = self._archive_failed_cloud_output(
                output_path,
                job.output_dir,
                preserve=job.preserve_on_failure,
            )
            return self._cloud_job_result(
                job,
                "failed",
                archived_path=failed_archived,
                download_path=getattr(result, "download_path", None),
                message=getattr(result, "message", None) or f"Unexpected Cloud status: {result.status}",
                delivery_status=result.status,
            )
        except RetryableCloudError as exc:
            if exc.safe_to_restart and job.attempt < _CLOUD_QUEUE_ATTEMPTS:
                retry_request = replace(job, attempt=job.attempt + 1)
                self.logger.warning(
                    "Cloud parked at queue tail after transient error: %s; retry %s/%s (%s)",
                    output_path,
                    retry_request.attempt,
                    _CLOUD_QUEUE_ATTEMPTS,
                    exc,
                )
                print(
                    f"AVISO - Cloud: {output_path.name} aparcada; "
                    f"reintento {retry_request.attempt}/{_CLOUD_QUEUE_ATTEMPTS} al final de la cola",
                    flush=True,
                )
                return self._cloud_job_result(
                    job,
                    "retry",
                    message=str(exc),
                    retry_request=retry_request,
                    delivery_status="retry",
                )
            print(f"CLOUD error {output_path.name}", flush=True)
            self.logger.exception(
                "Cloud module failed for %s after %s/%s attempts: %s",
                output_path,
                job.attempt,
                _CLOUD_QUEUE_ATTEMPTS,
                exc,
            )
            failed_archived = self._archive_failed_cloud_output(
                output_path,
                job.output_dir,
                preserve=job.preserve_on_failure,
            )
            return self._cloud_job_result(
                job,
                "failed",
                archived_path=failed_archived,
                message=str(exc),
                delivery_status="retry_exhausted",
            )
        except Exception as exc:
            print(f"CLOUD error {output_path.name}", flush=True)
            self.logger.exception("Cloud module failed for %s: %s", output_path, exc)
            failed_archived = self._archive_failed_cloud_output(
                output_path,
                job.output_dir,
                preserve=job.preserve_on_failure,
            )
            return self._cloud_job_result(
                job,
                "failed",
                archived_path=failed_archived,
                message=str(exc),
                delivery_status="exception",
            )

    def _archive_output_after_cloud(self, output_path: Path, processed_dir: Path, output_dir: Path) -> Path | None:
        if not output_path.exists():
            return None
        try:
            relative_parent = output_path.parent.resolve().relative_to(output_dir.resolve())
        except ValueError:
            relative_parent = Path()
        target_dir = processed_dir / relative_parent if str(relative_parent) != "." else processed_dir
        archived = move_to_directory(output_path, target_dir)
        self.logger.info("Cloud archived output after completion: %s -> %s", output_path, archived)
        return archived

    def _archive_failed_cloud_output(
        self,
        output_path: Path,
        output_dir: Path,
        *,
        preserve: bool = False,
    ) -> Path | None:
        if not output_path.exists():
            return None
        if preserve:
            self.logger.warning(
                "Cloud retry failed; safe output remains available for automatic recovery: %s",
                output_path,
            )
            return None
        try:
            relative_parent = output_path.parent.resolve().relative_to(output_dir.resolve())
        except ValueError:
            relative_parent = Path()
        target_root = self.settings.failed_dir / "cloud"
        target_dir = target_root / relative_parent if str(relative_parent) != "." else target_root
        archived = move_to_directory(output_path, target_dir)
        self.logger.warning("Cloud failed; archived temporary output: %s -> %s", output_path, archived)
        self.cleanup_empty_output_dirs(output_dir)
        return archived

    def cleanup_empty_output_dirs(self, output_dir: Path | None = None) -> int:
        selected_output_dir = (output_dir or self.park.output_dir).resolve()
        with self._output_tree_lock:
            return self._cleanup_empty_dirs(selected_output_dir, "OUT")

    def _record_cloud_queued(self, job: CloudJobRequest) -> None:
        status = "cloud_retry_queued" if job.attempt > 1 else "cloud_queued"
        self.processing_logger.photo_result(
            {
                "status": status,
                "event": "cloud",
                "terminal": False,
                "cloud_job_id": job.job_id,
                "cloud_origin": job.origin,
                "cloud_attempt": job.attempt,
                "input": str(job.input_path),
                "output": str(job.output_path),
            }
        )
        self.logger.info(
            "Cloud audit queued: job_id=%s origin=%s attempt=%s input=%s output=%s",
            job.job_id,
            job.origin,
            job.attempt,
            job.input_path,
            job.output_path,
        )

    def _record_cloud_retry(self, result: CloudJobResult) -> None:
        self.processing_logger.photo_result(
            {
                "status": "cloud_retry",
                "event": "cloud",
                "terminal": False,
                "cloud_job_id": result.job_id,
                "cloud_origin": result.origin,
                "cloud_attempt": result.attempt,
                "input": str(result.input_path) if result.input_path is not None else None,
                "output": str(result.output_path),
                "reason": result.message or "Transient Cloud error",
            }
        )
        self.logger.warning(
            "Cloud audit retry: job_id=%s attempt=%s reason=%s",
            result.job_id,
            result.attempt,
            result.message or "Transient Cloud error",
        )

    def _record_cloud_result(self, result: CloudJobResult) -> None:
        if result.status == "failed":
            status = "cloud_failed"
        elif result.status == "warning":
            status = "cloud_downloaded_warning"
        elif result.delivery_status == "downloaded":
            status = "cloud_downloaded"
        elif result.delivery_status == "uploaded":
            status = "cloud_uploaded"
        else:
            status = "cloud_completed"

        download_exists = False
        download_bytes = None
        if result.download_path is not None:
            try:
                download_bytes = result.download_path.stat().st_size
                download_exists = result.download_path.is_file() and download_bytes > 0
            except OSError:
                download_exists = False

        failed_path = result.archived_path if result.status == "failed" else None
        if result.status == "failed" and failed_path is None and result.output_path.exists():
            failed_path = result.output_path

        self.processing_logger.photo_result(
            {
                "status": status,
                "event": "cloud",
                "terminal": True,
                "cloud_job_id": result.job_id,
                "cloud_origin": result.origin,
                "cloud_attempts": result.attempt,
                "cloud_delivery_status": result.delivery_status,
                "input": str(result.input_path) if result.input_path is not None else None,
                "output": str(result.output_path),
                "download_path": str(result.download_path) if result.download_path is not None else None,
                "download_exists": download_exists,
                "download_bytes": download_bytes,
                "archived_path": (
                    str(result.archived_path) if result.archived_path is not None else None
                ),
                "failed_path": str(failed_path) if failed_path is not None else None,
                "reason": result.message,
            }
        )
        log = self.logger.error if result.status == "failed" else self.logger.info
        log(
            "Cloud audit terminal: job_id=%s status=%s delivery=%s attempt=%s "
            "download=%s failed_path=%s reason=%s",
            result.job_id,
            status,
            result.delivery_status,
            result.attempt,
            result.download_path,
            failed_path,
            result.message,
        )

    def _collect_cloud_futures(self, wait: bool) -> None:
        while self._cloud_futures:
            current = self._cloud_futures
            self._cloud_futures = []
            pending: list[Future] = []
            completed: list[CloudJobResult] = []
            retries: list[CloudJobRequest] = []
            retry_results: list[CloudJobResult] = []
            for future in current:
                if wait or future.done():
                    try:
                        result = future.result()
                    except Exception as exc:
                        result = CloudJobResult("failed", Path(""), None, str(exc))
                    if isinstance(result, CloudJobResult):
                        if result.status == "retry" and result.retry_request is not None:
                            retries.append(result.retry_request)
                            retry_results.append(result)
                        else:
                            completed.append(result)
                else:
                    pending.append(future)
            self._cloud_futures.extend(pending)
            for retry_result, retry_request in zip(retry_results, retries):
                self._record_cloud_retry(retry_result)
                self._enqueue_cloud_request(retry_request, already_tracked=True)
            for result in completed:
                resolved = result.output_path.resolve()
                self._cloud_queued_paths.discard(resolved)
                self._failed_cloud_retry_after.pop(resolved, None)
                if result.status == "failed":
                    retry_path = result.archived_path or result.output_path
                    if retry_path.exists():
                        self._failed_cloud_retry_after[retry_path.resolve()] = (
                            time.monotonic() + _FAILED_CLOUD_RETRY_DELAY_SECONDS
                        )
                self._record_cloud_result(result)
            self._print_cloud_summary(completed)
            if not wait:
                return

    def _print_cloud_summary(self, completed: list[CloudJobResult]) -> None:
        if not completed:
            return
        failed = [result for result in completed if result.status == "failed"]
        warnings = [result for result in completed if result.status == "warning"]
        processed = [result for result in completed if result.status not in {"failed", "warning"}]
        if processed:
            print(f"CLOUDSUMMARY ok {len(processed)} foto(s) completadas", flush=True)
        if warnings:
            print(
                f"AVISO - Cloud: {len(warnings)} foto(s) descargadas localmente, "
                "pero siguen pendientes porque no se pudo guardar su estado remoto",
                flush=True,
            )
        if failed:
            archived = [result for result in failed if result.archived_path is not None]
            examples = ", ".join(result.output_path.name for result in failed[:5] if result.output_path.name)
            suffix = f": {examples}" if examples else ""
            print(
                f"ERROR - Cloud: fallaron {len(failed)} foto(s); {len(archived)} movidas a failed/cloud{suffix}",
                flush=True,
            )
            print(
                f"CLOUDSUMMARY failed {len(failed)} archived {len(archived)} folder failed/cloud",
                flush=True,
            )

    def _cloud_worker_count(self, settings: AppSettings) -> int:
        # Two workers overlap the network-heavy upload/download round trip
        # without recreating the large synchronized bursts that previously
        # destabilised S3/TLS.  The hard ceiling is intentional even if a
        # copied configuration requests a larger value.
        requested = int(getattr(settings.cloud, "max_parallel_jobs", 2) or 1)
        return max(1, min(2, requested))

    def _context_for_input(self, input_path: Path) -> ProcessingContext:
        if self.strict_preset_context:
            self.refresh_live_automatic_settings()
        folder_name = self._top_level_input_folder(input_path)
        strict_preset_context = getattr(self, "strict_preset_context", False)
        if getattr(self, "force_live_context", False):
            if getattr(self, "manual_search", False):
                return self._manual_search_context(input_path, folder_name)
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                preset_name="preview",
                folder_name=folder_name,
            )
        if self._is_direct_photo_mode(self.park) and not strict_preset_context:
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )
        if (
            getattr(self.settings, "manual_composition_override", False)
            and not strict_preset_context
        ):
            return self._manual_composition_context(input_path, folder_name)
        for candidate in self._preset_rule_candidates(input_path):
            for rule in self.settings.folder_preset_rules:
                if not rule.enabled:
                    continue
                if not self._name_matches_rule(candidate, rule.pattern):
                    continue

                preset_name = self._variant_preset_name(rule.preset, input_path)
                if preset_name is None:
                    park = self._park_for_missing_orientation_variant(
                        self.park,
                        rule.preset,
                        input_path,
                    )
                    park = replace(
                        park,
                        photo_enhance=rule.photo_enhance or park.photo_enhance,
                    )
                    if not strict_preset_context:
                        park = self._park_with_live_harmonize_off(park)
                    background_removal = self.settings.background_removal
                    if strict_preset_context:
                        fallback_name = self._fallback_preset_name_for_missing_orientation(
                            rule.preset,
                            input_path,
                        )
                        if fallback_name is not None:
                            fallback_preset = self._load_folder_preset(fallback_name)
                            background_removal = self._background_removal_with_preset(
                                background_removal,
                                fallback_preset,
                            )
                    return ProcessingContext(
                        park=park,
                        background_removal=background_removal,
                        folder_name=folder_name,
                    )
                preset = self._load_folder_preset(preset_name)
                park = self._park_with_preset(self.park, preset, preset_name)
                # El montaje aporta fondo/overlay; el color pertenece a la regla del tirador.
                park = replace(
                    park,
                    photo_enhance=rule.photo_enhance
                    or (park.photo_enhance if strict_preset_context else self.park.photo_enhance),
                )
                if not strict_preset_context:
                    park = self._park_with_live_harmonize_off(park)
                background_removal = self._background_removal_with_preset(
                    self.settings.background_removal,
                    preset,
                    apply_desktop_mask=strict_preset_context,
                )
                self.logger.info(
                    "Folder/file preset matched: %s -> %s for %s by %s (retouch=%s)",
                    rule.pattern,
                    preset_name,
                    input_path,
                    candidate,
                    str(getattr(park.photo_enhance, "recipe", "") or "none"),
                )
                return ProcessingContext(
                    park=park,
                    background_removal=background_removal,
                    preset_name=preset_name,
                    folder_name=folder_name,
                )
        return self._active_preset_context(input_path, folder_name=folder_name)

    def _manual_search_context(
        self,
        input_path: Path,
        folder_name: str | None = None,
    ) -> ProcessingContext:
        active_preset = str(getattr(self.settings, "active_preset", "") or "").strip()
        family = self._variant_base_name(active_preset) if active_preset else ""
        orientation = self._orientation_suffix(input_path)

        # Dinos solo dispone de montaje vertical. En una foto horizontal el
        # Buscador conserva los ajustes manuales, pero procesa la foto directa,
        # sin reutilizar por error el fondo o la mascara vertical.
        if (
            family.casefold() == "dinos"
            and orientation == "h"
            and self._has_orientation_preset_family(family)
            and not self._preset_exists(f"{family}_h")
        ):
            return ProcessingContext(
                park=self._park_without_background_or_overlay(self.park),
                background_removal=self.settings.background_removal,
                preset_name="",
                folder_name=folder_name,
            )

        preset_name = self._variant_preset_name(active_preset, input_path) if active_preset else None
        if preset_name is None:
            return ProcessingContext(
                park=self._park_for_missing_orientation_variant(self.park, active_preset, input_path),
                background_removal=self.settings.background_removal,
                preset_name="",
                folder_name=folder_name,
            )
        if preset_name != active_preset and self._preset_exists(preset_name):
            preset = self._load_folder_preset(preset_name)
            park = self._park_with_preset(self.park, preset, preset_name)
            park = self._park_with_live_family_settings(park)
            return ProcessingContext(
                park=park,
                background_removal=self._background_removal_with_preset(
                    self.settings.background_removal,
                    preset,
                    apply_desktop_mask=False,
                ),
                preset_name=preset_name,
                folder_name=folder_name,
            )

        return ProcessingContext(
            park=self.park,
            background_removal=self.settings.background_removal,
            preset_name=preset_name or active_preset or "preview",
            folder_name=folder_name,
        )

    def _manual_composition_context(
        self,
        input_path: Path,
        folder_name: str | None,
    ) -> ProcessingContext:
        photo_enhance = self.park.photo_enhance
        matched_rule = None
        for candidate in self._preset_rule_candidates(input_path):
            for rule in self.settings.folder_preset_rules:
                if rule.enabled and self._name_matches_rule(candidate, rule.pattern):
                    photo_enhance = rule.photo_enhance or photo_enhance
                    matched_rule = rule
                    break
            if matched_rule is not None:
                break

        if matched_rule is not None:
            self.logger.info(
                "Manual composition with retouch rule: %s for %s",
                matched_rule.pattern,
                input_path,
            )
        return ProcessingContext(
            park=replace(self.park, photo_enhance=photo_enhance),
            background_removal=self.settings.background_removal,
            preset_name="manual",
            folder_name=folder_name,
        )

    def _active_preset_context(self, input_path: Path, folder_name: str | None = None) -> ProcessingContext:
        active_preset = str(getattr(self.settings, "active_preset", "") or "").strip()
        if not active_preset:
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )
        if getattr(self, "strict_preset_context", False):
            return self._saved_active_preset_context(
                active_preset,
                input_path,
                folder_name,
            )
        if not self._active_preset_background_matches(active_preset):
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )

        preset_name = self._variant_preset_name(active_preset, input_path)
        if preset_name is None:
            return ProcessingContext(
                park=self._park_for_missing_orientation_variant(self.park, active_preset, input_path),
                background_removal=self.settings.background_removal,
                folder_name=folder_name,
            )
        if self._preset_stem(preset_name).casefold() == self._preset_stem(active_preset).casefold():
            if not self._active_preset_exact_background_matches(active_preset):
                preset = self._load_folder_preset(preset_name)
                park = self._park_with_preset(self.park, preset, preset_name)
                park = self._park_with_live_family_settings(park)
                return ProcessingContext(
                    park=park,
                    background_removal=self._background_removal_with_preset(
                        self.settings.background_removal,
                        preset,
                        apply_desktop_mask=False,
                    ),
                    preset_name=preset_name,
                    folder_name=folder_name,
                )
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                preset_name=preset_name,
                folder_name=folder_name,
            )
        if not self._preset_exists(preset_name):
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )

        preset = self._load_folder_preset(preset_name)
        park = self._park_with_preset(self.park, preset, preset_name)
        park = self._park_with_live_family_settings(park)
        return ProcessingContext(
            park=park,
            background_removal=self._background_removal_with_preset(
                self.settings.background_removal,
                preset,
                apply_desktop_mask=False,
            ),
            preset_name=preset_name,
            folder_name=folder_name,
        )

    def _saved_active_preset_context(
        self,
        active_preset: str,
        input_path: Path,
        folder_name: str | None,
    ) -> ProcessingContext:
        preset_name = self._variant_preset_name(active_preset, input_path)
        if preset_name is None:
            park = self._park_for_missing_orientation_variant(
                self.park,
                active_preset,
                input_path,
            )
            background_removal = self.settings.background_removal
            fallback_name = self._fallback_preset_name_for_missing_orientation(
                active_preset,
                input_path,
            )
            if fallback_name is not None:
                fallback_preset = self._load_folder_preset(fallback_name)
                background_removal = self._background_removal_with_preset(
                    background_removal,
                    fallback_preset,
                )
            return ProcessingContext(
                park=park,
                background_removal=background_removal,
                folder_name=folder_name,
            )
        if not self._preset_exists(preset_name):
            return ProcessingContext(
                self.park,
                self.settings.background_removal,
                folder_name=folder_name,
            )

        preset = self._load_folder_preset(preset_name)
        return ProcessingContext(
            park=self._park_with_preset(self.park, preset, preset_name),
            background_removal=self._background_removal_with_preset(
                self.settings.background_removal,
                preset,
            ),
            preset_name=preset_name,
            folder_name=folder_name,
        )

    def _is_direct_photo_mode(self, park: ParkSettings) -> bool:
        return (
            park.background_path is None
            and park.overlay_path is None
            and park.logo_path is None
        )

    def _park_without_background_or_overlay(self, park: ParkSettings) -> ParkSettings:
        return replace(
            park,
            background_path=None,
            overlay_path=None,
        )

    def _park_for_missing_orientation_variant(
        self,
        base: ParkSettings,
        preset_name: str,
        input_path: Path,
    ) -> ParkSettings:
        fallback_name = self._fallback_preset_name_for_missing_orientation(preset_name, input_path)
        if fallback_name is None:
            return self._park_without_background_or_overlay(base)
        try:
            preset = self._load_folder_preset(fallback_name)
        except ConfigurationError:
            return self._park_without_background_or_overlay(base)
        return self._park_without_background_or_overlay(self._park_with_preset(base, preset, fallback_name))

    def _fallback_preset_name_for_missing_orientation(self, preset_name: str, input_path: Path) -> str | None:
        base = self._variant_base_name(preset_name)
        if self._preset_exists(base):
            return base
        suffix = self._orientation_suffix(input_path)
        opposite = "v" if suffix == "h" else "h" if suffix == "v" else None
        if opposite is not None:
            candidate = f"{base}_{opposite}"
            if self._preset_exists(candidate):
                return candidate
        if self._preset_exists(preset_name):
            return preset_name
        return None

    def _top_level_input_folder(self, input_path: Path) -> str | None:
        try:
            relative = input_path.resolve().relative_to(self.park.input_dir.resolve())
        except ValueError:
            return None
        if len(relative.parts) < 2:
            return None
        return relative.parts[0]

    def _preset_rule_candidates(self, input_path: Path) -> tuple[str, ...]:
        candidates: list[str] = []
        folder_name = self._top_level_input_folder(input_path)
        if folder_name:
            candidates.append(folder_name)
        if input_path.stem:
            candidates.append(input_path.stem)
        if input_path.name and input_path.name != input_path.stem:
            candidates.append(input_path.name)

        unique: list[str] = []
        seen: set[str] = set()
        for candidate in candidates:
            folded = candidate.casefold()
            if folded in seen:
                continue
            seen.add(folded)
            unique.append(candidate)
        return tuple(unique)

    def _name_matches_rule(self, name: str, pattern: str) -> bool:
        candidate = name.casefold()
        expected = pattern.strip().casefold()
        if not expected:
            return False
        if any(char in expected for char in "*?[]"):
            return fnmatch.fnmatchcase(candidate, expected)
        return candidate.startswith(expected)

    def _load_folder_preset(self, preset_name: str) -> dict[str, Any]:
        if preset_name in self._preset_cache:
            return self._preset_cache[preset_name]

        filename = Path(preset_name).name
        if not filename.lower().endswith(".json"):
            filename = f"{filename}.json"
        path = self.settings.root_dir / "presets" / filename
        if not path.exists():
            raise ConfigurationError(f"Preset para carpeta no encontrado: {preset_name}")

        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise ConfigurationError(f"Preset para carpeta no es JSON valido: {preset_name}") from exc
        if not isinstance(payload, dict):
            raise ConfigurationError(f"Preset para carpeta no valido: {preset_name}")
        self._preset_cache[preset_name] = payload
        return payload

    def _variant_preset_name(self, preset_name: str, input_path: Path) -> str | None:
        suffix = self._orientation_suffix(input_path)
        if suffix is None:
            return preset_name

        base = self._variant_base_name(preset_name)
        variant = f"{base}_{suffix}"
        if self._preset_exists(variant):
            return variant
        if self._has_orientation_preset_family(base):
            return None
        return preset_name

    def _variant_base_name(self, preset_name: str) -> str:
        base = self._preset_stem(preset_name)
        folded = base.casefold()
        if folded.endswith("_h") or folded.endswith("_v"):
            family = base[:-2]
            if self._preset_exists(f"{family}_h") or self._preset_exists(f"{family}_v"):
                return family
        return base

    def _has_orientation_preset_family(self, base_name: str) -> bool:
        return self._preset_exists(f"{base_name}_h") or self._preset_exists(f"{base_name}_v")

    def _orientation_suffix(self, input_path: Path) -> str | None:
        try:
            with Image.open(input_path) as image:
                width, height = image.size
                try:
                    orientation = int(image.getexif().get(274, 1) or 1)
                except Exception:
                    orientation = 1
        except OSError:
            return None
        if orientation in {5, 6, 7, 8}:
            width, height = height, width
        if width <= 0 or height <= 0:
            return None
        return "v" if height > width else "h"

    def _preset_stem(self, preset_name: str) -> str:
        return Path(preset_name).stem

    def _preset_exists(self, preset_name: str) -> bool:
        filename = Path(preset_name).name
        if not filename.lower().endswith(".json"):
            filename = f"{filename}.json"
        return (self.settings.root_dir / "presets" / filename).exists()

    def _active_preset_composition_matches(self, preset_name: str) -> bool:
        for candidate in self._active_preset_family_candidates(preset_name):
            if self._preset_composition_matches(candidate):
                return True
        return False

    def _active_preset_exact_composition_matches(self, preset_name: str) -> bool:
        return self._preset_composition_matches(preset_name)

    def _preset_composition_matches(self, preset_name: str) -> bool:
        if not self._preset_exists(preset_name):
            return False
        preset = self._load_folder_preset(preset_name)
        preset_park = self._park_with_preset(self.park, preset)
        return self._composition_preset_key(self.park) == self._composition_preset_key(preset_park)

    def _active_preset_family_candidates(self, preset_name: str) -> tuple[str, ...]:
        candidates: list[str] = [preset_name]
        base = self._variant_base_name(preset_name)
        for suffix in ("h", "v"):
            candidate = f"{base}_{suffix}"
            if candidate not in candidates:
                candidates.append(candidate)
        return tuple(candidates)

    def _active_preset_composition_changed(self, preset_name: str) -> bool:
        if not self._preset_exists(preset_name):
            return False
        return not self._active_preset_composition_matches(preset_name)

    def _active_preset_background_matches(self, preset_name: str) -> bool:
        for candidate in self._active_preset_family_candidates(preset_name):
            if self._preset_background_matches(candidate):
                return True
        return False

    def _active_preset_exact_background_matches(self, preset_name: str) -> bool:
        return self._preset_background_matches(preset_name)

    def _preset_background_matches(self, preset_name: str) -> bool:
        if not self._preset_exists(preset_name):
            return False
        preset = self._load_folder_preset(preset_name)
        preset_park = self._park_with_preset(self.park, preset)
        return self._path_signature(self.park.background_path) == self._path_signature(preset_park.background_path)

    def _composition_preset_key(self, park: ParkSettings) -> tuple[Any, ...]:
        return (
            self._path_signature(park.background_path),
            round(float(getattr(park, "background_brightness", 1.0) or 1.0), 6),
            self._path_signature(park.overlay_path),
            self._overlay_settings_key(park.overlay_settings),
            self._path_signature(park.logo_path),
            self._overlay_settings_key(park.logo_settings),
        )

    def _park_with_live_harmonize_off(self, park: ParkSettings) -> ParkSettings:
        if self.park.harmonize_strength <= 0:
            return replace(park, harmonize_strength=0.0)
        return park

    def _park_with_live_family_settings(self, park: ParkSettings) -> ParkSettings:
        return replace(
            park,
            jpg_quality=self.park.jpg_quality,
            harmonize_strength=self.park.harmonize_strength,
            contact_shadow=self.park.contact_shadow,
            photo_enhance=self.park.photo_enhance,
        )

    def _park_with_preset(
        self,
        base: ParkSettings,
        preset: dict[str, Any],
        preset_name: str | None = None,
    ) -> ParkSettings:
        park_raw = preset.get("park", {})
        if not isinstance(park_raw, dict):
            return base

        kwargs: dict[str, Any] = {}
        for key, attr in (
            ("background", "background_path"),
            ("overlay", "overlay_path"),
            ("logo", "logo_path"),
        ):
            if key in park_raw:
                kwargs[attr] = self._preset_path_value(park_raw.get(key))

        if "person" in park_raw:
            kwargs["person"] = self._replace_known(base.person, park_raw.get("person"))
        if "overlay_settings" in park_raw:
            kwargs["overlay_settings"] = self._replace_known(
                base.overlay_settings,
                park_raw.get("overlay_settings"),
            )
        if "logo_settings" in park_raw:
            kwargs["logo_settings"] = self._replace_known(
                base.logo_settings,
                park_raw.get("logo_settings"),
            )
        if "text_layer" in park_raw:
            kwargs["text_layer"] = self._replace_known(base.text_layer, park_raw.get("text_layer"))
        if "contact_shadow" in park_raw:
            kwargs["contact_shadow"] = self._replace_known(
                base.contact_shadow,
                park_raw.get("contact_shadow"),
            )
        if "photo_enhance" in park_raw:
            kwargs["photo_enhance"] = self._replace_known(
                base.photo_enhance,
                park_raw.get("photo_enhance"),
            )
        if "jpg_quality" in park_raw and park_raw.get("jpg_quality") is not None:
            kwargs["jpg_quality"] = int(park_raw.get("jpg_quality"))
        if "background_brightness" in park_raw and park_raw.get("background_brightness") is not None:
            kwargs["background_brightness"] = max(0.5, min(2.5, float(park_raw.get("background_brightness"))))
        if "harmonize_strength" in park_raw and park_raw.get("harmonize_strength") is not None:
            kwargs["harmonize_strength"] = float(park_raw.get("harmonize_strength"))

        selected = replace(base, **kwargs)
        if (
            preset_name
            and selected.background_path is not None
            and (not selected.background_path.exists() or not selected.background_path.is_file())
        ):
            self._warn_missing_preset_background(preset_name, selected.background_path)
            selected = replace(selected, background_path=None)
        return selected

    def _warn_missing_preset_background(self, preset_name: str, background_path: Path) -> None:
        key = self._preset_stem(preset_name).casefold()
        if key in self._warned_missing_preset_backgrounds:
            return
        self._warned_missing_preset_backgrounds.add(key)
        message = (
            f"El preset {preset_name} no tiene fondo disponible; "
            "se procesa la foto original conservando overlay, logo y retoque."
        )
        self.logger.warning("%s Ruta ausente: %s", message, background_path)
        safe_preset = preset_name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_message = message.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        self._emit_ui_event(f"HOTWARNING\t{safe_preset}\t{safe_message}")

    def _announce_processed_preview(
        self,
        input_path: Path,
        output_path: Path,
        preset_name: str | None,
    ) -> None:
        safe_input = input_path.name.replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_output = str(output_path).replace("\t", " ").replace("\r", " ").replace("\n", " ")
        safe_preset = (preset_name or "por defecto").replace("\t", " ").replace("\r", " ").replace("\n", " ")
        self._emit_ui_event(f"PROCESSPREVIEW\t{safe_input}\t{safe_output}\t{safe_preset}")

    def _emit_ui_event(self, message: str) -> None:
        try:
            print(message, flush=True)
        except (OSError, ValueError) as exc:
            self.logger.debug("UI event skipped: %s (%s)", message.split("\t", 1)[0], exc)

    def _background_removal_with_preset(
        self,
        base: BackgroundRemovalSettings,
        preset: dict[str, Any],
        apply_desktop_mask: bool = True,
    ) -> BackgroundRemovalSettings:
        # Backend, modelos y opciones de inferencia son globales. Los presets
        # antiguos pueden contener background_removal, pero nunca deben cambiar
        # el motor al seleccionar un montaje o una variante de orientacion.
        desktop_raw = preset.get("desktop", {})
        selected = base
        if apply_desktop_mask and isinstance(desktop_raw, dict):
            updates: dict[str, Any] = {}
            if "mask_protection" in desktop_raw:
                mask_value = self._clamp_int(desktop_raw.get("mask_protection"), -100, 100)
                updates["mask_protection"] = mask_value
                updates["mask_antighost"] = mask_value
            elif "mask_antighost" in desktop_raw:
                updates["mask_antighost"] = self._clamp_int(desktop_raw.get("mask_antighost"), -100, 100)
            if updates:
                selected = replace(selected, **updates)
        return selected

    def _preset_path_value(self, value: object) -> Path | None:
        if value is None or str(value).strip() == "":
            return None
        path = Path(str(value))
        if path.is_absolute():
            return path
        return self.settings.root_dir / path

    def _replace_known(self, current: Any, data: object) -> Any:
        if not isinstance(data, dict):
            return current
        allowed = getattr(current, "__dataclass_fields__", {})
        updates = {key: value for key, value in data.items() if key in allowed}
        if not updates:
            return current
        return replace(current, **updates)

    def _clamp_int(self, value: object, min_value: int, max_value: int) -> int:
        try:
            number = int(value)
        except (TypeError, ValueError):
            number = min_value
        return max(min_value, min(max_value, number))

    def _remover_for(self, settings: BackgroundRemovalSettings) -> BackgroundRemover:
        remover = self._removers.get(settings)
        if remover is None:
            remover = BackgroundRemover(settings, self.logger)
            self._removers[settings] = remover
        return remover

    def _output_path_for(self, input_path: Path, park: ParkSettings | None = None) -> Path:
        return unique_path(self._canonical_output_path_for(input_path, park))

    def _canonical_output_path_for(self, input_path: Path, park: ParkSettings | None = None) -> Path:
        selected = park or self.park
        output_dir = selected.output_dir
        if selected.mirror_input_folders and not self.repair_output_root:
            output_dir = self._archive_dir_for(selected.output_dir, input_path, selected)

        if selected.preserve_output_filename:
            filename = input_path.name
        else:
            filename = f"{input_path.stem}{selected.suffix}.jpg"

        return output_dir / filename

    def _archive_dir_for(
        self,
        base_dir: Path,
        input_path: Path,
        park: ParkSettings | None = None,
    ) -> Path:
        selected = park or self.park
        try:
            relative_parent = input_path.parent.resolve().relative_to(selected.input_dir.resolve())
        except ValueError:
            return base_dir
        if str(relative_parent) == ".":
            return base_dir
        return base_dir / relative_parent

    def _move_original_to_processed_enabled(self, park: ParkSettings) -> bool:
        if self.manual_search:
            return False
        enabled = park.move_original_to_processed
        if (
            not self.settings.config_path.name.startswith("settings_snapshot_")
            or not self.strict_preset_context
        ):
            return enabled
        self.refresh_live_automatic_settings()
        return self._live_move_processed_by_park.get(park.name, enabled)

    def cleanup_empty_input_dirs(self) -> int:
        return self._cleanup_empty_dirs(self.park.input_dir.resolve(), "IN")

    def _cleanup_empty_dirs(self, root: Path, label: str) -> int:
        removed = 0
        if not root.exists():
            return removed

        directories = sorted(
            (path for path in root.rglob("*") if path.is_dir()),
            key=lambda path: len(path.parts),
            reverse=True,
        )
        for directory in directories:
            try:
                next(directory.iterdir())
                continue
            except StopIteration:
                pass
            except OSError:
                continue

            try:
                relative = directory.resolve().relative_to(root)
            except ValueError:
                continue

            if str(relative) == ".":
                continue

            try:
                directory.rmdir()
                removed += 1
                self.logger.info("Removed empty %s folder after processing: %s", label, directory)
            except OSError:
                continue

        return removed

    def _save_jpeg(
        self,
        image: Image.Image,
        output_path: Path,
        source_path: Path | None = None,
        park: ParkSettings | None = None,
    ) -> None:
        selected = park or self.park
        quality = max(50, min(100, int(selected.jpg_quality or 90)))
        save_kwargs = {
            "quality": quality,
            "optimize": True,
            "subsampling": 0,
        }
        image_to_save = image.convert("RGB")
        if source_path is not None:
            image_to_save, metadata = self._jpeg_image_and_metadata_from_source(image_to_save, source_path)
            save_kwargs.update(metadata)

        image_to_save.save(output_path, "JPEG", **save_kwargs)

        if source_path is not None:
            self._copy_source_timestamps(source_path, output_path)

    def _jpeg_image_and_metadata_from_source(
        self,
        image: Image.Image,
        source_path: Path,
    ) -> tuple[Image.Image, dict[str, object]]:
        metadata: dict[str, object] = {}
        image_to_save = image
        try:
            with Image.open(source_path) as source:
                exif = source.getexif()
                if exif:
                    source_orientation = int(exif.get(274, 1) or 1)
                    source_display_size = ImageOps.exif_transpose(source).size
                    image_to_save = self._restore_source_storage_orientation(
                        image_to_save,
                        source.size,
                        source_display_size,
                        source_orientation,
                    )
                    exif[274] = source_orientation if image_to_save.size != image.size else 1
                    metadata["exif"] = exif.tobytes()
                icc_profile = source.info.get("icc_profile")
                if icc_profile:
                    metadata["icc_profile"] = icc_profile
        except Exception as exc:
            self.logger.warning("Could not preserve metadata from %s: %s", source_path, exc)
        return image_to_save, metadata

    def _restore_source_storage_orientation(
        self,
        image: Image.Image,
        source_stored_size: tuple[int, int],
        source_display_size: tuple[int, int],
        source_orientation: int,
    ) -> Image.Image:
        if source_orientation not in (5, 6, 7, 8):
            return image
        if image.width == image.height:
            return image

        source_stored_is_landscape = source_stored_size[0] > source_stored_size[1]
        source_display_is_landscape = source_display_size[0] > source_display_size[1]
        output_is_landscape = image.width > image.height
        if source_stored_is_landscape == source_display_is_landscape:
            return image
        if output_is_landscape != source_display_is_landscape:
            return image

        inverse_transpose = {
            5: Image.Transpose.TRANSPOSE,
            6: Image.Transpose.ROTATE_90,
            7: Image.Transpose.TRANSVERSE,
            8: Image.Transpose.ROTATE_270,
        }
        return image.transpose(inverse_transpose[source_orientation])

    def _copy_source_timestamps(self, source_path: Path, output_path: Path) -> None:
        try:
            source_stat = source_path.stat()
            os.utime(output_path, (source_stat.st_atime, source_stat.st_mtime))
        except OSError as exc:
            self.logger.warning("Could not copy timestamps from %s to %s: %s", source_path, output_path, exc)

    @contextmanager
    def _processing_lock(self, operation: str):
        lock_paths = [
            self.settings.logs.directory / "locks" / "photoia.lock",
            Path.cwd() / ".photoia.lock",
        ]
        lock_age_limit_seconds = 6 * 60 * 60
        descriptor: int | None = None
        lock_path: Path | None = None
        lock_errors: list[OSError] = []

        for candidate in lock_paths:
            try:
                candidate.parent.mkdir(parents=True, exist_ok=True)
                if candidate.exists():
                    lock_pid = _read_lock_pid(candidate)
                    if lock_pid == os.getpid() or _lock_is_stale(candidate, lock_age_limit_seconds):
                        self.logger.warning("Removing stale processing lock: %s", candidate)
                        try:
                            candidate.unlink(missing_ok=True)
                        except OSError as exc:
                            lock_errors.append(exc)
                            continue
                    else:
                        message = (
                            "Another processing job is already running. "
                            f"Lock: {candidate}"
                        )
                        raise ProcessingBusyError(message)
                descriptor = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                lock_path = candidate
                break
            except FileExistsError as exc:
                message = (
                    "Another processing job is already running. "
                    f"Lock: {candidate}"
                )
                raise ProcessingBusyError(message) from exc
            except OSError as exc:
                lock_errors.append(exc)

        if descriptor is None or lock_path is None:
            self.logger.warning("Processing lock disabled: %s", lock_errors)
            yield
            return

        try:
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                handle.write(f"pid={os.getpid()}\noperation={operation}\nstarted={time.time()}\n")
            yield
        finally:
            try:
                lock_path.unlink(missing_ok=True)
            except OSError as exc:
                self.logger.warning("Could not remove processing lock %s: %s", lock_path, exc)

