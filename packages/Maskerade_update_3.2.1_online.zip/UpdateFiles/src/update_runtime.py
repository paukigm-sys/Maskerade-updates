"""Install offline runtime additions without rewriting identical native libraries."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def stop_installation_processes(root: Path) -> None:
    """Stop only this installation; preserve the Python executing the migration."""
    if os.name != "nt":
        return
    env = os.environ.copy()
    env["MASKERADE_STOP_ROOT"] = str(root.resolve())
    env["MASKERADE_KEEP_PID"] = str(os.getpid())
    script = r"""
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($env:MASKERADE_STOP_ROOT).TrimEnd('\')
$runtime = $root + '\.runtime\'
$apps = @(($root + '\Maskerade.exe'), ($root + '\PhotoIA.exe'))
function OwnedProcesses {
    @(Get-CimInstance Win32_Process | Where-Object {
        $_.ProcessId -ne [int]$env:MASKERADE_KEEP_PID -and $_.ExecutablePath -and
        ($_.ExecutablePath.StartsWith($runtime, [StringComparison]::OrdinalIgnoreCase) -or
         $apps -contains $_.ExecutablePath)
    })
}
for ($attempt = 0; $attempt -lt 20; $attempt++) {
    $owned = @(OwnedProcesses)
    if ($owned.Count -eq 0) { exit 0 }
    foreach ($item in $owned) {
        Write-Output ('Stopping installation process: ' + $item.ProcessId + ' ' + $item.ExecutablePath)
        $process = Get-Process -Id $item.ProcessId -ErrorAction SilentlyContinue
        if ($process -and $process.Path -eq $item.ExecutablePath) {
            Stop-Process -InputObject $process -Force -ErrorAction Stop
        }
    }
    Start-Sleep -Milliseconds 250
}
throw 'Installation processes are still active; update stopped before copying.'
"""
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
        env=env, check=True, timeout=45,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )


def _validate_runtime(root: Path, spec: dict) -> None:
    python = root / ".runtime/python311/python.exe"
    code = """
import importlib, importlib.metadata as metadata, json, sys
from packaging.requirements import Requirement
spec = json.loads(sys.argv[1])
for name, version in spec['bundled'].items():
    distribution = metadata.distribution(name)
    if distribution.version != version:
        raise RuntimeError('Version incorrecta: ' + name)
    for text in distribution.requires or []:
        requirement = Requirement(text)
        if requirement.marker and not requirement.marker.evaluate({'extra': ''}):
            continue
        if metadata.version(requirement.name) not in requirement.specifier:
            raise RuntimeError('Dependencia incompatible: ' + text)
for name in spec['imports']:
    importlib.import_module(name)
"""
    subprocess.run([str(python), "-I", "-c", code, json.dumps(spec)],
                   cwd=root, check=True, timeout=180)


def install_runtime_additions(root: Path) -> None:
    from src.updater import _extract_validated_zip, _sha256

    root = root.resolve()
    archive = root / "updates/runtime-additions.zip"
    if not archive.is_file():
        return
    spec = json.loads((archive.parent / "runtime-additions.json").read_text(encoding="utf-8"))
    site = root / ".runtime/python311/Lib/site-packages"
    site.mkdir(parents=True, exist_ok=True)
    stop_installation_processes(root)
    with tempfile.TemporaryDirectory(prefix="maskerade-runtime-", dir=archive.parent) as temporary:
        stage = Path(temporary) / "files"
        backup = Path(temporary) / "backup"
        _extract_validated_zip(archive, stage)
        changed = []
        skipped = 0
        for source in sorted(stage.rglob("*")):
            if not source.is_file():
                continue
            relative = source.relative_to(stage)
            target = site / relative
            if not target.resolve().is_relative_to(site.resolve()):
                raise RuntimeError("Ruta de dependencia fuera del runtime privado.")
            if target.is_file() and _sha256(source) == _sha256(target):
                skipped += 1
                continue
            changed.append((source, target, relative))

        # Probe every replacement before modifying any runtime files.
        for source, target, relative in changed:
            if target.exists():
                with target.open("r+b"):
                    pass
                saved = backup / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, saved)
        written = []
        try:
            for source, target, relative in changed:
                target.parent.mkdir(parents=True, exist_ok=True)
                written.append((target, relative))
                shutil.copy2(source, target)
            _validate_runtime(root, spec)
        except Exception:
            for target, relative in reversed(written):
                saved = backup / relative
                if saved.is_file():
                    shutil.copy2(saved, target)
                else:
                    target.unlink(missing_ok=True)
            raise
    print(f"Runtime validado: {skipped} archivos conservados, {len(changed)} instalados.", flush=True)


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] != "--stop":
        raise SystemExit("Usage: update_runtime.py --stop INSTALLATION")
    stop_installation_processes(Path(sys.argv[2]))
