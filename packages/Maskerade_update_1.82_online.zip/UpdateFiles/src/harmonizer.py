from __future__ import annotations

import numpy as np
from PIL import Image

try:
    import cv2
except Exception:  # pragma: no cover - fallback for minimal installs
    cv2 = None


HARMONIZE_RESPONSE_GAIN = 1.45
HARMONIZE_MAX_STRENGTH = 3.0
LATE_HARMONIZE_WORK_MAX_SIDE = 1200
LATE_HARMONIZE_ADAPTIVE_MAX_SIDE = 960
LATE_HARMONIZE_ADAPTIVE_MIN_STRENGTH = 1.65


FAST_HARMONIZE_PROFILES: dict[str, dict[str, float | tuple[float, float, float]]] = {
    "cuevas_hams_vertical_v1": {
        "subject_exposure_ev": -0.12,
        "subject_contrast": 0.04,
        "subject_highlights": 0.28,
        "subject_whites": 0.32,
        "white_luma_max": 0.92,
        "shadow_tint_strength": 0.08,
        "highlight_tint_strength": 0.05,
        "skin_tint_multiplier": 0.35,
        "edge_wrap_strength": 0.12,
        "red_saturation": -0.08,
        "red_luminance": -0.03,
        "shadow_tint": (0.76, 0.92, 1.00),
        "highlight_tint": (1.00, 0.82, 0.52),
    },
    "cuevas_hams_horizontal_v1": {
        "subject_exposure_ev": -0.10,
        "subject_contrast": 0.04,
        "subject_highlights": 0.25,
        "subject_whites": 0.30,
        "white_luma_max": 0.92,
        "shadow_tint_strength": 0.07,
        "highlight_tint_strength": 0.05,
        "skin_tint_multiplier": 0.35,
        "edge_wrap_strength": 0.10,
        "red_saturation": -0.08,
        "red_luminance": -0.03,
        "shadow_tint": (0.76, 0.92, 1.00),
        "highlight_tint": (1.00, 0.82, 0.52),
    },
}


def _public_harmonize_strength(strength: float) -> float:
    return _clamp_harmonize_strength(float(strength or 0.0) * HARMONIZE_RESPONSE_GAIN)


def _clamp_harmonize_strength(strength: float) -> float:
    return max(0.0, min(HARMONIZE_MAX_STRENGTH, float(strength or 0.0)))


def _fast_profile_for(size: tuple[int, int]) -> dict[str, float | tuple[float, float, float]]:
    width, height = size
    key = "cuevas_hams_vertical_v1" if height >= width else "cuevas_hams_horizontal_v1"
    return FAST_HARMONIZE_PROFILES[key]


def harmonize_subject_layer(
    background: Image.Image,
    subject_rgba: Image.Image,
    strength: float,
) -> Image.Image:
    """Blend the BEN2 subject visually into the selected background.

    This keeps the subject alpha untouched. It only adjusts the visible RGB
    pixels, so it does not redraw faces or damage the overlay layer.
    """
    strength = _public_harmonize_strength(strength)
    if strength <= 0.001 or cv2 is None:
        return subject_rgba.convert("RGBA")

    background = background.convert("RGB")
    subject_rgba = subject_rgba.convert("RGBA")
    if subject_rgba.size != background.size:
        subject_rgba = subject_rgba.resize(background.size, Image.LANCZOS)

    subject = np.asarray(subject_rgba).astype(np.float32)
    bg = np.asarray(background).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return subject_rgba

    fg_rgb = subject[..., :3]
    sample_mask = _background_sample_mask(mask, bg.shape[:2])
    if not sample_mask.any():
        sample_mask = ~mask

    fg_lab = cv2.cvtColor(fg_rgb.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    bg_lab = cv2.cvtColor(bg.clip(0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)

    fg_pixels = fg_lab[mask]
    bg_pixels = bg_lab[sample_mask]
    fg_mean, fg_std = fg_pixels.mean(axis=0), fg_pixels.std(axis=0) + 1.0
    bg_mean, bg_std = bg_pixels.mean(axis=0), bg_pixels.std(axis=0) + 1.0

    mean_blend = min(0.92, 0.55 * strength)
    std_blend = min(0.76, 0.35 * strength)
    target_mean = fg_mean * (1.0 - mean_blend) + bg_mean * mean_blend
    target_std = fg_std * (1.0 - std_blend) + bg_std * std_blend
    adjusted_lab = (fg_lab - fg_mean) * (target_std / fg_std) + target_mean

    highlight = np.clip((fg_lab[..., 0:1] - 205.0) / 45.0, 0.0, 1.0) * alpha
    adjusted_lab[..., 0:1] -= highlight * (22.0 * strength)
    adjusted_lab[..., 0] = np.maximum(adjusted_lab[..., 0], fg_lab[..., 0] - 28.0 * strength)
    adjusted_lab = adjusted_lab.clip(0, 255)
    adjusted_rgb = cv2.cvtColor(adjusted_lab.astype(np.uint8), cv2.COLOR_LAB2RGB).astype(np.float32)

    edge = _edge_alpha(alpha[..., 0])
    wrap = cv2.GaussianBlur(bg, (0, 0), 22)
    wrap_amount = edge[..., None] * 0.28 * strength
    adjusted_rgb = adjusted_rgb * (1.0 - wrap_amount) + wrap * wrap_amount

    output_rgb = adjusted_rgb
    output = np.dstack([output_rgb.clip(0, 255), subject[..., 3:4]]).astype(np.uint8)
    return Image.fromarray(output, "RGBA")


def harmonize_composited_subject(
    background: Image.Image,
    composite: Image.Image,
    subject_rgba: Image.Image,
    strength: float,
    _allow_downsample: bool = True,
    _strength_is_public: bool = False,
) -> Image.Image:
    """Apply harmonization to the subject pixels after the full photo enhancement.

    This keeps enhancer/autotune analysis independent from harmonize while still
    nudging the composited people toward the selected background at the end.
    """
    strength = (
        _clamp_harmonize_strength(strength)
        if _strength_is_public
        else _public_harmonize_strength(strength)
    )
    if strength <= 0.001 or cv2 is None:
        return composite.convert("RGB")

    composite = composite.convert("RGB")
    background = background.convert("RGB")
    subject_rgba = subject_rgba.convert("RGBA")
    if background.size != composite.size:
        background = background.resize(composite.size, Image.LANCZOS)
    if subject_rgba.size != composite.size:
        subject_rgba = subject_rgba.resize(composite.size, Image.LANCZOS)

    max_side = max(composite.size)
    if _allow_downsample and max_side > LATE_HARMONIZE_WORK_MAX_SIDE and cv2 is not None:
        scale = LATE_HARMONIZE_WORK_MAX_SIDE / max_side
        work_size = (
            max(1, int(round(composite.width * scale))),
            max(1, int(round(composite.height * scale))),
        )
        composite_small = composite.resize(work_size, Image.Resampling.BILINEAR)
        background_small = background.resize(work_size, Image.Resampling.BILINEAR)
        subject_small = subject_rgba.resize(work_size, Image.Resampling.BILINEAR)
        harmonized_small = harmonize_composited_subject(
            background_small,
            composite_small,
            subject_small,
            strength,
            _allow_downsample=False,
            _strength_is_public=True,
        )
        base_small = np.asarray(composite_small, dtype=np.float32)
        adjusted_small = np.asarray(harmonized_small.convert("RGB"), dtype=np.float32)
        delta = adjusted_small - base_small
        delta = cv2.resize(delta, composite.size, interpolation=cv2.INTER_LINEAR)
        comp = np.asarray(composite, dtype=np.float32)
        alpha = np.asarray(subject_rgba.getchannel("A").convert("L"), dtype=np.float32) / 255.0
        output_rgb = comp + delta
        output_rgb = np.where((alpha > 0.03)[..., None], output_rgb, comp)
        return Image.fromarray(output_rgb.clip(0, 255).astype(np.uint8), "RGB")

    comp = np.asarray(composite).astype(np.float32)
    subject = np.asarray(subject_rgba).astype(np.float32)
    alpha = subject[..., 3:4] / 255.0
    mask = alpha[..., 0] > 0.03
    if not mask.any():
        return composite

    profile = _fast_profile_for(composite.size)
    adjusted_rgb = _fast_harmonize_rgb(comp / 255.0, alpha[..., 0], profile, strength)
    output_rgb = adjusted_rgb * 255.0

    bg_rgb = np.asarray(background).astype(np.float32) / 255.0
    scene_sample_mask = _background_sample_mask(mask, bg_rgb.shape[:2])
    bg_sample = bg_rgb[scene_sample_mask] if scene_sample_mask.any() else bg_rgb.reshape(-1, 3)
    sample_luma = _rgb_luma(bg_sample)
    bg_luma = float(np.percentile(sample_luma, 70))
    bg_mean = bg_sample.mean(axis=0)
    bg_warmth = float(bg_mean[0] - bg_mean[2])
    bright_scene = float(np.clip((bg_luma - 0.42) / 0.18, 0.0, 1.0))
    warm_scene = float(np.clip((bg_warmth + 0.02) / 0.12, 0.0, 1.0))

    mask_coverage = float(mask.mean())
    adaptive_scale = 0.55 + 0.15 * bright_scene + 0.07 * warm_scene
    adaptive_strength = min(1.75, max(0.0, (strength - 0.5) * adaptive_scale))
    if (
        strength >= LATE_HARMONIZE_ADAPTIVE_MIN_STRENGTH
        and adaptive_strength > 0.02
        and mask_coverage < 0.85
    ):
        current = Image.fromarray(output_rgb.clip(0, 255).astype(np.uint8), "RGB")
        adaptive_subject = current.convert("RGBA")
        adaptive_subject.putalpha(subject_rgba.getchannel("A"))
        adaptive_background = background
        max_side = max(background.size)
        if max_side > LATE_HARMONIZE_ADAPTIVE_MAX_SIDE:
            scale = LATE_HARMONIZE_ADAPTIVE_MAX_SIDE / max_side
            adaptive_size = (
                max(1, int(round(background.width * scale))),
                max(1, int(round(background.height * scale))),
            )
            adaptive_background = background.resize(adaptive_size, Image.Resampling.BILINEAR)
            adaptive_subject = adaptive_subject.resize(adaptive_size, Image.Resampling.BILINEAR)
        adaptive_layer = harmonize_subject_layer(adaptive_background, adaptive_subject, adaptive_strength)
        if adaptive_layer.size != composite.size:
            adaptive_layer = adaptive_layer.resize(composite.size, Image.Resampling.BILINEAR)
        adaptive = np.asarray(adaptive_layer.convert("RGBA")).astype(np.float32)
        adaptive_alpha = adaptive[..., 3:4] / 255.0
        adaptive_rgb = output_rgb * (1.0 - adaptive_alpha) + adaptive[..., :3] * adaptive_alpha
        adaptive_blend = min(0.90, adaptive_strength * (0.82 - 0.06 * bright_scene))
        output_rgb = output_rgb * (1.0 - adaptive_blend) + adaptive_rgb * adaptive_blend

    output_rgb = _restore_subject_detail(comp, output_rgb, alpha[..., 0], strength)
    output_rgb = np.where(mask[..., None], output_rgb, comp)
    return Image.fromarray(output_rgb.clip(0, 255).astype(np.uint8), "RGB")


def _fast_harmonize_rgb(
    rgb: np.ndarray,
    alpha: np.ndarray,
    profile: dict[str, float | tuple[float, float, float]],
    strength: float,
) -> np.ndarray:
    strength = _clamp_harmonize_strength(strength)
    subject = np.clip(alpha, 0.0, 1.0)
    if subject.max() <= 0.001:
        return rgb

    out = rgb.copy()
    luma = _rgb_luma(out)
    skin = _cheap_skin_mask(out) * subject

    exposure = float(profile["subject_exposure_ev"]) * min(1.0, strength)
    out = np.clip(out * (2.0 ** exposure), 0.0, 1.0)
    luma = _rgb_luma(out)

    contrast = float(profile["subject_contrast"]) * min(1.0, strength)
    contrasted = np.clip((out - 0.50) * (1.0 + contrast) + 0.50, 0.0, 1.0)
    out = out * (1.0 - subject[..., None]) + contrasted * subject[..., None]
    luma = _rgb_luma(out)

    hot = np.clip(_smoothstep(0.86, 1.0, luma) * subject, 0.0, 1.0)
    max_luma = float(profile["white_luma_max"])
    target_luma = np.minimum(luma, 0.86 + (luma - 0.86) * ((max_luma - 0.86) / 0.14))
    scale = np.divide(target_luma, np.maximum(luma, 0.001))
    recovered = np.clip(out * scale[..., None], 0.0, 1.0)
    white_strength = min(0.85, float(profile["subject_whites"]) * strength)
    out = out * (1.0 - hot[..., None] * white_strength) + recovered * (hot[..., None] * white_strength)
    luma = _rgb_luma(out)

    shadow_weight = (1.0 - _smoothstep(0.24, 0.58, luma)) * subject
    highlight_weight = _smoothstep(0.52, 0.92, luma) * subject
    tint_skin_hold = 1.0 - skin * (1.0 - float(profile["skin_tint_multiplier"]))
    shadow_tint = np.asarray(profile["shadow_tint"], dtype=np.float32)
    highlight_tint = np.asarray(profile["highlight_tint"], dtype=np.float32)
    shadow_blend = shadow_weight * float(profile["shadow_tint_strength"]) * strength * tint_skin_hold
    highlight_blend = highlight_weight * float(profile["highlight_tint_strength"]) * strength * tint_skin_hold
    out = out * (1.0 - shadow_blend[..., None]) + np.clip(out * shadow_tint, 0.0, 1.0) * shadow_blend[..., None]
    out = out * (1.0 - highlight_blend[..., None]) + np.clip(out * highlight_tint, 0.0, 1.0) * highlight_blend[..., None]

    out = _reduce_red_dominance(out, subject, float(profile["red_saturation"]), float(profile["red_luminance"]) * strength)

    edge = _edge_alpha(subject)
    edge_blend = edge * float(profile["edge_wrap_strength"]) * strength
    edge_tint = shadow_tint * 0.55 + highlight_tint * 0.45
    out = out * (1.0 - edge_blend[..., None]) + np.clip(out * edge_tint, 0.0, 1.0) * edge_blend[..., None]
    return np.clip(out, 0.0, 1.0)


def _reduce_red_dominance(rgb: np.ndarray, subject: np.ndarray, saturation_delta: float, value_delta: float) -> np.ndarray:
    if cv2 is None:
        return rgb
    hsv = cv2.cvtColor(np.clip(rgb * 255.0, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
    hue = hsv[..., 0]
    sat = hsv[..., 1]
    red = (((hue < 12.0) | (hue > 168.0)) & (sat > 70.0)).astype(np.float32) * subject
    if red.max() <= 0.001:
        return rgb
    hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + saturation_delta * red), 0, 255)
    hsv[..., 2] = np.clip(hsv[..., 2] + value_delta * 255.0 * red, 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32) / 255.0


def _cheap_skin_mask(rgb: np.ndarray) -> np.ndarray:
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    return (
        (r > 0.22) & (g > 0.13) & (b > 0.08)
        & ((maxc - minc) > 0.045)
        & (r > g * 1.04)
        & (r > b * 1.10)
    ).astype(np.float32)


def _rgb_luma(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _background_sample_mask(subject_mask: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    h, w = shape
    ys, xs = np.where(subject_mask)
    x1, x2 = max(0, xs.min() - w // 12), min(w, xs.max() + w // 12)
    y1, y2 = max(0, ys.min() - h // 12), min(h, ys.max() + h // 12)
    sample = np.zeros(shape, dtype=bool)
    sample[y1:y2, x1:x2] = True
    dilated = cv2.dilate(subject_mask.astype(np.uint8), np.ones((35, 35), np.uint8), iterations=1).astype(bool)
    return sample & ~dilated


def _edge_alpha(alpha: np.ndarray) -> np.ndarray:
    mask = (alpha > 0.03).astype(np.uint8)
    dilated = cv2.dilate(mask, np.ones((21, 21), np.uint8), iterations=1).astype(np.float32)
    eroded = cv2.erode(mask, np.ones((13, 13), np.uint8), iterations=1).astype(np.float32)
    edge = np.clip(dilated - eroded, 0, 1)
    edge = cv2.GaussianBlur(edge, (0, 0), 6)
    return np.clip(edge, 0, 1)


def _restore_subject_detail(source_rgb: np.ndarray, adjusted_rgb: np.ndarray, alpha: np.ndarray, strength: float) -> np.ndarray:
    if cv2 is None:
        return adjusted_rgb

    mask = (alpha > 0.14).astype(np.uint8)
    if not mask.any():
        return adjusted_rgb

    interior = cv2.erode(mask, np.ones((5, 5), np.uint8), iterations=1).astype(np.float32)
    if interior.max() <= 0:
        return adjusted_rgb
    detail_mask = cv2.GaussianBlur(interior, (0, 0), 1.1)[..., None]

    source = source_rgb.astype(np.float32)
    adjusted = adjusted_rgb.astype(np.float32)
    source_detail = source - cv2.GaussianBlur(source, (0, 0), 0.85)
    adjusted_detail = adjusted - cv2.GaussianBlur(adjusted, (0, 0), 0.85)
    missing_detail = source_detail - adjusted_detail
    amount = min(0.58, 0.22 + 0.13 * _clamp_harmonize_strength(strength))
    return np.clip(adjusted + missing_detail * (amount * detail_mask), 0, 255)
