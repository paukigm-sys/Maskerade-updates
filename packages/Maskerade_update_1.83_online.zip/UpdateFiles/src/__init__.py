"""Maskerade package."""

__version__ = "1.83"
