using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

public class CenteredButton : Button
{
    private bool hovering;
    private bool pressing;
    public int TextOffsetY { get; set; }
    public bool UseGradient { get; set; }
    public Color GradientStart { get; set; }
    public Color GradientEnd { get; set; }
    public int CornerRadius { get; set; }

    public CenteredButton()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
        GradientStart = Color.FromArgb(37, 99, 235);
        GradientEnd = Color.FromArgb(255, 138, 43);
        CornerRadius = 8;
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        hovering = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        hovering = false;
        pressing = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnMouseDown(MouseEventArgs mevent)
    {
        pressing = true;
        Invalidate();
        base.OnMouseDown(mevent);
    }

    protected override void OnMouseUp(MouseEventArgs mevent)
    {
        pressing = false;
        Invalidate();
        base.OnMouseUp(mevent);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Color parentBack = Parent != null ? Parent.BackColor : Color.FromArgb(14, 20, 31);
        using (SolidBrush parentBrush = new SolidBrush(parentBack))
        {
            e.Graphics.FillRectangle(parentBrush, ClientRectangle);
        }

        Color fill = BackColor;
        if (!Enabled)
        {
            fill = Color.FromArgb(27, 32, 43);
        }
        else if (pressing)
        {
            fill = ControlPaint.Dark(BackColor, 0.22f);
        }
        else if (hovering)
        {
            fill = ControlPaint.Light(BackColor, 0.10f);
        }

        Rectangle rect = new Rectangle(1, 1, Math.Max(1, Width - 3), Math.Max(1, Height - 3));
        int radius = Math.Max(0, Math.Min(CornerRadius, Math.Min(rect.Width, rect.Height) / 2));
        using (GraphicsPath path = radius > 0 ? RoundedRect(rect, radius) : null)
        {
            if (UseGradient && Enabled)
            {
                Color start = pressing ? ControlPaint.Dark(GradientStart, 0.24f) : hovering ? ControlPaint.Light(GradientStart, 0.10f) : GradientStart;
                Color end = pressing ? ControlPaint.Dark(GradientEnd, 0.24f) : hovering ? ControlPaint.Light(GradientEnd, 0.10f) : GradientEnd;
                using (LinearGradientBrush brush = new LinearGradientBrush(rect, start, end, LinearGradientMode.Horizontal))
                {
                    if (path != null) e.Graphics.FillPath(brush, path);
                    else e.Graphics.FillRectangle(brush, rect);
                }
            }
            else
            {
                using (SolidBrush brush = new SolidBrush(fill))
                {
                    if (path != null) e.Graphics.FillPath(brush, path);
                    else e.Graphics.FillRectangle(brush, rect);
                }
            }

            if (pressing)
            {
                using (SolidBrush shade = new SolidBrush(Color.FromArgb(62, 0, 0, 0)))
                {
                    if (path != null) e.Graphics.FillPath(shade, path);
                    else e.Graphics.FillRectangle(shade, rect);
                }
            }
            else if (hovering && Enabled)
            {
                using (SolidBrush glow = new SolidBrush(Color.FromArgb(26, 255, 255, 255)))
                {
                    Rectangle topGlow = new Rectangle(1, 1, Math.Max(1, Width - 2), Math.Max(1, Height / 2));
                    using (GraphicsPath glowPath = radius > 0 ? RoundedRect(topGlow, Math.Max(1, radius - 1)) : null)
                    {
                        if (glowPath != null) e.Graphics.FillPath(glow, glowPath);
                        else e.Graphics.FillRectangle(glow, topGlow);
                    }
                }
            }

            Color border = FlatAppearance.BorderColor;
            if (border == Color.Empty) border = Color.FromArgb(48, 56, 76);
            if (pressing) border = Color.FromArgb(255, 193, 77);
            else if (hovering && Enabled) border = ControlPaint.Light(border, 0.18f);
            using (Pen pen = new Pen(border, pressing ? 2F : 1F))
            {
                if (path != null) e.Graphics.DrawPath(pen, path);
                else e.Graphics.DrawRectangle(pen, rect);
            }
        }

        Color textColor = Enabled ? ForeColor : Color.FromArgb(110, 119, 139);
        Rectangle textRect = ClientRectangle;
        textRect.Offset(0, TextOffsetY);
        if (pressing) textRect.Offset(0, 1);
        TextRenderer.DrawText(
            e.Graphics,
            Text,
            Font,
            textRect,
            textColor,
            TextFormatFlags.HorizontalCenter
                | TextFormatFlags.VerticalCenter
                | TextFormatFlags.SingleLine
                | TextFormatFlags.EndEllipsis
        );
    }

    private GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        if (rect.Width <= 0 || rect.Height <= 0)
        {
            path.AddRectangle(Rectangle.Empty);
            return path;
        }
        radius = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
        if (radius <= 0)
        {
            path.AddRectangle(rect);
            path.CloseFigure();
            return path;
        }
        int diameter = radius * 2;
        path.AddArc(rect.Left, rect.Top, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Top, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }

}

public class FlatSlider : Control
{
    private int minimum = 0;
    private int maximum = 100;
    private int value = 50;
    private bool dragging;

    public event EventHandler ValueChanged;
    public event EventHandler ValueCommitted;

    public int Minimum
    {
        get { return minimum; }
        set { minimum = value; if (maximum < minimum) maximum = minimum; Value = this.value; Invalidate(); }
    }

    public int Maximum
    {
        get { return maximum; }
        set { maximum = value; if (minimum > maximum) minimum = maximum; Value = this.value; Invalidate(); }
    }

    public int Step { get; set; }

    public int Value
    {
        get { return value; }
        set
        {
            int next = Math.Max(minimum, Math.Min(maximum, value));
            if (this.value == next) return;
            this.value = next;
            Invalidate();
            if (ValueChanged != null) ValueChanged(this, EventArgs.Empty);
        }
    }

    public FlatSlider()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint | ControlStyles.Selectable, true);
        BackColor = Color.FromArgb(16, 22, 34);
        ForeColor = Color.White;
        TabStop = true;
        Step = 1;
        Height = 36;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;

        int left = 8;
        int right = Width - 8;
        int centerY = Math.Max(12, Height / 2 - 1);
        int trackHeight = 7;
        Rectangle track = new Rectangle(left, centerY - trackHeight / 2, right - left, trackHeight);
        float ratio = maximum == minimum ? 0f : (float)(value - minimum) / (float)(maximum - minimum);
        int thumbX = left + (int)Math.Round((right - left) * ratio);

        using (SolidBrush bg = new SolidBrush(Color.FromArgb(43, 52, 70)))
        using (GraphicsPath path = RoundedRect(track, 4))
        {
            g.FillPath(bg, path);
        }

        Rectangle fill = new Rectangle(left, centerY - trackHeight / 2, Math.Max(4, thumbX - left), trackHeight);
        using (LinearGradientBrush accentBrush = new LinearGradientBrush(track, Color.FromArgb(37, 99, 235), Color.FromArgb(255, 45, 186), LinearGradientMode.Horizontal))
        using (GraphicsPath path = RoundedRect(fill, 4))
        {
            g.FillPath(accentBrush, path);
        }

        using (Pen tickPen = new Pen(Color.FromArgb(72, 82, 106)))
        {
            for (int i = 0; i <= 4; i++)
            {
                int x = left + (right - left) * i / 4;
                g.DrawLine(tickPen, x, centerY + 9, x, centerY + 12);
            }
        }

        Rectangle thumb = new Rectangle(thumbX - 6, centerY - 11, 12, 22);
        using (LinearGradientBrush thumbBrush = new LinearGradientBrush(thumb, Color.FromArgb(255, 45, 186), Color.FromArgb(255, 193, 77), LinearGradientMode.Vertical))
        using (Pen border = new Pen(Color.FromArgb(10, 15, 26)))
        using (GraphicsPath path = RoundedRect(thumb, 7))
        {
            g.FillPath(thumbBrush, path);
            g.DrawPath(border, path);
        }

        // Keep slider focus visual quiet; the old dotted focus box made the grouped controls look broken.
    }

    protected override bool IsInputKey(Keys keyData)
    {
        Keys key = keyData & Keys.KeyCode;
        if (key == Keys.Left || key == Keys.Right || key == Keys.Up || key == Keys.Down || key == Keys.Home || key == Keys.End)
        {
            return true;
        }
        return base.IsInputKey(keyData);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        Focus();
        dragging = true;
        Capture = true;
        UpdateFromMouse(e.X);
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (dragging) UpdateFromMouse(e.X);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (!dragging) return;
        dragging = false;
        Capture = false;
        UpdateFromMouse(e.X);
        Commit();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        base.OnKeyDown(e);
        int step = e.Shift ? Math.Max(1, Step) : 1;
        if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Down)
        {
            Value -= step;
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Up)
        {
            Value += step;
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.Home)
        {
            Value = Minimum;
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
        else if (e.KeyCode == Keys.End)
        {
            Value = Maximum;
            e.Handled = true;
            e.SuppressKeyPress = true;
        }
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
        base.OnKeyUp(e);
        Commit();
    }

    protected override void OnLeave(EventArgs e)
    {
        base.OnLeave(e);
        Invalidate();
        Commit();
    }

    protected override void OnEnter(EventArgs e)
    {
        base.OnEnter(e);
        Invalidate();
    }

    private void UpdateFromMouse(int x)
    {
        int left = 8;
        int right = Math.Max(left + 1, Width - 8);
        double ratio = (double)(Math.Max(left, Math.Min(right, x)) - left) / (double)(right - left);
        Value = minimum + (int)Math.Round((maximum - minimum) * ratio);
    }

    private void Commit()
    {
        if (ValueCommitted != null) ValueCommitted(this, EventArgs.Empty);
    }

    private GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        if (rect.Width <= 0 || rect.Height <= 0)
        {
            path.AddRectangle(Rectangle.Empty);
            return path;
        }
        radius = Math.Max(0, Math.Min(radius, Math.Min(rect.Width, rect.Height) / 2));
        if (radius <= 0)
        {
            path.AddRectangle(rect);
            path.CloseFigure();
            return path;
        }
        int diameter = radius * 2;
        path.AddArc(rect.Left, rect.Top, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Top, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class FlatProgressBar : Control
{
    private int value;

    public int Minimum { get; set; }
    public int Maximum { get; set; }

    public int Value
    {
        get { return value; }
        set
        {
            int min = Minimum;
            int max = Maximum <= Minimum ? Minimum + 1 : Maximum;
            int next = Math.Max(min, Math.Min(max, value));
            if (this.value == next) return;
            this.value = next;
            Invalidate();
        }
    }

    public FlatProgressBar()
    {
        Minimum = 0;
        Maximum = 100;
        Height = 16;
        BackColor = Color.White;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        Graphics g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle track = new Rectangle(0, 0, Width - 1, Height - 1);
        float ratio = Maximum <= Minimum ? 0f : (float)(Value - Minimum) / (float)(Maximum - Minimum);
        Rectangle fill = new Rectangle(0, 0, Math.Max(0, (int)Math.Round((Width - 1) * ratio)), Height - 1);

        using (SolidBrush bg = new SolidBrush(Color.FromArgb(43, 52, 70)))
        using (GraphicsPath path = RoundedRect(track, Height / 2))
        {
            g.FillPath(bg, path);
        }
        if (fill.Width > 0)
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(track, Color.FromArgb(37, 99, 235), Color.FromArgb(255, 138, 43), LinearGradientMode.Horizontal))
            using (GraphicsPath path = RoundedRect(fill, Height / 2))
            {
                g.FillPath(brush, path);
            }
        }
    }

    private GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        int diameter = radius * 2;
        path.AddArc(rect.Left, rect.Top, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Top, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class PreviewNavButton : Control
{
    private bool hovering;
    private bool pressing;

    public PreviewNavButton(string text)
    {
        Text = text;
        Cursor = Cursors.Hand;
        Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        ForeColor = Color.FromArgb(230, 240, 255);
        BackColor = Color.FromArgb(16, 22, 34);
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.UserPaint, true);
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        hovering = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        hovering = false;
        pressing = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        pressing = true;
        Invalidate();
        base.OnMouseDown(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        pressing = false;
        Invalidate();
        base.OnMouseUp(e);
    }

    protected override void OnEnabledChanged(EventArgs e)
    {
        Invalidate();
        base.OnEnabledChanged(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        Rectangle rect = new Rectangle(1, 1, Math.Max(1, Width - 3), Math.Max(1, Height - 3));
        int radius = Math.Max(1, Math.Min(8, Math.Min(rect.Width, rect.Height) / 2));
        Color fill = Enabled ? Color.FromArgb(12, 18, 29) : Color.FromArgb(18, 23, 34);
        if (pressing && Enabled) fill = Color.FromArgb(31, 38, 56);
        else if (hovering && Enabled) fill = Color.FromArgb(25, 32, 48);
        Color border = Enabled ? Color.FromArgb(65, 76, 102) : Color.FromArgb(38, 47, 66);
        Color text = Enabled ? ForeColor : Color.FromArgb(90, 100, 120);

        using (GraphicsPath path = RoundedRect(rect, radius))
        using (SolidBrush brush = new SolidBrush(fill))
        using (Pen pen = new Pen(border))
        {
            e.Graphics.FillPath(brush, path);
            e.Graphics.DrawPath(pen, path);
        }

        Rectangle textRect = ClientRectangle;
        textRect.Offset(0, -1);
        TextRenderer.DrawText(
            e.Graphics,
            Text,
            Font,
            textRect,
            text,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine
        );
    }

    private GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        if (rect.Width <= 0 || rect.Height <= 0)
        {
            path.AddRectangle(Rectangle.Empty);
            return path;
        }
        int diameter = radius * 2;
        path.AddArc(rect.Left, rect.Top, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Top, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}

public class PhotoIADesktop : Form
{
    private static Mutex singleInstanceMutex;
    private const int DWMWA_USE_IMMERSIVE_DARK_MODE = 20;
    private const int DWMWA_USE_IMMERSIVE_DARK_MODE_OLD = 19;
    private const int DWMWA_BORDER_COLOR = 34;
    private const int DWMWA_CAPTION_COLOR = 35;
    private const int DWMWA_TEXT_COLOR = 36;

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
    private static extern int SetWindowTheme(IntPtr hwnd, string subAppName, string subIdList);

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    private const int SW_RESTORE = 9;
    private const int WM_THEMECHANGED = 0x031A;

    private readonly string appDir;
    private readonly string pythonExe;
    private readonly string mainPy;
    private readonly string bridgePy;

    private Dictionary<string, List<string>> state = new Dictionary<string, List<string>>();
    private readonly Dictionary<string, string> lastAssetDialogDirs = new Dictionary<string, string>();
    private bool darkTheme = true;
    private bool busy;
    private Process watchProcess;
    private bool hotfolderStopping;
    private string hotfolderConfigSnapshotPath = "";
    private Process runningProcess;
    private Thread runningWorkerThread;
    private bool cancelRequested;
    private volatile bool closingApp;

    private Label versionLabel;
    private Control updateButton;
    private volatile bool updateBusy;
    private Button hotfolderButton;
    private Button nuvolButton;
    private Button stopButton;
    private TextBox inputBox;
    private TextBox outputBox;
    private TextBox backgroundBox;
    private TextBox overlayBox;
    private TextBox processedBox;
    private ComboBox nuvolModeCombo;
    private TextBox nuvolParkBox;
    private TextBox nuvolUsernameBox;
    private TextBox nuvolAuthUsernameBox;
    private TextBox nuvolAuthPasswordBox;
    private TextBox nuvolDownloadBox;
    private Label activeBackgroundNameLabel;
    private Label activeOverlayNameLabel;
    private FlatSlider qualitySlider;
    private Label qualityValueLabel;
    private FlatSlider maskProtectionSlider;
    private Label maskProtectionValueLabel;
    private FlatSlider maskAntighostSlider;
    private Label maskAntighostValueLabel;
    private FlatSlider photoZoomSlider;
    private Label photoZoomValueLabel;
    private FlatSlider personVerticalSlider;
    private Label personVerticalValueLabel;
    private FlatSlider overlayScaleSlider;
    private Label overlayScaleValueLabel;
    private FlatSlider logoScaleSlider;
    private Label logoScaleValueLabel;
    private FlatSlider harmonizeSlider;
    private Label harmonizeValueLabel;
    private FlatSlider photoEnhanceSlider;
    private Label photoEnhanceValueLabel;
    private Button photoEnhanceConfigButton;
    private Button photoEnhanceAutoTuneButton;
    private FlatSlider shadowSlider;
    private Label shadowValueLabel;
    private Button batchProcessButton;
    private Button moveProcessedButton;
    private PictureBox previewBox;
    private PreviewNavButton previewPrevButton;
    private PreviewNavButton previewNextButton;
    private Label previewPhotoLabel;
    private FlowLayoutPanel backgroundsPanel;
    private FlowLayoutPanel overlaysPanel;
    private FlowLayoutPanel logosPanel;
    private TextBox textLayerBox;
    private ComboBox textLayerFontCombo;
    private ComboBox textLayerColorCombo;
    private FlatSlider textLayerScaleSlider;
    private Label textLayerScaleLabel;
    private FlatSlider textLayerRotationSlider;
    private Label textLayerRotationLabel;
    private bool suppressTextLayerEvents;
    private TableLayoutPanel centerLayoutPanel;
    private Panel centerSplitterPanel;
    private bool adjustingCenterLayout;
    private bool centerSplitterDragging;
    private int centerSplitterStartMouseY;
    private int centerSplitterStartPreviewHeight;
    private int manualPreviewHeight = -1;
    private TextBox presetNameBox;
    private ComboBox presetCombo;
    private ComboBox folderRuleCombo;
    private TextBox folderRulePatternBox;
    private TextBox logBox;
    private int logLineCount;
    private readonly object pendingProcessingLogLock = new object();
    private readonly List<string> pendingProcessingLogLines = new List<string>();
    private bool pendingProcessingLogFlushQueued;
    private FlatProgressBar batchProgress;
    private Label progressLabel;
    private System.Windows.Forms.Timer progressTimer;
    private System.Windows.Forms.Timer previewTimer;
    private System.Windows.Forms.Timer livePreviewTimer;
    private int progressTotal;
    private int progressStartOut;
    private int progressStartIn;
    private DateTime progressStartedAt;
    private bool progressTimingStarted;
    private int progressProcessedCount;
    private double progressSecondsPerPhoto;
    private string progressFolderName = "";
    private string activeLogFolderName = "";
    private int activeLogFolderProcessed;
    private double activeLogFolderSeconds;
    private bool overlayDragging;
    private bool livePreviewFast;
    private bool livePreviewPending;
    private Point overlayDragStartMouse;
    private Point overlayDragStartPosition;
    private double overlayDragSceneScale = 1.0;
    private double overlayDragCoordinateScale = 1.0;
    private const int OverlayOriginSnapPreviewPixels = 22;
    private string overlayDragLayer = "overlay";
    private Rectangle lastOverlayPreviewRect = Rectangle.Empty;
    private Rectangle lastLogoPreviewRect = Rectangle.Empty;
    private Rectangle lastTextPreviewRect = Rectangle.Empty;
    private RectangleF lastTextHitRect = RectangleF.Empty;
    private PointF lastTextHitCenter = PointF.Empty;
    private float lastTextHitRotation;
    private Rectangle lastScenePreviewRect = Rectangle.Empty;
    private int lastSavedMaskProtection = -1;
    private int lastSavedMaskAntighost = -1;
    private int lastSavedPhotoZoom = -1;
    private int lastSavedPersonVertical = 9999;
    private int lastSavedOverlayScale = -1;
    private int lastSavedLogoScale = -1;
    private int lastSavedJpgQuality = -1;
    private int lastSavedHarmonize = -1;
    private int lastSavedPhotoEnhance = -1;
    private int lastSavedShadow = -1;
    private Bitmap previewBaseSourceBitmap;
    private string previewBaseSourcePath = "";
    private Bitmap previewSceneBaseBitmap;
    private string previewSceneBaseKey = "";
    private int enhancedPreviewRevision;
    private bool enhancedPreviewRunning;
    private string enhancedPreviewRenderedKey = "";
    private List<string> cachedPreviewInputImages = new List<string>();
    private string cachedPreviewInputImagesKey = "";
    private DateTime cachedPreviewInputImagesAt = DateTime.MinValue;
    private Size cachedBackgroundSourceSize = Size.Empty;
    private string cachedBackgroundSourceSizePath = "";
    private Image previewSubjectSourceBitmap;
    private string previewSubjectSourcePath = "";
    private Image overlaySourceBitmap;
    private string overlaySourcePath = "";
    private Image logoSourceBitmap;
    private string logoSourcePath = "";
    private Bitmap logoPreviewBitmap;
    private string logoPreviewKey = "";
    private string harmonizeBackgroundSourcePath = "";
    private Color harmonizeBackgroundAverage = Color.Empty;
    private Size cachedPreviewBaseSize = Size.Empty;
    private string cachedPreviewBaseSizeKey = "";
    private readonly Color dark = Color.FromArgb(10, 15, 26);
    private readonly Color darkCard = Color.FromArgb(16, 22, 34);
    private readonly Color page = Color.FromArgb(243, 246, 255);
    private readonly Color accent = Color.FromArgb(124, 58, 237);
    private readonly Color brand = Color.FromArgb(255, 138, 43);
    private readonly Color azure = Color.FromArgb(37, 99, 235);
    private readonly Color magenta = Color.FromArgb(255, 45, 186);
    private readonly Color amber = Color.FromArgb(255, 193, 77);
    private readonly Color graphite = Color.FromArgb(26, 29, 38);

    private Color PageColor
    {
        get { return darkTheme ? dark : page; }
    }

    private Color SurfaceColor
    {
        get { return darkTheme ? darkCard : Color.White; }
    }

    private Color SubsurfaceColor
    {
        get { return darkTheme ? Color.FromArgb(20, 27, 41) : Color.FromArgb(235, 240, 250); }
    }

    private Color TileColor
    {
        get { return darkTheme ? Color.FromArgb(20, 27, 41) : Color.FromArgb(248, 250, 255); }
    }

    private Color ActiveTileColor
    {
        get { return darkTheme ? Color.FromArgb(33, 26, 58) : Color.FromArgb(238, 231, 255); }
    }

    private Color TextColor
    {
        get { return darkTheme ? Color.FromArgb(243, 246, 255) : Color.FromArgb(10, 15, 26); }
    }

    private Color MutedTextColor
    {
        get { return darkTheme ? Color.FromArgb(158, 167, 191) : Color.FromArgb(82, 91, 115); }
    }

    private Color BorderColor
    {
        get { return darkTheme ? Color.FromArgb(48, 56, 76) : Color.FromArgb(201, 209, 226); }
    }

    [STAThread]
    public static void Main()
    {
        bool createdNew;
        singleInstanceMutex = new Mutex(true, "Maskerade.SingleInstance", out createdNew);
        if (!createdNew) return;
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new PhotoIADesktop());
        singleInstanceMutex.ReleaseMutex();
    }

    public PhotoIADesktop()
    {
        appDir = AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
        pythonExe = Path.Combine(appDir, ".runtime", "python311", "python.exe");
        mainPy = Path.Combine(appDir, "main.py");
        bridgePy = Path.Combine(appDir, "desktop_bridge.py");

        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        DoubleBuffered = true;
        Text = "Maskerade";
        Icon = LoadIconSafe();
        ClientSize = new Size(1740, 980);
        MinimumSize = new Size(1360, 820);
        FormBorderStyle = FormBorderStyle.Sizable;
        MaximizeBox = true;
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = PageColor;
        Font = new Font("Segoe UI", 9F);

        BuildUi();
        ApplyStartupWindowLayout();
        ApplyWindowBrandChrome();
        BuildProgressTimer();
        BuildPreviewTimer();
        BuildLivePreviewTimer();
        LoadState();
        ApplyTheme();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        ApplyWindowBrandChrome();
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        Keys code = keyData & Keys.KeyCode;
        if ((code == Keys.Left || code == Keys.Right) && !IsTypingControlFocused())
        {
            NavigatePreviewPhoto(code == Keys.Left ? -1 : 1);
            return true;
        }
        return base.ProcessCmdKey(ref msg, keyData);
    }

    private bool IsTypingControlFocused()
    {
        Control focused = ActiveControl;
        ContainerControl container = focused as ContainerControl;
        while (container != null && container.ActiveControl != null)
        {
            focused = container.ActiveControl;
            container = focused as ContainerControl;
        }

        return focused is TextBoxBase || focused is ComboBox || focused is NumericUpDown;
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        closingApp = true;
        cancelRequested = true;
        StopCurrentWork(true);
        StopHotfolder(true);
        KillOwnedPythonProcesses();
        ClearPreviewBase();
        ClearOverlayCache();
        ClearLogoCache();
        base.OnFormClosing(e);
    }

    private void ApplyWindowBrandChrome()
    {
        ApplyWindowBrandChrome(this);
    }

    private void ApplyWindowBrandChrome(Form form)
    {
        if (form == null || !form.IsHandleCreated) return;
        try
        {
            int enabled = darkTheme ? 1 : 0;
            if (DwmSetWindowAttribute(form.Handle, DWMWA_USE_IMMERSIVE_DARK_MODE, ref enabled, sizeof(int)) != 0)
            {
                DwmSetWindowAttribute(form.Handle, DWMWA_USE_IMMERSIVE_DARK_MODE_OLD, ref enabled, sizeof(int));
            }

            int caption = darkTheme ? ColorRef(dark) : ColorRef(Color.FromArgb(248, 250, 255));
            int text = darkTheme ? ColorRef(Color.White) : ColorRef(Color.FromArgb(10, 15, 26));
            int border = darkTheme ? ColorRef(accent) : ColorRef(Color.FromArgb(201, 209, 226));
            DwmSetWindowAttribute(form.Handle, DWMWA_CAPTION_COLOR, ref caption, sizeof(int));
            DwmSetWindowAttribute(form.Handle, DWMWA_TEXT_COLOR, ref text, sizeof(int));
            DwmSetWindowAttribute(form.Handle, DWMWA_BORDER_COLOR, ref border, sizeof(int));
        }
        catch { }
    }

    private int ColorRef(Color color)
    {
        return color.R | (color.G << 8) | (color.B << 16);
    }

    private void ApplyStartupWindowLayout()
    {
        Rectangle workArea = Screen.FromPoint(Cursor.Position).WorkingArea;
        if (workArea.Width <= 0 || workArea.Height <= 0) return;

        MinimumSize = new Size(
            Math.Min(1360, Math.Max(960, workArea.Width)),
            Math.Min(820, Math.Max(680, workArea.Height))
        );

        int normalWidth = Math.Min(1740, Math.Max(MinimumSize.Width, (int)Math.Round(workArea.Width * 0.92)));
        int normalHeight = Math.Min(980, Math.Max(MinimumSize.Height, (int)Math.Round(workArea.Height * 0.92)));
        int normalX = workArea.Left + Math.Max(0, (workArea.Width - normalWidth) / 2);
        int normalY = workArea.Top + Math.Max(0, (workArea.Height - normalHeight) / 2);

        StartPosition = FormStartPosition.Manual;
        Bounds = new Rectangle(normalX, normalY, normalWidth, normalHeight);
        WindowState = FormWindowState.Normal;
    }

    private Icon LoadIconSafe()
    {
        string[] iconPaths =
        {
            Path.Combine(appDir, "maskerade.ico"),
            Path.Combine(appDir, "assets", "maskerade.ico"),
            Path.Combine(appDir, "photo_ia.ico"),
            Path.Combine(appDir, "assets", "photo_ia_app.ico"),
            Path.Combine(appDir, "assets", "photo_ia.ico")
        };

        foreach (string iconPath in iconPaths)
        {
            if (File.Exists(iconPath))
            {
                try { return new Icon(iconPath); } catch { }
            }
        }
        return SystemIcons.Application;
    }

    private Bitmap CreateBrandLogoBitmap(int size)
    {
        string imagePath = Path.Combine(appDir, "assets", "branding", "maskerade", "reduced_icon.png");
        if (!File.Exists(imagePath)) imagePath = Path.Combine(appDir, "assets", "maskerade_logo.png");
        if (!File.Exists(imagePath)) imagePath = Path.Combine(appDir, "assets", "photo_ia_icon.png");
        if (File.Exists(imagePath))
        {
            try
            {
                using (Image src = LoadBitmapUnlocked(imagePath))
                {
                    Bitmap icon = new Bitmap(size, size);
                    using (Graphics g = Graphics.FromImage(icon))
                    {
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.Clear(Color.Transparent);
                        g.DrawImage(src, new Rectangle(0, 0, size, size));
                    }
                    return icon;
                }
            }
            catch { }
        }

        Bitmap bmp = new Bitmap(size, size);
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Color.Transparent);
            Rectangle rect = new Rectangle(0, 0, size - 1, size - 1);
            using (SolidBrush bg = new SolidBrush(brand))
            using (GraphicsPath path = RoundedRect(rect, 8))
            {
                g.FillPath(bg, path);
            }

            using (SolidBrush text = new SolidBrush(Color.FromArgb(7, 19, 27)))
            using (Font font = new Font("Segoe UI", size * 0.42F, FontStyle.Bold, GraphicsUnit.Pixel))
            {
                StringFormat fmt = new StringFormat();
                fmt.Alignment = StringAlignment.Center;
                fmt.LineAlignment = StringAlignment.Center;
                g.DrawString("M", font, text, rect, fmt);
            }

            int lens = Math.Max(8, size / 5);
            Rectangle lensRect = new Rectangle(size - lens - 7, 7, lens, lens);
            using (SolidBrush lensBrush = new SolidBrush(Color.FromArgb(17, 126, 132)))
            using (Pen lensPen = new Pen(Color.FromArgb(7, 19, 27), 2))
            {
                g.FillEllipse(lensBrush, lensRect);
                g.DrawEllipse(lensPen, lensRect);
            }
        }
        return bmp;
    }

    private GraphicsPath RoundedRect(Rectangle rect, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        int diameter = radius * 2;
        path.AddArc(rect.Left, rect.Top, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Top, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.Left, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }

    private void ApplyRoundedRegion(Control control, int radius)
    {
        if (control.Width <= 0 || control.Height <= 0) return;
        Rectangle rect = new Rectangle(0, 0, control.Width, control.Height);
        using (GraphicsPath path = RoundedRect(rect, radius))
        {
            Region old = control.Region;
            control.Region = new Region(path);
            if (old != null) old.Dispose();
        }
    }

    private void ApplyRoundedPanel(Panel panel, int radius)
    {
        panel.Resize += delegate
        {
            ApplyRoundedRegion(panel, radius);
            panel.Invalidate();
        };
        panel.HandleCreated += delegate { ApplyRoundedRegion(panel, radius); };
        panel.Paint += delegate(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, panel.Width - 1, panel.Height - 1);
            using (GraphicsPath path = RoundedRect(rect, radius))
            using (Pen pen = new Pen(BorderColor))
            {
                e.Graphics.DrawPath(pen, path);
            }
        };
    }

    private void BuildUi()
    {
        TableLayoutPanel shell = new TableLayoutPanel();
        shell.Dock = DockStyle.Fill;
        shell.ColumnCount = 2;
        shell.RowCount = 1;
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
        shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        shell.BackColor = PageColor;
        Controls.Add(shell);
        ApplyDarkScrollbarTheme(shell);

        shell.Controls.Add(BuildSidebar(), 0, 0);
        shell.Controls.Add(BuildContent(), 1, 0);
    }

    private Control BuildSidebar()
    {
        Panel scroller = new Panel();
        scroller.Dock = DockStyle.Fill;
        scroller.BackColor = PageColor;
        scroller.AutoScroll = true;
        ApplyDarkScrollbarTheme(scroller);

        TableLayoutPanel side = new TableLayoutPanel();
        side.Dock = DockStyle.Top;
        side.AutoSize = true;
        side.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        side.BackColor = PageColor;
        side.Padding = new Padding(14, 14, 14, 14);
        side.RowCount = 6;
        side.ColumnCount = 1;
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 82F));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 410F));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 254F));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 166F));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 166F));
        side.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));

        side.Controls.Add(BuildBrand(), 0, 0);
        side.Controls.Add(BuildEngineCard(), 0, 1);
        side.Controls.Add(BuildHarmonizeCard(), 0, 2);
        side.Controls.Add(BuildShadowCard(), 0, 3);
        side.Controls.Add(BuildOperationCard(), 0, 4);

        scroller.Controls.Add(side);
        return scroller;
    }

    private Control BuildBrand()
    {
        Panel p = new Panel();
        p.Dock = DockStyle.Fill;
        p.BackColor = SurfaceColor;
        p.Margin = new Padding(0, 0, 0, 14);
        p.Resize += delegate { ApplyRoundedRegion(p, 10); p.Invalidate(); };
        p.HandleCreated += delegate { ApplyRoundedRegion(p, 10); };
        p.Paint += delegate(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(1, 1, Math.Max(1, p.Width - 3), Math.Max(1, p.Height - 3));
            using (GraphicsPath path = RoundedRect(rect, 10))
            using (Pen border = new Pen(BorderColor))
            {
                e.Graphics.DrawPath(border, path);
            }
            Rectangle glow = new Rectangle(1, p.Height - 4, Math.Max(1, p.Width - 2), 3);
            using (LinearGradientBrush brush = new LinearGradientBrush(glow, azure, brand, LinearGradientMode.Horizontal))
            {
                e.Graphics.FillRectangle(brush, glow);
            }
        };

        PictureBox logo = new PictureBox();
        logo.BackColor = SurfaceColor;
        logo.SizeMode = PictureBoxSizeMode.Zoom;
        logo.SetBounds(10, 10, 52, 52);
        logo.Image = CreateBrandLogoBitmap(52);
        p.Controls.Add(logo);

        Label title = new Label();
        title.Text = "Maskerade";
        title.ForeColor = Color.White;
        title.BackColor = SurfaceColor;
        title.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        title.SetBounds(70, 10, 140, 28);
        p.Controls.Add(title);

        versionLabel = new Label();
        versionLabel.ForeColor = MutedTextColor;
        versionLabel.BackColor = SurfaceColor;
        versionLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        versionLabel.AutoEllipsis = true;
        versionLabel.SetBounds(70, 41, 48, 18);
        versionLabel.Text = "v...";
        p.Controls.Add(versionLabel);

        updateButton = new PreviewNavButton("Actualizar");
        updateButton.SetBounds(122, 38, 78, 22);
        updateButton.BackColor = SurfaceColor;
        updateButton.ForeColor = TextColor;
        updateButton.Font = new Font("Segoe UI", 7.2F, FontStyle.Bold);
        updateButton.Click += delegate { CheckForOnlineUpdate(); };
        p.Controls.Add(updateButton);
        return p;
    }

    private Control BuildHarmonizeCard()
    {
        Panel p = DarkPanel();
        AddDarkLabel(p, "Harmonize", 12, true);
        AddDarkTitleRule(p);
        Label title = AddDarkLabel(p, "Integracion escena", 54, false);
        title.Height = 20;
        harmonizeSlider = new FlatSlider();
        harmonizeSlider.Minimum = 0;
        harmonizeSlider.Maximum = 200;
        harmonizeSlider.Step = 5;
        harmonizeSlider.SetBounds(10, 69, 186, 34);
        harmonizeSlider.ValueChanged += delegate
        {
            UpdateHarmonizeLabel();
            SetStateValueLocal("harmonize_strength", harmonizeSlider.Value.ToString());
            QueueLivePreview();
        };
        harmonizeSlider.ValueCommitted += delegate { CommitHarmonize(); };
        p.Controls.Add(harmonizeSlider);

        harmonizeValueLabel = AddDarkLabel(p, "", 105, false);
        harmonizeValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        harmonizeValueLabel.ForeColor = Color.White;
        harmonizeValueLabel.Height = 24;

        Label enhanceTitle = AddDarkLabel(p, "Mejora foto", 140, false);
        enhanceTitle.Height = 20;
        photoEnhanceAutoTuneButton = RoundSmallButton("Auto OFF");
        photoEnhanceAutoTuneButton.SetBounds(10, 161, 88, 22);
        photoEnhanceAutoTuneButton.Font = new Font("Segoe UI", 7.6F, FontStyle.Bold);
        photoEnhanceAutoTuneButton.Click += delegate { TogglePhotoEnhanceAutoTune(); };
        p.Controls.Add(photoEnhanceAutoTuneButton);
        photoEnhanceAutoTuneButton.BringToFront();

        photoEnhanceConfigButton = RoundSmallButton("Ajustes");
        photoEnhanceConfigButton.SetBounds(108, 161, 88, 22);
        photoEnhanceConfigButton.BackColor = SurfaceColor;
        photoEnhanceConfigButton.ForeColor = Color.White;
        photoEnhanceConfigButton.FlatAppearance.BorderColor = BorderColor;
        photoEnhanceConfigButton.FlatAppearance.BorderSize = 1;
        photoEnhanceConfigButton.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold);
        photoEnhanceConfigButton.Click += delegate { OpenPhotoEnhanceConfig(); };
        p.Controls.Add(photoEnhanceConfigButton);
        photoEnhanceConfigButton.BringToFront();

        photoEnhanceSlider = new FlatSlider();
        photoEnhanceSlider.Minimum = 0;
        photoEnhanceSlider.Maximum = 200;
        photoEnhanceSlider.Step = 5;
        photoEnhanceSlider.SetBounds(10, 187, 186, 34);
        photoEnhanceSlider.ValueChanged += delegate
        {
            UpdatePhotoEnhanceLabel();
            SetStateValueLocal("photo_enhance_strength", photoEnhanceSlider.Value.ToString());
            QueueLivePreview();
        };
        photoEnhanceSlider.ValueCommitted += delegate { CommitPhotoEnhance(); };
        p.Controls.Add(photoEnhanceSlider);

        photoEnhanceValueLabel = AddDarkLabel(p, "", 220, false);
        photoEnhanceValueLabel.Font = new Font("Segoe UI", 9.5F, FontStyle.Bold);
        photoEnhanceValueLabel.ForeColor = Color.White;
        photoEnhanceValueLabel.Height = 28;
        return p;
    }

    private void CheckForUpdatesLegacyStub()
    {
        if (logBox != null)
        {
            AddLog("Actualizador no configurado en esta version local.");
        }
        if (progressLabel != null)
        {
            progressLabel.Text = "Actualizador no configurado.";
        }
    }

    private Control BuildShadowCard()
    {
        Panel p = DarkPanel();
        AddDarkLabel(p, "Sombra contacto", 12, true);
        AddDarkTitleRule(p);
        Label title = AddDarkLabel(p, "Intensidad suelo", 56, false);
        title.Height = 20;

        shadowSlider = new FlatSlider();
        shadowSlider.Minimum = 0;
        shadowSlider.Maximum = 200;
        shadowSlider.Step = 5;
        shadowSlider.SetBounds(10, 72, 186, 36);
        shadowSlider.ValueChanged += delegate
        {
            UpdateShadowLabel();
            SetStateValueLocal("contact_shadow_strength", shadowSlider.Value.ToString());
        };
        shadowSlider.ValueCommitted += delegate { CommitShadow(); };
        p.Controls.Add(shadowSlider);

        shadowValueLabel = AddDarkLabel(p, "", 114, false);
        shadowValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        shadowValueLabel.ForeColor = Color.White;
        shadowValueLabel.Height = 24;
        return p;
    }

    private Control BuildEngineCard()
    {
        TableLayoutPanel stack = new TableLayoutPanel();
        stack.Dock = DockStyle.Fill;
        stack.BackColor = PageColor;
        stack.RowCount = 2;
        stack.ColumnCount = 1;
        stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 154F));
        stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 244F));

        Panel maskCard = EngineGroupPanel("Mascara");
        Label maskTitle = AddDarkLabel(maskCard, "Cerrar huecos + fantasmas", 48, false);
        maskTitle.Height = 20;
        maskProtectionSlider = new FlatSlider();
        maskProtectionSlider.Minimum = 0;
        maskProtectionSlider.Maximum = 100;
        maskProtectionSlider.Step = 1;
        maskProtectionSlider.SetBounds(10, 64, 186, 36);
        maskProtectionSlider.ValueChanged += delegate
        {
            SyncMaskRepairSliders(maskProtectionSlider.Value);
            UpdateMaskProtectionLabel();
            SetStateValueLocal("mask_protection", maskProtectionSlider.Value.ToString());
            SetStateValueLocal("mask_antighost", maskProtectionSlider.Value.ToString());
        };
        maskProtectionSlider.ValueCommitted += delegate { CommitMaskProtection(); };
        maskCard.Controls.Add(maskProtectionSlider);

        maskProtectionValueLabel = AddDarkLabel(maskCard, "", 104, false);
        maskProtectionValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        maskProtectionValueLabel.ForeColor = Color.White;
        maskProtectionValueLabel.Height = 26;

        maskAntighostSlider = maskProtectionSlider;
        maskAntighostValueLabel = null;
        stack.Controls.Add(maskCard, 0, 0);

        Panel peopleCard = EngineGroupPanel("Personas");
        Label zoomTitle = AddDarkLabel(peopleCard, "Zoom personas", 56, false);
        zoomTitle.Height = 20;
        photoZoomSlider = new FlatSlider();
        photoZoomSlider.Minimum = 50;
        photoZoomSlider.Maximum = 160;
        photoZoomSlider.Step = 5;
        photoZoomSlider.SetBounds(10, 72, 186, 36);
        photoZoomSlider.ValueChanged += delegate
        {
            UpdatePhotoZoomLabel();
            SetStateValueLocal("person_zoom", photoZoomSlider.Value.ToString());
            QueueLivePreview();
        };
        photoZoomSlider.ValueCommitted += delegate { CommitPhotoZoom(); };
        peopleCard.Controls.Add(photoZoomSlider);

        photoZoomValueLabel = AddDarkLabel(peopleCard, "", 112, false);
        photoZoomValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        photoZoomValueLabel.ForeColor = Color.White;
        photoZoomValueLabel.Height = 24;

        Label verticalTitle = AddDarkLabel(peopleCard, "Altura personas", 138, false);
        verticalTitle.Height = 20;
        personVerticalSlider = new FlatSlider();
        personVerticalSlider.Minimum = -25;
        personVerticalSlider.Maximum = 25;
        personVerticalSlider.Step = 1;
        personVerticalSlider.SetBounds(10, 154, 186, 36);
        personVerticalSlider.ValueChanged += delegate
        {
            UpdatePersonVerticalLabel();
            SetStateValueLocal("person_vertical", personVerticalSlider.Value.ToString());
            QueueLivePreview();
        };
        personVerticalSlider.ValueCommitted += delegate { CommitPersonVertical(); };
        peopleCard.Controls.Add(personVerticalSlider);

        personVerticalValueLabel = AddDarkLabel(peopleCard, "", 194, false);
        personVerticalValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        personVerticalValueLabel.ForeColor = Color.White;
        personVerticalValueLabel.Height = 24;
        stack.Controls.Add(peopleCard, 0, 1);

        return stack;
    }

    private Panel EngineGroupPanel(string title)
    {
        Panel p = DarkPanel();
        p.Margin = new Padding(0, 0, 0, 10);
        AddDarkLabel(p, title, 10, true);
        AddDarkTitleRule(p);
        return p;
    }

    private Control BuildOperationCard()
    {
        Panel p = DarkPanel();
        AddDarkLabel(p, "Operacion", 12, true);
        AddDarkTitleRule(p);
        Label qualityTitle = AddDarkLabel(p, "Calidad JPG", 56, false);
        qualityTitle.Height = 20;
        qualitySlider = new FlatSlider();
        qualitySlider.Minimum = 70;
        qualitySlider.Maximum = 100;
        qualitySlider.Step = 1;
        qualitySlider.SetBounds(10, 72, 186, 36);
        qualitySlider.ValueChanged += delegate { UpdateQualityLabel(); };
        qualitySlider.ValueCommitted += delegate { CommitQuality(); };
        p.Controls.Add(qualitySlider);

        qualityValueLabel = AddDarkLabel(p, "", 114, false);
        qualityValueLabel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        qualityValueLabel.ForeColor = Color.White;
        qualityValueLabel.Height = 26;
        return p;
    }

    private Control BuildContent()
    {
        TableLayoutPanel content = new TableLayoutPanel();
        content.Dock = DockStyle.Fill;
        content.BackColor = PageColor;
        content.Padding = new Padding(18, 12, 18, 16);
        content.RowCount = 1;
        content.ColumnCount = 1;
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

        content.Controls.Add(BuildBody(), 0, 0);
        return content;
    }

    private void BuildProgressTimer()
    {
        progressTimer = new System.Windows.Forms.Timer();
        progressTimer.Interval = 700;
        progressTimer.Tick += delegate { UpdateProgressEstimate(); };
    }

    private void BuildPreviewTimer()
    {
        previewTimer = new System.Windows.Forms.Timer();
        previewTimer.Interval = 350;
        previewTimer.Tick += delegate
        {
            previewTimer.Stop();
            DrawPreview();
        };
    }

    private void BuildLivePreviewTimer()
    {
        livePreviewTimer = new System.Windows.Forms.Timer();
        livePreviewTimer.Interval = 220;
        livePreviewTimer.Tick += delegate
        {
            livePreviewTimer.Stop();
            if (!livePreviewPending) return;
            livePreviewPending = false;
            if (!overlayDragging) livePreviewFast = false;
            DrawScenePreviewImmediate();
        };
    }

    private Control BuildTopbar()
    {
        TableLayoutPanel top = new TableLayoutPanel();
        top.Dock = DockStyle.Fill;
        top.ColumnCount = 7;
        top.RowCount = 1;
        top.BackColor = PageColor;
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 134F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 142F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 122F));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 4F));

        top.Controls.Add(BuildTopProgressPanel(), 0, 0);

        Button one = TopButton("Probar 1 foto");
        one.Dock = DockStyle.Fill;
        one.Margin = new Padding(6, 10, 6, 10);
        one.Click += delegate { RunProcess(true); };
        top.Controls.Add(one, 1, 0);

        batchProcessButton = TopButton("Procesar lote");
        batchProcessButton.Dock = DockStyle.Fill;
        batchProcessButton.Margin = new Padding(6, 10, 6, 10);
        batchProcessButton.Click += delegate { RunProcess(false); };
        top.Controls.Add(batchProcessButton, 2, 0);

        hotfolderButton = TopButton("Hotfolder OFF");
        hotfolderButton.Dock = DockStyle.Fill;
        hotfolderButton.Margin = new Padding(6, 10, 6, 10);
        hotfolderButton.Click += delegate { ToggleHotfolder(); };
        top.Controls.Add(hotfolderButton, 3, 0);

        nuvolButton = TopButton("Nuvol OFF");
        nuvolButton.Dock = DockStyle.Fill;
        nuvolButton.Margin = new Padding(6, 10, 6, 10);
        nuvolButton.Click += delegate { ToggleNuvol(); };
        top.Controls.Add(nuvolButton, 4, 0);

        Button openOut = TopButton("Abrir OUT");
        openOut.Dock = DockStyle.Fill;
        openOut.Margin = new Padding(6, 10, 6, 10);
        openOut.Click += delegate { OpenFolder(Value("output_abs")); };
        top.Controls.Add(openOut, 5, 0);
        return top;
    }

    private Control BuildTopProgressPanel()
    {
        Panel panel = new Panel();
        panel.Dock = DockStyle.Fill;
        panel.Margin = new Padding(0, 0, 0, 8);
        panel.BackColor = SurfaceColor;
        panel.BorderStyle = BorderStyle.None;
        ApplyRoundedPanel(panel, 10);

        Label title = new Label();
        title.Text = "Progreso";
        title.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        title.ForeColor = TextColor;
        title.BackColor = SurfaceColor;
        title.SetBounds(12, 7, 70, 18);
        panel.Controls.Add(title);

        progressLabel = new Label();
        progressLabel.Text = "Sin proceso activo.";
        progressLabel.ForeColor = MutedTextColor;
        progressLabel.BackColor = SurfaceColor;
        progressLabel.AutoEllipsis = true;
        progressLabel.SetBounds(12, 30, 240, 18);
        panel.Controls.Add(progressLabel);

        batchProgress = new FlatProgressBar();
        batchProgress.Minimum = 0;
        batchProgress.Maximum = 100;
        batchProgress.Value = 0;
        batchProgress.SetBounds(12, 58, 240, 14);
        panel.Controls.Add(batchProgress);

        stopButton = AbortButton();
        stopButton.Enabled = false;
        stopButton.Click += delegate { StopCurrentWork(); };
        panel.Controls.Add(stopButton);

        panel.Resize += delegate
        {
            int abortWidth = stopButton != null && stopButton.Visible ? 86 : 0;
            int right = panel.ClientSize.Width - 12;
            if (stopButton != null && stopButton.Visible)
            {
                stopButton.SetBounds(Math.Max(12, right - abortWidth), 8, abortWidth, 24);
            }
            int available = Math.Max(80, panel.ClientSize.Width - 24);
            progressLabel.SetBounds(12, 36, available, 18);
            batchProgress.SetBounds(12, 62, available, 14);
        };

        return panel;
    }

    private Control BuildBody()
    {
        TableLayoutPanel body = new TableLayoutPanel();
        body.Dock = DockStyle.Fill;
        body.BackColor = PageColor;
        body.ColumnCount = 2;
        body.RowCount = 1;
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 306F));
        body.Controls.Add(BuildCenter(), 0, 0);
        body.Controls.Add(BuildRight(), 1, 0);
        return body;
    }

    private Control BuildCenter()
    {
        TableLayoutPanel center = new TableLayoutPanel();
        centerLayoutPanel = center;
        center.Dock = DockStyle.Fill;
        center.BackColor = PageColor;
        center.RowCount = 3;
        center.ColumnCount = 1;
        center.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
        center.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
        center.RowStyles.Add(new RowStyle(SizeType.Percent, 30F));

        Panel previewCard = Card();
        previewCard.Padding = new Padding(14, 48, 14, 14);
        previewCard.Dock = DockStyle.Fill;
        AddCardTitle(previewCard, "Preview final");
        TableLayoutPanel previewLayout = new TableLayoutPanel();
        previewLayout.Dock = DockStyle.Fill;
        previewLayout.BackColor = SurfaceColor;
        previewLayout.ColumnCount = 1;
        previewLayout.RowCount = 2;
        previewLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        previewLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
        previewBox = new PictureBox();
        previewBox.Dock = DockStyle.Fill;
        previewBox.BackColor = dark;
        previewBox.SizeMode = PictureBoxSizeMode.Zoom;
        previewBox.Cursor = Cursors.Hand;
        previewBox.MouseDown += PreviewBox_MouseDown;
        previewBox.MouseMove += PreviewBox_MouseMove;
        previewBox.MouseUp += PreviewBox_MouseUp;
        previewLayout.Controls.Add(previewBox, 0, 0);
        previewLayout.Controls.Add(BuildPreviewNavigationBar(), 0, 1);
        previewCard.Controls.Add(previewLayout);
        center.Controls.Add(previewCard, 0, 0);

        centerSplitterPanel = BuildCenterSplitter();
        center.Controls.Add(centerSplitterPanel, 0, 1);

        Panel assetsCard = Card();
        assetsCard.Padding = new Padding(14, 48, 14, 14);
        assetsCard.Dock = DockStyle.Fill;
        AddCardTitle(assetsCard, "Capas");

        TableLayoutPanel assetsGrid = new TableLayoutPanel();
        assetsGrid.Dock = DockStyle.Fill;
        assetsGrid.ColumnCount = 3;
        assetsGrid.RowCount = 1;
        assetsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.34F));
        assetsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
        assetsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33F));
        backgroundsPanel = AssetPanel();
        overlaysPanel = AssetPanel();
        logosPanel = AssetPanel();
        assetsGrid.Controls.Add(backgroundsPanel, 0, 0);
        assetsGrid.Controls.Add(overlaysPanel, 1, 0);
        assetsGrid.Controls.Add(logosPanel, 2, 0);
        assetsCard.Controls.Add(assetsGrid);
        center.Controls.Add(assetsCard, 0, 2);
        center.Resize += delegate
        {
            AdjustCenterLayout();
        };
        previewCard.Resize += delegate
        {
            QueueLivePreviewAfterResize();
        };
        center.HandleCreated += delegate { AdjustCenterLayout(); };
        return center;
    }

    private Control BuildPreviewNavigationBar()
    {
        TableLayoutPanel nav = new TableLayoutPanel();
        nav.Dock = DockStyle.Fill;
        nav.BackColor = SurfaceColor;
        nav.ColumnCount = 3;
        nav.RowCount = 1;
        nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
        nav.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        nav.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40F));
        nav.Padding = new Padding(0, 3, 0, 2);

        previewPrevButton = new PreviewNavButton("<");
        previewPrevButton.Dock = DockStyle.Fill;
        previewPrevButton.Margin = new Padding(0, 0, 8, 0);
        previewPrevButton.Click += delegate { NavigatePreviewPhoto(-1); };
        nav.Controls.Add(previewPrevButton, 0, 0);

        previewPhotoLabel = new Label();
        previewPhotoLabel.Dock = DockStyle.Fill;
        previewPhotoLabel.Text = "Sin fotos en IN";
        previewPhotoLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        previewPhotoLabel.ForeColor = MutedTextColor;
        previewPhotoLabel.BackColor = SurfaceColor;
        previewPhotoLabel.TextAlign = ContentAlignment.MiddleCenter;
        previewPhotoLabel.AutoEllipsis = true;
        nav.Controls.Add(previewPhotoLabel, 1, 0);

        previewNextButton = new PreviewNavButton(">");
        previewNextButton.Dock = DockStyle.Fill;
        previewNextButton.Margin = new Padding(8, 0, 0, 0);
        previewNextButton.Click += delegate { NavigatePreviewPhoto(1); };
        nav.Controls.Add(previewNextButton, 2, 0);

        return nav;
    }

    private Panel BuildCenterSplitter()
    {
        Panel splitter = new Panel();
        splitter.Dock = DockStyle.Fill;
        splitter.Margin = new Padding(0, 0, 0, 0);
        splitter.BackColor = PageColor;
        splitter.Cursor = Cursors.HSplit;
        splitter.MouseDown += CenterSplitter_MouseDown;
        splitter.MouseMove += CenterSplitter_MouseMove;
        splitter.MouseUp += CenterSplitter_MouseUp;
        splitter.Paint += delegate(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            int y = Math.Max(1, splitter.Height / 2);
            Rectangle fullBar = new Rectangle(12, y - 1, Math.Max(1, splitter.Width - 24), 2);
            using (SolidBrush bar = new SolidBrush(BorderColor))
            using (GraphicsPath path = RoundedRect(fullBar, 1))
            {
                e.Graphics.FillPath(bar, path);
            }

            Rectangle handle = new Rectangle(Math.Max(0, splitter.Width / 2 - 56), y - 3, 112, 6);
            using (GraphicsPath path = RoundedRect(handle, 3))
            using (LinearGradientBrush brush = new LinearGradientBrush(handle, azure, magenta, LinearGradientMode.Horizontal))
            {
                e.Graphics.FillPath(brush, path);
            }
        };
        return splitter;
    }

    private void AddTextLayerControls(Panel parent)
    {
        EventHandler refreshTextLayerLayout = null;

        Label label = new Label();
        label.Text = "Introducir texto";
        label.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        label.ForeColor = MutedTextColor;
        label.BackColor = SurfaceColor;
        label.TextAlign = ContentAlignment.MiddleLeft;
        parent.Controls.Add(label);
        label.BringToFront();

        textLayerBox = new TextBox();
        StyleTextBox(textLayerBox);
        textLayerBox.BorderStyle = BorderStyle.FixedSingle;
        textLayerBox.AutoSize = false;
        textLayerBox.MinimumSize = Size.Empty;
        textLayerBox.Font = new Font("Segoe UI", 8F);
        textLayerBox.Height = 20;
        textLayerBox.BackColor = SubsurfaceColor;
        textLayerBox.ForeColor = TextColor;
        textLayerBox.TextChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            SetStateValueLocal("text_layer", textLayerBox.Text);
            if (refreshTextLayerLayout != null) refreshTextLayerLayout(parent, EventArgs.Empty);
            QueueLivePreview();
        };
        textLayerBox.Leave += delegate { CommitTextLayer(); };
        textLayerBox.KeyDown += delegate(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            CommitTextLayer();
            e.SuppressKeyPress = true;
        };
        parent.Controls.Add(textLayerBox);
        textLayerBox.BringToFront();

        Button clearTextButton = Button("Sin texto");
        clearTextButton.Click += delegate
        {
            if (textLayerBox.Text.Length == 0)
            {
                SaveSimple("text_layer", "", false);
                SetStateValueLocal("text_layer", "");
                QueueLivePreview();
                return;
            }
            textLayerBox.Text = "";
            SaveSimple("text_layer", "", false);
            SetStateValueLocal("text_layer", "");
            if (refreshTextLayerLayout != null) refreshTextLayerLayout(parent, EventArgs.Empty);
            QueueLivePreview();
        };
        parent.Controls.Add(clearTextButton);
        clearTextButton.BringToFront();

        Label fontLabel = new Label();
        fontLabel.Text = "Fuente";
        fontLabel.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        fontLabel.ForeColor = MutedTextColor;
        fontLabel.BackColor = SurfaceColor;
        fontLabel.TextAlign = ContentAlignment.MiddleLeft;
        parent.Controls.Add(fontLabel);
        fontLabel.BringToFront();

        textLayerFontCombo = new ComboBox();
        StyleComboBox(textLayerFontCombo);
        textLayerFontCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        textLayerFontCombo.Items.AddRange(new string[] { "Segoe UI", "Arial", "Calibri", "Impact", "Times New Roman", "Georgia", "Verdana", "Tahoma", "Courier New", "Comic Sans MS", "Bahnschrift" });
        textLayerFontCombo.SelectedIndexChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            string font = TextLayerFontName();
            SetStateValueLocal("text_layer_font", font);
            SaveSimple("text_layer_font", font, false);
            QueueLivePreview();
        };
        parent.Controls.Add(textLayerFontCombo);
        textLayerFontCombo.BringToFront();

        Label colorLabel = new Label();
        colorLabel.Text = "Color";
        colorLabel.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        colorLabel.ForeColor = MutedTextColor;
        colorLabel.BackColor = SurfaceColor;
        colorLabel.TextAlign = ContentAlignment.MiddleLeft;
        parent.Controls.Add(colorLabel);
        colorLabel.BringToFront();

        textLayerColorCombo = new ComboBox();
        StyleComboBox(textLayerColorCombo);
        textLayerColorCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        textLayerColorCombo.Items.AddRange(new string[] { "Blanco", "Negro", "Amarillo", "Naranja", "Rojo", "Rosa", "Azul", "Verde" });
        textLayerColorCombo.SelectedIndexChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            string color = TextLayerColorValue();
            SetStateValueLocal("text_layer_color", color);
            SaveSimple("text_layer_color", color, false);
            QueueLivePreview();
        };
        parent.Controls.Add(textLayerColorCombo);
        textLayerColorCombo.BringToFront();

        textLayerScaleLabel = new Label();
        textLayerScaleLabel.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        textLayerScaleLabel.ForeColor = MutedTextColor;
        textLayerScaleLabel.BackColor = SurfaceColor;
        textLayerScaleLabel.TextAlign = ContentAlignment.MiddleLeft;
        parent.Controls.Add(textLayerScaleLabel);
        textLayerScaleLabel.BringToFront();

        textLayerScaleSlider = new FlatSlider();
        textLayerScaleSlider.Minimum = 30;
        textLayerScaleSlider.Maximum = 300;
        textLayerScaleSlider.Step = 5;
        textLayerScaleSlider.Value = 100;
        textLayerScaleSlider.ValueChanged += delegate
        {
            UpdateTextLayerControlLabels();
            SetStateValueLocal("text_layer_scale", TextLayerScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
            QueueLivePreview();
        };
        textLayerScaleSlider.ValueCommitted += delegate { CommitTextLayerTransform(); };
        parent.Controls.Add(textLayerScaleSlider);
        textLayerScaleSlider.BringToFront();

        textLayerRotationLabel = new Label();
        textLayerRotationLabel.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        textLayerRotationLabel.ForeColor = MutedTextColor;
        textLayerRotationLabel.BackColor = SurfaceColor;
        textLayerRotationLabel.TextAlign = ContentAlignment.MiddleLeft;
        parent.Controls.Add(textLayerRotationLabel);
        textLayerRotationLabel.BringToFront();

        textLayerRotationSlider = new FlatSlider();
        textLayerRotationSlider.Minimum = -180;
        textLayerRotationSlider.Maximum = 180;
        textLayerRotationSlider.Step = 5;
        textLayerRotationSlider.Value = 0;
        textLayerRotationSlider.ValueChanged += delegate
        {
            UpdateTextLayerControlLabels();
            SetStateValueLocal("text_layer_rotation", textLayerRotationSlider.Value.ToString());
            QueueLivePreview();
        };
        textLayerRotationSlider.ValueCommitted += delegate { CommitTextLayerTransform(); };
        parent.Controls.Add(textLayerRotationSlider);
        textLayerRotationSlider.BringToFront();

        refreshTextLayerLayout = delegate
        {
            int groupWidth = Math.Max(620, Math.Min(920, parent.ClientSize.Width - 220));
            int left = Math.Max(88, (parent.ClientSize.Width - groupWidth) / 2);
            int top = 10;
            int boxWidth = TextLayerInputWidth();
            int clearWidth = 82;
            int clearGap = 8;
            int topGroupWidth = 112 + boxWidth + clearGap + clearWidth;
            int boxLeft = left + (groupWidth - topGroupWidth) / 2 + 112;
            label.SetBounds(boxLeft - 112, top, 104, 24);
            textLayerBox.SetBounds(boxLeft, top + 4, boxWidth, 20);
            clearTextButton.SetBounds(boxLeft + boxWidth + clearGap, top + 1, clearWidth, 26);

            int rowY = 42;
            int x = left;
            fontLabel.SetBounds(x, rowY, 48, 22);
            x += 52;
            textLayerFontCombo.SetBounds(x, rowY - 1, 128, 24);
            x += 140;
            colorLabel.SetBounds(x, rowY, 40, 22);
            x += 44;
            textLayerColorCombo.SetBounds(x, rowY - 1, 110, 24);
            x += 126;
            textLayerScaleLabel.SetBounds(x, rowY, 74, 22);
            x += 76;
            textLayerScaleSlider.SetBounds(x, rowY - 5, Math.Max(120, (groupWidth - (x - left) - 230) / 2), 30);
            x += textLayerScaleSlider.Width + 18;
            textLayerRotationLabel.SetBounds(x, rowY, 88, 22);
            x += 90;
            textLayerRotationSlider.SetBounds(x, rowY - 5, Math.Max(120, left + groupWidth - x), 30);
        };
        parent.Resize += refreshTextLayerLayout;
        parent.HandleCreated += refreshTextLayerLayout;
    }

    private int TextLayerInputWidth()
    {
        if (textLayerBox == null) return 90;
        string text = String.IsNullOrEmpty(textLayerBox.Text) ? "Texto" : textLayerBox.Text;
        int measured = TextRenderer.MeasureText(text, textLayerBox.Font).Width + 14;
        return Math.Max(64, Math.Min(220, measured));
    }

    private void CenterSplitter_MouseDown(object sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left || centerLayoutPanel == null) return;
        centerSplitterDragging = true;
        centerSplitterPanel.Capture = true;
        centerSplitterStartMouseY = centerLayoutPanel.PointToClient(Cursor.Position).Y;
        centerSplitterStartPreviewHeight = centerLayoutPanel.RowStyles.Count > 0 ? (int)Math.Round(centerLayoutPanel.RowStyles[0].Height) : 0;
    }

    private void CenterSplitter_MouseMove(object sender, MouseEventArgs e)
    {
        if (centerSplitterPanel != null) centerSplitterPanel.Cursor = Cursors.HSplit;
        if (!centerSplitterDragging || centerLayoutPanel == null) return;
        int currentY = centerLayoutPanel.PointToClient(Cursor.Position).Y;
        int next = centerSplitterStartPreviewHeight + (currentY - centerSplitterStartMouseY);
        SetManualPreviewHeight(next);
    }

    private void CenterSplitter_MouseUp(object sender, MouseEventArgs e)
    {
        centerSplitterDragging = false;
        if (centerSplitterPanel != null) centerSplitterPanel.Capture = false;
    }

    private void SetManualPreviewHeight(int previewHeight)
    {
        manualPreviewHeight = previewHeight;
        AdjustCenterLayout();
        QueueLivePreview();
    }

    private void AdjustCenterLayout()
    {
        if (adjustingCenterLayout || centerLayoutPanel == null || centerLayoutPanel.RowStyles.Count < 3) return;
        int availableHeight = centerLayoutPanel.ClientSize.Height;
        int availableWidth = centerLayoutPanel.ClientSize.Width;
        if (availableHeight <= 0 || availableWidth <= 0) return;

        adjustingCenterLayout = true;
        try
        {
            Size sceneSize = CurrentPreviewLayoutSize();
            if (sceneSize.Width <= 0 || sceneSize.Height <= 0) sceneSize = new Size(1600, 900);

            int innerWidth = Math.Max(320, availableWidth - 28);
            int splitterHeight = 18;
            int panelHeight = Math.Max(1, availableHeight - splitterHeight);
            double aspect = Math.Max(0.25, Math.Min(4.0, (double)sceneSize.Height / Math.Max(1, sceneSize.Width)));
            int usefulPreviewHeight = (int)Math.Ceiling(innerWidth * aspect) + 78;

            int minLayersHeight = Math.Min(430, Math.Max(260, (int)Math.Round(panelHeight * 0.30)));
            int minPreviewHeight = Math.Min(560, Math.Max(260, (int)Math.Round(panelHeight * 0.28)));
            int maxPreviewHeight = Math.Max(minPreviewHeight, panelHeight - minLayersHeight);
            int previewHeight = manualPreviewHeight > 0
                ? Math.Max(minPreviewHeight, Math.Min(manualPreviewHeight, maxPreviewHeight))
                : Math.Max(minPreviewHeight, Math.Min(usefulPreviewHeight, maxPreviewHeight));
            if (manualPreviewHeight > 0) manualPreviewHeight = previewHeight;
            int layersHeight = Math.Max(220, panelHeight - previewHeight);

            centerLayoutPanel.SuspendLayout();
            centerLayoutPanel.RowStyles[0].SizeType = SizeType.Absolute;
            centerLayoutPanel.RowStyles[0].Height = previewHeight;
            centerLayoutPanel.RowStyles[1].SizeType = SizeType.Absolute;
            centerLayoutPanel.RowStyles[1].Height = splitterHeight;
            centerLayoutPanel.RowStyles[2].SizeType = SizeType.Absolute;
            centerLayoutPanel.RowStyles[2].Height = layersHeight;
            centerLayoutPanel.ResumeLayout();
        }
        finally
        {
            adjustingCenterLayout = false;
        }
    }

    private Size CurrentPreviewLayoutSize()
    {
        Size baseSize = CurrentPreviewBaseSize();
        if (!baseSize.IsEmpty) return baseSize;
        if (!lastScenePreviewRect.Size.IsEmpty) return lastScenePreviewRect.Size;
        return new Size(1600, 900);
    }

    private Control BuildRight()
    {
        Panel scroller = new Panel();
        scroller.Dock = DockStyle.Fill;
        scroller.BackColor = PageColor;
        scroller.AutoScroll = true;
        ApplyDarkScrollbarTheme(scroller);

        TableLayoutPanel right = new TableLayoutPanel();
        right.Dock = DockStyle.Top;
        right.AutoSize = true;
        right.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        right.BackColor = PageColor;
        right.Padding = new Padding(10, 0, 0, 0);
        right.RowCount = 7;
        right.ColumnCount = 1;
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 204F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 208F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 92F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 306F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 286F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 620F));
        right.RowStyles.Add(new RowStyle(SizeType.Absolute, 174F));

        right.Controls.Add(BuildActionsCard(), 0, 0);

        Panel feed = Card();
        feed.Padding = new Padding(16, 46, 16, 14);
        AddCardTitle(feed, "Alimentar IN");
        TableLayoutPanel feedGrid = new TableLayoutPanel();
        feedGrid.Dock = DockStyle.Fill;
        feedGrid.RowCount = 3;
        feedGrid.ColumnCount = 1;
        feedGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 34F));
        feedGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
        feedGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 33F));
        feedGrid.BackColor = SurfaceColor;
        Button addPhotos = AccentButton("Anadir JPG");
        addPhotos.Dock = DockStyle.Fill;
        addPhotos.Margin = new Padding(0, 0, 0, 5);
        addPhotos.Click += delegate { AddPhotos(); };
        feedGrid.Controls.Add(addPhotos, 0, 0);
        Button openIn = Button("Abrir IN");
        openIn.Dock = DockStyle.Fill;
        openIn.Margin = new Padding(0, 3, 0, 3);
        openIn.Click += delegate { OpenFolder(Value("input_abs")); };
        feedGrid.Controls.Add(openIn, 0, 1);
        Button openOut = Button("Abrir OUT");
        openOut.Dock = DockStyle.Fill;
        openOut.Margin = new Padding(0, 5, 0, 0);
        openOut.Click += delegate { OpenFolder(Value("output_abs")); };
        feedGrid.Controls.Add(openOut, 0, 2);
        feed.Controls.Add(feedGrid);

        Panel logs = Card();
        logs.Padding = new Padding(16, 48, 16, 16);
        AddCardTitle(logs, "Ultima ejecucion");
        logBox = new TextBox();
        logBox.Dock = DockStyle.Fill;
        logBox.Multiline = true;
        logBox.ReadOnly = true;
        logBox.WordWrap = true;
        logBox.ScrollBars = ScrollBars.Vertical;
        logBox.BackColor = dark;
        logBox.ForeColor = Color.White;
        logBox.BorderStyle = BorderStyle.None;
        logBox.Font = new Font("Consolas", 8F);
        logBox.Margin = new Padding(0);
        logs.Controls.Add(logBox);
        right.Controls.Add(logs, 0, 1);

        right.Controls.Add(BuildTopProgressPanel(), 0, 2);

        Panel presets = Card();
        presets.Padding = new Padding(16, 40, 16, 8);
        AddCardTitle(presets, "Presets");
        TableLayoutPanel presetGrid = new TableLayoutPanel();
        presetGrid.Dock = DockStyle.Fill;
        presetGrid.RowCount = 7;
        presetGrid.ColumnCount = 1;
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 34F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 22F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        presetGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
        presetGrid.BackColor = SurfaceColor;

        presetNameBox = new TextBox();
        StyleTextBox(presetNameBox);
        Control presetNameHost = BuildCompactTextHost(presetNameBox);
        presetNameHost.Margin = new Padding(0, 0, 0, 8);
        presetGrid.Controls.Add(presetNameHost, 0, 0);

        presetCombo = new ComboBox();
        presetCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        StyleComboBox(presetCombo);
        Control presetComboHost = BuildCompactComboHost(presetCombo);
        presetComboHost.Margin = new Padding(0, 2, 0, 8);
        presetGrid.Controls.Add(presetComboHost, 0, 1);

        TableLayoutPanel presetButtons = new TableLayoutPanel();
        presetButtons.Dock = DockStyle.Fill;
        presetButtons.ColumnCount = 3;
        presetButtons.RowCount = 1;
        presetButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34F));
        presetButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33F));
        presetButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33F));
        Button savePreset = AccentButton("Guardar");
        savePreset.Dock = DockStyle.Fill;
        savePreset.Margin = new Padding(0, 2, 6, 2);
        savePreset.Click += delegate { SavePreset(); };
        presetButtons.Controls.Add(savePreset, 0, 0);
        Button applyPreset = Button("Aplicar");
        applyPreset.Dock = DockStyle.Fill;
        applyPreset.Margin = new Padding(3, 2, 3, 2);
        applyPreset.Click += delegate { ApplyPreset(); };
        presetButtons.Controls.Add(applyPreset, 1, 0);
        Button deletePreset = Button("Borrar");
        deletePreset.Dock = DockStyle.Fill;
        deletePreset.Margin = new Padding(6, 2, 0, 2);
        deletePreset.Click += delegate { DeletePreset(); };
        presetButtons.Controls.Add(deletePreset, 2, 0);
        presetGrid.Controls.Add(presetButtons, 0, 2);

        presetGrid.Controls.Add(BuildSectionLabel("Reglas carpetas"), 0, 3);

        folderRuleCombo = new ComboBox();
        folderRuleCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        StyleComboBox(folderRuleCombo);
        folderRuleCombo.SelectedIndexChanged += delegate { SelectFolderRuleFromList(); };
        Control folderRuleComboHost = BuildCompactComboHost(folderRuleCombo);
        folderRuleComboHost.Margin = new Padding(0, 2, 0, 8);
        presetGrid.Controls.Add(folderRuleComboHost, 0, 4);

        folderRulePatternBox = new TextBox();
        StyleTextBox(folderRulePatternBox);
        folderRulePatternBox.Text = "carla*";
        Control folderRulePatternHost = BuildCompactTextHost(folderRulePatternBox);
        folderRulePatternHost.Margin = new Padding(0, 0, 0, 8);
        presetGrid.Controls.Add(folderRulePatternHost, 0, 5);

        TableLayoutPanel folderRuleButtons = new TableLayoutPanel();
        folderRuleButtons.Dock = DockStyle.Fill;
        folderRuleButtons.ColumnCount = 2;
        folderRuleButtons.RowCount = 1;
        folderRuleButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        folderRuleButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
        Button saveFolderRule = AccentButton("Asociar");
        saveFolderRule.Dock = DockStyle.Fill;
        saveFolderRule.Margin = new Padding(0, 2, 4, 2);
        saveFolderRule.Click += delegate { SaveFolderRule(); };
        folderRuleButtons.Controls.Add(saveFolderRule, 0, 0);
        Button deleteFolderRule = Button("Quitar");
        deleteFolderRule.Dock = DockStyle.Fill;
        deleteFolderRule.Margin = new Padding(4, 2, 0, 2);
        deleteFolderRule.Click += delegate { DeleteFolderRule(); };
        folderRuleButtons.Controls.Add(deleteFolderRule, 1, 0);
        presetGrid.Controls.Add(folderRuleButtons, 0, 6);

        presets.Controls.Add(presetGrid);
        right.Controls.Add(presets, 0, 3);

        right.Controls.Add(BuildTextLayerCard(), 0, 4);

        Panel work = Card();
        work.Padding = new Padding(16, 42, 16, 10);
        AddCardTitle(work, "Trabajo");
        TableLayoutPanel workGrid = new TableLayoutPanel();
        workGrid.Dock = DockStyle.Fill;
        workGrid.RowCount = 14;
        workGrid.ColumnCount = 1;
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 46F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 62F));
        workGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, 62F));
        workGrid.BackColor = SurfaceColor;
        inputBox = new TextBox();
        outputBox = new TextBox();
        processedBox = new TextBox();
        nuvolModeCombo = new ComboBox();
        nuvolParkBox = new TextBox();
        nuvolUsernameBox = new TextBox();
        nuvolAuthUsernameBox = new TextBox();
        nuvolAuthPasswordBox = new TextBox();
        nuvolDownloadBox = new TextBox();
        backgroundBox = new TextBox();
        overlayBox = new TextBox();
        workGrid.Controls.Add(BuildSectionLabel("Carpetas"), 0, 0);
        workGrid.Controls.Add(BuildPathRow("IN", inputBox, delegate { SelectFolder("input", inputBox); }, delegate { OpenFolder(Value("input_abs")); }), 0, 1);
        workGrid.Controls.Add(BuildPathRow("OUT", outputBox, delegate { SelectFolder("output", outputBox); }, delegate { OpenFolder(Value("output_abs")); }), 0, 2);
        workGrid.Controls.Add(BuildPathRow("Procesadas", processedBox, delegate { SelectFolder("processed", processedBox); }, delegate { OpenFolder(Value("processed_abs")); }), 0, 3);
        workGrid.Controls.Add(BuildSectionLabel("Nuvol"), 0, 4);
        workGrid.Controls.Add(BuildNuvolModeRow(), 0, 5);
        workGrid.Controls.Add(BuildNuvolTextRow("Parque", nuvolParkBox), 0, 6);
        workGrid.Controls.Add(BuildNuvolTextRow("Destino", nuvolUsernameBox), 0, 7);
        workGrid.Controls.Add(BuildNuvolTextRow("Login", nuvolAuthUsernameBox), 0, 8);
        workGrid.Controls.Add(BuildNuvolTextRow("Clave", nuvolAuthPasswordBox), 0, 9);
        workGrid.Controls.Add(BuildPathRow("Descarga", nuvolDownloadBox, delegate { SelectFolder("nuvol_download_dir", nuvolDownloadBox); }, delegate { OpenFolder(Value("nuvol_download_dir")); }), 0, 10);
        workGrid.Controls.Add(BuildSectionLabel("Capas activas"), 0, 11);
        workGrid.Controls.Add(BuildActiveRow("Fondo", backgroundBox, out activeBackgroundNameLabel, delegate { SelectAssetFile("background"); }), 0, 12);
        workGrid.Controls.Add(BuildActiveRow("Overlay", overlayBox, out activeOverlayNameLabel, delegate { SelectAssetFile("overlay"); }), 0, 13);
        work.Controls.Add(workGrid);
        right.Controls.Add(work, 0, 5);
        right.Controls.Add(feed, 0, 6);
        scroller.Controls.Add(right);
        return scroller;
    }

    private Control BuildTextLayerCard()
    {
        Panel textCard = Card();
        textCard.Padding = new Padding(16, 46, 16, 14);
        AddCardTitle(textCard, "Texto");

        Panel body = new Panel();
        body.Dock = DockStyle.Fill;
        body.BackColor = SurfaceColor;
        textCard.Controls.Add(body);

        Label inputLabel = SmallLabel("Introducir texto", FontStyle.Bold);
        body.Controls.Add(inputLabel);

        textLayerBox = new TextBox();
        StyleTextBox(textLayerBox);
        textLayerBox.BorderStyle = BorderStyle.FixedSingle;
        textLayerBox.AutoSize = false;
        textLayerBox.MinimumSize = Size.Empty;
        textLayerBox.Font = new Font("Segoe UI", 8F);
        textLayerBox.Height = 22;
        textLayerBox.BackColor = SubsurfaceColor;
        textLayerBox.ForeColor = TextColor;
        textLayerBox.TextChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            SetStateValueLocal("text_layer", textLayerBox.Text);
            QueueLivePreview();
        };
        textLayerBox.Leave += delegate { CommitTextLayer(); };
        textLayerBox.KeyDown += delegate(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;
            CommitTextLayer();
            e.SuppressKeyPress = true;
        };
        Panel textLayerBoxHost = BuildRoundedInputHost(textLayerBox, false);
        body.Controls.Add(textLayerBoxHost);

        Button clearTextButton = Button("Sin texto");
        clearTextButton.Click += delegate
        {
            if (textLayerBox.Text.Length != 0) textLayerBox.Text = "";
            SaveSimple("text_layer", "", false);
            SetStateValueLocal("text_layer", "");
            QueueLivePreview();
        };
        body.Controls.Add(clearTextButton);

        Label fontLabel = SmallLabel("Fuente", FontStyle.Bold);
        body.Controls.Add(fontLabel);

        textLayerFontCombo = new ComboBox();
        StyleComboBox(textLayerFontCombo);
        textLayerFontCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        textLayerFontCombo.Items.AddRange(new string[] { "Segoe UI", "Arial", "Calibri", "Impact", "Times New Roman", "Georgia", "Verdana", "Tahoma", "Courier New", "Comic Sans MS", "Bahnschrift" });
        textLayerFontCombo.SelectedIndexChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            string font = TextLayerFontName();
            SetStateValueLocal("text_layer_font", font);
            SaveSimple("text_layer_font", font, false);
            QueueLivePreview();
        };
        Panel textLayerFontHost = BuildRoundedInputHost(textLayerFontCombo, true);
        body.Controls.Add(textLayerFontHost);

        Label colorLabel = SmallLabel("Color", FontStyle.Bold);
        body.Controls.Add(colorLabel);

        textLayerColorCombo = new ComboBox();
        StyleComboBox(textLayerColorCombo);
        textLayerColorCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        textLayerColorCombo.Items.AddRange(new string[] { "Blanco", "Negro", "Amarillo", "Naranja", "Rojo", "Rosa", "Azul", "Verde" });
        textLayerColorCombo.SelectedIndexChanged += delegate
        {
            if (suppressTextLayerEvents) return;
            string color = TextLayerColorValue();
            SetStateValueLocal("text_layer_color", color);
            SaveSimple("text_layer_color", color, false);
            QueueLivePreview();
        };
        Panel textLayerColorHost = BuildRoundedInputHost(textLayerColorCombo, true);
        body.Controls.Add(textLayerColorHost);

        textLayerScaleLabel = SmallLabel("", FontStyle.Bold);
        body.Controls.Add(textLayerScaleLabel);

        textLayerScaleSlider = new FlatSlider();
        textLayerScaleSlider.Minimum = 30;
        textLayerScaleSlider.Maximum = 300;
        textLayerScaleSlider.Step = 5;
        textLayerScaleSlider.Value = 100;
        textLayerScaleSlider.ValueChanged += delegate
        {
            UpdateTextLayerControlLabels();
            SetStateValueLocal("text_layer_scale", TextLayerScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
            QueueLivePreview();
        };
        textLayerScaleSlider.ValueCommitted += delegate { CommitTextLayerTransform(); };
        body.Controls.Add(textLayerScaleSlider);

        textLayerRotationLabel = SmallLabel("", FontStyle.Bold);
        body.Controls.Add(textLayerRotationLabel);

        textLayerRotationSlider = new FlatSlider();
        textLayerRotationSlider.Minimum = -180;
        textLayerRotationSlider.Maximum = 180;
        textLayerRotationSlider.Step = 5;
        textLayerRotationSlider.Value = 0;
        textLayerRotationSlider.ValueChanged += delegate
        {
            UpdateTextLayerControlLabels();
            SetStateValueLocal("text_layer_rotation", textLayerRotationSlider.Value.ToString());
            QueueLivePreview();
        };
        textLayerRotationSlider.ValueCommitted += delegate { CommitTextLayerTransform(); };
        body.Controls.Add(textLayerRotationSlider);

        EventHandler layout = delegate
        {
            int w = body.ClientSize.Width;
            int y = 0;
            int buttonW = 82;

            inputLabel.SetBounds(0, y, w, 18);
            y += 20;
            textLayerBoxHost.SetBounds(0, y, Math.Max(90, w - buttonW - 8), 28);
            clearTextButton.SetBounds(Math.Max(0, w - buttonW), y - 2, buttonW, 26);
            y += 36;

            fontLabel.SetBounds(0, y + 2, 52, 22);
            textLayerFontHost.SetBounds(60, y - 1, Math.Max(88, w - 60), 32);
            y += 36;

            colorLabel.SetBounds(0, y + 2, 52, 22);
            textLayerColorHost.SetBounds(60, y - 1, Math.Max(88, w - 60), 32);
            y += 36;

            textLayerScaleLabel.SetBounds(0, y - 1, w, 18);
            textLayerScaleSlider.SetBounds(0, y + 14, Math.Max(120, w), 28);
            y += 46;

            textLayerRotationLabel.SetBounds(0, y - 1, w, 18);
            textLayerRotationSlider.SetBounds(0, y + 14, Math.Max(120, w), 28);
        };
        body.Resize += layout;
        body.HandleCreated += delegate
        {
            layout(body, EventArgs.Empty);
            UpdateTextLayerControlLabels();
        };

        return textCard;
    }

    private Label SmallLabel(string text, FontStyle style)
    {
        Label label = new Label();
        label.Text = text;
        label.Font = new Font("Segoe UI", 8F, style);
        label.ForeColor = MutedTextColor;
        label.BackColor = SurfaceColor;
        label.TextAlign = ContentAlignment.MiddleLeft;
        label.AutoSize = false;
        return label;
    }

    private Control BuildActionsCard()
    {
        Panel actions = Card();
        actions.Padding = new Padding(16, 48, 16, 14);
        AddCardTitle(actions, "Procesar");

        TableLayoutPanel grid = new TableLayoutPanel();
        grid.Dock = DockStyle.Fill;
        grid.RowCount = 5;
        grid.ColumnCount = 1;
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        grid.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
        grid.BackColor = SurfaceColor;

        Button one = Button("Probar 1 foto");
        one.Dock = DockStyle.Fill;
        one.Margin = new Padding(0, 0, 0, 4);
        one.Click += delegate { RunProcess(true); };
        grid.Controls.Add(one, 0, 0);

        batchProcessButton = Button("Procesar lote");
        batchProcessButton.Dock = DockStyle.Fill;
        batchProcessButton.Margin = new Padding(0, 3, 0, 3);
        batchProcessButton.Click += delegate { RunProcess(false); };
        grid.Controls.Add(batchProcessButton, 0, 1);

        hotfolderButton = Button("Hotfolder OFF");
        hotfolderButton.Dock = DockStyle.Fill;
        hotfolderButton.Margin = new Padding(0, 3, 0, 3);
        hotfolderButton.Click += delegate { ToggleHotfolder(); };
        grid.Controls.Add(hotfolderButton, 0, 2);

        nuvolButton = Button("Nuvol OFF");
        nuvolButton.Dock = DockStyle.Fill;
        nuvolButton.Margin = new Padding(0, 3, 0, 3);
        nuvolButton.Click += delegate { ToggleNuvol(); };
        grid.Controls.Add(nuvolButton, 0, 3);

        moveProcessedButton = Button("Mover procesadas OFF");
        moveProcessedButton.Dock = DockStyle.Fill;
        moveProcessedButton.Margin = new Padding(0, 3, 0, 0);
        moveProcessedButton.Click += delegate { ToggleMoveProcessed(); };
        grid.Controls.Add(moveProcessedButton, 0, 4);

        actions.Controls.Add(grid);
        return actions;
    }

    private FlatSlider AddPostSlider(TableLayoutPanel parent, string title, out Label valueLabel, EventHandler committed)
    {
        Panel row = new Panel();
        row.Dock = DockStyle.Fill;
        row.BackColor = SurfaceColor;
        row.Margin = new Padding(0, 2, 0, 2);

        Label l = CardLabel(title);
        l.SetBounds(0, 0, 180, 18);
        row.Controls.Add(l);

        FlatSlider slider = new FlatSlider();
        slider.Minimum = 0;
        slider.Maximum = 100;
        slider.Step = 5;
        slider.BackColor = SurfaceColor;
        slider.SetBounds(0, 22, 250, 36);
        slider.ValueCommitted += committed;
        row.Controls.Add(slider);

        Label localValueLabel = CardLabel("");
        localValueLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        localValueLabel.ForeColor = TextColor;
        localValueLabel.SetBounds(266, 28, 90, 20);
        row.Controls.Add(localValueLabel);

        row.Resize += delegate
        {
            int labelWidth = 90;
            int gap = 10;
            int sliderWidth = Math.Max(120, row.ClientSize.Width - labelWidth - gap);
            slider.SetBounds(0, 22, sliderWidth, 36);
            localValueLabel.SetBounds(sliderWidth + gap, 28, labelWidth, 20);
        };

        parent.Controls.Add(row, 0, parent.Controls.Count);
        valueLabel = localValueLabel;
        return slider;
    }

    private Panel Card()
    {
        Panel p = new Panel();
        p.Dock = DockStyle.Fill;
        p.Margin = new Padding(0, 0, 0, 16);
        p.BackColor = SurfaceColor;
        p.BorderStyle = BorderStyle.None;
        ApplyRoundedPanel(p, 10);
        return p;
    }

    private Panel DarkPanel()
    {
        Panel p = new Panel();
        p.Dock = DockStyle.Fill;
        p.Margin = new Padding(0, 0, 0, 14);
        p.BackColor = darkCard;
        p.BorderStyle = BorderStyle.None;
        ApplyRoundedPanel(p, 10);
        return p;
    }

    private Panel SliderBand(int y, int height)
    {
        Panel p = new Panel();
        p.SetBounds(10, y, 186, height);
        p.BackColor = SubsurfaceColor;
        p.BorderStyle = BorderStyle.FixedSingle;
        return p;
    }

    private FlowLayoutPanel AssetPanel()
    {
        FlowLayoutPanel p = new FlowLayoutPanel();
        p.Dock = DockStyle.Fill;
        p.AutoScroll = true;
        p.WrapContents = true;
        p.TabStop = true;
        p.BackColor = SurfaceColor;
        p.Margin = new Padding(0, 0, 12, 0);
        p.MouseEnter += delegate { p.Focus(); };
        p.MouseWheel += delegate(object sender, MouseEventArgs e)
        {
            int currentY = -p.AutoScrollPosition.Y;
            int nextY = Math.Max(0, currentY - e.Delta);
            p.AutoScrollPosition = new Point(0, nextY);
        };
        ApplyDarkScrollbarTheme(p);
        return p;
    }

    private Label AddDarkLabel(Control parent, string text, int y, bool bold)
    {
        Label l = new Label();
        l.Text = text;
        l.ForeColor = bold ? Color.White : Color.FromArgb(203, 224, 238);
        l.BackColor = parent.BackColor;
        l.Font = new Font("Segoe UI", 9F, bold ? FontStyle.Bold : FontStyle.Regular);
        l.SetBounds(10, y, 180, bold ? 22 : 54);
        parent.Controls.Add(l);
        return l;
    }

    private void AddDarkTitleRule(Control parent)
    {
        Panel rule = new Panel();
        rule.BackColor = accent;
        rule.SetBounds(10, 36, 54, 2);
        parent.Controls.Add(rule);
        rule.BringToFront();
    }

    private void AddCardTitle(Control parent, string text)
    {
        Label l = new Label();
        l.Text = text;
        l.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        l.ForeColor = TextColor;
        l.BackColor = SurfaceColor;
        l.SetBounds(14, 12, 230, 24);
        parent.Controls.Add(l);
        l.BringToFront();

        Panel rule = new Panel();
        rule.BackColor = accent;
        rule.SetBounds(14, 38, 54, 2);
        parent.Controls.Add(rule);
        rule.BringToFront();
    }

    private Control BuildPathRow(string label, TextBox box, EventHandler select, EventHandler open)
    {
        TableLayoutPanel row = new TableLayoutPanel();
        row.Dock = DockStyle.Fill;
        row.BackColor = SubsurfaceColor;
        row.RowCount = 2;
        row.ColumnCount = 3;
        row.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
        row.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 32F));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 32F));
        row.Margin = new Padding(0, 0, 0, 6);
        row.Padding = new Padding(10, 4, 8, 4);

        Label l = CardLabel(label);
        l.BackColor = row.BackColor;
        l.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
        l.TextAlign = ContentAlignment.BottomLeft;
        row.Controls.Add(l, 0, 0);

        StyleTextBox(box);
        box.BorderStyle = BorderStyle.None;
        box.BackColor = row.BackColor;
        box.AutoSize = false;
        box.Height = 20;
        box.Dock = DockStyle.Fill;
        box.Margin = new Padding(0, 1, 8, 0);
        row.Controls.Add(box, 0, 1);

        Button s = RoundSmallButton("...");
        s.Dock = DockStyle.Fill;
        s.BackColor = SurfaceColor;
        s.Margin = new Padding(0, 7, 5, 7);
        s.Click += select;
        row.Controls.Add(s, 1, 0);
        row.SetRowSpan(s, 2);

        Button o = RoundSmallButton("↗");
        o.Dock = DockStyle.Fill;
        o.BackColor = SurfaceColor;
        o.Margin = new Padding(0, 7, 0, 7);
        o.Click += open;
        row.Controls.Add(o, 2, 0);
        row.SetRowSpan(o, 2);
        return row;
    }

    private Control BuildNuvolModeRow()
    {
        if (nuvolModeCombo == null) nuvolModeCombo = new ComboBox();
        nuvolModeCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        StyleComboBox(nuvolModeCombo);
        if (nuvolModeCombo.Items.Count == 0)
        {
            nuvolModeCombo.Items.AddRange(new string[] { "upload only", "upload and download" });
        }
        nuvolModeCombo.SelectedIndexChanged += delegate
        {
            if (nuvolModeCombo.SelectedItem == null) return;
            string mode = NuvolModeValue();
            SetStateValueLocal("nuvol_mode", mode);
            SaveSimple("nuvol_mode", mode, false);
        };
        return BuildNuvolFieldRow("Modo", BuildCompactComboHost(nuvolModeCombo));
    }

    private Control BuildNuvolTextRow(string label, TextBox box)
    {
        StyleTextBox(box);
        box.BorderStyle = BorderStyle.None;
        box.AutoSize = false;
        box.Height = 20;
        if (box == nuvolAuthPasswordBox) box.UseSystemPasswordChar = true;
        box.Leave += delegate
        {
            if (box == nuvolParkBox)
            {
                SaveSimple("nuvol_park", box.Text.Trim(), false);
                SaveSimple("nuvol_user_group", box.Text.Trim(), false);
                SetStateValueLocal("nuvol_park", box.Text.Trim());
                SetStateValueLocal("nuvol_user_group", box.Text.Trim());
            }
            else if (box == nuvolUsernameBox)
            {
                SaveSimple("nuvol_username", box.Text.Trim(), false);
                SetStateValueLocal("nuvol_username", box.Text.Trim());
            }
            else if (box == nuvolAuthUsernameBox)
            {
                SaveSimple("nuvol_auth_username", box.Text.Trim(), false);
                SetStateValueLocal("nuvol_auth_username", box.Text.Trim());
            }
            else if (box == nuvolAuthPasswordBox)
            {
                SaveSimple("nuvol_auth_password", box.Text, false);
                SetStateValueLocal("nuvol_auth_password", box.Text);
            }
        };
        return BuildNuvolFieldRow(label, BuildCompactTextHost(box));
    }

    private Control BuildNuvolFieldRow(string label, Control input)
    {
        TableLayoutPanel row = new TableLayoutPanel();
        row.Dock = DockStyle.Fill;
        row.BackColor = SurfaceColor;
        row.RowCount = 2;
        row.ColumnCount = 1;
        row.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
        row.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        row.Margin = new Padding(0, 0, 0, 5);

        Label l = CardLabel(label);
        l.Dock = DockStyle.Fill;
        l.Font = new Font("Segoe UI", 7.5F, FontStyle.Bold);
        l.TextAlign = ContentAlignment.BottomLeft;
        row.Controls.Add(l, 0, 0);

        input.Dock = DockStyle.Fill;
        input.Margin = new Padding(0, 0, 0, 0);
        row.Controls.Add(input, 0, 1);
        return row;
    }
    private Control BuildSectionLabel(string text)
    {
        Label label = new Label();
        label.Dock = DockStyle.Fill;
        label.Text = text.ToUpperInvariant();
        label.Font = new Font("Segoe UI", 7.5F, FontStyle.Bold);
        label.ForeColor = MutedTextColor;
        label.BackColor = SurfaceColor;
        label.TextAlign = ContentAlignment.BottomLeft;
        label.Padding = new Padding(2, 0, 0, 2);
        return label;
    }

    private Control BuildActiveRow(string label, TextBox box, out Label nameLabel, EventHandler select)
    {
        TableLayoutPanel row = new TableLayoutPanel();
        row.Dock = DockStyle.Fill;
        row.BackColor = SubsurfaceColor;
        row.RowCount = 3;
        row.ColumnCount = 2;
        row.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
        row.RowStyles.Add(new RowStyle(SizeType.Absolute, 18F));
        row.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        row.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 34F));
        row.Margin = new Padding(0, 0, 0, 8);
        row.Padding = new Padding(10, 5, 8, 5);

        Label l = CardLabel(label);
        l.BackColor = row.BackColor;
        l.Font = new Font("Segoe UI", 8F, FontStyle.Regular);
        l.TextAlign = ContentAlignment.MiddleLeft;
        row.Controls.Add(l, 0, 0);

        nameLabel = new Label();
        nameLabel.Dock = DockStyle.Fill;
        nameLabel.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold);
        nameLabel.ForeColor = TextColor;
        nameLabel.BackColor = row.BackColor;
        nameLabel.AutoEllipsis = true;
        nameLabel.TextAlign = ContentAlignment.MiddleLeft;
        nameLabel.Text = "Sin seleccionar";
        row.Controls.Add(nameLabel, 0, 1);

        StyleTextBox(box);
        box.BorderStyle = BorderStyle.None;
        box.BackColor = row.BackColor;
        box.AutoSize = false;
        box.Font = new Font("Segoe UI", 8.25F);
        box.MinimumSize = Size.Empty;
        box.Height = 19;
        box.Dock = DockStyle.Fill;
        box.Margin = new Padding(0, 0, 8, 0);
        row.Controls.Add(box, 0, 2);

        Button s = RoundSmallButton("...");
        s.Dock = DockStyle.Fill;
        s.BackColor = SurfaceColor;
        s.Margin = new Padding(0, 11, 0, 11);
        s.Click += select;
        row.Controls.Add(s, 1, 0);
        row.SetRowSpan(s, 3);
        return row;
    }

    private Label CardLabel(string text)
    {
        Label l = new Label();
        l.Text = text;
        l.ForeColor = MutedTextColor;
        l.BackColor = SurfaceColor;
        l.Dock = DockStyle.Fill;
        l.TextAlign = ContentAlignment.BottomLeft;
        return l;
    }

    private void StyleTextBox(TextBox box)
    {
        box.BorderStyle = BorderStyle.None;
        box.Font = new Font("Segoe UI", 9F);
        box.MinimumSize = new Size(0, 30);
        box.BackColor = SubsurfaceColor;
        box.ForeColor = TextColor;
    }

    private void StyleComboBox(ComboBox box)
    {
        box.FlatStyle = FlatStyle.Flat;
        box.Font = new Font("Segoe UI", 9F);
        box.BackColor = SubsurfaceColor;
        box.ForeColor = TextColor;
        box.DropDownHeight = 220;
        box.DrawMode = DrawMode.OwnerDrawFixed;
        box.ItemHeight = 20;
        box.DrawItem += delegate(object sender, DrawItemEventArgs e)
        {
            ComboBox combo = sender as ComboBox;
            if (combo == null) return;

            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Color back = selected && e.Index >= 0 ? Color.FromArgb(39, 49, 72) : SubsurfaceColor;
            using (SolidBrush backBrush = new SolidBrush(back))
            {
                e.Graphics.FillRectangle(backBrush, e.Bounds);
            }

            string text = "";
            if (e.Index >= 0 && e.Index < combo.Items.Count)
            {
                text = combo.Items[e.Index].ToString();
            }
            else if (combo.SelectedItem != null)
            {
                text = combo.SelectedItem.ToString();
            }
            else
            {
                text = combo.Text;
            }

            Rectangle textBounds = new Rectangle(e.Bounds.Left + 2, e.Bounds.Top, Math.Max(0, e.Bounds.Width - 6), e.Bounds.Height);
            TextRenderer.DrawText(e.Graphics, text, combo.Font, textBounds, TextColor, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        };
        try
        {
            SetWindowTheme(box.Handle, "DarkMode_CFD", null);
        }
        catch { }
        box.HandleCreated += delegate
        {
            try { SetWindowTheme(box.Handle, "DarkMode_CFD", null); }
            catch { }
        };
    }

    private Control BuildCompactTextHost(TextBox box)
    {
        Panel host = BuildRoundedInputHost(box, false);
        host.Dock = DockStyle.Fill;
        host.Margin = new Padding(0, 0, 0, 6);
        return host;
    }

    private Control BuildCompactComboHost(ComboBox box)
    {
        Panel host = BuildRoundedInputHost(box, true);
        host.Dock = DockStyle.Fill;
        host.Margin = new Padding(0, 0, 0, 6);
        return host;
    }

    private Panel BuildRoundedInputHost(Control inner, bool comboLike)
    {
        Panel host = new Panel();
        host.BackColor = SubsurfaceColor;
        host.Padding = comboLike ? new Padding(8, 3, 4, 3) : new Padding(10, 5, 10, 3);
        ApplyRoundedInputPanel(host, 8);

        inner.Dock = DockStyle.Fill;
        inner.BackColor = SubsurfaceColor;
        inner.ForeColor = TextColor;

        TextBox textBox = inner as TextBox;
        if (textBox != null)
        {
            textBox.BorderStyle = BorderStyle.None;
            textBox.MinimumSize = Size.Empty;
        }

        ComboBox comboBox = inner as ComboBox;
        if (comboBox != null)
        {
            comboBox.FlatStyle = FlatStyle.Flat;
        }

        host.Controls.Add(inner);

        if (comboLike && comboBox != null)
        {
            Panel face = new Panel();
            face.BackColor = SubsurfaceColor;
            face.Cursor = Cursors.Hand;
            face.Padding = new Padding(0);

            Label display = new Label();
            display.BackColor = SubsurfaceColor;
            display.ForeColor = TextColor;
            display.Font = comboBox.Font;
            display.TextAlign = ContentAlignment.MiddleLeft;
            display.Cursor = Cursors.Hand;
            face.Controls.Add(display);

            Panel arrow = new Panel();
            arrow.BackColor = SubsurfaceColor;
            arrow.Cursor = Cursors.Hand;
            arrow.Paint += delegate(object sender, PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                int cx = arrow.Width / 2;
                int cy = arrow.Height / 2 + 1;
                Point[] points = new Point[]
                {
                    new Point(cx - 4, cy - 2),
                    new Point(cx + 4, cy - 2),
                    new Point(cx, cy + 3)
                };
                using (SolidBrush brush = new SolidBrush(MutedTextColor))
                {
                    e.Graphics.FillPolygon(brush, points);
                }
            };
            face.Controls.Add(arrow);

            Action updateDisplay = delegate
            {
                if (comboBox.SelectedItem != null) display.Text = comboBox.SelectedItem.ToString();
                else display.Text = comboBox.Text;
            };

            EventHandler openCombo = delegate
            {
                try
                {
                    comboBox.Focus();
                    comboBox.DroppedDown = true;
                }
                catch { }
            };
            face.Click += openCombo;
            display.Click += openCombo;
            arrow.Click += openCombo;
            comboBox.SelectedIndexChanged += delegate { updateDisplay(); };
            comboBox.TextChanged += delegate { updateDisplay(); };

            host.Controls.Add(face);
            face.BringToFront();
            comboBox.SendToBack();
            host.Resize += delegate
            {
                face.SetBounds(0, 0, Math.Max(0, host.ClientSize.Width), Math.Max(0, host.ClientSize.Height));
                display.SetBounds(0, 0, Math.Max(0, face.ClientSize.Width - 24), face.ClientSize.Height);
                arrow.SetBounds(Math.Max(0, face.ClientSize.Width - 24), 0, 24, face.ClientSize.Height);
            };
            host.HandleCreated += delegate
            {
                face.SetBounds(0, 0, Math.Max(0, host.ClientSize.Width), Math.Max(0, host.ClientSize.Height));
                display.SetBounds(0, 0, Math.Max(0, face.ClientSize.Width - 24), face.ClientSize.Height);
                arrow.SetBounds(Math.Max(0, face.ClientSize.Width - 24), 0, 24, face.ClientSize.Height);
                updateDisplay();
            };
        }

        return host;
    }

    private void ApplyRoundedInputPanel(Panel panel, int radius)
    {
        panel.Resize += delegate
        {
            ApplyRoundedRegion(panel, radius);
            panel.Invalidate();
        };
        panel.HandleCreated += delegate { ApplyRoundedRegion(panel, radius); };
        panel.Paint += delegate(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = new Rectangle(0, 0, panel.Width - 1, panel.Height - 1);
            using (GraphicsPath path = RoundedRect(rect, radius))
            using (Pen pen = new Pen(Color.FromArgb(38, 48, 67)))
            {
                e.Graphics.DrawPath(pen, path);
            }
        };
    }

    private void AddPathRow(Control parent, string label, TextBox box, int y, EventHandler select, EventHandler open)
    {
        Label l = new Label();
        l.Text = label;
        l.ForeColor = MutedTextColor;
        l.BackColor = SurfaceColor;
        l.SetBounds(18, y, 210, 20);
        parent.Controls.Add(l);
        box.BorderStyle = BorderStyle.FixedSingle;
        box.SetBounds(18, y + 25, 156, 28);
        parent.Controls.Add(box);
        Button s = Button("Seleccionar");
        s.SetBounds(184, y + 24, 80, 30);
        s.Click += select;
        parent.Controls.Add(s);
        Button o = Button("Abrir");
        o.SetBounds(270, y + 24, 48, 30);
        o.Click += open;
        parent.Controls.Add(o);
    }

    private void AddActiveRow(Control parent, string label, TextBox box, int y, EventHandler select)
    {
        Label l = new Label();
        l.Text = label;
        l.ForeColor = MutedTextColor;
        l.BackColor = SurfaceColor;
        l.SetBounds(18, y, 100, 20);
        parent.Controls.Add(l);
        box.BorderStyle = BorderStyle.FixedSingle;
        box.SetBounds(18, y + 25, 190, 28);
        parent.Controls.Add(box);
        Button s = Button("Cambiar");
        s.SetBounds(218, y + 24, 100, 30);
        s.Click += select;
        parent.Controls.Add(s);
    }

    private Button Button(string text)
    {
        Button b = new CenteredButton();
        b.Text = text;
        b.FlatStyle = FlatStyle.Flat;
        b.BackColor = SurfaceColor;
        b.ForeColor = TextColor;
        b.FlatAppearance.BorderColor = BorderColor;
        b.FlatAppearance.BorderSize = 1;
        b.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
        b.TextAlign = ContentAlignment.MiddleCenter;
        b.Padding = new Padding(0);
        b.UseVisualStyleBackColor = false;
        b.Cursor = Cursors.Hand;
        CenteredButton cb = b as CenteredButton;
        if (cb != null) cb.CornerRadius = 10;
        return b;
    }

    private Button AccentButton(string text)
    {
        Button b = Button(text);
        b.BackColor = SurfaceColor;
        b.ForeColor = TextColor;
        b.FlatAppearance.BorderColor = BorderColor;
        CenteredButton cb = b as CenteredButton;
        if (cb != null)
        {
            cb.UseGradient = false;
        }
        return b;
    }

    private Button TopButton(string text)
    {
        Button b = Button(text);
        b.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        CenteredButton cb = b as CenteredButton;
        if (cb != null) cb.TextOffsetY = -14;
        return b;
    }

    private Button TopAccentButton(string text)
    {
        Button b = TopButton(text);
        b.BackColor = SurfaceColor;
        b.ForeColor = TextColor;
        b.FlatAppearance.BorderColor = BorderColor;
        CenteredButton cb = b as CenteredButton;
        if (cb != null)
        {
            cb.UseGradient = false;
        }
        return b;
    }

    private Button AbortButton()
    {
        Button b = RoundSmallButton("Abortar");
        b.BackColor = Color.FromArgb(86, 34, 52);
        b.ForeColor = Color.White;
        b.FlatAppearance.BorderColor = Color.FromArgb(255, 104, 157);
        b.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold);
        return b;
    }

    private Button RoundSmallButton(string text)
    {
        Button b = Button(text);
        b.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        CenteredButton cb = b as CenteredButton;
        if (cb != null) cb.CornerRadius = 12;
        return b;
    }

    private void ApplyButtonVisual(Button button, bool active)
    {
        if (button == null) return;
        button.BackColor = active ? azure : SurfaceColor;
        button.ForeColor = active ? Color.White : TextColor;
        button.FlatAppearance.BorderColor = active ? ControlPaint.Light(azure, 0.12F) : BorderColor;
        CenteredButton cb = button as CenteredButton;
        if (cb != null)
        {
            cb.UseGradient = false;
        }
        button.Invalidate();
    }

    private bool IsNoAssetSelected(string key)
    {
        string active = key == "overlay" ? Value("overlay_abs") : key == "logo" ? Value("logo_abs") : Value("background_abs");
        string relative = Value(key);
        return String.IsNullOrWhiteSpace(active) && String.IsNullOrWhiteSpace(relative);
    }

    private void ToggleTheme()
    {
        darkTheme = true;
        Controls.Clear();
        BuildUi();
        LoadState();
        ApplyTheme();
    }

    private void ApplyTheme()
    {
        darkTheme = true;
        BackColor = PageColor;
        ApplyThemeRecursive(this);
        UpdateHotfolderButton(IsHotfolderRunning());
        UpdateMoveProcessedButton(Value("move_processed") == "true");
        UpdateNuvolButton(Value("nuvol_enabled") == "true");
        UpdatePhotoEnhanceAutoTuneButton(Value("photo_enhance_autotune") == "true");
        UpdateStopButtonState();
        ApplyWindowBrandChrome();
        Invalidate(true);
    }

    private void ApplyThemeRecursive(Control control)
    {
        foreach (Control child in control.Controls)
        {
            ApplyThemeToControl(child);
            ApplyDarkScrollbarTheme(child);
            ApplyThemeRecursive(child);
        }
    }

    private void ApplyDarkScrollbarTheme(Control control)
    {
        if (!darkTheme || control == null || control.IsDisposed) return;
        try
        {
            if (control.IsHandleCreated)
            {
                SetWindowTheme(control.Handle, "DarkMode_Explorer", null);
                SendMessage(control.Handle, WM_THEMECHANGED, IntPtr.Zero, IntPtr.Zero);
            }
            control.HandleCreated -= Control_HandleCreatedApplyDarkTheme;
            control.HandleCreated += Control_HandleCreatedApplyDarkTheme;
        }
        catch { }
    }

    private void Control_HandleCreatedApplyDarkTheme(object sender, EventArgs e)
    {
        Control control = sender as Control;
        if (control == null) return;
        try
        {
            SetWindowTheme(control.Handle, "DarkMode_Explorer", null);
            SendMessage(control.Handle, WM_THEMECHANGED, IntPtr.Zero, IntPtr.Zero);
        }
        catch { }
    }

    private Bitmap LoadBrandBitmap(string relativePath, int width, int height)
    {
        string imagePath = Path.Combine(appDir, relativePath);
        if (!File.Exists(imagePath)) return null;
        try
        {
            using (Image src = LoadBitmapUnlocked(imagePath))
            {
                Bitmap bmp = new Bitmap(width, height);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = SmoothingMode.HighQuality;
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.Clear(Color.Transparent);
                    float scale = Math.Min((float)width / src.Width, (float)height / src.Height);
                    int drawW = Math.Max(1, (int)Math.Round(src.Width * scale));
                    int drawH = Math.Max(1, (int)Math.Round(src.Height * scale));
                    int x = (width - drawW) / 2;
                    int y = (height - drawH) / 2;
                    g.DrawImage(src, new Rectangle(x, y, drawW, drawH));
                }
                return bmp;
            }
        }
        catch { return null; }
    }

    private void ApplyThemeToControl(Control control)
    {
        if (control == previewBox) return;

        if (control is PictureBox)
        {
            if (control.BackColor != Color.Transparent)
            {
                control.BackColor = dark;
            }
            return;
        }

        if (control is FlatSlider)
        {
            control.BackColor = control.Parent != null ? control.Parent.BackColor : SurfaceColor;
            control.ForeColor = TextColor;
            control.Invalidate();
            return;
        }

        if (control is FlatProgressBar)
        {
            control.BackColor = control.Parent != null ? control.Parent.BackColor : SurfaceColor;
            control.Invalidate();
            return;
        }

        if (control is TextBox)
        {
            TextBox box = (TextBox)control;
            if (box == logBox)
            {
                box.BackColor = dark;
                box.ForeColor = Color.White;
            }
            else
            {
                box.BackColor = SubsurfaceColor;
                box.ForeColor = TextColor;
            }
            return;
        }

        if (control is ComboBox)
        {
            ComboBox box = (ComboBox)control;
            box.BackColor = SubsurfaceColor;
            box.ForeColor = TextColor;
            return;
        }

        if (control is Button)
        {
            Button button = (Button)control;
            if (button == stopButton)
            {
                UpdateStopButtonState();
            }
            else if (button.Tag is string && ((string)button.Tag).StartsWith("asset-none:", StringComparison.Ordinal))
            {
                string key = ((string)button.Tag).Substring("asset-none:".Length);
                ApplyButtonVisual(button, IsNoAssetSelected(key));
            }
            else
            {
                CenteredButton cb = button as CenteredButton;
                if (cb != null) cb.UseGradient = false;
                button.BackColor = SurfaceColor;
                button.ForeColor = TextColor;
                button.FlatAppearance.BorderColor = BorderColor;
            }
            return;
        }

        if (control is Label)
        {
            Label label = (Label)control;
            if (label.BackColor.ToArgb() == accent.ToArgb())
            {
                label.ForeColor = Color.White;
                return;
            }
            if (label.Parent != null)
            {
                label.BackColor = label.Parent.BackColor;
            }
            label.ForeColor = label.Font.Bold ? TextColor : MutedTextColor;
            if (label.Parent != null && label.Parent.BackColor.ToArgb() == dark.ToArgb())
            {
                label.ForeColor = label.Font.Bold ? TextColor : MutedTextColor;
            }
            return;
        }

        if (control.BackColor.ToArgb() == Color.White.ToArgb() ||
            control.BackColor.ToArgb() == darkCard.ToArgb())
        {
            control.BackColor = SurfaceColor;
        }
        else if (control.BackColor.ToArgb() == page.ToArgb())
        {
            control.BackColor = PageColor;
        }
        else if (control.BackColor.ToArgb() == Color.FromArgb(236, 243, 247).ToArgb() ||
            control.BackColor.ToArgb() == Color.FromArgb(22, 34, 42).ToArgb() ||
            control.BackColor.ToArgb() == Color.FromArgb(20, 27, 41).ToArgb())
        {
            control.BackColor = SubsurfaceColor;
        }
        else if (control.BackColor.ToArgb() == Color.FromArgb(247, 250, 252).ToArgb())
        {
            control.BackColor = TileColor;
        }
        else if (control.BackColor.ToArgb() == Color.FromArgb(224, 246, 245).ToArgb())
        {
            control.BackColor = ActiveTileColor;
        }
    }

    private void LoadState()
    {
        try
        {
            state = ParseState(RunPython("\"" + bridgePy + "\" state"));
            ClearPreviewInputImagesCache();
            inputBox.Text = Value("input");
            outputBox.Text = Value("output");
            backgroundBox.Text = Value("background");
            overlayBox.Text = Value("overlay");
            processedBox.Text = Value("processed");
            if (nuvolParkBox != null) nuvolParkBox.Text = Value("nuvol_park");
            if (nuvolUsernameBox != null) nuvolUsernameBox.Text = Value("nuvol_username");
            if (nuvolAuthUsernameBox != null) nuvolAuthUsernameBox.Text = Value("nuvol_auth_username");
            if (nuvolAuthPasswordBox != null) nuvolAuthPasswordBox.Text = Value("nuvol_auth_password");
            if (nuvolDownloadBox != null) nuvolDownloadBox.Text = Value("nuvol_download_dir");
            SelectNuvolMode(Value("nuvol_mode"));
            suppressTextLayerEvents = true;
            if (textLayerBox != null) textLayerBox.Text = Value("text_layer");
            if (textLayerFontCombo != null) SelectTextLayerFont(Value("text_layer_font"));
            if (textLayerColorCombo != null) SelectTextLayerColor(Value("text_layer_color"));
            if (textLayerScaleSlider != null) textLayerScaleSlider.Value = Clamp((int)Math.Round(ToDouble(Value("text_layer_scale"), 1.0) * 100.0), textLayerScaleSlider.Minimum, textLayerScaleSlider.Maximum);
            if (textLayerRotationSlider != null) textLayerRotationSlider.Value = Clamp(ToInt(Value("text_layer_rotation")), textLayerRotationSlider.Minimum, textLayerRotationSlider.Maximum);
            suppressTextLayerEvents = false;
            if (activeBackgroundNameLabel != null) activeBackgroundNameLabel.Text = ActiveAssetName(Value("background"), "Sin fondo");
            if (activeOverlayNameLabel != null) activeOverlayNameLabel.Text = ActiveAssetName(Value("overlay"), "Sin overlay");
            qualitySlider.Value = Clamp(ToInt(Value("jpg_quality")), qualitySlider.Minimum, qualitySlider.Maximum);
            int maskRepair = Math.Max(
                Clamp(ToInt(Value("mask_protection")), maskProtectionSlider.Minimum, maskProtectionSlider.Maximum),
                Clamp(ToInt(Value("mask_antighost")), maskAntighostSlider.Minimum, maskAntighostSlider.Maximum)
            );
            maskProtectionSlider.Value = maskRepair;
            maskAntighostSlider.Value = maskRepair;
            photoZoomSlider.Value = Clamp(ToInt(Value("person_zoom")), photoZoomSlider.Minimum, photoZoomSlider.Maximum);
            personVerticalSlider.Value = Clamp(ToInt(Value("person_vertical")), personVerticalSlider.Minimum, personVerticalSlider.Maximum);
            if (overlayScaleSlider != null) overlayScaleSlider.Value = Clamp((int)Math.Round(ToDouble(Value("overlay_scale"), 1.0) * 100.0), overlayScaleSlider.Minimum, overlayScaleSlider.Maximum);
            if (logoScaleSlider != null) logoScaleSlider.Value = Clamp((int)Math.Round(ToDouble(Value("logo_scale"), 1.0) * 100.0), logoScaleSlider.Minimum, logoScaleSlider.Maximum);
            harmonizeSlider.Value = Clamp(ToInt(Value("harmonize_strength")), harmonizeSlider.Minimum, harmonizeSlider.Maximum);
            if (photoEnhanceSlider != null) photoEnhanceSlider.Value = Clamp(ToInt(Value("photo_enhance_strength")), photoEnhanceSlider.Minimum, photoEnhanceSlider.Maximum);
            UpdatePhotoEnhanceAutoTuneButton(Value("photo_enhance_autotune") == "true");
            shadowSlider.Value = Clamp(ToInt(Value("contact_shadow_strength")), shadowSlider.Minimum, shadowSlider.Maximum);
            lastSavedJpgQuality = qualitySlider.Value;
            lastSavedMaskProtection = maskProtectionSlider.Value;
            lastSavedMaskAntighost = maskAntighostSlider.Value;
            lastSavedPhotoZoom = photoZoomSlider.Value;
            lastSavedPersonVertical = personVerticalSlider.Value;
            lastSavedOverlayScale = overlayScaleSlider != null ? overlayScaleSlider.Value : Clamp((int)Math.Round(ToDouble(Value("overlay_scale"), 1.0) * 100.0), 20, 200);
            lastSavedLogoScale = logoScaleSlider != null ? logoScaleSlider.Value : Clamp((int)Math.Round(ToDouble(Value("logo_scale"), 1.0) * 100.0), 20, 250);
            lastSavedHarmonize = harmonizeSlider.Value;
            lastSavedPhotoEnhance = photoEnhanceSlider != null ? photoEnhanceSlider.Value : ToInt(Value("photo_enhance_strength"));
            lastSavedShadow = shadowSlider.Value;
            UpdateQualityLabel();
            UpdateMaskProtectionLabel();
            UpdateMaskAntighostLabel();
            UpdatePhotoZoomLabel();
            UpdatePersonVerticalLabel();
            UpdateOverlayScaleLabel();
            UpdateLogoScaleLabel();
            UpdateHarmonizeLabel();
            UpdatePhotoEnhanceLabel();
            UpdateShadowLabel();
            UpdateTextLayerControlLabels();
            UpdateMoveProcessedButton(Value("move_processed") == "true");
            UpdateNuvolButton(Value("nuvol_enabled") == "true");
            if (versionLabel != null)
            {
                string version = Value("version");
                versionLabel.Text = String.IsNullOrWhiteSpace(version) ? "v..." : "v" + version;
            }
            UpdatePreviewNavigationState();
            RefreshPresetList();
            RefreshFolderRuleList();
            RequestPreview();
            DrawAssets();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Error cargando", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private Dictionary<string, List<string>> ParseState(string text)
    {
        Dictionary<string, List<string>> result = new Dictionary<string, List<string>>();
        foreach (string line in text.Replace("\r", "").Split('\n'))
        {
            if (line.Trim().Length == 0) continue;
            int idx = line.IndexOf('\t');
            if (idx < 0) continue;
            string key = line.Substring(0, idx);
            string value = line.Substring(idx + 1);
            if (!result.ContainsKey(key)) result[key] = new List<string>();
            result[key].Add(value);
        }
        return result;
    }

    private string Value(string key)
    {
        if (!state.ContainsKey(key) || state[key].Count == 0) return "";
        return state[key][0];
    }

    private string ActiveAssetName(string value, string emptyText)
    {
        if (String.IsNullOrWhiteSpace(value)) return emptyText;
        try
        {
            return Path.GetFileName(value.TrimEnd('\\', '/'));
        }
        catch
        {
            return value;
        }
    }

    private List<string> Values(string key)
    {
        return state.ContainsKey(key) ? state[key] : new List<string>();
    }

    private string RunPython(string arguments)
    {
        return RunPython(arguments, 0);
    }

    private string QuoteArg(string value)
    {
        return "\"" + value.Replace("\"", "\\\"") + "\"";
    }

    private string RunPython(string arguments, int timeoutMs)
    {
        if (!File.Exists(pythonExe)) throw new FileNotFoundException("No existe Python portable", pythonExe);
        ProcessStartInfo psi = new ProcessStartInfo(pythonExe, arguments);
        psi.WorkingDirectory = appDir;
        psi.UseShellExecute = false;
        psi.RedirectStandardOutput = true;
        psi.RedirectStandardError = true;
        psi.CreateNoWindow = true;
        Process p = Process.Start(psi);

        if (timeoutMs > 0 && !p.WaitForExit(timeoutMs))
        {
            try { p.Kill(); } catch { }
            throw new TimeoutException("Python ha tardado demasiado generando el preview.");
        }

        string output = p.StandardOutput.ReadToEnd();
        string error = p.StandardError.ReadToEnd();
        if (timeoutMs <= 0) p.WaitForExit();
        if (p.ExitCode != 0) throw new Exception(error.Length > 0 ? error : output);
        return output;
    }

    private void SaveSimple(string key, string value, bool reload)
    {
        try
        {
            RunPython("\"" + bridgePy + "\" set " + key + " " + QuoteArg(value));
            if (reload) LoadState();
        }
        catch (Exception ex)
        {
            if (logBox != null)
            {
                ClearLog();
                AddLog("ERROR: " + ex.Message);
            }
        }
    }

    private void CheckForOnlineUpdate()
    {
        if (updateBusy) return;
        updateBusy = true;
        SetUpdateButtonState("Buscando...", false);
        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                string output = RunPython(QuoteArg(mainPy) + " --update-check", 30000);
                Dictionary<string, string> info = ParseKeyValueOutput(output);
                BeginInvoke((MethodInvoker)delegate
                {
                    if (IsDisposed) return;
                    string status = GetValue(info, "status");
                    string current = GetValue(info, "current");
                    string latest = GetValue(info, "latest");
                    string notes = GetValue(info, "notes");
                    if (String.Equals(status, "update_available", StringComparison.OrdinalIgnoreCase))
                    {
                        string message = "Hay una version nueva de Maskerade." + Environment.NewLine + Environment.NewLine +
                            "Actual: " + current + Environment.NewLine +
                            "Nueva: " + latest;
                        if (!String.IsNullOrWhiteSpace(notes))
                        {
                            message += Environment.NewLine + Environment.NewLine + notes;
                        }
                        message += Environment.NewLine + Environment.NewLine + "Descargar e instalar ahora?";
                        DialogResult answer = MessageBox.Show(this, message, "Actualizar Maskerade", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (answer == DialogResult.Yes)
                        {
                            InstallOnlineUpdate();
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show(this, "Maskerade esta actualizado." + Environment.NewLine + "Version: " + current, "Actualizar Maskerade", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    updateBusy = false;
                    SetUpdateButtonState("Actualizar", true);
                });
            }
            catch (Exception ex)
            {
                BeginInvoke((MethodInvoker)delegate
                {
                    if (IsDisposed) return;
                    updateBusy = false;
                    SetUpdateButtonState("Actualizar", true);
                    MessageBox.Show(this, CleanError(ex.Message), "No se pudo buscar actualizacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                });
            }
        });
    }

    private void InstallOnlineUpdate()
    {
        updateBusy = true;
        SetUpdateButtonState("Descargando...", false);
        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                int pid = Process.GetCurrentProcess().Id;
                RunPython(QuoteArg(mainPy) + " --update-install --update-pid " + pid.ToString(CultureInfo.InvariantCulture), 300000);
                BeginInvoke((MethodInvoker)delegate
                {
                    if (IsDisposed) return;
                    MessageBox.Show(this, "Update descargado. Maskerade se cerrara y volvera a abrirse.", "Actualizar Maskerade", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Close();
                });
            }
            catch (Exception ex)
            {
                BeginInvoke((MethodInvoker)delegate
                {
                    if (IsDisposed) return;
                    updateBusy = false;
                    SetUpdateButtonState("Actualizar", true);
                    MessageBox.Show(this, CleanError(ex.Message), "No se pudo instalar actualizacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                });
            }
        });
    }

    private Dictionary<string, string> ParseKeyValueOutput(string output)
    {
        Dictionary<string, string> result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        string[] lines = (output ?? "").Replace("\r", "").Split('\n');
        for (int i = 0; i < lines.Length; i++)
        {
            string line = lines[i];
            if (String.IsNullOrWhiteSpace(line)) continue;
            int equals = line.IndexOf('=');
            if (equals <= 0) continue;
            result[line.Substring(0, equals).Trim()] = line.Substring(equals + 1).Trim();
        }
        return result;
    }

    private string GetValue(Dictionary<string, string> values, string key)
    {
        string value;
        return values.TryGetValue(key, out value) ? value : "";
    }

    private void SetUpdateButtonState(string text, bool enabled)
    {
        if (updateButton == null) return;
        updateButton.Text = text;
        updateButton.Enabled = enabled;
    }

    private string CleanError(string message)
    {
        if (String.IsNullOrWhiteSpace(message)) return "Error desconocido.";
        message = message.Trim();
        if (message.Length > 900) message = message.Substring(0, 900) + "...";
        return message;
    }

    private void RefreshPresetList()
    {
        string current = presetCombo == null || presetCombo.SelectedItem == null ? "" : presetCombo.SelectedItem.ToString();
        string active = Value("active_preset");
        if (presetCombo != null) presetCombo.Items.Clear();
        foreach (string preset in Values("preset"))
        {
            if (presetCombo != null) presetCombo.Items.Add(preset);
        }
        if (presetCombo != null && presetCombo.Items.Count == 0)
        {
            presetCombo.Text = "";
        }
        else if (presetCombo != null)
        {
            int index = active.Length > 0 ? presetCombo.Items.IndexOf(active) : -1;
            if (index < 0 && current.Length > 0) index = presetCombo.Items.IndexOf(current);
            presetCombo.SelectedIndex = index >= 0 ? index : 0;
        }
    }

    private void RefreshFolderRuleList()
    {
        if (folderRuleCombo == null) return;
        string currentPattern = folderRulePatternBox == null ? "" : folderRulePatternBox.Text.Trim();
        folderRuleCombo.Items.Clear();
        foreach (string rule in Values("folder_rule"))
        {
            string[] parts = rule.Split('\t');
            if (parts.Length < 3) continue;
            string enabled = parts[0] == "1" ? "" : " (off)";
            folderRuleCombo.Items.Add(parts[1] + " -> " + parts[2] + enabled);
        }
        if (folderRuleCombo.Items.Count == 0)
        {
            folderRuleCombo.Text = "";
            return;
        }

        int selected = -1;
        List<string> rules = Values("folder_rule");
        for (int i = 0; i < rules.Count; i++)
        {
            string[] parts = rules[i].Split('\t');
            if (parts.Length >= 2 && String.Equals(parts[1], currentPattern, StringComparison.OrdinalIgnoreCase))
            {
                selected = i;
                break;
            }
        }
        folderRuleCombo.SelectedIndex = selected >= 0 ? selected : 0;
    }

    private void SelectFolderRuleFromList()
    {
        if (folderRuleCombo == null || folderRuleCombo.SelectedIndex < 0) return;
        List<string> rules = Values("folder_rule");
        if (folderRuleCombo.SelectedIndex >= rules.Count) return;
        string[] parts = rules[folderRuleCombo.SelectedIndex].Split('\t');
        if (parts.Length < 3) return;
        if (folderRulePatternBox != null) folderRulePatternBox.Text = parts[1];
        SelectPresetInCombo(parts[2]);
    }

    private void SaveFolderRule()
    {
        string pattern = folderRulePatternBox == null ? "" : folderRulePatternBox.Text.Trim();
        string preset = presetCombo != null && presetCombo.SelectedItem != null ? presetCombo.SelectedItem.ToString() : "";
        if (String.IsNullOrWhiteSpace(pattern))
        {
            MessageBox.Show(this, "Escribe el inicio de carpeta, por ejemplo carla*.", "Reglas carpetas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (String.IsNullOrWhiteSpace(preset))
        {
            MessageBox.Show(this, "Selecciona un preset.", "Reglas carpetas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        try
        {
            RunPython("\"" + bridgePy + "\" folder_rule_save " + QuoteArg(pattern) + " " + QuoteArg(preset) + " true");
            LoadState();
            if (progressLabel != null) progressLabel.Text = "Regla guardada: " + pattern + " -> " + preset;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Error guardando regla", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void DeleteFolderRule()
    {
        string pattern = folderRulePatternBox == null ? "" : folderRulePatternBox.Text.Trim();
        if (String.IsNullOrWhiteSpace(pattern) && folderRuleCombo != null && folderRuleCombo.SelectedIndex >= 0)
        {
            List<string> rules = Values("folder_rule");
            if (folderRuleCombo.SelectedIndex < rules.Count)
            {
                string[] parts = rules[folderRuleCombo.SelectedIndex].Split('\t');
                if (parts.Length >= 2) pattern = parts[1];
            }
        }
        if (String.IsNullOrWhiteSpace(pattern)) return;
        try
        {
            RunPython("\"" + bridgePy + "\" folder_rule_delete " + QuoteArg(pattern));
            if (folderRulePatternBox != null) folderRulePatternBox.Text = "";
            LoadState();
            if (progressLabel != null) progressLabel.Text = "Regla quitada: " + pattern;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Error quitando regla", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SelectPresetInCombo(string name)
    {
        if (presetCombo == null || String.IsNullOrWhiteSpace(name)) return;
        int index = presetCombo.Items.IndexOf(name);
        if (index >= 0)
        {
            presetCombo.SelectedIndex = index;
        }
    }

    private string SelectedPresetName()
    {
        string typed = presetNameBox == null ? "" : presetNameBox.Text.Trim();
        if (typed.Length > 0) return typed;
        if (presetCombo != null && presetCombo.SelectedItem != null) return presetCombo.SelectedItem.ToString();
        return "";
    }

    private void SavePreset()
    {
        string name = SelectedPresetName();
        if (String.IsNullOrWhiteSpace(name))
        {
            name = "Preset " + DateTime.Now.ToString("yyyy-MM-dd HH-mm", CultureInfo.InvariantCulture);
        }
        try
        {
            SaveCurrentFields();
            RunPython("\"" + bridgePy + "\" preset_save " + QuoteArg(name));
            if (presetNameBox != null) presetNameBox.Text = "";
            LoadState();
            SelectPresetInCombo(name);
            if (progressLabel != null) progressLabel.Text = "Preset guardado: " + name;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Error guardando preset", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ApplyPreset()
    {
        string name = SelectedPresetName();
        if (String.IsNullOrWhiteSpace(name))
        {
            MessageBox.Show(this, "Selecciona un preset.", "Presets", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        try
        {
            RunPython("\"" + bridgePy + "\" preset_apply " + QuoteArg(name));
            ClearPreviewBase();
            ClearPreviewSubjectCache();
            ClearOverlayCache();
            ClearLogoCache();
            LoadState();
            if (progressLabel != null) progressLabel.Text = "Preset aplicado: " + name;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Error aplicando preset", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void DeletePreset()
    {
        string name = SelectedPresetName();
        if (String.IsNullOrWhiteSpace(name)) return;
        if (MessageBox.Show(this, "Borrar preset " + name + "?", "Presets", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            RunPython("\"" + bridgePy + "\" preset_delete " + QuoteArg(name));
            if (presetNameBox != null) presetNameBox.Text = "";
            LoadState();
            if (progressLabel != null) progressLabel.Text = "Preset borrado: " + name;
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Error borrando preset", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void SaveCurrentFields()
    {
        if (!String.IsNullOrWhiteSpace(Value("overlay_abs")) && ToInt(Value("overlay_x")) == 0 && ToInt(Value("overlay_y")) == 0)
        {
            PlaceOverlayBottomCenter(false);
        }

        List<string> args = new List<string>();
        AddSetArg(args, "input", inputBox.Text);
        AddSetArg(args, "output", outputBox.Text);
        AddSetArg(args, "background", backgroundBox.Text);
        AddSetArg(args, "overlay", overlayBox.Text);
        AddSetArg(args, "logo", Value("logo"));
        AddSetArg(args, "processed", processedBox.Text);
        AddSetArg(args, "overlay_x", Value("overlay_x"));
        AddSetArg(args, "overlay_y", Value("overlay_y"));
        AddSetArg(args, "jpg_quality", qualitySlider.Value.ToString());
        AddSetArg(args, "mask_protection", maskProtectionSlider.Value.ToString());
        AddSetArg(args, "mask_antighost", maskProtectionSlider.Value.ToString());
        AddSetArg(args, "person_zoom", photoZoomSlider.Value.ToString());
        AddSetArg(args, "person_vertical", personVerticalSlider.Value.ToString());
        AddSetArg(args, "overlay_scale", OverlayScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
        AddSetArg(args, "logo_x", Value("logo_x"));
        AddSetArg(args, "logo_y", Value("logo_y"));
        AddSetArg(args, "logo_scale", LogoScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
        AddSetArg(args, "text_layer", textLayerBox == null ? Value("text_layer") : textLayerBox.Text);
        AddSetArg(args, "text_layer_font", TextLayerFontName());
        AddSetArg(args, "text_layer_color", TextLayerColorValue());
        AddSetArg(args, "text_layer_x", Value("text_layer_x"));
        AddSetArg(args, "text_layer_y", Value("text_layer_y"));
        AddSetArg(args, "text_layer_scale", TextLayerScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
        AddSetArg(args, "text_layer_rotation", textLayerRotationSlider == null ? Value("text_layer_rotation") : textLayerRotationSlider.Value.ToString());
        AddSetArg(args, "harmonize_strength", harmonizeSlider.Value.ToString());
        AddSetArg(args, "photo_enhance_strength", photoEnhanceSlider == null ? Value("photo_enhance_strength") : photoEnhanceSlider.Value.ToString());
        AddSetArg(args, "photo_enhance_autotune", IsPhotoEnhanceAutoTuneEnabled() ? "true" : "false");
        AddSetArg(args, "contact_shadow_strength", shadowSlider.Value.ToString());
        AddSetArg(args, "move_processed", IsMoveProcessedEnabled() ? "true" : "false");
        AddSetArg(args, "nuvol_enabled", IsNuvolEnabled() ? "true" : "false");
        string nuvolPark = nuvolParkBox == null ? Value("nuvol_park") : nuvolParkBox.Text.Trim();
        AddSetArg(args, "nuvol_mode", NuvolModeValue());
        AddSetArg(args, "nuvol_park", nuvolPark);
        AddSetArg(args, "nuvol_user_group", nuvolPark);
        AddSetArg(args, "nuvol_username", nuvolUsernameBox == null ? Value("nuvol_username") : nuvolUsernameBox.Text.Trim());
        AddSetArg(args, "nuvol_auth_username", nuvolAuthUsernameBox == null ? Value("nuvol_auth_username") : nuvolAuthUsernameBox.Text.Trim());
        AddSetArg(args, "nuvol_auth_password", nuvolAuthPasswordBox == null ? Value("nuvol_auth_password") : nuvolAuthPasswordBox.Text);
        AddSetArg(args, "nuvol_download_dir", nuvolDownloadBox == null ? Value("nuvol_download_dir") : nuvolDownloadBox.Text.Trim());
        RunPython("\"" + bridgePy + "\" set_many " + String.Join(" ", args.ToArray()));
    }

    private string CreateFrozenConfigSnapshot(string reason)
    {
        string configDir = Path.Combine(appDir, "config");
        string source = Path.Combine(configDir, "settings.json");
        if (!File.Exists(source)) throw new FileNotFoundException("No existe settings.json", source);
        Directory.CreateDirectory(configDir);
        CleanupOldConfigSnapshots(configDir);
        string safeReason = String.IsNullOrWhiteSpace(reason) ? "batch" : reason.Replace(" ", "_");
        string name = "settings_snapshot_" + safeReason + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff", CultureInfo.InvariantCulture) + "_" + Guid.NewGuid().ToString("N").Substring(0, 8) + ".json";
        string target = Path.Combine(configDir, name);
        File.Copy(source, target, false);
        return target;
    }

    private void CleanupConfigSnapshot(string path)
    {
        if (String.IsNullOrWhiteSpace(path)) return;
        try
        {
            string full = Path.GetFullPath(path);
            string configDir = Path.GetFullPath(Path.Combine(appDir, "config"));
            if (!full.StartsWith(configDir, StringComparison.OrdinalIgnoreCase)) return;
            if (Path.GetFileName(full).StartsWith("settings_snapshot_", StringComparison.OrdinalIgnoreCase) && File.Exists(full))
            {
                File.Delete(full);
            }
        }
        catch { }
    }

    private void CleanupOldConfigSnapshots(string configDir)
    {
        try
        {
            foreach (string file in Directory.GetFiles(configDir, "settings_snapshot_*.json"))
            {
                try
                {
                    if (File.GetLastWriteTime(file) < DateTime.Now.AddDays(-1)) File.Delete(file);
                }
                catch { }
            }
        }
        catch { }
    }

    private void AddSetArg(List<string> args, string key, string value)
    {
        args.Add(key);
        args.Add(QuoteArg(value ?? ""));
    }

    private void SyncMaskRepairSliders(int value)
    {
        value = Clamp(value, 0, 100);
        if (maskProtectionSlider != null && maskProtectionSlider.Value != value) maskProtectionSlider.Value = value;
        if (maskAntighostSlider != null && maskAntighostSlider.Value != value) maskAntighostSlider.Value = value;
    }

    private void CommitMaskProtection()
    {
        if (maskProtectionSlider == null) return;
        SyncMaskRepairSliders(maskProtectionSlider.Value);
        UpdateMaskProtectionLabel();
        if (maskProtectionSlider.Value == lastSavedMaskProtection && maskProtectionSlider.Value == lastSavedMaskAntighost) return;
        lastSavedMaskProtection = maskProtectionSlider.Value;
        lastSavedMaskAntighost = maskProtectionSlider.Value;
        SaveSimple("mask_protection", maskProtectionSlider.Value.ToString(), false);
        SaveSimple("mask_antighost", maskProtectionSlider.Value.ToString(), false);
    }

    private void CommitMaskAntighost()
    {
        if (maskAntighostSlider == null) return;
        SyncMaskRepairSliders(maskAntighostSlider.Value);
        UpdateMaskAntighostLabel();
        if (maskAntighostSlider.Value == lastSavedMaskProtection && maskAntighostSlider.Value == lastSavedMaskAntighost) return;
        lastSavedMaskProtection = maskAntighostSlider.Value;
        lastSavedMaskAntighost = maskAntighostSlider.Value;
        SaveSimple("mask_protection", maskAntighostSlider.Value.ToString(), false);
        SaveSimple("mask_antighost", maskAntighostSlider.Value.ToString(), false);
    }

    private void CommitQuality()
    {
        if (qualitySlider == null) return;
        UpdateQualityLabel();
        if (qualitySlider.Value == lastSavedJpgQuality) return;
        lastSavedJpgQuality = qualitySlider.Value;
        SaveSimple("jpg_quality", qualitySlider.Value.ToString(), false);
    }

    private void CommitPhotoZoom()
    {
        if (photoZoomSlider == null) return;
        UpdatePhotoZoomLabel();
        FinishLivePreview();
        if (photoZoomSlider.Value == lastSavedPhotoZoom) return;
        lastSavedPhotoZoom = photoZoomSlider.Value;
        SaveSimple("person_zoom", photoZoomSlider.Value.ToString(), false);
    }

    private void CommitPersonVertical()
    {
        if (personVerticalSlider == null) return;
        UpdatePersonVerticalLabel();
        FinishLivePreview();
        if (personVerticalSlider.Value == lastSavedPersonVertical) return;
        lastSavedPersonVertical = personVerticalSlider.Value;
        SaveSimple("person_vertical", personVerticalSlider.Value.ToString(), false);
    }

    private void CommitOverlayScale()
    {
        if (overlayScaleSlider == null) return;
        UpdateOverlayScaleLabel();
        FinishLivePreview();
        if (overlayScaleSlider.Value == lastSavedOverlayScale) return;
        lastSavedOverlayScale = overlayScaleSlider.Value;
        string value = OverlayScaleValue().ToString("0.###", CultureInfo.InvariantCulture);
        SetStateValueLocal("overlay_scale", value);
        SaveSimple("overlay_scale", value, false);
    }

    private void CommitLogoScale()
    {
        if (logoScaleSlider == null) return;
        UpdateLogoScaleLabel();
        FinishLivePreview();
        if (logoScaleSlider.Value == lastSavedLogoScale) return;
        lastSavedLogoScale = logoScaleSlider.Value;
        string value = LogoScaleValue().ToString("0.###", CultureInfo.InvariantCulture);
        SetStateValueLocal("logo_scale", value);
        SaveSimple("logo_scale", value, false);
    }

    private void CommitHarmonize()
    {
        if (harmonizeSlider == null) return;
        UpdateHarmonizeLabel();
        FinishLivePreview();
        if (harmonizeSlider.Value == lastSavedHarmonize) return;
        lastSavedHarmonize = harmonizeSlider.Value;
        SaveSimple("harmonize_strength", harmonizeSlider.Value.ToString(), false);
    }

    private void CommitPhotoEnhance()
    {
        if (photoEnhanceSlider == null) return;
        UpdatePhotoEnhanceLabel();
        FinishLivePreview();
        if (photoEnhanceSlider.Value == lastSavedPhotoEnhance) return;
        lastSavedPhotoEnhance = photoEnhanceSlider.Value;
        SaveSimple("photo_enhance_strength", photoEnhanceSlider.Value.ToString(), false);
    }

    private void OpenPhotoEnhanceConfig()
    {
        Form dlg = new Form();
        dlg.Text = "Config mejora foto";
        dlg.StartPosition = FormStartPosition.CenterParent;
        dlg.FormBorderStyle = FormBorderStyle.Sizable;
        dlg.MinimumSize = new Size(1080, 760);
        dlg.MaximizeBox = true;
        dlg.MinimizeBox = false;
        dlg.ClientSize = new Size(1220, 820);
        dlg.BackColor = PageColor;
        dlg.Font = new Font("Segoe UI", 9F);
        dlg.HandleCreated += delegate { ApplyWindowBrandChrome(dlg); };

        Label title = new Label();
        title.Text = "Mejora foto local";
        title.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        title.ForeColor = TextColor;
        title.BackColor = PageColor;
        title.SetBounds(18, 14, 260, 28);
        dlg.Controls.Add(title);

        Label subtitle = new Label();
        subtitle.Text = "Ajustes finos tipo QEnhancer. Puedes comparar el motor clasico con QEnhance Auto v2.";
        subtitle.Font = new Font("Segoe UI", 9F, FontStyle.Regular);
        subtitle.ForeColor = MutedTextColor;
        subtitle.BackColor = PageColor;
        subtitle.SetBounds(18, 42, 740, 24);
        dlg.Controls.Add(subtitle);

        Panel presets = new Panel();
        presets.BackColor = PageColor;
        presets.SetBounds(18, 72, 584, 78);
        dlg.Controls.Add(presets);

        Label engineLabel = new Label();
        engineLabel.Text = "Motor";
        engineLabel.ForeColor = TextColor;
        engineLabel.BackColor = PageColor;
        engineLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        engineLabel.SetBounds(0, 2, 54, 22);
        presets.Controls.Add(engineLabel);

        ComboBox engineCombo = new ComboBox();
        StyleComboBox(engineCombo);
        engineCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        engineCombo.Items.AddRange(new string[] { "Classic (sliders)", "Enhancer2 (presets v2)", "Sin mejora" });
        engineCombo.SetBounds(56, 0, 158, 26);
        SelectComboValue(engineCombo, PhotoEnhanceEngineLabelFromId(Value("photo_enhance_engine")), PhotoEnhanceEngineLabelFromId("classic"));
        presets.Controls.Add(engineCombo);

        Label presetLabel = new Label();
        presetLabel.Text = "Preset v2";
        presetLabel.ForeColor = TextColor;
        presetLabel.BackColor = PageColor;
        presetLabel.Font = new Font("Segoe UI", 8.5F, FontStyle.Bold);
        presetLabel.SetBounds(232, 2, 88, 22);
        presets.Controls.Add(presetLabel);

        ComboBox enhancerPresetCombo = new ComboBox();
        StyleComboBox(enhancerPresetCombo);
        enhancerPresetCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        enhancerPresetCombo.Items.AddRange(new string[] {
            "Normal venta (color y contraste)",
            "Flash / quemadas (recupera luces)",
            "Souvenir familia (piel + blancos)",
            "Oscuras sin flash (levanta sombras)",
            "Exterior / color vivo",
            "Piel suave / recorte",
            "Final montaje suave"
        });
        enhancerPresetCombo.SetBounds(322, 0, 238, 26);
        SelectComboValue(enhancerPresetCombo, PhotoEnhancePresetLabelFromId(Value("photo_enhance_preset")), PhotoEnhancePresetLabelFromId("default_event"));
        presets.Controls.Add(enhancerPresetCombo);

        ToolTip sliderTips = new ToolTip();
        sliderTips.AutoPopDelay = 12000;
        sliderTips.InitialDelay = 350;
        sliderTips.ReshowDelay = 120;
        sliderTips.ShowAlways = true;

        Panel body = new Panel();
        body.BackColor = SurfaceColor;
        body.BorderStyle = BorderStyle.FixedSingle;
        body.AutoScroll = true;
        body.SetBounds(18, 158, 584, 592);
        body.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
        ApplyDarkScrollbarTheme(body);
        dlg.Controls.Add(body);

        Panel v2Panel = new Panel();
        v2Panel.BackColor = SurfaceColor;
        v2Panel.BorderStyle = BorderStyle.FixedSingle;
        v2Panel.SetBounds(18, 158, 584, 592);
        v2Panel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
        dlg.Controls.Add(v2Panel);

        Label v2ModeTitle = new Label();
        v2ModeTitle.Text = "Activo: Enhancer2";
        v2ModeTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        v2ModeTitle.ForeColor = TextColor;
        v2ModeTitle.BackColor = SurfaceColor;
        v2ModeTitle.SetBounds(18, 22, 520, 30);
        v2Panel.Controls.Add(v2ModeTitle);

        Label v2ModeText = new Label();
        v2ModeText.Font = new Font("Segoe UI", 9.5F, FontStyle.Regular);
        v2ModeText.ForeColor = MutedTextColor;
        v2ModeText.BackColor = SurfaceColor;
        v2ModeText.SetBounds(18, 62, 535, 92);
        v2ModeText.Text = "Preset v2 + fuerza general Mejora foto.";
        v2Panel.Controls.Add(v2ModeText);

        Panel previewPanel = new Panel();
        previewPanel.BackColor = SurfaceColor;
        previewPanel.BorderStyle = BorderStyle.FixedSingle;
        previewPanel.SetBounds(620, 118, 582, 632);
        previewPanel.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dlg.Controls.Add(previewPanel);

        Label previewTitle = new Label();
        previewTitle.Text = "Preview";
        previewTitle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        previewTitle.ForeColor = TextColor;
        previewTitle.BackColor = SurfaceColor;
        previewTitle.SetBounds(14, 12, 170, 24);
        previewPanel.Controls.Add(previewTitle);

        Label previewStatus = new Label();
        previewStatus.Text = "Preparando primera foto de IN...";
        previewStatus.Font = new Font("Segoe UI", 8.5F, FontStyle.Regular);
        previewStatus.ForeColor = MutedTextColor;
        previewStatus.BackColor = SurfaceColor;
        previewStatus.TextAlign = ContentAlignment.MiddleRight;
        previewStatus.SetBounds(190, 12, 370, 24);
        previewStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
        previewPanel.Controls.Add(previewStatus);

        PictureBox enhancePreviewBox = new PictureBox();
        enhancePreviewBox.BackColor = Color.FromArgb(8, 13, 24);
        enhancePreviewBox.BorderStyle = BorderStyle.FixedSingle;
        enhancePreviewBox.SizeMode = PictureBoxSizeMode.Zoom;
        enhancePreviewBox.SetBounds(14, 44, 552, 526);
        enhancePreviewBox.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        previewPanel.Controls.Add(enhancePreviewBox);

        Button previewPrev = Button("<");
        previewPrev.SetBounds(14, 584, 48, 32);
        previewPrev.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        previewPanel.Controls.Add(previewPrev);

        Button previewNext = Button(">");
        previewNext.SetBounds(518, 584, 48, 32);
        previewNext.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        previewPanel.Controls.Add(previewNext);

        Dictionary<string, FlatSlider> sliders = new Dictionary<string, FlatSlider>();
        int y = 14;
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_brightness", "Brillo", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_shadow_contrast", "Contraste sombras", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_highlight_contrast", "Contraste luces", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_saturation", "Saturacion", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_red", "Rojo", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_green", "Verde", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_blue", "Azul", -100, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_auto_brightness", "Auto brillo/contraste", 0, 150, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_auto_color", "Auto color", 0, 150, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_memory_color", "Color memorizado", 0, 150, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_shadows", "Levantar sombras", 0, 150, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_lights", "Control luces", 0, 150, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_global_sharpen", "Enfoque global", 0, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_local_sharpen", "Enfoque local", 0, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_denoise", "Reducir ruido", 0, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_desaturate_shadows", "Desaturar sombras", 0, 100, 5, y);
        y = AddPhotoEnhanceConfigSlider(body, sliders, sliderTips, "photo_enhance_hue_rotation", "Rotar color", -180, 180, 5, y);

        Button neutral = Button("Neutral");
        neutral.SetBounds(0, 42, 92, 32);
        neutral.Click += delegate { ApplyPhotoEnhancePreset(sliders, "neutral"); };
        presets.Controls.Add(neutral);

        Button cuevas = Button("Cuevas");
        cuevas.SetBounds(100, 42, 92, 32);
        cuevas.Click += delegate { ApplyPhotoEnhancePreset(sliders, "cuevas"); };
        presets.Controls.Add(cuevas);

        Button rescue = Button("Rescate");
        rescue.SetBounds(200, 42, 92, 32);
        rescue.Click += delegate { ApplyPhotoEnhancePreset(sliders, "rescate"); };
        presets.Controls.Add(rescue);

        EventHandler updatePresetButtons = delegate { UpdatePhotoEnhancePresetButtons(sliders, neutral, cuevas, rescue); };
        foreach (FlatSlider slider in sliders.Values)
        {
            slider.ValueChanged += updatePresetButtons;
        }
        UpdatePhotoEnhancePresetButtons(sliders, neutral, cuevas, rescue);

        Button cancel = Button("Cancelar");
        cancel.SetBounds(994, 766, 96, 34);
        cancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        cancel.Click += delegate { dlg.Close(); };
        dlg.Controls.Add(cancel);

        Button save = AccentButton("Guardar");
        save.SetBounds(1100, 766, 102, 34);
        save.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        save.Click += delegate
        {
            SavePhotoEnhanceConfig(sliders, engineCombo, enhancerPresetCombo);
            dlg.Close();
        };
        dlg.Controls.Add(save);

        System.Windows.Forms.Timer previewTimer = new System.Windows.Forms.Timer();
        previewTimer.Interval = 420;
        int[] previewIndex = new int[] { 0 };
        EventHandler schedulePreview = delegate
        {
            previewStatus.Text = "Actualizando...";
            previewTimer.Stop();
            previewTimer.Start();
        };
        previewTimer.Tick += delegate
        {
            previewTimer.Stop();
            RefreshPhotoEnhanceConfigPreview(sliders, enhancePreviewBox, previewStatus, previewIndex[0], engineCombo, enhancerPresetCombo);
        };
        foreach (FlatSlider slider in sliders.Values)
        {
            slider.ValueChanged += schedulePreview;
        }
        engineCombo.SelectedIndexChanged += delegate
        {
            UpdatePhotoEnhanceConfigModeUI(engineCombo, enhancerPresetCombo, body, v2Panel, v2ModeTitle, v2ModeText, neutral, cuevas, rescue);
            schedulePreview(engineCombo, EventArgs.Empty);
        };
        enhancerPresetCombo.SelectedIndexChanged += schedulePreview;

        previewPrev.Click += delegate
        {
            previewIndex[0]--;
            previewStatus.Text = "Foto anterior...";
            previewTimer.Stop();
            RefreshPhotoEnhanceConfigPreview(sliders, enhancePreviewBox, previewStatus, previewIndex[0], engineCombo, enhancerPresetCombo);
        };
        previewNext.Click += delegate
        {
            previewIndex[0]++;
            previewStatus.Text = "Foto siguiente...";
            previewTimer.Stop();
            RefreshPhotoEnhanceConfigPreview(sliders, enhancePreviewBox, previewStatus, previewIndex[0], engineCombo, enhancerPresetCombo);
        };

        UpdatePhotoEnhanceConfigModeUI(engineCombo, enhancerPresetCombo, body, v2Panel, v2ModeTitle, v2ModeText, neutral, cuevas, rescue);
        dlg.Shown += delegate { RefreshPhotoEnhanceConfigPreview(sliders, enhancePreviewBox, previewStatus, previewIndex[0], engineCombo, enhancerPresetCombo); };
        dlg.FormClosed += delegate
        {
            previewTimer.Stop();
            previewTimer.Dispose();
            ReplaceImage(enhancePreviewBox, null);
            sliderTips.Dispose();
        };

        dlg.ShowDialog(this);
        dlg.Dispose();
    }

    private int AddPhotoEnhanceConfigSlider(
        Panel parent,
        Dictionary<string, FlatSlider> sliders,
        ToolTip sliderTips,
        string key,
        string labelText,
        int min,
        int max,
        int step,
        int y
    )
    {
        Label label = new Label();
        label.Text = labelText;
        label.ForeColor = TextColor;
        label.BackColor = SurfaceColor;
        label.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        label.SetBounds(14, y + 8, 168, 22);
        parent.Controls.Add(label);
        string tooltip = PhotoEnhanceTooltip(key);
        if (!String.IsNullOrWhiteSpace(tooltip))
        {
            sliderTips.SetToolTip(label, tooltip);
        }

        FlatSlider slider = new FlatSlider();
        slider.Minimum = min;
        slider.Maximum = max;
        slider.Step = step;
        slider.Value = Clamp(ToInt(Value(key)), min, max);
        slider.BackColor = SurfaceColor;
        slider.SetBounds(190, y, 278, 36);
        parent.Controls.Add(slider);
        if (!String.IsNullOrWhiteSpace(tooltip))
        {
            sliderTips.SetToolTip(slider, tooltip);
        }

        Label valueLabel = new Label();
        valueLabel.Text = slider.Value.ToString();
        valueLabel.ForeColor = TextColor;
        valueLabel.BackColor = SurfaceColor;
        valueLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        valueLabel.TextAlign = ContentAlignment.MiddleRight;
        valueLabel.SetBounds(476, y + 7, 56, 22);
        parent.Controls.Add(valueLabel);

        slider.ValueChanged += delegate
        {
            valueLabel.Text = slider.Value.ToString();
        };

        sliders[key] = slider;
        return y + 44;
    }

    private string PhotoEnhanceTooltip(string key)
    {
        switch (key)
        {
            case "photo_enhance_brightness": return "Sube o baja la luminosidad general despues del montaje.";
            case "photo_enhance_shadow_contrast": return "Da mas cuerpo a zonas oscuras sin tocar tanto las luces.";
            case "photo_enhance_highlight_contrast": return "Recupera o refuerza contraste en zonas claras.";
            case "photo_enhance_saturation": return "Aumenta o reduce la intensidad de color.";
            case "photo_enhance_red": return "Compensa el canal rojo para calentar o enfriar pieles.";
            case "photo_enhance_green": return "Compensa dominantes verdes o magentas.";
            case "photo_enhance_blue": return "Compensa dominantes azules o amarillas.";
            case "photo_enhance_auto_brightness": return "Correccion automatica de brillo y contraste.";
            case "photo_enhance_auto_color": return "Neutraliza dominantes de color de forma automatica.";
            case "photo_enhance_memory_color": return "Protege tonos naturales como pieles y blancos.";
            case "photo_enhance_shadows": return "Levanta detalle en sombras profundas.";
            case "photo_enhance_lights": return "Controla altas luces para evitar blancos quemados.";
            case "photo_enhance_global_sharpen": return "Enfoque general de toda la imagen.";
            case "photo_enhance_local_sharpen": return "Microcontraste local para texturas y detalle fino.";
            case "photo_enhance_denoise": return "Reduce ruido, especialmente en fotos oscuras.";
            case "photo_enhance_desaturate_shadows": return "Quita color sucio de las sombras.";
            case "photo_enhance_hue_rotation": return "Gira el tono global si hay una dominante rara.";
        }
        return "";
    }

    private void RefreshPhotoEnhanceConfigPreview(Dictionary<string, FlatSlider> sliders, PictureBox previewBox, Label statusLabel, int previewIndex, ComboBox engineCombo, ComboBox enhancerPresetCombo)
    {
        if (previewBox == null || statusLabel == null) return;
        try
        {
            List<string> args = new List<string>();
            AddSetArg(args, "preview_index", previewIndex.ToString());
            int strength = photoEnhanceSlider == null ? ToInt(Value("photo_enhance_strength")) : photoEnhanceSlider.Value;
            AddSetArg(args, "photo_enhance_strength", strength.ToString());
            string engine = PhotoEnhanceEngineIdFromLabel(ComboValue(engineCombo, Value("photo_enhance_engine")));
            AddSetArg(args, "photo_enhance_engine", engine);
            AddSetArg(args, "photo_enhance_preset", PhotoEnhancePresetIdFromLabel(ComboValue(enhancerPresetCombo, Value("photo_enhance_preset"))));
            AddSetArg(args, "photo_enhance_autotune", Value("photo_enhance_autotune"));
            if (String.Equals(engine, "classic", StringComparison.OrdinalIgnoreCase))
            {
                foreach (KeyValuePair<string, FlatSlider> item in sliders)
                {
                    AddSetArg(args, item.Key, item.Value.Value.ToString());
                }
            }

            string output = RunPython("\"" + bridgePy + "\" preview_photo_enhance " + String.Join(" ", args.ToArray()), 12000);
            string previewPath = OutputLine(output, 0);
            string previewLabel = OutputLine(output, 1);
            if (!String.IsNullOrWhiteSpace(previewPath) && File.Exists(previewPath))
            {
                SetPicture(previewBox, previewPath);
                statusLabel.Text = String.IsNullOrWhiteSpace(previewLabel) ? "Preview actualizado" : previewLabel;
            }
            else
            {
                statusLabel.Text = "Sin preview";
            }
        }
        catch (Exception ex)
        {
            statusLabel.Text = "Preview no disponible";
            if (logBox != null && !String.IsNullOrWhiteSpace(ex.Message))
            {
                AddLog("Preview mejora foto: " + ex.Message.Trim());
            }
        }
    }

    private string OutputLine(string output, int wantedIndex)
    {
        if (String.IsNullOrWhiteSpace(output)) return "";
        string[] lines = output.Replace("\r", "").Split('\n');
        int current = 0;
        for (int i = 0; i < lines.Length; i++)
        {
            if (String.IsNullOrWhiteSpace(lines[i])) continue;
            if (current == wantedIndex) return lines[i].Trim();
            current++;
        }
        return "";
    }

    private void ApplyPhotoEnhancePreset(Dictionary<string, FlatSlider> sliders, string preset)
    {
        Dictionary<string, int> values = PhotoEnhancePresetValues(preset);
        foreach (KeyValuePair<string, int> item in values)
        {
            SetPhotoEnhanceSlider(sliders, item.Key, item.Value);
        }
    }

    private Dictionary<string, int> PhotoEnhancePresetValues(string preset)
    {
        Dictionary<string, int> values = new Dictionary<string, int>();
        if (String.Equals(preset, "neutral", StringComparison.OrdinalIgnoreCase))
        {
            values["photo_enhance_brightness"] = 0;
            values["photo_enhance_shadow_contrast"] = 0;
            values["photo_enhance_highlight_contrast"] = 0;
            values["photo_enhance_saturation"] = 0;
            values["photo_enhance_red"] = 0;
            values["photo_enhance_green"] = 0;
            values["photo_enhance_blue"] = 0;
            values["photo_enhance_auto_brightness"] = 100;
            values["photo_enhance_auto_color"] = 100;
            values["photo_enhance_memory_color"] = 100;
            values["photo_enhance_shadows"] = 100;
            values["photo_enhance_lights"] = 100;
            values["photo_enhance_global_sharpen"] = 0;
            values["photo_enhance_local_sharpen"] = 0;
            values["photo_enhance_denoise"] = 0;
            values["photo_enhance_desaturate_shadows"] = 0;
            values["photo_enhance_hue_rotation"] = 0;
            return values;
        }

        if (String.Equals(preset, "rescate", StringComparison.OrdinalIgnoreCase))
        {
            values["photo_enhance_brightness"] = 10;
            values["photo_enhance_shadow_contrast"] = 35;
            values["photo_enhance_highlight_contrast"] = 10;
            values["photo_enhance_saturation"] = 8;
            values["photo_enhance_red"] = 6;
            values["photo_enhance_green"] = -2;
            values["photo_enhance_blue"] = -3;
            values["photo_enhance_auto_brightness"] = 120;
            values["photo_enhance_auto_color"] = 80;
            values["photo_enhance_memory_color"] = 95;
            values["photo_enhance_shadows"] = 135;
            values["photo_enhance_lights"] = 65;
            values["photo_enhance_global_sharpen"] = 28;
            values["photo_enhance_local_sharpen"] = 15;
            values["photo_enhance_denoise"] = 65;
            values["photo_enhance_desaturate_shadows"] = 22;
            values["photo_enhance_hue_rotation"] = 0;
            return values;
        }

        values["photo_enhance_brightness"] = 4;
        values["photo_enhance_shadow_contrast"] = 30;
        values["photo_enhance_highlight_contrast"] = 18;
        values["photo_enhance_saturation"] = 8;
        values["photo_enhance_red"] = 3;
        values["photo_enhance_green"] = -1;
        values["photo_enhance_blue"] = -4;
        values["photo_enhance_auto_brightness"] = 130;
        values["photo_enhance_auto_color"] = 70;
        values["photo_enhance_memory_color"] = 90;
        values["photo_enhance_shadows"] = 115;
        values["photo_enhance_lights"] = 55;
        values["photo_enhance_global_sharpen"] = 22;
        values["photo_enhance_local_sharpen"] = 10;
        values["photo_enhance_denoise"] = 45;
        values["photo_enhance_desaturate_shadows"] = 14;
        values["photo_enhance_hue_rotation"] = 0;
        return values;
    }

    private void UpdatePhotoEnhancePresetButtons(Dictionary<string, FlatSlider> sliders, Button neutral, Button cuevas, Button rescue)
    {
        SetPhotoEnhancePresetButtonState(neutral, PhotoEnhancePresetMatches(sliders, "neutral"));
        SetPhotoEnhancePresetButtonState(cuevas, PhotoEnhancePresetMatches(sliders, "cuevas"));
        SetPhotoEnhancePresetButtonState(rescue, PhotoEnhancePresetMatches(sliders, "rescate"));
    }

    private bool PhotoEnhancePresetMatches(Dictionary<string, FlatSlider> sliders, string preset)
    {
        Dictionary<string, int> values = PhotoEnhancePresetValues(preset);
        foreach (KeyValuePair<string, int> item in values)
        {
            FlatSlider slider;
            if (!sliders.TryGetValue(item.Key, out slider)) return false;
            if (slider.Value != Clamp(item.Value, slider.Minimum, slider.Maximum)) return false;
        }
        return true;
    }

    private void SetPhotoEnhancePresetButtonState(Button button, bool activePreset)
    {
        if (button == null) return;
        ApplyButtonVisual(button, activePreset);
        button.Font = new Font("Segoe UI", 9F, activePreset ? FontStyle.Bold : FontStyle.Regular);
    }

    private void SetPhotoEnhanceSlider(Dictionary<string, FlatSlider> sliders, string key, int value)
    {
        FlatSlider slider;
        if (!sliders.TryGetValue(key, out slider)) return;
        slider.Value = Clamp(value, slider.Minimum, slider.Maximum);
    }

    private void SavePhotoEnhanceConfig(Dictionary<string, FlatSlider> sliders, ComboBox engineCombo, ComboBox enhancerPresetCombo)
    {
        List<string> args = new List<string>();
        string engine = PhotoEnhanceEngineIdFromLabel(ComboValue(engineCombo, "classic"));
        string preset = PhotoEnhancePresetIdFromLabel(ComboValue(enhancerPresetCombo, "default_event"));
        bool autotune = IsPhotoEnhanceAutoTuneEnabled();
        if (autotune) engine = "enhancer2";
        AddSetArg(args, "photo_enhance_engine", engine);
        AddSetArg(args, "photo_enhance_preset", preset);
        AddSetArg(args, "photo_enhance_autotune", autotune ? "true" : "false");
        SetStateValueLocal("photo_enhance_engine", engine);
        SetStateValueLocal("photo_enhance_preset", preset);
        SetStateValueLocal("photo_enhance_autotune", autotune ? "true" : "false");
        if (String.Equals(engine, "classic", StringComparison.OrdinalIgnoreCase))
        {
            foreach (KeyValuePair<string, FlatSlider> item in sliders)
            {
                AddSetArg(args, item.Key, item.Value.Value.ToString());
                SetStateValueLocal(item.Key, item.Value.Value.ToString());
            }
        }
        if (args.Count > 0)
        {
            RunPython("\"" + bridgePy + "\" set_many " + String.Join(" ", args.ToArray()));
        }
        QueueLivePreview();
    }

    private string ComboValue(ComboBox combo, string fallback)
    {
        if (combo != null && combo.SelectedItem != null)
        {
            return combo.SelectedItem.ToString();
        }
        return String.IsNullOrWhiteSpace(fallback) ? "" : fallback;
    }

    private string PhotoEnhancePresetIdFromLabel(string text)
    {
        string value = String.IsNullOrWhiteSpace(text) ? "default_event" : text.Trim();
        if (String.Equals(value, "Normal venta (color y contraste)", StringComparison.OrdinalIgnoreCase)) return "default_event";
        if (String.Equals(value, "Flash / quemadas (recupera luces)", StringComparison.OrdinalIgnoreCase)) return "pirates_flash";
        if (String.Equals(value, "Souvenir familia (piel + blancos)", StringComparison.OrdinalIgnoreCase)) return "souvenir_family_flash_perfect_v1";
        if (String.Equals(value, "Oscuras sin flash (levanta sombras)", StringComparison.OrdinalIgnoreCase)) return "cuevas_lowlight";
        if (String.Equals(value, "Exterior / color vivo", StringComparison.OrdinalIgnoreCase)) return "dinos_daylight";
        if (String.Equals(value, "Piel suave / recorte", StringComparison.OrdinalIgnoreCase)) return "ai_composite_subject";
        if (String.Equals(value, "Final montaje suave", StringComparison.OrdinalIgnoreCase)) return "final_composite_grade";
        return value;
    }

    private string PhotoEnhanceEngineIdFromLabel(string text)
    {
        string value = String.IsNullOrWhiteSpace(text) ? "classic" : text.Trim();
        if (String.Equals(value, "Classic (sliders)", StringComparison.OrdinalIgnoreCase)) return "classic";
        if (String.Equals(value, "Enhancer2 (presets v2)", StringComparison.OrdinalIgnoreCase)) return "enhancer2";
        if (String.Equals(value, "Sin mejora", StringComparison.OrdinalIgnoreCase)) return "none";
        if (String.Equals(value, "off", StringComparison.OrdinalIgnoreCase)) return "none";
        return value.ToLowerInvariant();
    }

    private string PhotoEnhanceEngineLabelFromId(string id)
    {
        string value = String.IsNullOrWhiteSpace(id) ? "classic" : id.Trim();
        if (String.Equals(value, "classic", StringComparison.OrdinalIgnoreCase)) return "Classic (sliders)";
        if (String.Equals(value, "enhancer2", StringComparison.OrdinalIgnoreCase)) return "Enhancer2 (presets v2)";
        if (String.Equals(value, "none", StringComparison.OrdinalIgnoreCase) || String.Equals(value, "off", StringComparison.OrdinalIgnoreCase)) return "Sin mejora";
        return value;
    }

    private string PhotoEnhancePresetLabelFromId(string id)
    {
        string value = String.IsNullOrWhiteSpace(id) ? "default_event" : id.Trim();
        if (String.Equals(value, "default_event", StringComparison.OrdinalIgnoreCase)) return "Normal venta (color y contraste)";
        if (String.Equals(value, "pirates_flash", StringComparison.OrdinalIgnoreCase)) return "Flash / quemadas (recupera luces)";
        if (String.Equals(value, "souvenir_family_flash_perfect_v1", StringComparison.OrdinalIgnoreCase)) return "Souvenir familia (piel + blancos)";
        if (String.Equals(value, "cuevas_lowlight", StringComparison.OrdinalIgnoreCase)) return "Oscuras sin flash (levanta sombras)";
        if (String.Equals(value, "dinos_daylight", StringComparison.OrdinalIgnoreCase)) return "Exterior / color vivo";
        if (String.Equals(value, "ai_composite_subject", StringComparison.OrdinalIgnoreCase)) return "Piel suave / recorte";
        if (String.Equals(value, "final_composite_grade", StringComparison.OrdinalIgnoreCase)) return "Final montaje suave";
        return value;
    }

    private void UpdatePhotoEnhanceConfigModeUI(ComboBox engineCombo, ComboBox enhancerPresetCombo, Panel classicPanel, Panel v2Panel, Label v2ModeTitle, Label v2ModeText, Button neutral, Button cuevas, Button rescue)
    {
        string engine = PhotoEnhanceEngineIdFromLabel(ComboValue(engineCombo, Value("photo_enhance_engine")));
        bool classic = String.Equals(engine, "classic", StringComparison.OrdinalIgnoreCase);
        bool v2 = String.Equals(engine, "enhancer2", StringComparison.OrdinalIgnoreCase);
        bool autotune = IsPhotoEnhanceAutoTuneEnabled();

        if (classicPanel != null)
        {
            classicPanel.Visible = classic;
            classicPanel.Enabled = classic;
        }
        if (v2Panel != null)
        {
            v2Panel.Visible = !classic;
            v2Panel.Enabled = !classic;
        }
        if (neutral != null) neutral.Visible = classic;
        if (cuevas != null) cuevas.Visible = classic;
        if (rescue != null) rescue.Visible = classic;
        if (enhancerPresetCombo != null) enhancerPresetCombo.Enabled = v2 && !autotune;

        if (v2ModeTitle != null)
        {
            v2ModeTitle.Text = v2 ? "Activo: Enhancer2" : "Activo: sin mejora";
        }
        if (v2ModeText != null)
        {
            if (v2 && autotune)
            {
                v2ModeText.Text = "AutoTune esta ON: el preset se decide automaticamente en cada foto. El combo de preset v2 queda apagado.";
            }
            else if (v2)
            {
                v2ModeText.Text = "Actua el preset v2 elegido arriba y la fuerza general Mejora foto. Los sliders clasicos no se mezclan en este modo.";
            }
            else
            {
                v2ModeText.Text = "La mejora de foto esta apagada para comparar con la imagen sin correccion.";
            }
        }
    }

    private void SelectComboValue(ComboBox combo, string value, string fallback)
    {
        if (combo == null || combo.Items.Count == 0) return;
        string selected = String.IsNullOrWhiteSpace(value) ? fallback : value;
        int index = combo.Items.IndexOf(selected);
        if (index < 0) index = combo.Items.IndexOf(fallback);
        combo.SelectedIndex = index >= 0 ? index : 0;
    }

    private void CommitTextLayer()
    {
        if (textLayerBox == null) return;
        SaveSimple("text_layer", textLayerBox.Text, false);
    }

    private void CommitTextLayerTransform()
    {
        if (textLayerScaleSlider != null)
        {
            SaveSimple("text_layer_scale", TextLayerScaleValue().ToString("0.###", CultureInfo.InvariantCulture), false);
        }
        if (textLayerRotationSlider != null)
        {
            SaveSimple("text_layer_rotation", textLayerRotationSlider.Value.ToString(), false);
        }
    }

    private double TextLayerScaleValue()
    {
        int value = textLayerScaleSlider != null ? textLayerScaleSlider.Value : (int)Math.Round(ToDouble(Value("text_layer_scale"), 1.0) * 100.0);
        return Math.Max(0.3, Math.Min(3.0, value / 100.0));
    }

    private string TextLayerFontName()
    {
        if (textLayerFontCombo != null && textLayerFontCombo.SelectedItem != null)
        {
            return textLayerFontCombo.SelectedItem.ToString();
        }
        string value = Value("text_layer_font");
        return String.IsNullOrWhiteSpace(value) ? "Segoe UI" : value;
    }

    private Font CreateTextLayerPreviewFont(float size)
    {
        if (Single.IsNaN(size) || Single.IsInfinity(size) || size < 1F) size = 14F;
        string fontName = TextLayerFontName();
        if (String.IsNullOrWhiteSpace(fontName)) fontName = "Segoe UI";
        try
        {
            return new Font(fontName, Math.Max(1F, size), FontStyle.Bold, GraphicsUnit.Pixel);
        }
        catch
        {
            try
            {
                return new Font("Segoe UI", Math.Max(1F, size), FontStyle.Bold, GraphicsUnit.Pixel);
            }
            catch
            {
                Font fallback = this.Font ?? SystemFonts.DefaultFont;
                return new Font(fallback.FontFamily, Math.Max(1F, size), FontStyle.Bold, GraphicsUnit.Pixel);
            }
        }
    }

    private void SelectTextLayerFont(string fontName)
    {
        if (textLayerFontCombo == null) return;
        string value = String.IsNullOrWhiteSpace(fontName) ? "Segoe UI" : fontName;
        int index = textLayerFontCombo.Items.IndexOf(value);
        if (index < 0) index = textLayerFontCombo.Items.IndexOf("Segoe UI");
        textLayerFontCombo.SelectedIndex = index >= 0 ? index : 0;
    }

    private string TextLayerColorValue()
    {
        string name = textLayerColorCombo != null && textLayerColorCombo.SelectedItem != null
            ? textLayerColorCombo.SelectedItem.ToString()
            : Value("text_layer_color");
        if (String.Equals(name, "Negro", StringComparison.OrdinalIgnoreCase)) return "#111111";
        if (String.Equals(name, "Amarillo", StringComparison.OrdinalIgnoreCase)) return "#FFD84A";
        if (String.Equals(name, "Naranja", StringComparison.OrdinalIgnoreCase)) return "#FF8A2B";
        if (String.Equals(name, "Rojo", StringComparison.OrdinalIgnoreCase)) return "#FF4D5E";
        if (String.Equals(name, "Rosa", StringComparison.OrdinalIgnoreCase)) return "#FF2DBA";
        if (String.Equals(name, "Azul", StringComparison.OrdinalIgnoreCase)) return "#2563EB";
        if (String.Equals(name, "Verde", StringComparison.OrdinalIgnoreCase)) return "#34D399";
        if (!String.IsNullOrWhiteSpace(name) && name.StartsWith("#", StringComparison.Ordinal)) return name;
        return "#FFFFFF";
    }

    private void SelectTextLayerColor(string colorValue)
    {
        if (textLayerColorCombo == null) return;
        string value = String.IsNullOrWhiteSpace(colorValue) ? "#FFFFFF" : colorValue;
        string name = "Blanco";
        if (String.Equals(value, "#111111", StringComparison.OrdinalIgnoreCase)) name = "Negro";
        else if (String.Equals(value, "#FFD84A", StringComparison.OrdinalIgnoreCase)) name = "Amarillo";
        else if (String.Equals(value, "#FF8A2B", StringComparison.OrdinalIgnoreCase)) name = "Naranja";
        else if (String.Equals(value, "#FF4D5E", StringComparison.OrdinalIgnoreCase)) name = "Rojo";
        else if (String.Equals(value, "#FF2DBA", StringComparison.OrdinalIgnoreCase)) name = "Rosa";
        else if (String.Equals(value, "#2563EB", StringComparison.OrdinalIgnoreCase)) name = "Azul";
        else if (String.Equals(value, "#34D399", StringComparison.OrdinalIgnoreCase)) name = "Verde";
        int index = textLayerColorCombo.Items.IndexOf(name);
        textLayerColorCombo.SelectedIndex = index >= 0 ? index : 0;
    }

    private Color TextLayerPreviewColor()
    {
        try
        {
            return ColorTranslator.FromHtml(TextLayerColorValue());
        }
        catch
        {
            return Color.White;
        }
    }

    private void CommitShadow()
    {
        if (shadowSlider == null) return;
        UpdateShadowLabel();
        if (shadowSlider.Value == lastSavedShadow) return;
        lastSavedShadow = shadowSlider.Value;
        SaveSimple("contact_shadow_strength", shadowSlider.Value.ToString(), false);
    }

    private void SelectFolder(string key, TextBox box)
    {
        FolderBrowserDialog dlg = new FolderBrowserDialog();
        dlg.SelectedPath = AbsPath(box.Text);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            box.Text = dlg.SelectedPath;
            SaveSimple(key, dlg.SelectedPath, true);
        }
    }

    private void SelectAssetFile(string key)
    {
        if (key == "background")
        {
            SelectBackgroundFiles();
            return;
        }

        OpenFileDialog dlg = new OpenFileDialog();
        dlg.Filter = (key == "overlay" || key == "logo") ? "PNG|*.png" : "Imagen|*.jpg;*.jpeg;*.png";
        dlg.Multiselect = false;
        string destDir = key == "overlay"
            ? Path.Combine(appDir, "assets", "overlays")
            : key == "logo"
                ? Path.Combine(appDir, "assets", "logos")
                : Path.Combine(appDir, "assets", "backgrounds");
        Directory.CreateDirectory(destDir);
        dlg.InitialDirectory = AssetDialogInitialDirectory(key, destDir);
        dlg.RestoreDirectory = true;
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        Directory.CreateDirectory(destDir);

        RememberAssetDialogDirectory(key, dlg.FileName);
        string selectedTarget = "";
        foreach (string fileName in dlg.FileNames)
        {
            string target = UniquePath(Path.Combine(destDir, Path.GetFileName(fileName)));
            File.Copy(fileName, target);
            selectedTarget = target;
        }
        if (String.IsNullOrWhiteSpace(selectedTarget)) return;

        if (key != "overlay" && key != "logo") ClearPreviewBase();
        if (key == "overlay") ClearOverlayCache();
        if (key == "logo") ClearLogoCache();
        SaveSimple(key, selectedTarget, true);
        if (key == "overlay")
        {
            FitOverlayToBackgroundWidth(selectedTarget, true);
        }
        DrawScenePreviewImmediate();
    }

    private void SelectBackgroundFiles()
    {
        string key = "background";
        string destDir = Path.Combine(appDir, "assets", "backgrounds");
        Directory.CreateDirectory(destDir);

        OpenFileDialog dlg = new OpenFileDialog();
        dlg.Title = "Seleccionar uno o varios fondos";
        dlg.Filter = "Imagenes|*.jpg;*.jpeg;*.png|Todos los archivos|*.*";
        dlg.Multiselect = true;
        dlg.CheckFileExists = true;
        dlg.CheckPathExists = true;
        dlg.InitialDirectory = AssetDialogInitialDirectory(key, destDir);
        dlg.RestoreDirectory = true;

        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        string[] selectedFiles = dlg.FileNames;
        if (selectedFiles == null || selectedFiles.Length == 0)
        {
            selectedFiles = new string[] { dlg.FileName };
        }

        RememberAssetDialogDirectory(key, selectedFiles[0]);

        string selectedTarget = "";
        foreach (string fileName in selectedFiles)
        {
            if (String.IsNullOrWhiteSpace(fileName) || !File.Exists(fileName)) continue;
            string target = UniquePath(Path.Combine(destDir, Path.GetFileName(fileName)));
            File.Copy(fileName, target);
            selectedTarget = target;
        }
        if (String.IsNullOrWhiteSpace(selectedTarget)) return;

        ClearPreviewBase();
        SaveSimple(key, selectedTarget, true);
        DrawScenePreviewImmediate();
    }

    private string AssetDialogInitialDirectory(string key, string fallbackDir)
    {
        string remembered;
        if (lastAssetDialogDirs.TryGetValue(key, out remembered) && Directory.Exists(remembered))
        {
            return remembered;
        }
        return fallbackDir;
    }

    private void RememberAssetDialogDirectory(string key, string selectedFile)
    {
        try
        {
            string dir = Path.GetDirectoryName(selectedFile);
            if (!String.IsNullOrWhiteSpace(dir) && Directory.Exists(dir))
            {
                lastAssetDialogDirs[key] = dir;
            }
        }
        catch { }
    }

    private void AddPhotos()
    {
        OpenFileDialog dlg = new OpenFileDialog();
        dlg.Filter = "JPG|*.jpg;*.jpeg";
        dlg.Multiselect = true;
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        string input = Value("input_abs");
        Directory.CreateDirectory(input);
        int copied = 0;
        foreach (string file in dlg.FileNames)
        {
            string target = UniquePath(Path.Combine(input, Path.GetFileName(file)));
            File.Copy(file, target);
            copied++;
        }
        if (progressLabel != null) progressLabel.Text = copied + " foto(s) anadidas.";
        ClearPreviewBase();
        LoadState();
    }

    private string UniquePath(string path)
    {
        if (!File.Exists(path)) return path;
        string dir = Path.GetDirectoryName(path);
        string name = Path.GetFileNameWithoutExtension(path);
        string ext = Path.GetExtension(path);
        for (int i = 1; i < 10000; i++)
        {
            string candidate = Path.Combine(dir, name + "_" + i.ToString("000") + ext);
            if (!File.Exists(candidate)) return candidate;
        }
        return path;
    }

    private string AbsPath(string value)
    {
        if (String.IsNullOrWhiteSpace(value)) return appDir;
        return Path.IsPathRooted(value) ? value : Path.Combine(appDir, value.Replace('/', '\\'));
    }

    private void OpenFolder(string path)
    {
        if (String.IsNullOrWhiteSpace(path)) return;
        string folder = AbsPath(path);
        Directory.CreateDirectory(folder);
        if (FocusExistingExplorerFolder(folder)) return;
        Process.Start("explorer.exe", QuoteArg(folder));
    }

    private bool FocusExistingExplorerFolder(string folder)
    {
        object shell = null;
        object windows = null;
        try
        {
            string target = NormalizeFolderPath(folder);
            Type shellType = Type.GetTypeFromProgID("Shell.Application");
            if (shellType == null) return false;
            shell = Activator.CreateInstance(shellType);
            windows = shellType.InvokeMember(
                "Windows",
                System.Reflection.BindingFlags.InvokeMethod,
                null,
                shell,
                null);

            System.Collections.IEnumerable enumerable = windows as System.Collections.IEnumerable;
            if (enumerable == null) return false;
            foreach (object window in enumerable)
            {
                try
                {
                    Type windowType = window.GetType();
                    object urlObj = windowType.InvokeMember(
                        "LocationURL",
                        System.Reflection.BindingFlags.GetProperty,
                        null,
                        window,
                        null);
                    string windowPath = FolderPathFromExplorerUrl(Convert.ToString(urlObj));
                    if (!String.Equals(NormalizeFolderPath(windowPath), target, StringComparison.OrdinalIgnoreCase)) continue;

                    object hwndObj = windowType.InvokeMember(
                        "HWND",
                        System.Reflection.BindingFlags.GetProperty,
                        null,
                        window,
                        null);
                    IntPtr hwnd = HwndFromComValue(hwndObj);
                    if (hwnd == IntPtr.Zero) continue;
                    ShowWindow(hwnd, SW_RESTORE);
                    SetForegroundWindow(hwnd);
                    return true;
                }
                catch { }
            }
        }
        catch { }
        finally
        {
            try { if (windows != null && Marshal.IsComObject(windows)) Marshal.ReleaseComObject(windows); } catch { }
            try { if (shell != null && Marshal.IsComObject(shell)) Marshal.ReleaseComObject(shell); } catch { }
        }
        return false;
    }

    private string FolderPathFromExplorerUrl(string locationUrl)
    {
        if (String.IsNullOrWhiteSpace(locationUrl)) return "";
        try
        {
            Uri uri = new Uri(locationUrl);
            if (uri.IsFile) return uri.LocalPath;
        }
        catch { }
        return locationUrl;
    }

    private string NormalizeFolderPath(string path)
    {
        if (String.IsNullOrWhiteSpace(path)) return "";
        try
        {
            return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        }
        catch
        {
            return path.TrimEnd('\\', '/');
        }
    }

    private IntPtr HwndFromComValue(object value)
    {
        if (value == null) return IntPtr.Zero;
        try
        {
            long hwnd = Convert.ToInt64(value, CultureInfo.InvariantCulture);
            return hwnd == 0 ? IntPtr.Zero : new IntPtr(hwnd);
        }
        catch
        {
            return IntPtr.Zero;
        }
    }

    private void DrawPreview()
    {
        ClearPreviewBase();
        DrawScenePreviewImmediate();
    }

    private string ExtractExistingPath(string text)
    {
        if (String.IsNullOrWhiteSpace(text)) return "";
        string[] lines = text.Replace("\r", "").Split('\n');
        for (int i = lines.Length - 1; i >= 0; i--)
        {
            string candidate = lines[i].Trim().Trim('"');
            if (candidate.Length == 0) continue;
            if (File.Exists(candidate)) return candidate;
        }
        return text.Trim();
    }

    private void DrawScenePreviewImmediate()
    {
        if (previewBox == null) return;
        if (!adjustingCenterLayout) AdjustCenterLayout();
        int w = Math.Max(1, previewBox.ClientSize.Width);
        int h = Math.Max(1, previewBox.ClientSize.Height);
        Size baseSize = CurrentPreviewBaseSize();
        if (baseSize.Width <= 0 || baseSize.Height <= 0) baseSize = new Size(1600, 1000);
        Bitmap bmp = new Bitmap(w, h);
        bool fastPreview = overlayDragging || livePreviewFast;
        using (Graphics g = Graphics.FromImage(bmp))
        {
            g.Clear(Color.FromArgb(15, 26, 32));
            if (overlayDragging || livePreviewFast)
            {
                g.SmoothingMode = SmoothingMode.None;
                g.InterpolationMode = InterpolationMode.Low;
                g.PixelOffsetMode = PixelOffsetMode.None;
            }
            else
            {
                g.SmoothingMode = SmoothingMode.HighQuality;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            }

            Rectangle sceneRect = FitRect(baseSize, new Rectangle(0, 0, w, h));
            lastScenePreviewRect = sceneRect;
            if (fastPreview)
            {
                if (!DrawCachedPreviewBase(g, w, h, sceneRect, baseSize))
                {
                    DrawPreviewBaseOnly(g, sceneRect, baseSize, new Size(w, h));
                }
            }
            else
            {
                DrawPreviewBaseOnly(g, sceneRect, baseSize, new Size(w, h));
            }
            DrawOverlayInside(g, sceneRect, baseSize);
            DrawLogoInside(g, sceneRect, baseSize);
            DrawTextLayerInside(g, sceneRect, baseSize);
        }
        ReplaceImage(previewBox, bmp);
    }

    private void QueueEnhancedRenderedPreview()
    {
        if (previewBox == null || previewBox.IsDisposed) return;
        string key = EnhancedPreviewKey();
        if (String.Equals(enhancedPreviewRenderedKey, key, StringComparison.Ordinal)) return;
        enhancedPreviewRevision++;
        if (enhancedPreviewRunning) return;
        StartEnhancedRenderedPreview(enhancedPreviewRevision, key, EnhancedPreviewArgs());
    }

    private void StartEnhancedRenderedPreview(int revision, string key, string[] args)
    {
        enhancedPreviewRunning = true;
        ThreadPool.QueueUserWorkItem(delegate
        {
            try
            {
                string output = RunPython("\"" + bridgePy + "\" preview_fast " + String.Join(" ", args), 18000);
                string previewPath = ExtractExistingPath(output);
                BeginInvoke((MethodInvoker)delegate
                {
                    if (IsDisposed || previewBox == null || previewBox.IsDisposed) return;
                    enhancedPreviewRunning = false;
                    if (revision != enhancedPreviewRevision)
                    {
                        QueueEnhancedRenderedPreview();
                        return;
                    }
                    if (!String.IsNullOrWhiteSpace(previewPath) && File.Exists(previewPath))
                    {
                        SetPicture(previewBox, previewPath);
                        enhancedPreviewRenderedKey = key;
                    }
                });
            }
            catch
            {
                try
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        enhancedPreviewRunning = false;
                    });
                }
                catch { enhancedPreviewRunning = false; }
            }
        });
    }

    private string[] EnhancedPreviewArgs()
    {
        List<string> args = new List<string>();
        int maxSide = previewBox == null ? 560 : Math.Max(360, Math.Min(760, Math.Max(previewBox.ClientSize.Width, previewBox.ClientSize.Height)));
        AddSetArg(args, "max_side", maxSide.ToString(CultureInfo.InvariantCulture));
        AddSetArg(args, "photo_enhance_strength", photoEnhanceSlider == null ? Value("photo_enhance_strength") : photoEnhanceSlider.Value.ToString());
        AddSetArg(args, "photo_enhance_engine", Value("photo_enhance_engine"));
        AddSetArg(args, "photo_enhance_preset", Value("photo_enhance_preset"));
        AddSetArg(args, "photo_enhance_autotune", Value("photo_enhance_autotune"));
        AddSetArg(args, "selected_input", CurrentFirstInputForPreview());
        return args.ToArray();
    }

    private string EnhancedPreviewKey()
    {
        return String.Join("|", new string[]
        {
            CurrentFirstInputForPreview(),
            Value("background_abs"),
            Value("overlay_abs"),
            Value("logo_abs"),
            Value("overlay_x"),
            Value("overlay_y"),
            Value("overlay_scale"),
            Value("overlay_mode"),
            Value("logo_x"),
            Value("logo_y"),
            Value("logo_scale"),
            Value("person_zoom"),
            Value("person_vertical"),
            Value("harmonize_strength"),
            photoEnhanceSlider == null ? Value("photo_enhance_strength") : photoEnhanceSlider.Value.ToString(),
            Value("photo_enhance_engine"),
            Value("photo_enhance_preset"),
            Value("photo_enhance_autotune"),
            previewBox == null ? "" : previewBox.ClientSize.ToString()
        });
    }

    private bool DrawCachedPreviewBase(Graphics target, int width, int height, Rectangle sceneRect, Size baseSize)
    {
        try
        {
            string key = PreviewBaseCacheKey(width, height, sceneRect, baseSize);
            if (previewSceneBaseBitmap == null || !String.Equals(previewSceneBaseKey, key, StringComparison.Ordinal))
            {
                ClearPreviewSceneBaseCache();
                previewSceneBaseBitmap = new Bitmap(Math.Max(1, width), Math.Max(1, height));
                using (Graphics g = Graphics.FromImage(previewSceneBaseBitmap))
                {
                    g.Clear(Color.FromArgb(15, 26, 32));
                    g.SmoothingMode = SmoothingMode.None;
                    g.InterpolationMode = InterpolationMode.Low;
                    g.PixelOffsetMode = PixelOffsetMode.None;
                    DrawPreviewBaseOnly(g, sceneRect, baseSize, new Size(width, height));
                }
                previewSceneBaseKey = key;
            }
            if (previewSceneBaseBitmap == null) return false;
            target.DrawImageUnscaled(previewSceneBaseBitmap, 0, 0);
            return true;
        }
        catch
        {
            ClearPreviewSceneBaseCache();
            return false;
        }
    }

    private void DrawPreviewBaseOnly(Graphics g, Rectangle sceneRect, Size baseSize, Size canvasSize)
    {
        string bg = Value("background_abs");
        string first = CurrentFirstInputForPreview();
        if ((String.IsNullOrWhiteSpace(bg) || !File.Exists(bg)) &&
            !String.IsNullOrWhiteSpace(first) &&
            File.Exists(first))
        {
            Bitmap image = GetPreviewBaseImage(first);
            if (image != null)
            {
                g.DrawImage(image, sceneRect);
            }
            return;
        }

        if (!String.IsNullOrWhiteSpace(bg) && File.Exists(bg))
        {
            Bitmap image = GetPreviewBaseImage(bg);
            if (image != null)
            {
                DrawCoverImage(g, image, sceneRect, baseSize);
            }
            DrawFastSubjectInside(g, sceneRect);
            return;
        }

        if (previewBaseSourceBitmap != null)
        {
            Rectangle sourceRect = FitRect(previewBaseSourceBitmap.Size, new Rectangle(0, 0, canvasSize.Width, canvasSize.Height));
            lastScenePreviewRect = sourceRect;
            g.DrawImage(previewBaseSourceBitmap, sourceRect);
            return;
        }
        DrawFastSubjectInside(g, sceneRect);
    }

    private Bitmap GetPreviewBaseImage(string path)
    {
        if (String.IsNullOrWhiteSpace(path) || !File.Exists(path)) return null;
        try
        {
            string full = Path.GetFullPath(path);
            if (previewBaseSourceBitmap != null &&
                String.Equals(previewBaseSourcePath, full, StringComparison.OrdinalIgnoreCase))
            {
                return previewBaseSourceBitmap;
            }

            ClearPreviewBaseImageOnly();
            previewBaseSourceBitmap = LoadBitmapWithExifOrientation(full);
            previewBaseSourcePath = full;
            return previewBaseSourceBitmap;
        }
        catch
        {
            ClearPreviewBaseImageOnly();
            return null;
        }
    }

    private string PreviewBaseCacheKey(int width, int height, Rectangle sceneRect, Size baseSize)
    {
        return String.Join("|", new string[]
        {
            width.ToString(CultureInfo.InvariantCulture),
            height.ToString(CultureInfo.InvariantCulture),
            sceneRect.ToString(),
            baseSize.ToString(),
            previewBaseSourcePath ?? "",
            Value("background_abs"),
            CurrentFirstInputForPreview(),
            Value("latest_processed"),
            Value("latest_output"),
            Value("person_zoom"),
            Value("person_vertical"),
            Value("harmonize_strength"),
            IsHotfolderRunning() ? "hot" : "manual"
        });
    }

    private void ClearPreviewBase()
    {
        ClearPreviewBaseImageOnly();
        ClearPreviewSceneBaseCache();
    }

    private void ClearPreviewBaseImageOnly()
    {
        if (previewBaseSourceBitmap != null)
        {
            previewBaseSourceBitmap.Dispose();
            previewBaseSourceBitmap = null;
        }
        previewBaseSourcePath = "";
        cachedPreviewBaseSize = Size.Empty;
        cachedPreviewBaseSizeKey = "";
        cachedBackgroundSourceSize = Size.Empty;
        cachedBackgroundSourceSizePath = "";
    }

    private void ClearPreviewSceneBaseCache()
    {
        if (previewSceneBaseBitmap != null)
        {
            previewSceneBaseBitmap.Dispose();
            previewSceneBaseBitmap = null;
        }
        previewSceneBaseKey = "";
    }

    private void ClearOverlayCache()
    {
        if (overlaySourceBitmap != null)
        {
            overlaySourceBitmap.Dispose();
            overlaySourceBitmap = null;
        }
        overlaySourcePath = "";
    }

    private void ClearLogoCache()
    {
        if (logoSourceBitmap != null)
        {
            logoSourceBitmap.Dispose();
            logoSourceBitmap = null;
        }
        logoSourcePath = "";
        ClearLogoPreviewCache();
    }

    private void ClearLogoPreviewCache()
    {
        if (logoPreviewBitmap != null)
        {
            logoPreviewBitmap.Dispose();
            logoPreviewBitmap = null;
        }
        logoPreviewKey = "";
    }

    private void SetPreviewBasePicture(string path)
    {
        try
        {
            ClearPreviewBase();
            previewBaseSourceBitmap = LoadBitmapWithExifOrientation(path);
            previewBaseSourcePath = path;
        }
        catch
        {
            ClearPreviewBase();
        }
    }

    private Bitmap LoadBitmapWithExifOrientation(string path)
    {
        using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
        using (Image src = Image.FromStream(stream, true, false))
        {
            Bitmap bitmap = new Bitmap(src);
            ApplyExifOrientation(src, bitmap);
            return bitmap;
        }
    }

    private Bitmap LoadBitmapUnlocked(string path)
    {
        using (FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
        using (Image src = Image.FromStream(stream, true, false))
        {
            return new Bitmap(src);
        }
    }

    private void ApplyExifOrientation(Image source, Bitmap bitmap)
    {
        const int orientationId = 0x0112;
        try
        {
            if (Array.IndexOf(source.PropertyIdList, orientationId) < 0) return;
            byte[] value = source.GetPropertyItem(orientationId).Value;
            if (value == null || value.Length < 2) return;

            switch (BitConverter.ToUInt16(value, 0))
            {
                case 2:
                    bitmap.RotateFlip(RotateFlipType.RotateNoneFlipX);
                    break;
                case 3:
                    bitmap.RotateFlip(RotateFlipType.Rotate180FlipNone);
                    break;
                case 4:
                    bitmap.RotateFlip(RotateFlipType.Rotate180FlipX);
                    break;
                case 5:
                    bitmap.RotateFlip(RotateFlipType.Rotate90FlipX);
                    break;
                case 6:
                    bitmap.RotateFlip(RotateFlipType.Rotate90FlipNone);
                    break;
                case 7:
                    bitmap.RotateFlip(RotateFlipType.Rotate270FlipX);
                    break;
                case 8:
                    bitmap.RotateFlip(RotateFlipType.Rotate270FlipNone);
                    break;
            }

            try { bitmap.RemovePropertyItem(orientationId); } catch { }
        }
        catch { }
    }

    private void DrawFastSubjectInside(Graphics g, Rectangle sceneRect)
    {
        if (IsHotfolderRunning()) return;
        string first = CurrentFirstInputForPreview();
        if (String.IsNullOrWhiteSpace(first) || !File.Exists(first)) return;
        Image subject = GetPreviewSubjectImage(first);
        if (subject == null) return;

        double scale = Math.Max(0.2, Math.Min(2.5, ToInt(Value("person_zoom")) / 100.0));
        int offsetY = ToInt(Value("person_vertical"));
        int offsetX = 0;

        Rectangle fitRect = FitRect(subject.Size, sceneRect);
        int drawW = Math.Max(1, (int)Math.Round(fitRect.Width * scale));
        int drawH = Math.Max(1, (int)Math.Round(fitRect.Height * scale));
        int x = sceneRect.Left + (int)Math.Round((sceneRect.Width - drawW) / 2.0 + sceneRect.Width * offsetX / 100.0);
        int y = sceneRect.Top + (int)Math.Round((sceneRect.Height - drawH) / 2.0 + sceneRect.Height * offsetY / 100.0);
        Rectangle subjectRect = new Rectangle(x, y, drawW, drawH);

        DrawSubjectPreviewImage(g, subject, subjectRect, 0.94F);
    }

    private void DrawSubjectPreviewImage(Graphics g, Image image, Rectangle dest, float opacity)
    {
        int harmonize = harmonizeSlider != null ? harmonizeSlider.Value : ToInt(Value("harmonize_strength"));
        float strength = Math.Max(0F, Math.Min(2F, harmonize / 100F));
        if (strength <= 0.001F)
        {
            DrawImageWithOpacity(g, image, dest, opacity);
            return;
        }

        Color avg = GetHarmonizeBackgroundAverage();
        float darken = 1F - 0.08F * strength;
        float rGain = 1F + ((avg.R - 128F) / 255F) * 0.24F * strength;
        float gGain = 1F + ((avg.G - 128F) / 255F) * 0.16F * strength;
        float bGain = 1F + ((avg.B - 128F) / 255F) * 0.24F * strength;
        float rLift = ((avg.R - 128F) / 255F) * 0.07F * strength;
        float gLift = ((avg.G - 128F) / 255F) * 0.05F * strength;
        float bLift = ((avg.B - 128F) / 255F) * 0.07F * strength;

        ColorMatrix matrix = new ColorMatrix(new float[][]
        {
            new float[] { rGain * darken, 0F, 0F, 0F, 0F },
            new float[] { 0F, gGain * darken, 0F, 0F, 0F },
            new float[] { 0F, 0F, bGain * darken, 0F, 0F },
            new float[] { 0F, 0F, 0F, Math.Max(0F, Math.Min(1F, opacity)), 0F },
            new float[] { rLift, gLift, bLift, 0F, 1F }
        });

        using (ImageAttributes attributes = new ImageAttributes())
        {
            attributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            g.DrawImage(
                image,
                dest,
                0,
                0,
                image.Width,
                image.Height,
                GraphicsUnit.Pixel,
                attributes
            );
        }
    }

    private Color GetHarmonizeBackgroundAverage()
    {
        string path = Value("background_abs");
        if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            path = AbsPath(Value("background"));
        }
        if (String.IsNullOrWhiteSpace(path) || !File.Exists(path))
        {
            return Color.FromArgb(128, 128, 128);
        }

        try
        {
            string full = Path.GetFullPath(path);
            if (!harmonizeBackgroundAverage.IsEmpty && String.Equals(harmonizeBackgroundSourcePath, full, StringComparison.OrdinalIgnoreCase))
            {
                return harmonizeBackgroundAverage;
            }

            using (Image source = LoadBitmapUnlocked(full))
            using (Bitmap small = new Bitmap(24, 24))
            using (Graphics sampleGraphics = Graphics.FromImage(small))
            {
                sampleGraphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
                sampleGraphics.DrawImage(source, new Rectangle(0, 0, small.Width, small.Height));
                long r = 0;
                long g = 0;
                long b = 0;
                int count = 0;
                for (int y = 0; y < small.Height; y++)
                {
                    for (int x = 0; x < small.Width; x++)
                    {
                        Color pixel = small.GetPixel(x, y);
                        r += pixel.R;
                        g += pixel.G;
                        b += pixel.B;
                        count++;
                    }
                }
                if (count <= 0) return Color.FromArgb(128, 128, 128);
                harmonizeBackgroundAverage = Color.FromArgb((int)(r / count), (int)(g / count), (int)(b / count));
                harmonizeBackgroundSourcePath = full;
                return harmonizeBackgroundAverage;
            }
        }
        catch
        {
            harmonizeBackgroundSourcePath = "";
            harmonizeBackgroundAverage = Color.FromArgb(128, 128, 128);
            return harmonizeBackgroundAverage;
        }
    }

    private void DrawPreviewContactShadow(Graphics g, Rectangle sceneRect, Rectangle subjectRect)
    {
        int strength = shadowSlider != null ? shadowSlider.Value : ToInt(Value("contact_shadow_strength"));
        if (strength <= 0 || subjectRect.Width <= 0 || subjectRect.Height <= 0) return;

        double normalized = Math.Max(0.0, Math.Min(2.0, strength / 100.0));
        double previewPower = Math.Max(0.0, Math.Min(4.0, strength / 50.0));
        double curve = Math.Pow(previewPower, 0.72);
        int centerX = subjectRect.Left + subjectRect.Width / 2;
        int footY = subjectRect.Bottom - Math.Max(4, (int)Math.Round(subjectRect.Height * 0.055));
        int width = Math.Max(24, (int)Math.Round(subjectRect.Width * (0.46 + normalized * 0.08)));
        int height = Math.Max(8, (int)Math.Round(sceneRect.Height * (0.026 + normalized * 0.008)));
        int baseAlpha = Math.Max(8, Math.Min(185, (int)Math.Round(78 * curve)));

        GraphicsState state = g.Save();
        try
        {
            g.SetClip(sceneRect);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            for (int i = 5; i >= 1; i--)
            {
                double spread = 1.0 + i * 0.22;
                int w = Math.Max(1, (int)Math.Round(width * spread));
                int h = Math.Max(1, (int)Math.Round(height * spread));
                int alpha = Math.Max(1, baseAlpha / (i + 1));
                using (SolidBrush brush = new SolidBrush(Color.FromArgb(alpha, 0, 0, 0)))
                {
                    g.FillEllipse(
                        brush,
                        centerX - w / 2,
                        footY - h / 2,
                        w,
                        h
                    );
                }
            }

            int contactW = Math.Max(14, (int)Math.Round(subjectRect.Width * 0.32));
            int contactH = Math.Max(4, (int)Math.Round(height * 0.38));
            int contactAlpha = Math.Min(155, (int)Math.Round(baseAlpha * 1.05));
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(contactAlpha, 0, 0, 0)))
            {
                g.FillEllipse(
                    brush,
                    centerX - contactW / 2,
                    footY - contactH / 2,
                    contactW,
                    contactH
                );
            }
        }
        finally
        {
            g.Restore(state);
        }
    }

    private Image GetPreviewSubjectImage(string path)
    {
        try
        {
            string full = Path.GetFullPath(path);
            string cacheKey = full + "|preview-cutout";
            if (previewSubjectSourceBitmap != null && String.Equals(previewSubjectSourcePath, cacheKey, StringComparison.OrdinalIgnoreCase))
            {
                return previewSubjectSourceBitmap;
            }
            ClearPreviewSubjectCache();
            using (Bitmap original = LoadBitmapWithExifOrientation(full))
            {
                previewSubjectSourceBitmap = CreateFastPreviewSubjectCutout(original);
            }
            previewSubjectSourcePath = cacheKey;
            return previewSubjectSourceBitmap;
        }
        catch
        {
            ClearPreviewSubjectCache();
            return null;
        }
    }

    private void ClearPreviewSubjectCache()
    {
        if (previewSubjectSourceBitmap != null)
        {
            previewSubjectSourceBitmap.Dispose();
            previewSubjectSourceBitmap = null;
        }
        previewSubjectSourcePath = "";
        ClearPreviewSceneBaseCache();
    }

    private int CurrentMaskProtection()
    {
        if (maskProtectionSlider != null) return Math.Max(0, Math.Min(100, maskProtectionSlider.Value));
        return Math.Max(0, Math.Min(100, ToInt(Value("mask_protection"))));
    }

    private Bitmap CreateFastPreviewSubjectCutout(Image source)
    {
        int maxSide = 760;
        double ratio = Math.Min(1.0, maxSide / (double)Math.Max(source.Width, source.Height));
        int w = Math.Max(1, (int)Math.Round(source.Width * ratio));
        int h = Math.Max(1, (int)Math.Round(source.Height * ratio));

        Bitmap bitmap = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        using (Graphics g = Graphics.FromImage(bitmap))
        {
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(source, new Rectangle(0, 0, w, h));
        }

        int baseAlpha = 14;
        for (int y = 0; y < h; y++)
        {
            double py = (y + 0.5) / h;
            double bodyVertical = SoftBand(py, 0.04, 0.99, 0.09);
            double footBoost = SoftBand(py, 0.58, 1.0, 0.12);
            for (int x = 0; x < w; x++)
            {
                double px = (x + 0.5) / w;
                double center = SoftBand(px, 0.18, 0.72, 0.09);
                double placementAlpha = Math.Max(center * bodyVertical, center * footBoost);
                Color pixel = bitmap.GetPixel(x, y);
                int alpha = baseAlpha + (int)Math.Round(Math.Pow(Clamp01(placementAlpha), 0.58) * (255 - baseAlpha));
                bitmap.SetPixel(x, y, Color.FromArgb(Math.Max(baseAlpha, Math.Min(255, alpha)), pixel.R, pixel.G, pixel.B));
            }
        }

        return bitmap;
    }

    private List<Color> BorderColorSamples(Bitmap bitmap, int maxSamples)
    {
        List<Color> samples = new List<Color>();
        if (bitmap.Width <= 0 || bitmap.Height <= 0) return samples;
        int perimeter = Math.Max(1, bitmap.Width * 2 + bitmap.Height * 2);
        int step = Math.Max(1, perimeter / Math.Max(8, maxSamples));
        for (int x = 0; x < bitmap.Width && samples.Count < maxSamples; x += step)
        {
            samples.Add(bitmap.GetPixel(x, 0));
            if (bitmap.Height > 1 && samples.Count < maxSamples) samples.Add(bitmap.GetPixel(x, bitmap.Height - 1));
        }
        for (int y = 0; y < bitmap.Height && samples.Count < maxSamples; y += step)
        {
            samples.Add(bitmap.GetPixel(0, y));
            if (bitmap.Width > 1 && samples.Count < maxSamples) samples.Add(bitmap.GetPixel(bitmap.Width - 1, y));
        }
        if (samples.Count == 0) samples.Add(AverageBorderColor(bitmap));
        return samples;
    }

    private double MinBorderDistanceSquared(Color pixel, List<Color> samples)
    {
        double best = Double.MaxValue;
        for (int i = 0; i < samples.Count; i++)
        {
            Color sample = samples[i];
            double dr = pixel.R - sample.R;
            double dg = pixel.G - sample.G;
            double db = pixel.B - sample.B;
            double d = dr * dr + dg * dg + db * db;
            if (d < best) best = d;
        }
        return best == Double.MaxValue ? 0.0 : best;
    }

    private Color AverageBorderColor(Bitmap bitmap)
    {
        long r = 0;
        long g = 0;
        long b = 0;
        int count = 0;
        int step = Math.Max(1, Math.Min(bitmap.Width, bitmap.Height) / 80);
        for (int x = 0; x < bitmap.Width; x += step)
        {
            AddPixel(bitmap.GetPixel(x, 0), ref r, ref g, ref b, ref count);
            AddPixel(bitmap.GetPixel(x, bitmap.Height - 1), ref r, ref g, ref b, ref count);
        }
        for (int y = 0; y < bitmap.Height; y += step)
        {
            AddPixel(bitmap.GetPixel(0, y), ref r, ref g, ref b, ref count);
            AddPixel(bitmap.GetPixel(bitmap.Width - 1, y), ref r, ref g, ref b, ref count);
        }
        if (count <= 0) return Color.FromArgb(128, 128, 128);
        return Color.FromArgb((int)(r / count), (int)(g / count), (int)(b / count));
    }

    private void AddPixel(Color pixel, ref long r, ref long g, ref long b, ref int count)
    {
        r += pixel.R;
        g += pixel.G;
        b += pixel.B;
        count++;
    }

    private double SoftBand(double value, double min, double max, double edge)
    {
        if (value <= min - edge || value >= max + edge) return 0.0;
        if (value >= min + edge && value <= max - edge) return 1.0;
        if (value < min + edge) return Clamp01((value - (min - edge)) / (edge * 2.0));
        return Clamp01(((max + edge) - value) / (edge * 2.0));
    }

    private double Clamp01(double value)
    {
        if (value < 0.0) return 0.0;
        if (value > 1.0) return 1.0;
        return value;
    }

    private void DrawImageWithOpacity(Graphics g, Image image, Rectangle dest, float opacity)
    {
        ColorMatrix matrix = new ColorMatrix();
        matrix.Matrix33 = Math.Max(0F, Math.Min(1F, opacity));
        using (ImageAttributes attributes = new ImageAttributes())
        {
            attributes.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
            g.DrawImage(
                image,
                dest,
                0,
                0,
                image.Width,
                image.Height,
                GraphicsUnit.Pixel,
                attributes
            );
        }
    }

    private void DrawCoverImage(Graphics g, Image image, Rectangle dest, Size targetSize)
    {
        if (image.Width <= 0 || image.Height <= 0 || dest.Width <= 0 || dest.Height <= 0) return;
        double srcAspect = image.Width / (double)image.Height;
        double targetAspect = targetSize.Width / (double)Math.Max(1, targetSize.Height);
        Rectangle src;
        if (srcAspect > targetAspect)
        {
            int cropW = Math.Max(1, (int)Math.Round(image.Height * targetAspect));
            int cropX = Math.Max(0, (image.Width - cropW) / 2);
            src = new Rectangle(cropX, 0, Math.Min(cropW, image.Width - cropX), image.Height);
        }
        else
        {
            int cropH = Math.Max(1, (int)Math.Round(image.Width / targetAspect));
            int cropY = Math.Max(0, (image.Height - cropH) / 2);
            src = new Rectangle(0, cropY, image.Width, Math.Min(cropH, image.Height - cropY));
        }
        g.DrawImage(image, dest, src, GraphicsUnit.Pixel);
    }

    private void DrawOverlayInside(Graphics g, Rectangle sceneRect, Size baseSize)
    {
        string overlay = Value("overlay_abs");
        lastOverlayPreviewRect = Rectangle.Empty;
        if (String.IsNullOrWhiteSpace(overlay) || !File.Exists(overlay)) return;
        Image image = GetOverlayImage(overlay);
        if (image == null) return;
        try
        {
            string mode = Value("overlay_mode").ToLowerInvariant();
            if (mode == "cover" || mode == "stretch")
            {
                double sceneScale = baseSize.Width <= 0 ? 1.0 : sceneRect.Width / (double)baseSize.Width;
                double coverOverlayScale = OverlayScaleValue();
                int coverX = sceneRect.Left + (int)Math.Round(ToInt(Value("overlay_x")) * sceneScale);
                int coverY = sceneRect.Top + (int)Math.Round(ToInt(Value("overlay_y")) * sceneScale);
                int coverW = Math.Max(1, (int)Math.Round(sceneRect.Width * coverOverlayScale));
                int coverH = Math.Max(1, (int)Math.Round(sceneRect.Height * coverOverlayScale));
                lastOverlayPreviewRect = new Rectangle(coverX, coverY, coverW, coverH);
                GraphicsState coverState = g.Save();
                try
                {
                    g.SetClip(sceneRect);
                    if (mode == "stretch")
                    {
                        g.DrawImage(image, lastOverlayPreviewRect);
                    }
                    else
                    {
                        DrawCoverImage(g, image, lastOverlayPreviewRect, baseSize);
                    }
                }
                finally
                {
                    g.Restore(coverState);
                }
                return;
            }

            if (IsFullSceneOverlay(image))
            {
                double fullSceneScale = baseSize.Width <= 0 ? 1.0 : sceneRect.Width / (double)baseSize.Width;
                double fullSceneOverlayScale = OverlayScaleValue();
                double cropX;
                double cropY;
                double backgroundScale = BackgroundToBaseScale(baseSize, out cropX, out cropY);
                double mappedX = ToInt(Value("overlay_x")) * backgroundScale - cropX;
                double mappedY = ToInt(Value("overlay_y")) * backgroundScale - cropY;
                int fullSceneX = sceneRect.Left + (int)Math.Round(mappedX * fullSceneScale);
                int fullSceneY = sceneRect.Top + (int)Math.Round(mappedY * fullSceneScale);
                int fullSceneW = Math.Max(1, (int)Math.Round(image.Width * fullSceneScale * fullSceneOverlayScale * backgroundScale));
                int fullSceneH = Math.Max(1, (int)Math.Round(image.Height * fullSceneScale * fullSceneOverlayScale * backgroundScale));
                lastOverlayPreviewRect = new Rectangle(fullSceneX, fullSceneY, fullSceneW, fullSceneH);
                GraphicsState coverState = g.Save();
                try
                {
                    g.SetClip(sceneRect);
                    g.DrawImage(image, lastOverlayPreviewRect);
                }
                finally
                {
                    g.Restore(coverState);
                }
                return;
            }

            double scale = baseSize.Width <= 0 ? 1.0 : sceneRect.Width / (double)baseSize.Width;
            double overlayScale = OverlayScaleValue();
            int x = sceneRect.Left + (int)Math.Round(ToInt(Value("overlay_x")) * scale);
            int y = sceneRect.Top + (int)Math.Round(ToInt(Value("overlay_y")) * scale);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale * overlayScale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale * overlayScale));
            lastOverlayPreviewRect = new Rectangle(x, y, w, h);
            GraphicsState state = g.Save();
            try
            {
                g.SetClip(sceneRect);
                g.DrawImage(image, lastOverlayPreviewRect);
            }
            finally
            {
                g.Restore(state);
            }
        }
        catch { }
    }

    private bool IsFullSceneOverlay(Image image)
    {
        string mode = Value("overlay_mode").ToLowerInvariant();
        if (mode == "cover" || mode == "stretch") return true;
        Size backgroundSize = CurrentBackgroundSourceSize();
        return backgroundSize.Width > 0 &&
            backgroundSize.Height > 0 &&
            image.Width == backgroundSize.Width &&
            image.Height == backgroundSize.Height;
    }

    private void DrawLogoInside(Graphics g, Rectangle sceneRect, Size baseSize)
    {
        string logo = Value("logo_abs");
        lastLogoPreviewRect = Rectangle.Empty;
        if (String.IsNullOrWhiteSpace(logo) || !File.Exists(logo)) return;
        Image image = GetLogoImage(logo);
        if (image == null) return;
        try
        {
            double scale = baseSize.Width <= 0 ? 1.0 : sceneRect.Width / (double)baseSize.Width;
            double logoScale = LogoScaleValue();
            double cropX;
            double cropY;
            double backgroundScale = BackgroundToBaseScale(baseSize, out cropX, out cropY);
            double mappedX = ToInt(Value("logo_x")) * backgroundScale - cropX;
            double mappedY = ToInt(Value("logo_y")) * backgroundScale - cropY;
            int x = sceneRect.Left + (int)Math.Round(mappedX * scale);
            int y = sceneRect.Top + (int)Math.Round(mappedY * scale);
            int w = Math.Max(1, (int)Math.Round(image.Width * scale * logoScale * backgroundScale));
            int h = Math.Max(1, (int)Math.Round(image.Height * scale * logoScale * backgroundScale));
            lastLogoPreviewRect = new Rectangle(x, y, w, h);
            GraphicsState state = g.Save();
            try
            {
                g.SetClip(sceneRect);
                if (overlayDragging && overlayDragLayer == "logo")
                {
                    DrawLogoPreviewFast(g, image, lastLogoPreviewRect);
                }
                else
                {
                    g.DrawImage(image, lastLogoPreviewRect);
                }
            }
            finally
            {
                g.Restore(state);
            }
        }
        catch { }
    }

    private void DrawLogoPreviewFast(Graphics g, Image source, Rectangle target)
    {
        if (source == null || target.Width <= 0 || target.Height <= 0) return;
        string key = logoSourcePath + "|" + target.Width.ToString() + "x" + target.Height.ToString();
        try
        {
            if (logoPreviewBitmap == null || !String.Equals(logoPreviewKey, key, StringComparison.Ordinal))
            {
                ClearLogoPreviewCache();
                logoPreviewBitmap = new Bitmap(target.Width, target.Height);
                using (Graphics scaled = Graphics.FromImage(logoPreviewBitmap))
                {
                    scaled.Clear(Color.Transparent);
                    scaled.CompositingMode = CompositingMode.SourceOver;
                    scaled.CompositingQuality = CompositingQuality.HighSpeed;
                    scaled.InterpolationMode = InterpolationMode.Low;
                    scaled.SmoothingMode = SmoothingMode.None;
                    scaled.PixelOffsetMode = PixelOffsetMode.None;
                    scaled.DrawImage(source, new Rectangle(0, 0, target.Width, target.Height));
                }
                logoPreviewKey = key;
            }
            if (logoPreviewBitmap != null)
            {
                g.DrawImageUnscaled(logoPreviewBitmap, target.Left, target.Top);
            }
        }
        catch
        {
            ClearLogoPreviewCache();
            g.DrawImage(source, target);
        }
    }

    private void DrawTextLayerInside(Graphics g, Rectangle sceneRect, Size baseSize)
    {
        lastTextPreviewRect = Rectangle.Empty;
        lastTextHitRect = RectangleF.Empty;
        lastTextHitCenter = PointF.Empty;
        lastTextHitRotation = 0F;
        string text = textLayerBox != null ? textLayerBox.Text : Value("text_layer");
        if (String.IsNullOrWhiteSpace(text) || sceneRect.Width <= 0 || sceneRect.Height <= 0) return;

        double sceneScale = baseSize.Width <= 0 ? 1.0 : sceneRect.Width / (double)baseSize.Width;
        double textScale = TextLayerScaleValue();
        float size = Math.Max(14F, Math.Min(180F, (float)(sceneRect.Width * 0.065 * textScale)));
        float rotation = textLayerRotationSlider != null ? textLayerRotationSlider.Value : ToInt(Value("text_layer_rotation"));
        Font font = null;
        GraphicsPath path = null;
        GraphicsState state = null;
        try
        {
            using (StringFormat format = new StringFormat())
            {
                format.Alignment = StringAlignment.Center;
                format.LineAlignment = StringAlignment.Near;
                while (size > 14F)
                {
                    if (font != null) font.Dispose();
                    font = CreateTextLayerPreviewFont(size);
                    SizeF measured = g.MeasureString(text, font);
                    if (measured.Width <= sceneRect.Width * 0.88F) break;
                    size -= 2F;
                }
                if (font == null) font = CreateTextLayerPreviewFont(size);

                path = new GraphicsPath();
                SizeF textMeasure = g.MeasureString(text, font);
                float textW = Math.Min((float)(sceneRect.Width * 0.88), textMeasure.Width + size * 0.12F);
                float textH = textMeasure.Height + size * 0.10F;
                float centerX = (float)(sceneRect.Left + sceneRect.Width / 2.0 + ToInt(Value("text_layer_x")) * sceneScale);
                float top = (float)(sceneRect.Top + sceneRect.Height * 0.065 + ToInt(Value("text_layer_y")) * sceneScale);
                float centerY = top + textH / 2F;
                RectangleF layout = new RectangleF(centerX - textW / 2F, top, textW, textH);
                path.AddString(text, font.FontFamily, (int)FontStyle.Bold, font.Size, layout, format);

                RectangleF tightHit = path.GetBounds();
                float hitPad = Math.Max(2F, size * 0.035F);
                tightHit.Inflate(hitPad, hitPad);
                lastTextHitRect = tightHit;
                lastTextHitCenter = new PointF(centerX, centerY);
                lastTextHitRotation = rotation;

                double radians = rotation * Math.PI / 180.0;
                int hitW = (int)Math.Ceiling(Math.Abs(tightHit.Width * Math.Cos(radians)) + Math.Abs(tightHit.Height * Math.Sin(radians)));
                int hitH = (int)Math.Ceiling(Math.Abs(tightHit.Width * Math.Sin(radians)) + Math.Abs(tightHit.Height * Math.Cos(radians)));
                lastTextPreviewRect = new Rectangle((int)Math.Round(centerX - hitW / 2.0), (int)Math.Round(centerY - hitH / 2.0), Math.Max(1, hitW), Math.Max(1, hitH));

                state = g.Save();
                g.SetClip(sceneRect);
                if (Math.Abs(rotation) > 0.01F)
                {
                    g.TranslateTransform(centerX, centerY);
                    g.RotateTransform(rotation);
                    g.TranslateTransform(-centerX, -centerY);
                }
                using (Pen shadow = new Pen(Color.FromArgb(190, 0, 0, 0), Math.Max(3F, size / 9F)))
                using (SolidBrush fill = new SolidBrush(TextLayerPreviewColor()))
                {
                    shadow.LineJoin = LineJoin.Round;
                    g.DrawPath(shadow, path);
                    g.FillPath(fill, path);
                }
            }
        }
        finally
        {
            if (state != null) g.Restore(state);
            if (path != null) path.Dispose();
            if (font != null) font.Dispose();
        }
    }

    private double BackgroundToBaseScale(Size baseSize, out double cropX, out double cropY)
    {
        cropX = 0.0;
        cropY = 0.0;
        Size backgroundSize = CurrentBackgroundSourceSize();
        if (backgroundSize.Width <= 0 || backgroundSize.Height <= 0 || baseSize.Width <= 0 || baseSize.Height <= 0)
        {
            return 1.0;
        }

        double coverScale = Math.Max(
            baseSize.Width / (double)backgroundSize.Width,
            baseSize.Height / (double)backgroundSize.Height
        );
        cropX = Math.Max(0.0, (backgroundSize.Width * coverScale - baseSize.Width) / 2.0);
        cropY = Math.Max(0.0, (backgroundSize.Height * coverScale - baseSize.Height) / 2.0);
        return coverScale;
    }

    private Size CurrentBackgroundSourceSize()
    {
        string bg = Value("background_abs");
        if (String.IsNullOrWhiteSpace(bg) || !File.Exists(bg)) bg = AbsPath(Value("background"));
        try
        {
            if (!String.IsNullOrWhiteSpace(bg) && File.Exists(bg))
            {
                string full = Path.GetFullPath(bg);
                if (!cachedBackgroundSourceSize.IsEmpty &&
                    String.Equals(cachedBackgroundSourceSizePath, full, StringComparison.OrdinalIgnoreCase))
                {
                    return cachedBackgroundSourceSize;
                }
                using (Image image = LoadBitmapUnlocked(bg))
                {
                    cachedBackgroundSourceSize = image.Size;
                    cachedBackgroundSourceSizePath = full;
                    return cachedBackgroundSourceSize;
                }
            }
        }
        catch { }
        return Size.Empty;
    }

    private Image GetLogoImage(string logo)
    {
        try
        {
            string full = Path.GetFullPath(logo);
            if (logoSourceBitmap != null && String.Equals(logoSourcePath, full, StringComparison.OrdinalIgnoreCase))
            {
                return logoSourceBitmap;
            }
            ClearLogoCache();
            logoSourceBitmap = LoadBitmapUnlocked(full);
            logoSourcePath = full;
            return logoSourceBitmap;
        }
        catch
        {
            ClearLogoCache();
            return null;
        }
    }

    private Image GetOverlayImage(string overlay)
    {
        try
        {
            string full = Path.GetFullPath(overlay);
            if (overlaySourceBitmap != null && String.Equals(overlaySourcePath, full, StringComparison.OrdinalIgnoreCase))
            {
                return overlaySourceBitmap;
            }
            ClearOverlayCache();
            overlaySourceBitmap = LoadBitmapUnlocked(full);
            overlaySourcePath = full;
            return overlaySourceBitmap;
        }
        catch
        {
            ClearOverlayCache();
            return null;
        }
    }

    private void PreviewBox_MouseDown(object sender, MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        bool hasText = !String.IsNullOrWhiteSpace(textLayerBox != null ? textLayerBox.Text : Value("text_layer"));
        if (hasText)
        {
            if (TextLayerHitTest(e.Location))
            {
                overlayDragging = true;
                overlayDragLayer = "text_layer";
                livePreviewFast = true;
                overlayDragStartMouse = e.Location;
                overlayDragStartPosition = new Point(ToInt(Value("text_layer_x")), ToInt(Value("text_layer_y")));
                PreparePreviewDragScales("text_layer");
                previewBox.Capture = true;
                return;
            }
        }

        bool hasLogo = !String.IsNullOrWhiteSpace(Value("logo_abs")) && File.Exists(Value("logo_abs"));
        if (hasLogo)
        {
            Rectangle logoGrabRect = lastLogoPreviewRect;
            if (!logoGrabRect.IsEmpty) logoGrabRect.Inflate(24, 24);
            if (!logoGrabRect.IsEmpty && logoGrabRect.Contains(e.Location))
            {
                overlayDragging = true;
                overlayDragLayer = "logo";
                livePreviewFast = true;
                overlayDragStartMouse = e.Location;
                overlayDragStartPosition = new Point(ToInt(Value("logo_x")), ToInt(Value("logo_y")));
                PreparePreviewDragScales("logo");
                previewBox.Capture = true;
                return;
            }
        }

        if (String.IsNullOrWhiteSpace(Value("overlay_abs")) || !File.Exists(Value("overlay_abs"))) return;
        Rectangle grabRect = lastOverlayPreviewRect;
        if (!grabRect.IsEmpty) grabRect.Inflate(24, 24);
        bool grabbedOverlay = !grabRect.IsEmpty && grabRect.Contains(e.Location);
        if (!grabbedOverlay)
        {
            if (lastScenePreviewRect.IsEmpty || !lastScenePreviewRect.Contains(e.Location)) return;
            Size baseSize = CurrentPreviewBaseSize();
            if (baseSize.Width <= 0 || lastScenePreviewRect.Width <= 0) return;
            double scale = lastScenePreviewRect.Width / (double)baseSize.Width;
            if (scale <= 0) return;
            Size overlaySize = CurrentOverlayBaseSize();
            double overlayScale = OverlayScaleValue();
            int overlayW = lastOverlayPreviewRect.Width > 0
                ? Math.Max(1, (int)Math.Round(lastOverlayPreviewRect.Width / scale))
                : Math.Max(1, (int)Math.Round(overlaySize.Width * overlayScale));
            int overlayH = lastOverlayPreviewRect.Height > 0
                ? Math.Max(1, (int)Math.Round(lastOverlayPreviewRect.Height / scale))
                : Math.Max(1, (int)Math.Round(overlaySize.Height * overlayScale));
            int nextX = (int)Math.Round((e.X - lastScenePreviewRect.Left) / scale) - overlayW / 2;
            int nextY = (int)Math.Round((e.Y - lastScenePreviewRect.Top) / scale) - overlayH / 2;
            SetStateValueLocal("overlay_x", nextX.ToString());
            SetStateValueLocal("overlay_y", nextY.ToString());
            QueueLivePreview();
        }
        overlayDragging = true;
        overlayDragLayer = "overlay";
        livePreviewFast = true;
        overlayDragStartMouse = e.Location;
        overlayDragStartPosition = new Point(ToInt(Value("overlay_x")), ToInt(Value("overlay_y")));
        PreparePreviewDragScales("overlay");
        previewBox.Capture = true;
    }

    private void PreviewBox_MouseMove(object sender, MouseEventArgs e)
    {
        if (!overlayDragging) return;
        string prefix = overlayDragLayer == "logo" ? "logo" : (overlayDragLayer == "text_layer" ? "text_layer" : "overlay");
        double dragScale = Math.Max(0.01, overlayDragSceneScale * overlayDragCoordinateScale);
        int nextX = overlayDragStartPosition.X + (int)Math.Round((e.X - overlayDragStartMouse.X) / dragScale);
        int nextY = overlayDragStartPosition.Y + (int)Math.Round((e.Y - overlayDragStartMouse.Y) / dragScale);
        if (prefix == "overlay")
        {
            Point snapped = SnapOverlayToOrigin(nextX, nextY, dragScale);
            nextX = snapped.X;
            nextY = snapped.Y;
        }
        if (nextX == ToInt(Value(prefix + "_x")) && nextY == ToInt(Value(prefix + "_y"))) return;
        SetStateValueLocal(prefix + "_x", nextX.ToString());
        SetStateValueLocal(prefix + "_y", nextY.ToString());
        QueueLivePreview();
    }

    private Point SnapOverlayToOrigin(int x, int y, double previewPixelsPerUnit)
    {
        int snapUnits = Math.Max(1, (int)Math.Ceiling(OverlayOriginSnapPreviewPixels / Math.Max(0.01, previewPixelsPerUnit)));
        if (Math.Abs(x) <= snapUnits) x = 0;
        if (Math.Abs(y) <= snapUnits) y = 0;
        return new Point(x, y);
    }

    private void PreparePreviewDragScales(string prefix)
    {
        overlayDragSceneScale = 1.0;
        overlayDragCoordinateScale = 1.0;
        Size baseSize = CurrentPreviewBaseSize();
        if (lastScenePreviewRect.Width <= 0 || baseSize.Width <= 0) return;
        overlayDragSceneScale = Math.Max(0.01, lastScenePreviewRect.Width / (double)baseSize.Width);
        if (prefix == "logo" || (prefix == "overlay" && CurrentOverlayUsesBackgroundCoordinates()))
        {
            double cropX;
            double cropY;
            overlayDragCoordinateScale = Math.Max(0.01, BackgroundToBaseScale(baseSize, out cropX, out cropY));
        }
    }

    private void PreviewBox_MouseUp(object sender, MouseEventArgs e)
    {
        if (!overlayDragging) return;
        string prefix = overlayDragLayer == "logo" ? "logo" : (overlayDragLayer == "text_layer" ? "text_layer" : "overlay");
        overlayDragging = false;
        previewBox.Capture = false;
        SaveSimple(prefix + "_x", Value(prefix + "_x"), false);
        SaveSimple(prefix + "_y", Value(prefix + "_y"), false);
        overlayDragLayer = "overlay";
        FinishLivePreview();
    }

    private bool TextLayerHitTest(Point point)
    {
        if (lastTextHitRect.IsEmpty) return false;
        float x = point.X;
        float y = point.Y;
        if (Math.Abs(lastTextHitRotation) > 0.01F)
        {
            double radians = -lastTextHitRotation * Math.PI / 180.0;
            float dx = point.X - lastTextHitCenter.X;
            float dy = point.Y - lastTextHitCenter.Y;
            x = lastTextHitCenter.X + (float)(dx * Math.Cos(radians) - dy * Math.Sin(radians));
            y = lastTextHitCenter.Y + (float)(dx * Math.Sin(radians) + dy * Math.Cos(radians));
        }
        return lastTextHitRect.Contains(x, y);
    }

    private bool CurrentOverlayUsesBackgroundCoordinates()
    {
        string mode = Value("overlay_mode").ToLowerInvariant();
        if (mode == "cover" || mode == "stretch") return false;
        Size overlaySize = CurrentOverlayBaseSize();
        Size backgroundSize = CurrentBackgroundSourceSize();
        return overlaySize.Width > 0 &&
            overlaySize.Height > 0 &&
            overlaySize.Width == backgroundSize.Width &&
            overlaySize.Height == backgroundSize.Height;
    }

    private Size CurrentPreviewBaseSize()
    {
        string first = CurrentFirstInputForPreview();
        string latestProcessed = Value("latest_processed");
        string latest = Value("latest_output");
        string bg = Value("background_abs");
        string key = !String.IsNullOrWhiteSpace(bg) && File.Exists(bg)
            ? bg
            : (!String.IsNullOrWhiteSpace(first) && File.Exists(first)
                ? first
                : (!String.IsNullOrWhiteSpace(latestProcessed) && File.Exists(latestProcessed)
                    ? latestProcessed
                    : (!String.IsNullOrWhiteSpace(latest) && File.Exists(latest) ? latest : "")));
        if (!String.IsNullOrWhiteSpace(key) &&
            !cachedPreviewBaseSize.IsEmpty &&
            String.Equals(cachedPreviewBaseSizeKey, key, StringComparison.OrdinalIgnoreCase))
        {
            return cachedPreviewBaseSize;
        }

        try
        {
            if (!String.IsNullOrWhiteSpace(bg) && File.Exists(bg))
            {
                Bitmap image = GetPreviewBaseImage(bg);
                if (image != null)
                {
                    cachedPreviewBaseSize = image.Size;
                    cachedPreviewBaseSizeKey = key;
                    return cachedPreviewBaseSize;
                }
            }
        }
        catch { }

        try
        {
            if (!String.IsNullOrWhiteSpace(first) && File.Exists(first))
            {
                Bitmap image = GetPreviewBaseImage(first);
                if (image != null)
                {
                    cachedPreviewBaseSize = image.Size;
                    cachedPreviewBaseSizeKey = first;
                    return cachedPreviewBaseSize;
                }
            }
        }
        catch { }

        try
        {
            if (!String.IsNullOrWhiteSpace(latestProcessed) && File.Exists(latestProcessed))
            {
                using (Bitmap image = LoadBitmapWithExifOrientation(latestProcessed))
                {
                    cachedPreviewBaseSize = image.Size;
                    cachedPreviewBaseSizeKey = latestProcessed;
                    return cachedPreviewBaseSize;
                }
            }
        }
        catch { }

        try
        {
            if (!String.IsNullOrWhiteSpace(latest) && File.Exists(latest))
            {
                using (Bitmap image = LoadBitmapWithExifOrientation(latest))
                {
                    cachedPreviewBaseSize = image.Size;
                    cachedPreviewBaseSizeKey = latest;
                    return cachedPreviewBaseSize;
                }
            }
        }
        catch { }

        if (!cachedPreviewBaseSize.IsEmpty)
        {
            return cachedPreviewBaseSize;
        }
        return lastScenePreviewRect.Size;
    }

    private string CurrentFirstInputForPreview()
    {
        string first = Value("first_input");
        List<string> images = PreviewInputImagesForCurrentOrientation();
        if (images.Count == 0)
        {
            SetStateValueLocal("first_input", "");
            UpdatePreviewNavigationState();
            return "";
        }

        if (!String.IsNullOrWhiteSpace(first))
        {
            string current = images.Find(delegate(string path)
            {
                return String.Equals(path, first, StringComparison.OrdinalIgnoreCase);
            });
            if (!String.IsNullOrWhiteSpace(current))
            {
                return current;
            }
        }

        string found = images[0];
        SetStateValueLocal("first_input", found);
        UpdatePreviewNavigationState();
        return found;
    }

    private List<string> PreviewInputImagesForCurrentOrientation()
    {
        string input = Value("input_abs");
        List<string> images = new List<string>();
        if (String.IsNullOrWhiteSpace(input) || !Directory.Exists(input)) return images;

        try
        {
            string cacheKey = input + "|all";
            double cacheSeconds = cachedPreviewInputImages.Count == 0 ? 0.75 : 5.0;
            if (String.Equals(cachedPreviewInputImagesKey, cacheKey, StringComparison.OrdinalIgnoreCase) &&
                (DateTime.Now - cachedPreviewInputImagesAt).TotalSeconds < cacheSeconds)
            {
                return new List<string>(cachedPreviewInputImages);
            }

            images.AddRange(Directory.GetFiles(input, "*.jpg", SearchOption.AllDirectories));
            images.AddRange(Directory.GetFiles(input, "*.jpeg", SearchOption.AllDirectories));
            images.Sort(NaturalPathCompare);

            CachePreviewInputImages(cacheKey, images);
            return images;
        }
        catch
        {
            return new List<string>();
        }
    }

    private void CachePreviewInputImages(string key, List<string> images)
    {
        cachedPreviewInputImagesKey = key ?? "";
        cachedPreviewInputImages = images == null ? new List<string>() : new List<string>(images);
        cachedPreviewInputImagesAt = DateTime.Now;
    }

    private void ClearPreviewInputImagesCache()
    {
        cachedPreviewInputImagesKey = "";
        cachedPreviewInputImages.Clear();
        cachedPreviewInputImagesAt = DateTime.MinValue;
    }

    private void NavigatePreviewPhoto(int direction)
    {
        List<string> images = PreviewInputImagesForCurrentOrientation();
        if (images.Count == 0)
        {
            SetStateValueLocal("first_input", "");
            ClearPreviewSubjectCache();
            ClearPreviewBase();
            UpdatePreviewNavigationState();
            DrawScenePreviewImmediate();
            return;
        }

        string current = Value("first_input");
        int index = images.FindIndex(delegate(string path)
        {
            return String.Equals(path, current, StringComparison.OrdinalIgnoreCase);
        });
        if (index < 0) index = 0;
        else index = (index + direction + images.Count) % images.Count;

        string selectedImage = images[index];
        SetStateValueLocal("first_input", selectedImage);
        ApplySiblingPresetForPreviewImage(selectedImage);
        ClearPreviewSubjectCache();
        ClearPreviewBase();
        UpdatePreviewNavigationState();
        DrawScenePreviewImmediate();
    }

    private void ApplySiblingPresetForPreviewImage(string imagePath)
    {
        if (String.IsNullOrWhiteSpace(imagePath) || !File.Exists(imagePath)) return;
        string orientation = ImageOrientationForPreview(imagePath);
        if (String.IsNullOrWhiteSpace(orientation)) return;

        string currentPreset = Value("active_preset");
        if (String.IsNullOrWhiteSpace(currentPreset)) return;

        string targetSuffix = orientation == "horizontal" ? "_h" : "_v";
        string otherSuffix = orientation == "horizontal" ? "_v" : "_h";
        if (currentPreset.EndsWith(targetSuffix, StringComparison.OrdinalIgnoreCase)) return;
        if (!currentPreset.EndsWith(otherSuffix, StringComparison.OrdinalIgnoreCase)) return;

        string candidate = currentPreset.Substring(0, currentPreset.Length - otherSuffix.Length) + targetSuffix;
        if (!PresetExists(candidate)) return;

        try
        {
            RunPython("\"" + bridgePy + "\" preset_apply " + QuoteArg(candidate));
            LoadState();
            SetStateValueLocal("first_input", imagePath);
            ClearPreviewSubjectCache();
            ClearPreviewBase();
            if (progressLabel != null) progressLabel.Text = "Preset aplicado: " + candidate;
        }
        catch (Exception ex)
        {
            if (progressLabel != null) progressLabel.Text = "No se pudo aplicar preset " + candidate + ".";
            if (logBox != null) AddLog("Preset hermano no aplicado: " + ex.Message);
        }
    }

    private bool PresetExists(string name)
    {
        if (String.IsNullOrWhiteSpace(name)) return false;
        List<string> presets = Values("preset");
        for (int i = 0; i < presets.Count; i++)
        {
            if (String.Equals(presets[i], name, StringComparison.OrdinalIgnoreCase)) return true;
        }

        try
        {
            string path = Path.Combine(appDir, "presets", name + ".json");
            return File.Exists(path);
        }
        catch
        {
            return false;
        }
    }

    private void UpdatePreviewNavigationState()
    {
        if (previewPhotoLabel == null) return;
        List<string> images = PreviewInputImagesForCurrentOrientation();
        string current = Value("first_input");
        int index = images.FindIndex(delegate(string path)
        {
            return String.Equals(path, current, StringComparison.OrdinalIgnoreCase);
        });

        bool hasImages = images.Count > 0;
        if (!hasImages)
        {
            previewPhotoLabel.Text = "Sin fotos en IN";
        }
        else
        {
            if (index < 0) index = 0;
            previewPhotoLabel.Text = Path.GetFileName(images[index]) + "  " + (index + 1).ToString() + "/" + images.Count.ToString();
        }

        if (previewPrevButton != null) previewPrevButton.Enabled = hasImages && images.Count > 1;
        if (previewNextButton != null) previewNextButton.Enabled = hasImages && images.Count > 1;
    }

    private int NaturalPathCompare(string left, string right)
    {
        return NaturalCompare(left ?? "", right ?? "");
    }

    private int NaturalCompare(string left, string right)
    {
        MatchCollection leftParts = Regex.Matches(left.ToLowerInvariant().Replace('\\', '/'), @"\d+|\D+");
        MatchCollection rightParts = Regex.Matches(right.ToLowerInvariant().Replace('\\', '/'), @"\d+|\D+");
        int count = Math.Min(leftParts.Count, rightParts.Count);
        for (int i = 0; i < count; i++)
        {
            string a = leftParts[i].Value;
            string b = rightParts[i].Value;
            int compare;
            int ai;
            int bi;
            if (Int32.TryParse(a, out ai) && Int32.TryParse(b, out bi))
            {
                compare = ai.CompareTo(bi);
            }
            else
            {
                compare = String.Compare(a, b, StringComparison.OrdinalIgnoreCase);
            }
            if (compare != 0) return compare;
        }
        return leftParts.Count.CompareTo(rightParts.Count);
    }

    private string CurrentPreviewOrientation()
    {
        Size backgroundSize = CurrentBackgroundSourceSize();
        if (backgroundSize.Height > backgroundSize.Width) return "vertical";
        if (backgroundSize.Width > backgroundSize.Height) return "horizontal";
        return "";
    }

    private string ImageOrientationForPreview(string path)
    {
        try
        {
            using (Bitmap image = LoadBitmapWithExifOrientation(path))
            {
                if (image.Height > image.Width) return "vertical";
                if (image.Width > image.Height) return "horizontal";
            }
        }
        catch { }
        return "";
    }

    private Size CurrentOverlayBaseSize()
    {
        string overlay = Value("overlay_abs");
        try
        {
            if (!String.IsNullOrWhiteSpace(overlay) && File.Exists(overlay))
            {
                using (Image image = LoadBitmapUnlocked(overlay))
                {
                    return image.Size;
                }
            }
        }
        catch { }
        return new Size(1, 1);
    }

    private void PlaceOverlayBottomCenter(bool redraw)
    {
        Size baseSize = CurrentPreviewBaseSize();
        Size overlaySize = CurrentOverlayBaseSize();
        if (baseSize.Width <= 0 || baseSize.Height <= 0 || overlaySize.Width <= 0 || overlaySize.Height <= 0) return;
        double overlayScale = OverlayScaleValue();
        int overlayW = Math.Max(1, (int)Math.Round(overlaySize.Width * overlayScale));
        int overlayH = Math.Max(1, (int)Math.Round(overlaySize.Height * overlayScale));
        int x = Math.Max(0, (baseSize.Width - overlayW) / 2);
        int y = Math.Max(0, baseSize.Height - overlayH);
        SetStateValueLocal("overlay_x", x.ToString());
        SetStateValueLocal("overlay_y", y.ToString());
        if (redraw) DrawScenePreviewImmediate();
    }

    private void FitOverlayToBackgroundWidth(string overlayPath, bool reloadState)
    {
        if (String.IsNullOrWhiteSpace(overlayPath) || !File.Exists(overlayPath)) return;

        int scalePercent = 100;
        string scaleValue = "1";

        SetStateValueLocal("overlay_mode", "stretch");
        SetStateValueLocal("overlay_scale", scaleValue);
        SetStateValueLocal("overlay_x", "0");
        SetStateValueLocal("overlay_y", "0");

        if (overlayScaleSlider != null)
        {
            overlayScaleSlider.Value = scalePercent;
            lastSavedOverlayScale = scalePercent;
            UpdateOverlayScaleLabel();
        }

        SaveSimple("overlay_mode", "stretch", false);
        SaveSimple("overlay_scale", scaleValue, reloadState);
        SaveSimple("overlay_x", "0", false);
        SaveSimple("overlay_y", "0", false);
    }

    private void SetStateValueLocal(string key, string value)
    {
        if (!state.ContainsKey(key)) state[key] = new List<string>();
        if (state[key].Count == 0) state[key].Add(value);
        else state[key][0] = value;
    }

    private void QueueLivePreview()
    {
        QueueLivePreview(false);
    }

    private void QueueLivePreviewAfterResize()
    {
        QueueLivePreview(true);
    }

    private void QueueLivePreview(bool debounce)
    {
        enhancedPreviewRenderedKey = "";
        enhancedPreviewRevision++;
        livePreviewFast = overlayDragging;
        livePreviewPending = true;
        if (livePreviewTimer == null)
        {
            DrawScenePreviewImmediate();
            return;
        }
        if (debounce)
        {
            livePreviewTimer.Stop();
            livePreviewTimer.Start();
            return;
        }
        if (!livePreviewTimer.Enabled) livePreviewTimer.Start();
    }

    private void FinishLivePreview()
    {
        if (livePreviewTimer != null) livePreviewTimer.Stop();
        livePreviewPending = false;
        livePreviewFast = false;
        DrawScenePreviewImmediate();
    }

    private Rectangle FitRect(Size imageSize, Rectangle target)
    {
        if (imageSize.Width <= 0 || imageSize.Height <= 0) return target;
        double scale = Math.Min(target.Width / (double)imageSize.Width, target.Height / (double)imageSize.Height);
        int drawW = Math.Max(1, (int)Math.Round(imageSize.Width * scale));
        int drawH = Math.Max(1, (int)Math.Round(imageSize.Height * scale));
        int x = target.Left + (target.Width - drawW) / 2;
        int y = target.Top + (target.Height - drawH) / 2;
        return new Rectangle(x, y, drawW, drawH);
    }

    private void RequestPreview()
    {
        if (previewTimer == null) return;
        previewTimer.Stop();
        previewTimer.Start();
    }

    private void ClearLog()
    {
        if (logBox == null) return;
        logBox.Clear();
        logLineCount = 0;
        ClearQueuedProcessingLogLines();
    }

    private void ClearQueuedProcessingLogLines()
    {
        lock (pendingProcessingLogLock)
        {
            pendingProcessingLogLines.Clear();
            pendingProcessingLogFlushQueued = false;
        }
    }

    private void AddLog(string text)
    {
        if (logBox == null) return;
        if (logLineCount > 0) logBox.AppendText(Environment.NewLine);
        logBox.AppendText(text ?? "");
        logLineCount++;
        logBox.SelectionStart = logBox.TextLength;
        logBox.ScrollToCaret();
    }

    private void AppendHotfolderLog(string text)
    {
        if (String.IsNullOrWhiteSpace(text)) return;
        QueueProcessingLogLine(text);
    }

    private void AppendProcessLog(string text)
    {
        if (String.IsNullOrWhiteSpace(text)) return;
        QueueProcessingLogLine(text);
    }

    private void QueueProcessingLogLine(string text)
    {
        if (String.IsNullOrWhiteSpace(text)) return;
        string line = text.Trim();
        if (line.Length == 0) return;
        try
        {
            if (IsDisposed || !IsHandleCreated) return;
            bool shouldQueueFlush = false;
            lock (pendingProcessingLogLock)
            {
                pendingProcessingLogLines.Add(line);
                if (!pendingProcessingLogFlushQueued)
                {
                    pendingProcessingLogFlushQueued = true;
                    shouldQueueFlush = true;
                }
            }
            if (shouldQueueFlush) BeginInvoke((MethodInvoker)FlushQueuedProcessingLogLines);
        }
        catch
        {
            lock (pendingProcessingLogLock) pendingProcessingLogFlushQueued = false;
        }
    }

    private void FlushQueuedProcessingLogLines()
    {
        if (logBox == null) return;
        List<string> lines = new List<string>();
        bool hasMore;
        lock (pendingProcessingLogLock)
        {
            int count = Math.Min(80, pendingProcessingLogLines.Count);
            for (int i = 0; i < count; i++) lines.Add(pendingProcessingLogLines[i]);
            if (count > 0) pendingProcessingLogLines.RemoveRange(0, count);
            hasMore = pendingProcessingLogLines.Count > 0;
            pendingProcessingLogFlushQueued = hasMore;
        }

        foreach (string line in lines)
        {
            AppendRelevantProcessingLog(line);
        }

        if (hasMore && !closingApp && !IsDisposed && IsHandleCreated)
        {
            try { BeginInvoke((MethodInvoker)FlushQueuedProcessingLogLines); }
            catch
            {
                lock (pendingProcessingLogLock) pendingProcessingLogFlushQueued = false;
            }
        }
    }

    private string ShortNuvolFileName(string value)
    {
        string name = Path.GetFileNameWithoutExtension(value ?? "").Trim();
        if (name.Length > 6) name = name.Substring(0, 6);
        return name;
    }
    private void AppendRelevantProcessingLog(string line)
    {
        if (String.IsNullOrWhiteSpace(line)) return;

        if (line.StartsWith("NUVOL ", StringComparison.OrdinalIgnoreCase))
        {
            string[] parts = line.Split(new char[] { ' ' }, 4, StringSplitOptions.RemoveEmptyEntries);
            string action = parts.Length > 1 ? parts[1].ToLowerInvariant() : "";
            string shortName = ShortNuvolFileName(parts.Length > 2 ? parts[2] : "");
            if (shortName.Length == 0) shortName = "foto";
            if (action == "uploaded") AddLog("nuvol- subida OK " + shortName);
            else if (action == "downloaded") AddLog("nuvol- descarga OK " + shortName);
            else if (action.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0 || action == "failed") AddLog("nuvol- ERROR " + shortName);
            else if (progressLabel != null)
            {
                if (action == "presigned") progressLabel.Text = "Nuvol preparando " + shortName + "...";
                else if (action == "uploading") progressLabel.Text = "Nuvol subiendo " + shortName + "...";
                else if (action == "watermark") progressLabel.Text = "Nuvol marca " + shortName + "...";
                else if (action == "downloading") progressLabel.Text = "Nuvol bajando " + shortName + "...";
                else progressLabel.Text = "Nuvol " + action + " " + shortName + "...";
            }
            return;
        }
        int processingIndex = line.IndexOf("Processing file:", StringComparison.OrdinalIgnoreCase);
        if (processingIndex >= 0)
        {
            string filePath = line.Substring(processingIndex + "Processing file:".Length).Trim().Trim('"', '\'');
            string fileName = Path.GetFileName(filePath);
            if (fileName.Length > 0)
            {
                SetCurrentProgressFolder(filePath);
                EnsureActiveLogFolder(progressFolderName);
                AddLog("Procesando - " + activeLogFolderName + ": " + fileName);
                EnsureProgressCountersForRunningBatch();
                MarkProgressProcessingStarted();
                UpdateProgressEstimate();
            }
            return;
        }

        string processedName;
        double seconds;
        if (TryParseProcessedLine(line, out processedName, out seconds))
        {
            if (activeLogFolderName.Length == 0) EnsureActiveLogFolder(progressFolderName.Length > 0 ? progressFolderName : "IN");
            activeLogFolderProcessed++;
            activeLogFolderSeconds += Math.Max(0.0, seconds);
            UpdateProgressSpeed(seconds);
            AddLog("OK - " + processedName + " · " + seconds.ToString("0.0", CultureInfo.InvariantCulture) + "s/foto");
            UpdateProgressEstimate();
            return;
        }

        int removedIndex = line.IndexOf("Removed empty IN folder after backup:", StringComparison.OrdinalIgnoreCase);
        if (removedIndex >= 0)
        {
            string folderPath = line.Substring(removedIndex + "Removed empty IN folder after backup:".Length).Trim();
            string folder = Path.GetFileName(folderPath.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
            if (folder.Length == 0) folder = activeLogFolderName;
            FinishActiveLogFolder(folder);
            return;
        }

        if (line.IndexOf("Hotfolder batch complete", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            FinishActiveLogFolder(activeLogFolderName);
            return;
        }

        if (line.IndexOf("Failed processing", StringComparison.OrdinalIgnoreCase) >= 0 ||
            line.IndexOf("Configuration error", StringComparison.OrdinalIgnoreCase) >= 0 ||
            line.IndexOf("ERROR", StringComparison.OrdinalIgnoreCase) >= 0)
        {
            List<string> cleaned = CleanProcessLines(line);
            if (cleaned.Count > 0) AddLog("ERROR - " + cleaned[0]);
        }
    }

    private bool TryParseProcessedLine(string line, out string processedName, out double seconds)
    {
        processedName = "";
        seconds = 0.0;
        int start = line.IndexOf("Processed ", StringComparison.OrdinalIgnoreCase);
        if (start < 0) return false;
        start += "Processed ".Length;
        int arrow = line.IndexOf(" -> ", start, StringComparison.OrdinalIgnoreCase);
        int inIndex = line.IndexOf(" in ", arrow >= 0 ? arrow : start, StringComparison.OrdinalIgnoreCase);
        int secondsEnd = line.IndexOf("s using", inIndex >= 0 ? inIndex : start, StringComparison.OrdinalIgnoreCase);
        if (arrow < 0 || inIndex < 0 || secondsEnd < 0) return false;

        processedName = line.Substring(start, arrow - start).Trim();
        string secondsText = line.Substring(inIndex + " in ".Length, secondsEnd - (inIndex + " in ".Length)).Trim();
        if (!Double.TryParse(secondsText, NumberStyles.Float, CultureInfo.InvariantCulture, out seconds))
        {
            Double.TryParse(secondsText, NumberStyles.Float, CultureInfo.CurrentCulture, out seconds);
        }
        return processedName.Length > 0;
    }

    private void EnsureActiveLogFolder(string folder)
    {
        if (String.IsNullOrWhiteSpace(folder)) folder = "IN";
        if (String.Equals(activeLogFolderName, folder, StringComparison.OrdinalIgnoreCase)) return;
        FinishActiveLogFolder(activeLogFolderName);
        activeLogFolderName = folder;
        activeLogFolderProcessed = 0;
        activeLogFolderSeconds = 0.0;
    }

    private void FinishActiveLogFolder(string folder)
    {
        if (activeLogFolderProcessed <= 0) return;
        if (String.IsNullOrWhiteSpace(folder)) folder = activeLogFolderName.Length > 0 ? activeLogFolderName : "IN";
        double avg = activeLogFolderSeconds / Math.Max(1, activeLogFolderProcessed);
        AddLog("Resumen " + folder + ": " + activeLogFolderProcessed + " archivo(s) · " +
            activeLogFolderSeconds.ToString("0.0", CultureInfo.InvariantCulture) + "s total · " +
            avg.ToString("0.0", CultureInfo.InvariantCulture) + "s/foto");
        if (progressLabel != null)
        {
            progressLabel.Text = "Resumen " + folder + ": " + activeLogFolderProcessed + " archivo(s)";
        }
        activeLogFolderName = "";
        activeLogFolderProcessed = 0;
        activeLogFolderSeconds = 0.0;
    }

    private void ResetVisibleProcessingLog()
    {
        activeLogFolderName = "";
        activeLogFolderProcessed = 0;
        activeLogFolderSeconds = 0.0;
    }

    private void SetCurrentProgressFolder(string filePath)
    {
        string folder = "";
        try
        {
            string inputRoot = Value("input_abs");
            string parent = Path.GetDirectoryName(filePath);
            if (!String.IsNullOrWhiteSpace(inputRoot) && !String.IsNullOrWhiteSpace(parent))
            {
                string root = Path.GetFullPath(inputRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                string fullParent = Path.GetFullPath(parent).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                if (fullParent.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                {
                    string relative = fullParent.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                    if (relative.Length > 0)
                    {
                        folder = relative.Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)[0];
                    }
                }
            }
            if (folder.Length == 0 && !String.IsNullOrWhiteSpace(parent))
            {
                folder = Path.GetFileName(parent);
            }
        }
        catch { }

        progressFolderName = folder.Length > 0 ? folder : "IN";
    }

    private void DrawAssets()
    {
        backgroundsPanel.Controls.Clear();
        overlaysPanel.Controls.Clear();
        logosPanel.Controls.Clear();
        AddAssets(backgroundsPanel, "Fondos", Values("background_asset"), "background");
        AddAssets(overlaysPanel, "Overlays", Values("overlay_asset"), "overlay");
        AddAssets(logosPanel, "Logos", Values("logo_asset"), "logo");
        ApplyTheme();
    }

    private void AddAssets(FlowLayoutPanel panel, string title, List<string> files, string key)
    {
        Panel header = new Panel();
        int tileWidth = Math.Max(172, panel.ClientSize.Width - SystemInformation.VerticalScrollBarWidth - 18);
        if (tileWidth > 268) tileWidth = 268;
        header.Width = tileWidth;
        bool hasScale = key == "overlay" || key == "logo";
        header.Height = hasScale ? 76 : 40;
        header.Margin = new Padding(0, 0, 10, hasScale ? 4 : 8);
        header.BackColor = SurfaceColor;

        Label titleLabel = new Label();
        titleLabel.Text = title;
        titleLabel.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        titleLabel.SetBounds(0, 8, 64, 24);
        titleLabel.ForeColor = TextColor;
        titleLabel.BackColor = SurfaceColor;
        header.Controls.Add(titleLabel);

        Button upload = AccentButton("Añadir");
        upload.SetBounds(68, 4, 70, 30);
        upload.Click += delegate { SelectAssetFile(key); };
        header.Controls.Add(upload);

        Button clear = Button(key == "overlay" ? "Sin overlay" : key == "logo" ? "Sin logo" : "Sin fondo");
        clear.Tag = "asset-none:" + key;
        clear.SetBounds(146, 4, Math.Max(34, tileWidth - 146), 30);
        ApplyButtonVisual(clear, IsNoAssetSelected(key));
        clear.Click += delegate
        {
            ApplyButtonVisual(clear, true);
            SaveSimple(key, "", true);
        };
        header.Controls.Add(clear);

        if (hasScale)
        {
            AddLayerScaleControls(header, tileWidth, key);
        }
        panel.Controls.Add(header);

        foreach (string file in files)
        {
            string active = key == "overlay" ? Value("overlay_abs") : key == "logo" ? Value("logo_abs") : Value("background_abs");
            bool isActive = !String.IsNullOrWhiteSpace(active) &&
                String.Equals(Path.GetFullPath(active), Path.GetFullPath(file), StringComparison.OrdinalIgnoreCase);

            Panel tile = new Panel();
            tile.Width = tileWidth;
            tile.Height = 150;
            tile.Margin = new Padding(0, 0, 10, 12);
            tile.BorderStyle = BorderStyle.None;
            tile.Cursor = Cursors.Hand;
            tile.BackColor = isActive ? ActiveTileColor : TileColor;
            tile.Resize += delegate { ApplyRoundedRegion(tile, 8); tile.Invalidate(); };
            tile.HandleCreated += delegate { ApplyRoundedRegion(tile, 8); };
            tile.Click += delegate { SelectAssetFromTile(key, file); };
            tile.Paint += delegate(object sender, PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                Color border = isActive ? accent : BorderColor;
                Rectangle rect = new Rectangle(0, 0, tile.Width - 1, tile.Height - 1);
                using (GraphicsPath path = RoundedRect(rect, 8))
                using (Pen pen = new Pen(border, isActive ? 2 : 1))
                {
                    e.Graphics.DrawPath(pen, path);
                }
            };

            PictureBox pic = new PictureBox();
            pic.SetBounds(8, isActive ? 32 : 8, tileWidth - 16, isActive ? 72 : 90);
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            pic.BackColor = dark;
            if (File.Exists(file)) SetPicture(pic, file);
            pic.Cursor = Cursors.Hand;
            pic.Click += delegate { SelectAssetFromTile(key, file); };
            tile.Controls.Add(pic);

            Label name = new Label();
            name.Text = Path.GetFileName(file);
            name.ForeColor = TextColor;
            name.BackColor = tile.BackColor;
            name.SetBounds(8, 114, Math.Max(70, tileWidth - 70), 22);
            name.Cursor = Cursors.Hand;
            name.Click += delegate { SelectAssetFromTile(key, file); };
            tile.Controls.Add(name);

            if (isActive)
            {
                Label activeLabel = new Label();
                activeLabel.Text = "ACTIVO";
                activeLabel.TextAlign = ContentAlignment.MiddleCenter;
                activeLabel.ForeColor = Color.White;
                activeLabel.BackColor = accent;
                activeLabel.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
                activeLabel.SetBounds(0, 0, tile.Width, 26);
                activeLabel.Cursor = Cursors.Hand;
                activeLabel.Click += delegate { SelectAssetFromTile(key, file); };
                tile.Controls.Add(activeLabel);
                activeLabel.BringToFront();
            }

            Button del = Button("X");
            del.SetBounds(tileWidth - 40, 120, 32, 24);
            del.Cursor = Cursors.Default;
            del.Click += delegate { DeleteAsset(file, key); };
            tile.Controls.Add(del);
            del.BringToFront();
            panel.Controls.Add(tile);
        }
    }

    private void AddLayerScaleControls(Panel header, int tileWidth, string key)
    {
        Label title = new Label();
        title.Text = key == "overlay" ? "Tamaño overlay" : "Tamaño logo";
        title.Font = new Font("Segoe UI", 8F, FontStyle.Regular);
        title.ForeColor = MutedTextColor;
        title.BackColor = SurfaceColor;
        title.SetBounds(0, 34, Math.Max(92, (tileWidth - 8) / 2), 18);
        header.Controls.Add(title);

        Label value = new Label();
        value.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        value.ForeColor = TextColor;
        value.BackColor = SurfaceColor;
        value.TextAlign = ContentAlignment.MiddleRight;
        value.SetBounds(Math.Max(96, tileWidth / 2 - 4), 34, Math.Max(90, tileWidth / 2), 18);
        header.Controls.Add(value);

        FlatSlider slider = new FlatSlider();
        slider.Minimum = 20;
        slider.Maximum = key == "logo" ? 250 : 200;
        slider.Step = 5;
        slider.SetBounds(0, 48, Math.Max(120, tileWidth - 4), 28);
        header.Controls.Add(slider);

        if (key == "overlay")
        {
            overlayScaleSlider = slider;
            overlayScaleValueLabel = value;
            overlayScaleSlider.Value = Clamp((int)Math.Round(ToDouble(Value("overlay_scale"), 1.0) * 100.0), overlayScaleSlider.Minimum, overlayScaleSlider.Maximum);
            lastSavedOverlayScale = overlayScaleSlider.Value;
            overlayScaleSlider.ValueChanged += delegate
            {
                UpdateOverlayScaleLabel();
                QueueLivePreview();
            };
            overlayScaleSlider.ValueCommitted += delegate { CommitOverlayScale(); };
            UpdateOverlayScaleLabel();
        }
        else
        {
            logoScaleSlider = slider;
            logoScaleValueLabel = value;
            logoScaleSlider.Value = Clamp((int)Math.Round(ToDouble(Value("logo_scale"), 1.0) * 100.0), logoScaleSlider.Minimum, logoScaleSlider.Maximum);
            lastSavedLogoScale = logoScaleSlider.Value;
            logoScaleSlider.ValueChanged += delegate
            {
                UpdateLogoScaleLabel();
                SetStateValueLocal("logo_scale", LogoScaleValue().ToString("0.###", CultureInfo.InvariantCulture));
                QueueLivePreview();
            };
            logoScaleSlider.ValueCommitted += delegate { CommitLogoScale(); };
            UpdateLogoScaleLabel();
        }
    }

    private void SelectAssetFromTile(string key, string file)
    {
        if (key == "overlay")
        {
            ClearOverlayCache();
            SaveSimple(key, file, false);
            overlayBox.Text = file;
            SetStateValueLocal("overlay", file);
            SetStateValueLocal("overlay_abs", file);
            if (activeOverlayNameLabel != null) activeOverlayNameLabel.Text = ActiveAssetName(file, "Sin overlay");
            FitOverlayToBackgroundWidth(file, false);
            DrawAssets();
        }
        else if (key == "logo")
        {
            ClearLogoCache();
            SaveSimple(key, file, false);
            SetStateValueLocal("logo", file);
            SetStateValueLocal("logo_abs", file);
            SetStateValueLocal("logo_x", "0");
            SetStateValueLocal("logo_y", "0");
            SetStateValueLocal("logo_scale", "1");
            if (logoScaleSlider != null)
            {
                logoScaleSlider.Value = 100;
                lastSavedLogoScale = 100;
                UpdateLogoScaleLabel();
            }
            DrawAssets();
        }
        else
        {
            ClearPreviewBase();
            SaveSimple(key, file, true);
        }
        DrawScenePreviewImmediate();
    }

    private void SetPicture(PictureBox box, string path)
    {
        try
        {
            using (Image src = LoadBitmapUnlocked(path))
            {
                ReplaceImage(box, new Bitmap(src));
            }
        }
        catch
        {
            ReplaceImage(box, null);
        }
    }

    private void ReplaceImage(PictureBox box, Image image)
    {
        Image old = box.Image;
        box.Image = image;
        if (old != null) old.Dispose();
    }

    private void DeleteAsset(string file, string key)
    {
        if (!File.Exists(file)) { LoadState(); return; }
        if (MessageBox.Show(this, "Eliminar " + Path.GetFileName(file) + "?", "Eliminar", MessageBoxButtons.YesNo) != DialogResult.Yes) return;
        try
        {
            string active = key == "overlay" ? Value("overlay_abs") : key == "logo" ? Value("logo_abs") : Value("background_abs");
            if (!String.IsNullOrWhiteSpace(active) && String.Equals(Path.GetFullPath(active), Path.GetFullPath(file), StringComparison.OrdinalIgnoreCase))
            {
                SaveSimple(key, "", false);
            }
            File.Delete(file);
            LoadState();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "No se pudo eliminar");
        }
    }

    private bool IsHotfolderRunning()
    {
        return watchProcess != null && !watchProcess.HasExited;
    }

    private void ToggleHotfolder()
    {
        if (IsHotfolderRunning())
        {
            StopHotfolder();
            return;
        }
        StartHotfolder();
    }

    private void StartHotfolder()
    {
        if (closingApp) return;
        if (busy) return;
        try
        {
            SaveCurrentFields();
            hotfolderStopping = false;

            hotfolderConfigSnapshotPath = CreateFrozenConfigSnapshot("hotfolder");
            string args = "\"" + mainPy + "\" --config " + QuoteArg(hotfolderConfigSnapshotPath) + " --watch";
            ProcessStartInfo psi = new ProcessStartInfo(pythonExe, args);
            psi.WorkingDirectory = appDir;
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;

            watchProcess = Process.Start(psi);
            if (watchProcess != null)
            {
                Process startedProcess = watchProcess;
                watchProcess.EnableRaisingEvents = true;
                watchProcess.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
                {
                    AppendHotfolderLog(e.Data);
                };
                watchProcess.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
                {
                    AppendHotfolderLog(e.Data);
                };
                watchProcess.Exited += delegate
                {
                    try
                    {
                        if (!IsDisposed)
                        {
                            BeginInvoke((MethodInvoker)delegate
                            {
                                if (progressTimer != null) progressTimer.Stop();
                                UpdateHotfolderButton(false);
                                UpdateStopButtonState();
                                CleanupConfigSnapshot(hotfolderConfigSnapshotPath);
                                hotfolderConfigSnapshotPath = "";
                                if (progressLabel != null) progressLabel.Text = "Hotfolder parada.";
                                if (logBox != null)
                                {
                                    FinishActiveLogFolder(activeLogFolderName);
                                    int exitCode = -1;
                                    try { exitCode = startedProcess.ExitCode; } catch { }
                                    if (!hotfolderStopping)
                                    {
                                        AddLog("Hotfolder se ha detenido. Codigo: " + exitCode);
                                        AddLog("Si no la paraste tu, revisa el mensaje anterior.");
                                    }
                                }
                            });
                        }
                    }
                    catch { }
                };
                watchProcess.BeginOutputReadLine();
                watchProcess.BeginErrorReadLine();
            }

            UpdateHotfolderButton(true);
            UpdateStopButtonState();
            progressTotal = Math.Max(0, CountJpg(Value("input_abs")));
            progressStartOut = CountJpg(Value("output_abs"));
            progressStartIn = CountJpg(Value("input_abs"));
            ResetProgressTiming();
            progressFolderName = "";
            if (batchProgress != null) batchProgress.Value = 0;
            if (progressTotal > 0 && progressTimer != null) progressTimer.Start();
            if (progressLabel != null) progressLabel.Text = "Hotfolder activa: procesa JPG nuevos en IN y subcarpetas.";
            if (logBox != null)
            {
                ResetVisibleProcessingLog();
                ClearLog();
                AddLog("Hotfolder activa. Esperando fotos en IN...");
            }
        }
        catch (Exception ex)
        {
            CleanupConfigSnapshot(hotfolderConfigSnapshotPath);
            hotfolderConfigSnapshotPath = "";
            if (logBox != null)
            {
                ClearLog();
                AddLog("ERROR hotfolder: " + ex.Message);
            }
            UpdateHotfolderButton(false);
        }
    }

    private void StopHotfolder()
    {
        StopHotfolder(false);
    }

    private void StopHotfolder(bool shuttingDown)
    {
        try
        {
            hotfolderStopping = true;
            if (IsHotfolderRunning()) KillProcessTree(watchProcess);
        }
        catch { }
        if (progressTimer != null) progressTimer.Stop();
        watchProcess = null;
        CleanupConfigSnapshot(hotfolderConfigSnapshotPath);
        hotfolderConfigSnapshotPath = "";
        if (shuttingDown || IsDisposed) return;
        UpdateHotfolderButton(false);
        UpdateStopButtonState();
        if (progressLabel != null) progressLabel.Text = "Hotfolder parada. Modo manual activo.";
    }

    private void UpdateHotfolderButton(bool active)
    {
        if (hotfolderButton == null) return;
        hotfolderButton.Text = active ? "Hotfolder ON" : "Hotfolder OFF";
        ApplyButtonVisual(hotfolderButton, active);
    }

    private bool IsMoveProcessedEnabled()
    {
        return String.Equals(Value("move_processed"), "true", StringComparison.OrdinalIgnoreCase);
    }

    private void ToggleMoveProcessed()
    {
        bool enabled = !IsMoveProcessedEnabled();
        SetStateValueLocal("move_processed", enabled ? "true" : "false");
        SaveSimple("move_processed", enabled ? "true" : "false", false);
        UpdateMoveProcessedButton(enabled);
        if (IsHotfolderRunning() && progressLabel != null)
        {
            progressLabel.Text = "Cambio guardado. Reinicia Hotfolder para aplicarlo.";
        }
        if (IsHotfolderRunning() && logBox != null)
        {
            AddLog("Mover procesadas cambiado a " + (enabled ? "ON" : "OFF") + ". Para aplicarlo al Hotfolder, paralo y vuelvelo a arrancar.");
        }
    }

    private void UpdateMoveProcessedButton(bool enabled)
    {
        if (moveProcessedButton == null) return;
        moveProcessedButton.Text = enabled ? "Mover procesadas ON" : "Mover procesadas OFF";
        ApplyButtonVisual(moveProcessedButton, enabled);
    }

    private bool IsPhotoEnhanceAutoTuneEnabled()
    {
        return String.Equals(Value("photo_enhance_autotune"), "true", StringComparison.OrdinalIgnoreCase);
    }

    private void TogglePhotoEnhanceAutoTune()
    {
        bool enabled = !IsPhotoEnhanceAutoTuneEnabled();
        SetStateValueLocal("photo_enhance_autotune", enabled ? "true" : "false");
        if (enabled)
        {
            SetStateValueLocal("photo_enhance_engine", "enhancer2");
            SaveSimple("photo_enhance_engine", "enhancer2", false);
        }
        SaveSimple("photo_enhance_autotune", enabled ? "true" : "false", false);
        UpdatePhotoEnhanceAutoTuneButton(enabled);
        UpdatePhotoEnhanceLabel();
        QueueLivePreview();
        if (logBox != null)
        {
            AddLog("AutoTune mejora foto " + (enabled ? "ON" : "OFF") + ".");
        }
    }

    private void UpdatePhotoEnhanceAutoTuneButton(bool enabled)
    {
        if (photoEnhanceAutoTuneButton == null) return;
        photoEnhanceAutoTuneButton.Text = enabled ? "Auto ON" : "Auto OFF";
        ApplyButtonVisual(photoEnhanceAutoTuneButton, enabled);
    }

    private string NuvolModeValue()
    {
        if (nuvolModeCombo == null || nuvolModeCombo.SelectedItem == null)
        {
            string current = Value("nuvol_mode");
            return String.IsNullOrWhiteSpace(current) ? "upload_only" : current;
        }
        string text = nuvolModeCombo.SelectedItem.ToString().Trim().ToLowerInvariant();
        return text.IndexOf("download", StringComparison.OrdinalIgnoreCase) >= 0 ? "upload_and_download" : "upload_only";
    }

    private void SelectNuvolMode(string mode)
    {
        if (nuvolModeCombo == null) return;
        if (nuvolModeCombo.Items.Count == 0)
        {
            nuvolModeCombo.Items.AddRange(new string[] { "upload only", "upload and download" });
        }
        string normalized = (mode ?? "").Trim().ToLowerInvariant();
        nuvolModeCombo.SelectedIndex = normalized == "upload_download" || normalized == "upload_and_download" ? 1 : 0;
    }
    private bool IsNuvolEnabled()
    {
        return String.Equals(Value("nuvol_enabled"), "true", StringComparison.OrdinalIgnoreCase);
    }

    private void ToggleNuvol()
    {
        bool enabled = !IsNuvolEnabled();
        SetStateValueLocal("nuvol_enabled", enabled ? "true" : "false");
        SaveSimple("nuvol_enabled", enabled ? "true" : "false", false);
        UpdateNuvolButton(enabled);
        if (progressLabel != null)
        {
            progressLabel.Text = enabled ? "Modulo Nuvol activado." : "Modulo Nuvol desactivado.";
        }
        if (logBox != null)
        {
            AddLog("Modulo Nuvol " + (enabled ? "ON" : "OFF") + ".");
        }
    }

    private void UpdateNuvolButton(bool enabled)
    {
        if (nuvolButton == null) return;
        nuvolButton.Text = enabled ? "Nuvol ON" : "Nuvol OFF";
        ApplyButtonVisual(nuvolButton, enabled);
    }

    private void UpdateBatchProcessButton(bool active)
    {
        if (batchProcessButton == null) return;
        ApplyButtonVisual(batchProcessButton, active);
    }

    private void UpdateStopButtonState()
    {
        if (stopButton == null) return;
        bool active = busy || IsHotfolderRunning();
        stopButton.Enabled = active;
        stopButton.Visible = active;
        ApplyButtonVisual(stopButton, active);
        CenteredButton cb = stopButton as CenteredButton;
        if (cb != null)
        {
            cb.UseGradient = false;
            cb.CornerRadius = 8;
        }
        if (stopButton.Parent != null)
        {
            Control panel = stopButton.Parent;
            int abortWidth = stopButton.Visible ? 86 : 0;
            int right = panel.ClientSize.Width - 12;
            if (stopButton.Visible)
            {
                stopButton.SetBounds(Math.Max(12, right - abortWidth), 8, abortWidth, 24);
            }
            int available = Math.Max(80, panel.ClientSize.Width - 24);
            if (progressLabel != null) progressLabel.SetBounds(12, 36, available, 18);
            if (batchProgress != null) batchProgress.SetBounds(12, 62, available, 14);
        }
        stopButton.Invalidate();
    }

    private void StopCurrentWork()
    {
        StopCurrentWork(false);
    }

    private void StopCurrentWork(bool shuttingDown)
    {
        cancelRequested = true;
        try
        {
            hotfolderStopping = true;
            if (IsHotfolderRunning()) KillProcessTree(watchProcess);
        }
        catch { }

        try
        {
            Process p = runningProcess;
            if (p != null && !p.HasExited) KillProcessTree(p);
        }
        catch { }

        if (shuttingDown)
        {
            WaitForWorkerToStop(2500);
            try
            {
                Process p = runningProcess;
                if (p != null && !p.HasExited) KillProcessTree(p);
            }
            catch { }
            return;
        }

        UpdateHotfolderButton(false);
        UpdateStopButtonState();
        if (progressLabel != null) progressLabel.Text = "Parando proceso...";
        if (logBox != null)
        {
            ClearLog();
            AddLog("Parada solicitada.");
            AddLog("Cerrando procesos Python de Maskerade...");
        }
    }

    private void WaitForWorkerToStop(int milliseconds)
    {
        try
        {
            Thread t = runningWorkerThread;
            if (t != null && t.IsAlive) t.Join(milliseconds);
        }
        catch { }
    }

    private void KillProcessTree(Process process)
    {
        if (process == null) return;
        try
        {
            if (process.HasExited) return;
            ProcessStartInfo psi = new ProcessStartInfo("taskkill.exe", "/PID " + process.Id + " /T /F");
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            Process killer = Process.Start(psi);
            if (killer != null) killer.WaitForExit(5000);
            try { process.WaitForExit(3000); } catch { }
        }
        catch
        {
            try
            {
                if (!process.HasExited) process.Kill();
            }
            catch { }
        }
    }

    private void KillOwnedPythonProcesses()
    {
        try
        {
            string root = appDir.TrimEnd('\\');
            string script =
                "$root=" + PowerShellQuote(root) + ";" +
                "$py=" + PowerShellQuote(pythonExe) + ";" +
                "Get-CimInstance Win32_Process -Filter \"name='python.exe' or name='pythonw.exe'\" | " +
                "Where-Object { ($_.ExecutablePath -eq $py) -or ($_.CommandLine -like ('*' + $root + '*')) } | " +
                "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }";
            ProcessStartInfo psi = new ProcessStartInfo("powershell.exe", "-NoProfile -ExecutionPolicy Bypass -Command " + QuoteArg(script));
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            Process killer = Process.Start(psi);
            if (killer != null) killer.WaitForExit(5000);
        }
        catch { }
    }

    private string PowerShellQuote(string value)
    {
        return "'" + (value ?? "").Replace("'", "''") + "'";
    }

    private void RunProcess(bool one)
    {
        if (closingApp) return;
        if (busy) return;
        if (IsHotfolderRunning())
        {
            if (progressLabel != null) progressLabel.Text = "Para Hotfolder antes de procesar manualmente.";
            if (logBox != null)
            {
                ClearLog();
                AddLog("Hotfolder esta activa.");
                AddLog("Pulsa Hotfolder ON para pararla antes de usar modo manual.");
            }
            return;
        }
        string selectedPreviewInput = one ? CurrentFirstInputForPreview() : "";
        SaveCurrentFields();
        LoadState();
        string frozenFirstInput = one && !String.IsNullOrWhiteSpace(selectedPreviewInput) && File.Exists(selectedPreviewInput)
            ? selectedPreviewInput
            : Value("first_input");
        if (one && String.IsNullOrWhiteSpace(frozenFirstInput))
        {
            if (progressLabel != null) progressLabel.Text = "No hay JPG en IN.";
            if (logBox != null)
            {
                ClearLog();
                AddLog("No hay JPG en IN.");
            }
            return;
        }
        string frozenConfigPath;
        try
        {
            frozenConfigPath = CreateFrozenConfigSnapshot(one ? "single" : "batch");
        }
        catch (Exception ex)
        {
            if (progressLabel != null) progressLabel.Text = "ERROR congelando configuracion.";
            if (logBox != null)
            {
                ClearLog();
                AddLog("ERROR congelando configuracion: " + ex.Message);
            }
            return;
        }
        busy = true;
        cancelRequested = false;
        UpdateStopButtonState();
        StartProgress(one);
        ClearLog();
        AddLog("Procesando...");
        if (one && !String.IsNullOrWhiteSpace(frozenFirstInput))
        {
            AddLog("Foto preview: " + Path.GetFileName(frozenFirstInput));
        }
        Thread t = new Thread(delegate()
        {
            if (closingApp || cancelRequested)
            {
                CleanupConfigSnapshot(frozenConfigPath);
                return;
            }
            string args;
            if (one)
            {
                args = "\"" + mainPy + "\" --config " + QuoteArg(frozenConfigPath) + " --file " + QuoteArg(frozenFirstInput);
            }
            else
            {
                args = "\"" + mainPy + "\" --config " + QuoteArg(frozenConfigPath) + " --batch";
            }
            RunProcessWorker(args, frozenConfigPath);
        });
        t.IsBackground = true;
        runningWorkerThread = t;
        t.Start();
    }

    private void RunProcessWorker(string args, string configSnapshotPath)
    {
        try
        {
            if (closingApp || cancelRequested) return;
            ProcessStartInfo psi = new ProcessStartInfo(pythonExe, args);
            psi.WorkingDirectory = appDir;
            psi.UseShellExecute = false;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;
            psi.CreateNoWindow = true;
            Process p = Process.Start(psi);
            if (p == null)
            {
                UiDone("ERROR: no se pudo arrancar Python.", false);
                return;
            }
            runningProcess = p;
            if (closingApp || cancelRequested)
            {
                KillProcessTree(p);
            }
            StringBuilder output = new StringBuilder();
            StringBuilder error = new StringBuilder();
            object captureLock = new object();
            p.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e)
            {
                if (e.Data == null) return;
                lock (captureLock) output.AppendLine(e.Data);
                AppendProcessLog(e.Data);
            };
            p.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e)
            {
                if (e.Data == null) return;
                lock (captureLock) error.AppendLine(e.Data);
                AppendProcessLog(e.Data);
            };
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();
            if (cancelRequested && p != null && !p.HasExited)
            {
                KillProcessTree(p);
            }
            p.WaitForExit();
            string outputText;
            string errorText;
            lock (captureLock)
            {
                outputText = output.ToString().Trim();
                errorText = error.ToString().Trim();
            }
            string text = outputText;
            if (errorText.Length > 0) text = text.Length > 0 ? text + "\n" + errorText : errorText;
            if (cancelRequested)
            {
                UiDone("Proceso parado por el operador.", false);
            }
            else
            {
                UiDone(text.Length > 0 ? text : "Terminado.", p.ExitCode == 0);
            }
        }
        catch (Exception ex)
        {
            UiDone(cancelRequested ? "Proceso parado por el operador." : "ERROR: " + ex.Message, false);
        }
        finally
        {
            runningProcess = null;
            runningWorkerThread = null;
            CleanupConfigSnapshot(configSnapshotPath);
        }
    }

    private void UiDone(string text, bool ok)
    {
        if (closingApp || IsDisposed || !IsHandleCreated) return;
        BeginInvoke((MethodInvoker)delegate
        {
            if (closingApp || IsDisposed) return;
            busy = false;
            cancelRequested = false;
            UpdateStopButtonState();
            FinishProgress(ok);
            FillLastRunSummary(text, ok);
            LoadState();
        });
    }

    private void FillLastRunSummary(string rawText, bool ok)
    {
        if (logBox == null) return;
        ClearLog();

        if (!ok)
        {
            if (rawText.StartsWith("Proceso parado", StringComparison.OrdinalIgnoreCase))
            {
                AddLog(rawText);
                return;
            }
            AddLog("ERROR en el proceso");
            foreach (string line in CleanProcessLines(rawText))
            {
                AddLog(line);
                if (logLineCount >= 9) break;
            }
            return;
        }

        List<string> entries = LatestProcessingEntries(progressTotal <= 0 ? 1 : progressTotal);
        if (entries.Count == 0)
        {
            AddLog("Terminado correctamente.");
            foreach (string line in CleanProcessLines(rawText))
            {
                AddLog(line);
                if (logLineCount >= 8) break;
            }
            return;
        }

        int processed = 0;
        int failed = 0;
        double seconds = 0;
        string lastInput = "";
        string lastOutput = "";
        string backend = "";

        foreach (string entry in entries)
        {
            string status = JsonValue(entry, "status");
            if (status == "processed") processed++;
            if (status == "failed") failed++;
            double dur;
            if (Double.TryParse(JsonValue(entry, "duration_seconds").Replace(".", ","), out dur) ||
                Double.TryParse(JsonValue(entry, "duration_seconds"), out dur))
            {
                seconds += dur;
            }
            string input = JsonValue(entry, "input");
            string output = JsonValue(entry, "output");
            if (input.Length > 0) lastInput = Path.GetFileName(input);
            if (output.Length > 0) lastOutput = Path.GetFileName(output);
            string b = JsonValue(entry, "backend");
            if (b.Length > 0) backend = b;
        }

        AddLog("Resumen final");
        AddLog("Procesadas: " + processed + (failed > 0 ? " · Fallidas: " + failed : ""));
        if (processed > 0)
        {
            double avg = seconds / processed;
            AddLog("Tiempo total: " + seconds.ToString("0.0") + "s · Media: " + avg.ToString("0.0") + "s/foto");
        }
    }

    private List<string> CleanProcessLines(string rawText)
    {
        List<string> result = new List<string>();
        foreach (string raw in rawText.Replace("\r", "").Split('\n'))
        {
            string line = raw.Trim();
            if (line.Length == 0) continue;
            if (line.IndexOf("Loading weights", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            if (line.IndexOf("site-packages", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            if (line.IndexOf("UserWarning", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            if (line.IndexOf("FutureWarning", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            if (line.IndexOf("INFO | photoia | Loading", StringComparison.OrdinalIgnoreCase) >= 0) continue;
            line = line.Replace(appDir + "\\", "");
            if (line.IndexOf("Background image not found", StringComparison.OrdinalIgnoreCase) >= 0 ||
                line.IndexOf("No se ha detectado Fondo", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                line = "No se ha detectado Fondo, por favor selecciona uno.";
            }
            else if (line.StartsWith("Configuration error:", StringComparison.OrdinalIgnoreCase))
            {
                line = line.Substring("Configuration error:".Length).Trim();
            }
            if (line.StartsWith("Processed:", StringComparison.OrdinalIgnoreCase))
            {
                line = "Procesado: " + Path.GetFileName(line.Substring("Processed:".Length).Trim());
            }
            bool isImportantError =
                line.IndexOf("error", StringComparison.OrdinalIgnoreCase) >= 0 ||
                line.IndexOf("No se ha detectado", StringComparison.OrdinalIgnoreCase) >= 0 ||
                line.IndexOf("not found", StringComparison.OrdinalIgnoreCase) >= 0;
            if (!isImportantError && line.Length > 54) line = line.Substring(0, 51) + "...";
            result.Add(line);
        }
        return result;
    }

    private List<string> LatestProcessingEntries(int maxEntries)
    {
        List<string> result = new List<string>();
        try
        {
            string file = Path.Combine(appDir, "logs", "processing.jsonl");
            if (!File.Exists(file)) return result;
            string[] lines = File.ReadAllLines(file);
            for (int i = lines.Length - 1; i >= 0 && result.Count < Math.Max(1, maxEntries); i--)
            {
                string line = lines[i].Trim();
                if (line.StartsWith("{") && line.EndsWith("}")) result.Insert(0, line);
            }
        }
        catch { }
        return result;
    }

    private string JsonValue(string json, string key)
    {
        string marker = "\"" + key + "\":";
        int idx = json.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
        if (idx < 0) return "";
        idx += marker.Length;
        while (idx < json.Length && Char.IsWhiteSpace(json[idx])) idx++;
        if (idx >= json.Length) return "";
        if (json[idx] == '"')
        {
            idx++;
            int end = idx;
            while (end < json.Length)
            {
                if (json[end] == '"' && json[end - 1] != '\\') break;
                end++;
            }
            if (end <= idx) return "";
            return json.Substring(idx, end - idx).Replace("\\\\", "\\").Replace("\\\"", "\"");
        }
        int stop = idx;
        while (stop < json.Length && json[stop] != ',' && json[stop] != '}') stop++;
        return json.Substring(idx, stop - idx).Trim();
    }

    private void StartProgress(bool one)
    {
        int currentIn = CountJpg(Value("input_abs"));
        progressTotal = one ? 1 : currentIn;
        progressStartOut = CountJpg(Value("output_abs"));
        progressStartIn = currentIn;
        ResetProgressTiming();
        progressFolderName = "";
        ResetVisibleProcessingLog();
        UpdateBatchProcessButton(!one);
        if (batchProgress != null) batchProgress.Value = 0;
        if (progressLabel != null)
        {
            progressLabel.Text = progressTotal > 0
                ? "Procesando 0/" + progressTotal
                : "No hay fotos pendientes.";
        }
        if (progressTotal > 0) progressTimer.Start();
    }

    private void FinishProgress(bool ok)
    {
        if (progressTimer != null) progressTimer.Stop();
        UpdateBatchProcessButton(false);
        if (batchProgress != null) batchProgress.Value = ok ? 100 : Math.Min(batchProgress.Value, 99);
        if (progressLabel != null)
        {
            progressLabel.Text = ok ? "100% · terminado." : "Proceso detenido con error.";
        }
    }

    private void UpdateProgressEstimate()
    {
        if (progressTotal <= 0) return;

        int currentOut = CountJpg(Value("output_abs"));
        int currentIn = CountJpg(Value("input_abs"));
        int doneByOut = Math.Max(0, currentOut - progressStartOut);
        int doneByIn = Math.Max(0, progressStartIn - currentIn);
        int done = Math.Min(progressTotal, Math.Max(doneByOut, doneByIn));
        int percent = Math.Max(0, Math.Min(99, (int)Math.Round(done * 100.0 / progressTotal)));

        if (batchProgress != null) batchProgress.Value = percent;
        if (progressLabel == null) return;

        TimeSpan elapsed = DateTime.Now - progressStartedAt;
        int current = Math.Min(progressTotal, Math.Max(1, done + 1));
        if (done <= 0)
        {
            progressLabel.Text = "Procesando " + current + "/" + progressTotal;
            return;
        }

        double secondsPerPhoto = progressSecondsPerPhoto > 0.0
            ? progressSecondsPerPhoto
            : elapsed.TotalSeconds / done;
        int left = Math.Max(0, progressTotal - done);
        TimeSpan remaining = TimeSpan.FromSeconds(secondsPerPhoto * left);
        progressLabel.Text = "Procesando " + current + "/" + progressTotal +
            (left > 0 ? " · quedan " + FormatTime(remaining) : " · terminando...");
    }

    private void ResetProgressTiming()
    {
        progressStartedAt = DateTime.Now;
        progressTimingStarted = false;
        progressProcessedCount = 0;
        progressSecondsPerPhoto = 0.0;
    }

    private void MarkProgressProcessingStarted()
    {
        if (progressTimingStarted) return;
        progressTimingStarted = true;
        progressStartedAt = DateTime.Now;
    }

    private void UpdateProgressSpeed(double seconds)
    {
        double cleanSeconds = Math.Max(0.0, seconds);
        if (cleanSeconds <= 0.0) return;

        progressProcessedCount++;
        progressSecondsPerPhoto = progressProcessedCount == 1 || progressSecondsPerPhoto <= 0.0
            ? cleanSeconds
            : (progressSecondsPerPhoto + cleanSeconds) / 2.0;
    }

    private void EnsureProgressCountersForRunningBatch()
    {
        if (progressTotal > 0)
        {
            int currentOut = CountJpg(Value("output_abs"));
            int currentIn = CountJpg(Value("input_abs"));
            int doneByOut = Math.Max(0, currentOut - progressStartOut);
            int doneByIn = Math.Max(0, progressStartIn - currentIn);
            int done = Math.Min(progressTotal, Math.Max(doneByOut, doneByIn));
            if (done < progressTotal) return;
        }
        int inputCount = CountJpg(Value("input_abs"));
        progressTotal = Math.Max(1, inputCount);
        progressStartOut = CountJpg(Value("output_abs"));
        progressStartIn = Math.Max(progressTotal, inputCount);
        ResetProgressTiming();
        if (batchProgress != null) batchProgress.Value = 0;
        if (progressTimer != null) progressTimer.Start();
    }

    private int CountJpg(string folder)
    {
        try
        {
            if (String.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder)) return 0;
            return Directory.GetFiles(folder, "*.jpg", SearchOption.AllDirectories).Length +
                Directory.GetFiles(folder, "*.jpeg", SearchOption.AllDirectories).Length;
        }
        catch
        {
            return 0;
        }
    }

    private int ToInt(string text)
    {
        int value;
        return Int32.TryParse(text, out value) ? value : 0;
    }

    private double ToDouble(string text, double fallback)
    {
        double value;
        if (Double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value)) return value;
        if (Double.TryParse(text, out value)) return value;
        return fallback;
    }

    private double OverlayScaleValue()
    {
        if (overlayScaleSlider != null) return Math.Max(0.1, overlayScaleSlider.Value / 100.0);
        return Math.Max(0.1, ToDouble(Value("overlay_scale"), 1.0));
    }

    private double LogoScaleValue()
    {
        if (logoScaleSlider != null) return Math.Max(0.1, logoScaleSlider.Value / 100.0);
        return Math.Max(0.1, ToDouble(Value("logo_scale"), 1.0));
    }

    private int Clamp(int value, int min, int max)
    {
        if (value < min) return min;
        if (value > max) return max;
        return value;
    }

    private void UpdateQualityLabel()
    {
        if (qualityValueLabel == null || qualitySlider == null) return;
        string note = qualitySlider.Value == 93 ? "original" : (qualitySlider.Value > 93 ? "mas peso" : "mas ligero");
        qualityValueLabel.Text = qualitySlider.Value.ToString() + "% calidad " + note;
    }

    private void UpdateMaskProtectionLabel()
    {
        if (maskProtectionValueLabel == null || maskProtectionSlider == null) return;
        string note;
        if (maskProtectionSlider.Value <= 0) note = "off";
        else if (maskProtectionSlider.Value < 35) note = "suave";
        else if (maskProtectionSlider.Value < 70) note = "medio";
        else if (maskProtectionSlider.Value < 95) note = "fuerte";
        else note = "maximo";
        maskProtectionValueLabel.Text = maskProtectionSlider.Value.ToString() + "% " + note;
    }

    private void UpdateMaskAntighostLabel()
    {
        if (maskAntighostValueLabel == null || maskAntighostSlider == null) return;
        maskAntighostValueLabel.Text = maskAntighostSlider.Value <= 0 ? "off" : maskAntighostSlider.Value.ToString() + "%";
    }

    private void UpdatePhotoZoomLabel()
    {
        if (photoZoomValueLabel == null || photoZoomSlider == null) return;
        string note;
        if (photoZoomSlider.Value < 95) note = "mas lejos";
        else if (photoZoomSlider.Value > 145) note = "muy cerca";
        else if (photoZoomSlider.Value > 105) note = "mas cerca";
        else note = "normal";
        photoZoomValueLabel.Text = photoZoomSlider.Value.ToString() + "% " + note;
    }

    private void UpdatePersonVerticalLabel()
    {
        if (personVerticalValueLabel == null || personVerticalSlider == null) return;
        string note;
        if (personVerticalSlider.Value < 0) note = "sube";
        else if (personVerticalSlider.Value > 0) note = "baja";
        else note = "centrado";
        personVerticalValueLabel.Text = personVerticalSlider.Value.ToString("+0;-0;0") + "% " + note;
    }

    private void UpdateOverlayScaleLabel()
    {
        if (overlayScaleValueLabel == null || overlayScaleSlider == null) return;
        string note;
        if (overlayScaleSlider.Value < 95) note = "mas pequeno";
        else if (overlayScaleSlider.Value > 105) note = "mas grande";
        else note = "original";
        overlayScaleValueLabel.Text = overlayScaleSlider.Value.ToString() + "% " + note;
    }

    private void UpdateLogoScaleLabel()
    {
        if (logoScaleValueLabel == null || logoScaleSlider == null) return;
        string note;
        if (logoScaleSlider.Value < 95) note = "mas pequeno";
        else if (logoScaleSlider.Value > 105) note = "mas grande";
        else note = "original";
        logoScaleValueLabel.Text = logoScaleSlider.Value.ToString() + "% " + note;
    }

    private void UpdateHarmonizeLabel()
    {
        if (harmonizeValueLabel == null || harmonizeSlider == null) return;
        string note;
        if (harmonizeSlider.Value <= 0) note = "off";
        else if (harmonizeSlider.Value < 35) note = "suave";
        else if (harmonizeSlider.Value < 75) note = "medio";
        else if (harmonizeSlider.Value <= 100) note = "fuerte";
        else note = "extra";
        harmonizeValueLabel.Text = harmonizeSlider.Value.ToString() + "% " + note;
    }

    private void UpdatePhotoEnhanceLabel()
    {
        if (photoEnhanceValueLabel == null) return;
        string engine = Value("photo_enhance_engine");
        if (String.Equals(engine, "none", StringComparison.OrdinalIgnoreCase) || String.Equals(engine, "off", StringComparison.OrdinalIgnoreCase))
        {
            photoEnhanceValueLabel.Text = "Sin mejora";
        }
        else if (IsPhotoEnhanceAutoTuneEnabled())
        {
            photoEnhanceValueLabel.Text = "Enhancer2 AutoTune";
        }
        else if (String.Equals(engine, "enhancer2", StringComparison.OrdinalIgnoreCase))
        {
            photoEnhanceValueLabel.Text = "Enhancer2 preset";
        }
        else
        {
            photoEnhanceValueLabel.Text = "Classic fijo";
        }
    }

    private void UpdateTextLayerControlLabels()
    {
        if (textLayerScaleLabel != null)
        {
            int scale = textLayerScaleSlider == null ? (int)Math.Round(ToDouble(Value("text_layer_scale"), 1.0) * 100.0) : textLayerScaleSlider.Value;
            textLayerScaleLabel.Text = "Tamaño " + scale.ToString() + "%";
        }
        if (textLayerRotationLabel != null)
        {
            int rotation = textLayerRotationSlider == null ? ToInt(Value("text_layer_rotation")) : textLayerRotationSlider.Value;
            textLayerRotationLabel.Text = "Giro " + rotation.ToString() + " grados";
        }
    }

    private void UpdateShadowLabel()
    {
        if (shadowValueLabel == null || shadowSlider == null) return;
        string note;
        if (shadowSlider.Value <= 0) note = "off";
        else if (shadowSlider.Value < 60) note = "suave";
        else if (shadowSlider.Value < 120) note = "media";
        else if (shadowSlider.Value < 170) note = "fuerte";
        else note = "muy fuerte";
        shadowValueLabel.Text = shadowSlider.Value.ToString() + "% " + note;
    }

    private string FormatTime(TimeSpan time)
    {
        if (time.TotalMinutes >= 1)
            return ((int)time.TotalMinutes).ToString() + "m " + time.Seconds.ToString("00") + "s";
        return Math.Max(0, (int)Math.Round(time.TotalSeconds)).ToString() + "s";
    }
}





