from __future__ import annotations

import numpy as np
from PIL import Image, ImageEnhance, ImageOps

try:
    import cv2
except Exception:  # pragma: no cover - optional runtime fallback
    cv2 = None

from .decision import CorrectionPlan


class EnhancementEngine:
    def apply(self, image: Image.Image, plan: CorrectionPlan) -> Image.Image:
        if plan.strength <= 0.001:
            return image.convert("RGB")
        if cv2 is None:
            return self._apply_pillow(image, plan)

        rgb = np.asarray(image.convert("RGB")).astype(np.float32)
        original = rgb.copy()
        skin = _skin_mask(rgb) if plan.skin_protection > 0 else np.zeros(rgb.shape[:2], dtype=np.float32)

        rgb = self._white_balance(rgb, plan, skin)
        rgb = self._exposure_gamma(rgb, plan, skin)
        rgb = self._tone_curve(rgb, plan)
        rgb = self._shadows_highlights(rgb, plan, skin)
        rgb = self._local_contrast(rgb, plan)
        rgb = self._saturation(rgb, plan, skin)
        rgb = self._denoise(rgb, plan, skin)
        rgb = self._sharpen(rgb, plan, skin)
        rgb = self._protect_extremes(original, rgb, skin, plan)

        return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB")

    def apply_fast(self, image: Image.Image, plan: CorrectionPlan) -> Image.Image:
        if plan.strength <= 0.001:
            return image.convert("RGB")
        if cv2 is None:
            return self._apply_pillow(image, plan)

        rgb = np.asarray(image.convert("RGB"))
        out = cv2.LUT(rgb, _fast_tone_lut(plan))

        contrast = plan.global_contrast * 0.12 + plan.local_contrast * 0.08
        if contrast > 0.005:
            out_float = out.astype(np.float32)
            out = np.clip((out_float - 128.0) * (1.0 + contrast) + 128.0, 0, 255).astype(np.uint8)

        if abs(plan.saturation) > 0.005:
            hsv = cv2.cvtColor(out, cv2.COLOR_RGB2HSV).astype(np.float32)
            hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + plan.saturation * 1.55), 0, 255)
            out = cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB)

        if plan.sharpen > 0.045:
            blur = cv2.GaussianBlur(out, (0, 0), 0.85)
            amount = min(0.28, 0.07 + plan.sharpen * 0.80)
            out = cv2.addWeighted(out, 1.0 + amount, blur, -amount, 0)

        return Image.fromarray(out, "RGB")

    def _apply_pillow(self, image: Image.Image, plan: CorrectionPlan) -> Image.Image:
        result = ImageOps.autocontrast(image.convert("RGB"), cutoff=1)
        result = ImageEnhance.Brightness(result).enhance(1.0 + plan.exposure * 0.30)
        result = ImageEnhance.Contrast(result).enhance(1.0 + plan.global_contrast * 0.46)
        result = ImageEnhance.Color(result).enhance(1.0 + plan.saturation * 1.05)
        result = ImageEnhance.Sharpness(result).enhance(1.0 + plan.sharpen * 1.35)
        return result

    def _white_balance(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        if plan.white_balance <= 0.18:
            return rgb
        means = np.mean(np.clip(rgb, 1, 255), axis=(0, 1))
        gray = float(np.mean(means))
        gains = np.clip(gray / np.maximum(means, 1.0), 0.86, 1.14)
        corrected = np.clip(rgb * gains[None, None, :], 0, 255)
        blend = min(0.24, plan.white_balance * 0.22)
        blend_map = blend * (1.0 - skin[..., None] * plan.skin_protection * 0.45)
        return rgb * (1.0 - blend_map) + corrected * blend_map

    def _exposure_gamma(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        out = rgb.copy()
        lum = _luminance(out)
        bright_skin_hold = 1.0 - skin * plan.skin_protection * _smoothstep(118.0, 218.0, lum) * 0.82
        if plan.gamma > 0.001:
            gamma = max(0.58, 1.0 - plan.gamma * 0.54)
            lut = np.clip(255.0 * np.power(np.arange(256, dtype=np.float32) / 255.0, gamma), 0, 255).astype(np.uint8)
            curved = cv2.LUT(np.clip(out, 0, 255).astype(np.uint8), lut).astype(np.float32)
            out = out * (1.0 - bright_skin_hold[..., None]) + curved * bright_skin_hold[..., None]
        if plan.exposure > 0.001:
            lum = _luminance(out)
            mid = _smoothstep(30.0, 220.0, lum) * (1.0 - _smoothstep(236.0, 255.0, lum))
            out += (30.0 * plan.exposure) * mid[..., None] * bright_skin_hold[..., None]
        return np.clip(out, 0, 255)

    def _tone_curve(self, rgb: np.ndarray, plan: CorrectionPlan) -> np.ndarray:
        if plan.global_contrast <= 0.001:
            return rgb
        lum = _luminance(rgb)
        p_low, p_high = np.percentile(lum, [1.0, 99.0])
        if p_high <= p_low + 8:
            return rgb
        stretched = np.clip((rgb - p_low) * (255.0 / (p_high - p_low)), 0, 255)
        blend = min(0.50, plan.global_contrast * 0.44)
        return rgb * (1.0 - blend) + stretched * blend

    def _shadows_highlights(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        lum = _luminance(rgb)
        shadows = 1.0 - _smoothstep(28.0, 132.0, lum)
        highs = _smoothstep(170.0, 250.0, lum)
        skin_shadow_hold = 1.0 - skin * plan.skin_protection * _smoothstep(95.0, 205.0, lum) * 0.75
        out = rgb.copy()
        out += (28.0 * plan.shadow_recovery) * shadows[..., None] * skin_shadow_hold[..., None]
        out -= (24.0 * plan.highlight_protection) * highs[..., None]
        return np.clip(out, 0, 255)

    def _local_contrast(self, rgb: np.ndarray, plan: CorrectionPlan) -> np.ndarray:
        if plan.local_contrast <= 0.10:
            return rgb
        lab = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=1.22 + plan.local_contrast * 2.2, tileGridSize=(8, 8))
        enhanced = clahe.apply(l_channel)
        blend = min(0.46, plan.local_contrast * 0.58)
        l_channel = cv2.addWeighted(l_channel, 1.0 - blend, enhanced, blend, 0)
        return cv2.cvtColor(cv2.merge([l_channel, a_channel, b_channel]), cv2.COLOR_LAB2RGB).astype(np.float32)

    def _saturation(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        if abs(plan.saturation) <= 0.001:
            return rgb
        hsv = cv2.cvtColor(np.clip(rgb, 0, 255).astype(np.uint8), cv2.COLOR_RGB2HSV).astype(np.float32)
        skin_hold = 1.0 - skin * plan.skin_protection * 0.65
        hsv[..., 1] = np.clip(hsv[..., 1] * (1.0 + plan.saturation * 1.45 * skin_hold), 0, 255)
        shadow = 1.0 - _smoothstep(32.0, 110.0, hsv[..., 2])
        hsv[..., 1] *= 1.0 - np.clip(0.08 * shadow * plan.strength, 0.0, 0.16)
        return cv2.cvtColor(np.clip(hsv, 0, 255).astype(np.uint8), cv2.COLOR_HSV2RGB).astype(np.float32)

    def _denoise(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        if plan.denoise <= 0.16:
            return rgb
        h = max(1, int(round(2 + 7 * min(1.0, plan.denoise))))
        denoised = cv2.fastNlMeansDenoisingColored(np.clip(rgb, 0, 255).astype(np.uint8), None, h, h, 5, 15)
        blend = min(0.42, 0.30 * plan.denoise)
        blend_map = blend * (1.0 - skin[..., None] * plan.skin_protection * 0.25)
        return rgb * (1.0 - blend_map) + denoised.astype(np.float32) * blend_map

    def _sharpen(self, rgb: np.ndarray, plan: CorrectionPlan, skin: np.ndarray) -> np.ndarray:
        if plan.sharpen <= 0.12:
            return rgb
        blur = cv2.GaussianBlur(rgb, (0, 0), 1.10)
        detail = rgb - blur
        lum = _luminance(rgb)
        edges = np.clip(cv2.Laplacian(np.clip(lum, 0, 255).astype(np.uint8), cv2.CV_32F), -255, 255)
        edge_mask = _smoothstep(4.0, 34.0, np.abs(edges))
        skin_hold = 1.0 - skin * plan.skin_protection * 0.55
        amount = 0.82 * plan.sharpen * edge_mask * skin_hold
        return np.clip(rgb + detail * amount[..., None], 0, 255)

    def _protect_extremes(self, original: np.ndarray, enhanced: np.ndarray, skin: np.ndarray, plan: CorrectionPlan) -> np.ndarray:
        lum = _luminance(original)
        keep_black = 1.0 - _smoothstep(12.0, 45.0, lum)
        keep_white = _smoothstep(238.0, 255.0, lum)
        keep_skin = skin * plan.skin_protection * _smoothstep(142.0, 245.0, lum) * 0.70
        keep = np.clip(keep_black * 0.25 + keep_white * 0.48 + keep_skin, 0.0, 0.82)[..., None]
        return enhanced * (1.0 - keep) + original * keep


def _luminance(rgb: np.ndarray) -> np.ndarray:
    return rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    t = np.clip((value - edge0) / max(0.0001, edge1 - edge0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _fast_tone_lut(plan: CorrectionPlan) -> np.ndarray:
    values = np.arange(256, dtype=np.float32)
    normalized = values / 255.0
    gamma = max(0.72, 1.0 - plan.gamma * 0.34)
    curve = 255.0 * np.power(normalized, gamma)
    shadows = 1.0 - _smoothstep(24.0, 126.0, values)
    mids = _smoothstep(42.0, 210.0, values) * (1.0 - _smoothstep(232.0, 255.0, values))
    highs = _smoothstep(178.0, 255.0, values)
    flash_guard = _smoothstep(0.34, 0.62, np.array([plan.highlight_protection], dtype=np.float32))[0]
    strength_lift = 8.0 * plan.strength * (1.0 - flash_guard)
    curve += (18.0 * plan.shadow_recovery) * shadows
    curve += (14.0 * plan.exposure + strength_lift) * mids
    curve -= (13.0 * plan.highlight_protection) * highs
    return np.clip(curve, 0, 255).astype(np.uint8)


def _skin_mask(rgb: np.ndarray) -> np.ndarray:
    height, width = rgb.shape[:2]
    max_side = max(height, width)
    if cv2 is not None and max_side > 900:
        scale = 900.0 / float(max_side)
        small_width = max(1, int(round(width * scale)))
        small_height = max(1, int(round(height * scale)))
        small = cv2.resize(np.clip(rgb, 0, 255).astype(np.uint8), (small_width, small_height), interpolation=cv2.INTER_AREA).astype(np.float32)
        small_mask = _skin_mask_raw(small)
        soft = cv2.GaussianBlur(small_mask.astype(np.float32), (0, 0), 2.0)
        return np.clip(cv2.resize(soft, (width, height), interpolation=cv2.INTER_LINEAR), 0.0, 1.0)
    mask = _skin_mask_raw(rgb)
    if cv2 is not None:
        soft = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), 3.0)
        return np.clip(soft, 0.0, 1.0)
    return mask.astype(np.float32)


def _skin_mask_raw(rgb: np.ndarray) -> np.ndarray:
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    mask = (
        (r > 55) & (g > 35) & (b > 22)
        & ((maxc - minc) > 12)
        & (r > g * 1.05)
        & (r > b * 1.12)
    )
    return mask.astype(np.float32)
