from __future__ import annotations

from dataclasses import asdict, dataclass

from .analyzer import ImageAnalysis
from .presets import EnhancementPreset


@dataclass(frozen=True)
class CorrectionPlan:
    preset_name: str
    strength: float
    white_balance: float
    exposure: float
    gamma: float
    global_contrast: float
    local_contrast: float
    shadow_recovery: float
    highlight_protection: float
    saturation: float
    skin_protection: float
    denoise: float
    sharpen: float
    jpeg_quality: int
    confidence: float
    autopilot_ready: bool = True

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


class DecisionEngine:
    """Preset-led decision layer prepared for future AutoPilot rules."""

    def build_plan(self, analysis: ImageAnalysis, preset: EnhancementPreset, requested_strength: float) -> CorrectionPlan:
        preset_strength = preset.get_float("strength", 0.80)
        base_strength = _clamp(float(requested_strength) * (0.55 + preset_strength * 0.65), 0.0, 1.65)
        underexposed = _clamp((0.50 - analysis.mean_luma) / 0.28, 0.0, 1.0)
        bright = _clamp((analysis.mean_luma - 0.60) / 0.25, 0.0, 1.0)
        flat = _clamp((0.56 - analysis.contrast_score) / 0.42, 0.0, 1.0)
        noisy = _clamp((analysis.noise_score - 0.28) / 0.55, 0.0, 1.0)
        clipped = _clamp(analysis.highlight_clip_percent / 8.0, 0.0, 1.0)
        confidence = 0.45 if analysis.width < 32 or analysis.height < 32 else (0.62 if analysis.highlight_clip_percent > 18.0 else 0.82)

        return CorrectionPlan(
            preset_name=preset.name,
            strength=round(base_strength, 4),
            white_balance=round(_clamp(preset.get_float("white_balance") * base_strength, 0.0, 1.0), 4),
            exposure=round(_clamp(preset.get_float("exposure") * base_strength * (0.65 + 0.55 * underexposed - 0.35 * bright), 0.0, 1.0), 4),
            gamma=round(_clamp(preset.get_float("gamma") * base_strength * (0.70 + 0.60 * underexposed), 0.0, 1.0), 4),
            global_contrast=round(_clamp(preset.get_float("global_contrast") * base_strength * (0.70 + 0.55 * flat), 0.0, 1.0), 4),
            local_contrast=round(_clamp(preset.get_float("local_contrast") * base_strength * (0.75 + 0.35 * flat), 0.0, 0.65), 4),
            shadow_recovery=round(_clamp(preset.get_float("shadow_recovery") * base_strength * (0.70 + 0.65 * underexposed - 0.25 * noisy), 0.0, 1.0), 4),
            highlight_protection=round(_clamp(preset.get_float("highlight_protection") * base_strength * (0.75 + 0.75 * clipped), 0.0, 1.0), 4),
            saturation=round(_clamp(preset.get_float("saturation") * base_strength * (0.75 + 0.35 * (1.0 - analysis.saturation_score)), -0.5, 0.55), 4),
            skin_protection=round(_clamp(preset.get_float("skin_protection", 0.85), 0.0, 1.0), 4),
            denoise=round(_clamp(preset.get_float("denoise") * base_strength * (0.65 + 0.85 * noisy), 0.0, 0.75), 4),
            sharpen=round(_clamp(preset.get_float("sharpen") * base_strength * (1.0 - 0.35 * noisy), 0.0, 0.75), 4),
            jpeg_quality=max(60, min(100, preset.get_int("jpeg_quality", 94))),
            confidence=round(confidence, 4),
        )


def _clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def diagnose(analysis: ImageAnalysis) -> dict[str, object]:
    return {
        "underexposed": analysis.mean_luma < 0.42,
        "overexposed": analysis.mean_luma > 0.68,
        "highlight_clipping": _level(analysis.highlight_clip_percent, 1.0, 4.0),
        "shadow_clipping": _level(analysis.shadow_clip_percent, 2.0, 8.0),
        "low_contrast": analysis.contrast_score < 0.48,
        "white_balance_shift": analysis.color_cast,
        "skin_detected": analysis.skin_detected,
        "noise_level": _level(analysis.noise_score, 0.28, 0.62),
        "sharpness": "low" if analysis.sharpness_score < 0.32 else "acceptable",
        "scene_type": "unknown",
        "confidence": 0.78,
    }


class AutoTuneDecisionEngine:
    def choose_preset(self, analysis: ImageAnalysis) -> tuple[str, dict[str, object]]:
        diagnosis = diagnose(analysis)
        reasons: list[str] = []
        selected = "default_event"

        if (
            analysis.skin_detected
            and analysis.highlight_clip_percent > 1.2
            and 0.36 <= analysis.mean_luma <= 0.62
        ):
            selected = "souvenir_family_flash_perfect_v1"
            reasons.append("souvenir_family_flash_highlights")
        elif (analysis.mean_luma < 0.37 or analysis.shadow_clip_percent > 7.0) and analysis.highlight_clip_percent < 4.5:
            selected = "cuevas_lowlight"
            reasons.append("low_light_or_shadow_clipping")
        elif analysis.highlight_clip_percent > 8.0:
            selected = "pirates_flash"
            reasons.append("highlight_protection_needed")
        elif analysis.mean_luma > 0.55 and analysis.saturation_score < 0.34:
            selected = "dinos_daylight"
            reasons.append("bright_low_saturation")
        elif analysis.mean_luma > 0.52 and analysis.saturation_score < 0.42:
            selected = "dinos_daylight"
            reasons.append("normal_light_needs_color_pop")
        elif analysis.skin_detected and analysis.mean_luma >= 0.45:
            selected = "default_event"
            reasons.append("skin_detected_balanced_event_profile")
        else:
            reasons.append("balanced_default")

        diagnosis["selected_preset"] = selected
        diagnosis["reasons"] = reasons
        diagnosis["mode"] = "autotune_basic"
        return selected, diagnosis


def _level(value: float, low: float, high: float) -> str:
    if value < low:
        return "low"
    if value < high:
        return "medium"
    return "high"
