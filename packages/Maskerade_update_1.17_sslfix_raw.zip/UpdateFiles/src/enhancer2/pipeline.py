from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PIL import Image, ImageOps

from .analyzer import EnhancementAnalyzer
from .decision import AutoTuneDecisionEngine, DecisionEngine
from .engine import EnhancementEngine
from .output import attach_report
from .presets import PresetManager
from .reanalyzer import ReAnalyzer
from .souvenir_flash import PRESET_NAME as SOUVENIR_FLASH_PRESET
from .souvenir_flash import AdaptiveSouvenirFlashEnhancer


VERSION = "0.1.0"


@dataclass(frozen=True)
class EnhancementResult:
    image: Image.Image
    report: dict[str, Any]


def enhance_image(
    image: Image.Image,
    preset_name: str = "default_event",
    strength: float = 1.0,
    root_dir: Path | None = None,
    autotune: bool = False,
) -> EnhancementResult:
    started = time.perf_counter()
    analyzer = EnhancementAnalyzer()
    preset_manager = PresetManager(root_dir)
    source = ImageOps.exif_transpose(image).convert("RGB")
    before = analyzer.analyze(source)
    diagnosis: dict[str, object] | None = None
    if autotune:
        preset_name, diagnosis = AutoTuneDecisionEngine().choose_preset(before)
    preset = preset_manager.load(preset_name)
    if preset.name == SOUVENIR_FLASH_PRESET:
        enhanced, souvenir_report = AdaptiveSouvenirFlashEnhancer().enhance(source, preset)
        after = analyzer.analyze(enhanced)
        quality = ReAnalyzer().compare(before, after)
        report: dict[str, Any] = {
            "engine": "enhancer2",
            "engine_label": "QEnhance Souvenir Flash Perfect v1" if autotune else "QEnhance Auto v2",
            "version": VERSION,
            "status": "ok",
            "preset": preset.name,
            "autotune": bool(autotune),
            "diagnosis": diagnosis,
            "requested_strength": round(float(strength), 4),
            "effective_strength": 1.0,
            "analysis": before.to_dict(),
            "decision": {
                "preset_name": preset.name,
                "autopilot_ready": True,
                "specialized_engine": "souvenir_family_flash_perfect_v1",
            },
            "reanalysis": after.to_dict(),
            "quality": quality.to_dict(),
            "fallback_used": False,
            "processing_ms": int(round((time.perf_counter() - started) * 1000)),
        }
        report.update(souvenir_report)
        return EnhancementResult(attach_report(enhanced, report), report)

    effective_strength = 0.72 if autotune else 1.0
    plan_strength = effective_strength
    if autotune and preset_name == "pirates_flash":
        plan_strength = 0.82
    elif autotune and preset_name == "cuevas_lowlight":
        plan_strength = 0.66
    plan = DecisionEngine().build_plan(before, preset, plan_strength)
    engine = EnhancementEngine()
    enhanced = engine.apply_fast(source, plan) if autotune else engine.apply(source, plan)
    after = analyzer.analyze(enhanced)
    quality = ReAnalyzer().compare(before, after)

    status = "ok"
    output_image = enhanced
    if not quality.accepted:
        status = "rejected_original"
        output_image = source

    report: dict[str, Any] = {
        "engine": "enhancer2",
        "engine_label": "QEnhance AutoTune" if autotune else "QEnhance Auto v2",
        "version": VERSION,
        "status": status,
        "preset": preset.name,
        "autotune": bool(autotune),
        "diagnosis": diagnosis,
        "requested_strength": round(float(strength), 4),
        "effective_strength": round(float(effective_strength), 4),
        "analysis": before.to_dict(),
        "decision": plan.to_dict(),
        "reanalysis": after.to_dict(),
        "quality": quality.to_dict(),
        "fallback_used": status != "ok",
        "processing_ms": int(round((time.perf_counter() - started) * 1000)),
    }
    return EnhancementResult(attach_report(output_image, report), report)
