from __future__ import annotations

import json
from dataclasses import dataclass, field, fields, replace
from pathlib import Path
from typing import Any


SUPPORTED_IMAGE_EXTENSIONS = {".jpg", ".jpeg"}


class ConfigurationError(RuntimeError):
    """Raised when settings are missing or invalid."""


@dataclass(frozen=True)
class BackgroundRemovalSettings:
    backend: str = "ben2"
    model: str = "models/BEN2"
    max_processing_side: int = 0
    ben2_model: str = "models/BEN2"
    ben2_device: str = "auto"
    ben2_refine_foreground: bool = False
    mask_protection: int = 55
    mask_antighost: int = 0


@dataclass(frozen=True)
class DesktopSettings:
    mask_protection: int = 55
    mask_antighost: int = 0
    person_zoom: int = 70
    person_vertical: int = 10


@dataclass(frozen=True)
class FileStabilitySettings:
    interval_seconds: float = 0.8
    stable_checks: int = 3
    timeout_seconds: float = 90.0


@dataclass(frozen=True)
class ProcessingSettings:
    move_failed_to_failed: bool = True
    process_existing_on_watch_start: bool = True
    watch_poll_interval_seconds: float = 2.0


@dataclass(frozen=True)
class NuvolSettings:
    enabled: bool = False
    mode: str = "upload_only"
    upload_endpoint: str = "https://bpfhse7oje.execute-api.eu-west-3.amazonaws.com/prod/upload"
    watermark_endpoint: str = "https://gahvah962d.execute-api.eu-west-3.amazonaws.com/test/watermark"
    api_endpoint: str = "https://z1r3s9gz67.execute-api.eu-west-3.amazonaws.com/prod"
    download_dir: Path | None = None
    processed_dir: Path | None = None
    park: str = "monasterio"
    user_group: str = "monasterio"
    username: str = "photoIA"
    auth_username: str = ""
    auth_password: str = ""
    timeout_seconds: float = 90.0
    max_parallel_jobs: int = 2


@dataclass(frozen=True)
class FolderPresetRule:
    pattern: str
    preset: str
    enabled: bool = True


@dataclass(frozen=True)
class LogSettings:
    directory: Path
    jsonl_file: str = "processing.jsonl"

    @property
    def jsonl_path(self) -> Path:
        return self.directory / self.jsonl_file


@dataclass(frozen=True)
class PersonPlacementSettings:
    anchor: str = "bottom_center"
    x: int = 1200
    y: int = 1500
    scale: float = 0.92
    max_width_ratio: float = 0.86
    max_height_ratio: float = 0.95


@dataclass(frozen=True)
class OverlaySettings:
    mode: str = "cover"
    anchor: str = "center"
    x: int = 0
    y: int = 0
    scale: float = 1.0
    opacity: float = 1.0


@dataclass(frozen=True)
class TextLayerSettings:
    text: str = ""
    enabled: bool = False
    anchor: str = "top_center"
    x: int = 0
    y: int = 0
    scale: float = 1.0
    rotation: float = 0.0
    font: str = "Segoe UI"
    color: str = "#FFFFFF"


@dataclass(frozen=True)
class ContactShadowSettings:
    enabled: bool = True
    strength: float = 0.55
    width_ratio: float = 0.72
    height_ratio: float = 0.075
    blur_ratio: float = 0.018
    y_offset_ratio: float = -0.006
    contact_strength: float = 0.85


@dataclass(frozen=True)
class PhotoEnhanceSettings:
    enabled: bool = True
    engine: str = "classic"
    preset: str = "default_event"
    autotune: bool = False
    save_logs: bool = True
    strength: float = 1.0
    brightness: int = 4
    shadow_contrast: int = 30
    highlight_contrast: int = 18
    saturation: int = 8
    red: int = 3
    green: int = -1
    blue: int = -4
    auto_brightness: int = 130
    auto_color: int = 70
    memory_color: int = 90
    shadows: int = 115
    lights: int = 55
    global_sharpen: int = 22
    local_sharpen: int = 10
    denoise: int = 45
    desaturate_shadows: int = 14
    hue_rotation: int = 0


@dataclass(frozen=True)
class ParkSettings:
    name: str
    input_dir: Path
    output_dir: Path
    background_path: Path | None
    overlay_path: Path | None
    logo_path: Path | None
    output_size: tuple[int, int] | str
    person: PersonPlacementSettings
    overlay_settings: OverlaySettings
    logo_settings: OverlaySettings
    text_layer: TextLayerSettings
    jpg_quality: int = 94
    harmonize_strength: float = 0.0
    contact_shadow: ContactShadowSettings = field(default_factory=ContactShadowSettings)
    photo_enhance: PhotoEnhanceSettings = field(default_factory=PhotoEnhanceSettings)
    move_original_to_processed: bool = True
    overwrite_output: bool = False
    unique_output_names: bool = True
    suffix: str = ""
    mirror_input_folders: bool = True
    preserve_output_filename: bool = True


@dataclass(frozen=True)
class AppSettings:
    root_dir: Path
    config_path: Path
    background_removal: BackgroundRemovalSettings
    file_stability: FileStabilitySettings
    processing: ProcessingSettings
    nuvol: NuvolSettings
    logs: LogSettings
    processed_dir: Path
    failed_dir: Path
    parks: dict[str, ParkSettings]
    desktop: DesktopSettings
    active_preset: str = ""
    folder_preset_rules: tuple[FolderPresetRule, ...] = ()

    def get_park(self, name: str) -> ParkSettings:
        try:
            return self.parks[name]
        except KeyError as exc:
            available = ", ".join(sorted(self.parks))
            raise ConfigurationError(
                f"Unknown profile '{name}'. Available profiles: {available}"
            ) from exc

    def ensure_runtime_directories(self) -> None:
        self.logs.directory.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.failed_dir.mkdir(parents=True, exist_ok=True)
        if self.nuvol.download_dir is not None:
            self.nuvol.download_dir.mkdir(parents=True, exist_ok=True)
        if self.nuvol.processed_dir is not None:
            self.nuvol.processed_dir.mkdir(parents=True, exist_ok=True)
        for park in self.parks.values():
            park.input_dir.mkdir(parents=True, exist_ok=True)
            park.output_dir.mkdir(parents=True, exist_ok=True)


def load_settings(path: str | Path = "config/settings.json") -> AppSettings:
    config_path = Path(path).resolve()
    if not config_path.exists():
        raise ConfigurationError(f"Settings file not found: {config_path}")

    with config_path.open("r", encoding="utf-8-sig") as f:
        raw = json.load(f)

    root_dir = _guess_root_dir(config_path)

    background_removal = BackgroundRemovalSettings(
        **_known_dataclass_values(BackgroundRemovalSettings, raw.get("background_removal", {}))
    )
    desktop = DesktopSettings(**_known_dataclass_values(DesktopSettings, raw.get("desktop", {})))
    background_removal = replace(
        background_removal,
        mask_protection=_clamp_int(desktop.mask_protection, 0, 100),
        mask_antighost=_clamp_int(desktop.mask_antighost, 0, 100),
    )
    file_stability = FileStabilitySettings(**raw.get("file_stability", {}))
    processing = ProcessingSettings(**raw.get("processing", {}))
    nuvol_raw = raw.get("nuvol", {}) if isinstance(raw.get("nuvol", {}), dict) else {}
    nuvol_values = _known_dataclass_values(NuvolSettings, nuvol_raw)
    nuvol_download_dir = nuvol_raw.get("download_dir", "nuvol_downloads")
    nuvol_processed_dir = nuvol_raw.get("processed_dir", "processed/nuvol processed")
    nuvol_values["download_dir"] = _resolve_path(root_dir, nuvol_download_dir) if nuvol_download_dir else None
    nuvol_values["processed_dir"] = _resolve_path(root_dir, nuvol_processed_dir) if nuvol_processed_dir else None
    nuvol = NuvolSettings(**nuvol_values)

    logs_raw = raw.get("logs", {})
    logs = LogSettings(
        directory=_resolve_path(root_dir, logs_raw.get("directory", "logs")),
        jsonl_file=logs_raw.get("jsonl_file", "processing.jsonl"),
    )

    parks_raw = raw.get("parks", {})
    if not parks_raw:
        raise ConfigurationError("No processing profiles configured in settings.json")

    parks = {
        name: _park_from_dict(name, data, root_dir)
        for name, data in parks_raw.items()
    }

    settings = AppSettings(
        root_dir=root_dir,
        config_path=config_path,
        background_removal=background_removal,
        file_stability=file_stability,
        processing=processing,
        nuvol=nuvol,
        logs=logs,
        processed_dir=_resolve_path(root_dir, raw.get("processed_dir", "processed")),
        failed_dir=_resolve_path(root_dir, raw.get("failed_dir", "failed")),
        parks=parks,
        desktop=desktop,
        active_preset=str(raw.get("active_preset") or "").strip(),
        folder_preset_rules=_folder_preset_rules_from_raw(raw),
    )
    settings.ensure_runtime_directories()
    return settings


def _park_from_dict(name: str, data: dict[str, Any], root_dir: Path) -> ParkSettings:
    required = ["input_dir", "output_dir"]
    missing = [key for key in required if key not in data]
    if missing:
        raise ConfigurationError(
            f"Profile '{name}' is missing required keys: {', '.join(missing)}"
        )

    output_size_raw = data.get("output_size", "input")
    if isinstance(output_size_raw, str):
        output_size: tuple[int, int] | str = output_size_raw
    else:
        if len(output_size_raw) != 2:
            raise ConfigurationError(f"Profile '{name}' output_size must contain width/height")
        output_size = (int(output_size_raw[0]), int(output_size_raw[1]))

    overlay_raw = data.get("overlay")
    overlay_path = _resolve_path(root_dir, overlay_raw) if overlay_raw else None
    logo_raw = data.get("logo")
    logo_path = _resolve_path(root_dir, logo_raw) if logo_raw else None
    background_raw = data.get("background")
    background_path = _resolve_path(root_dir, background_raw) if background_raw else None

    return ParkSettings(
        name=name,
        input_dir=_resolve_path(root_dir, data["input_dir"]),
        output_dir=_resolve_path(root_dir, data["output_dir"]),
        background_path=background_path,
        overlay_path=overlay_path,
        logo_path=logo_path,
        output_size=output_size,
        person=PersonPlacementSettings(**_known_dataclass_values(PersonPlacementSettings, data.get("person", {}))),
        overlay_settings=OverlaySettings(**_known_dataclass_values(OverlaySettings, data.get("overlay_settings", {}))),
        logo_settings=OverlaySettings(**_known_dataclass_values(OverlaySettings, data.get("logo_settings", {"mode": "original", "anchor": "top_left"}))),
        text_layer=TextLayerSettings(**_known_dataclass_values(TextLayerSettings, data.get("text_layer", {}))),
        jpg_quality=int(data.get("jpg_quality", 94)),
        harmonize_strength=float(data.get("harmonize_strength", 0.0)),
        contact_shadow=ContactShadowSettings(**_known_dataclass_values(ContactShadowSettings, data.get("contact_shadow", {}))),
        photo_enhance=PhotoEnhanceSettings(**_known_dataclass_values(PhotoEnhanceSettings, data.get("photo_enhance", {}))),
        move_original_to_processed=bool(data.get("move_original_to_processed", True)),
        overwrite_output=bool(data.get("overwrite_output", False)),
        unique_output_names=bool(data.get("unique_output_names", True)),
        suffix=str(data.get("suffix", f"_{name}")),
        mirror_input_folders=bool(data.get("mirror_input_folders", True)),
        preserve_output_filename=bool(data.get("preserve_output_filename", True)),
    )


def _guess_root_dir(config_path: Path) -> Path:
    if config_path.parent.name.lower() == "config":
        return config_path.parent.parent
    return config_path.parent


def _folder_preset_rules_from_raw(raw: dict[str, Any]) -> tuple[FolderPresetRule, ...]:
    rules_raw = raw.get("folder_presets", raw.get("folder_preset_rules", []))
    if isinstance(rules_raw, dict):
        rules_raw = [
            {"pattern": pattern, "preset": preset}
            for pattern, preset in rules_raw.items()
        ]
    if not isinstance(rules_raw, list):
        return ()

    rules: list[FolderPresetRule] = []
    for item in rules_raw:
        if not isinstance(item, dict):
            continue
        pattern = str(
            item.get("pattern")
            or item.get("folder")
            or item.get("prefix")
            or ""
        ).strip()
        preset = str(item.get("preset") or "").strip()
        if not pattern or not preset:
            continue
        rules.append(
            FolderPresetRule(
                pattern=pattern,
                preset=preset,
                enabled=bool(item.get("enabled", True)),
            )
        )
    return tuple(rules)


def _resolve_path(root_dir: Path, value: str | Path) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return root_dir / path


def _clamp_int(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(max_value, int(value)))


def _known_dataclass_values(cls, data: dict[str, Any]) -> dict[str, Any]:
    allowed = {field.name for field in fields(cls)}
    return {key: value for key, value in data.items() if key in allowed}


