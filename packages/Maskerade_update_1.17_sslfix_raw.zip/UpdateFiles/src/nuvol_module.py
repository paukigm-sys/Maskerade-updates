from __future__ import annotations

import json
import hashlib
import hmac
import mimetypes
import os
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib import request, error, parse


IMAGE_FIELD_NAME = "file"
AWS_REGION = "eu-west-3"
COGNITO_USER_POOL_ID = "eu-west-3_kRUJ6ppMH"
COGNITO_CLIENT_ID = "40paf165ojf7d5bs7u549souqh"
COGNITO_IDENTITY_POOL_ID = "eu-west-3:76772541-ec8c-45b9-9883-178c18f75e86"
PHOTO_EVENTS_TABLE = "nuvolcam-photo-events-prod"
PHOTO_BUCKET = "nuvolcam-photos-prod"
_AUTH_CACHE: dict[str, dict[str, Any]] = {}
_PROCESSED_LIST_LOCK = threading.Lock()


@dataclass(frozen=True)
class NuvolResult:
    status: str
    uploaded: bool = False
    downloaded: bool = False
    skipped: bool = False
    output_path: Path | None = None
    download_path: Path | None = None
    message: str = ""


def process_output_photo(output_path: Path, input_path: Path, settings, root_dir: Path, logger) -> NuvolResult:
    if not getattr(settings, "enabled", False):
        return NuvolResult("disabled", output_path=output_path)

    output_path = Path(output_path)
    input_path = Path(input_path)
    if not output_path.exists():
        return NuvolResult("missing", output_path=output_path, message="Output file does not exist")

    mode = str(getattr(settings, "mode", "upload_only") or "upload_only").strip().lower()
    processed = _ProcessedList(_processed_list_path(root_dir))
    key = _processed_key(output_path)
    if processed.contains(key):
        logger.info("Nuvol skipped already processed: %s", output_path)
        return NuvolResult("skipped", skipped=True, output_path=output_path)

    if mode in {"upload_download", "upload_and_download", "download", "subir_descargar"}:
        result = _upload_and_download(output_path, input_path, settings, root_dir, logger)
    else:
        result = _upload_only(output_path, settings, logger)

    if result.uploaded or result.downloaded:
        processed.add(key)
    return result


def _request_presigned_upload(photo_path: Path, settings, logger) -> bytes:
    endpoint = str(getattr(settings, "upload_endpoint", "") or "").strip()
    if not endpoint:
        raise RuntimeError("Nuvol upload endpoint is empty")

    mime = mimetypes.guess_type(photo_path.name)[0] or "image/jpeg"
    now = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    payload = {
        "filename": photo_path.name,
        "park": str(getattr(settings, "park", "") or ""),
        "userGroup": str(getattr(settings, "user_group", "") or ""),
        "username": str(getattr(settings, "username", "") or ""),
        "contentType": mime,
        "exif": {
            "image": photo_path.name,
            "program": "Maskerade",
            "originalDateTime": now,
            "digitizationDateTime": now,
            "source": "maskerade-nuvol-module",
            "uploadTimestamp": now,
        },
    }
    logger.info(
        "Nuvol presigned request: %s -> park=%s userGroup=%s username=%s",
        photo_path.name,
        payload["park"],
        payload["userGroup"],
        payload["username"],
    )
    print(f"NUVOL presigned {photo_path.name} {payload['username']}", flush=True)
    return _post_json(endpoint, payload, timeout=_timeout(settings))


def _upload_to_s3(photo_path: Path, settings, logger) -> tuple[bytes, Any]:
    response = _request_presigned_upload(photo_path, settings, logger)
    payload = _json_or_text(response)
    presigned_url = _find_presigned_url(payload)
    if not presigned_url:
        raise RuntimeError(f"Nuvol did not return presignedUrl: {_short_response(response)}")

    mime = mimetypes.guess_type(photo_path.name)[0] or "image/jpeg"
    print(f"NUVOL uploading {photo_path.name} {str(getattr(settings, 'username', '') or '')}", flush=True)
    status = _put_file(presigned_url, photo_path, mime, timeout=_timeout(settings))
    logger.info("Nuvol upload OK: %s HTTP %s", photo_path, status)
    print(f"NUVOL uploaded {photo_path.name} {str(getattr(settings, 'username', '') or '')}", flush=True)
    return response, payload


def _upload_only(photo_path: Path, settings, logger) -> NuvolResult:
    _upload_to_s3(photo_path, settings, logger)
    return NuvolResult("uploaded", uploaded=True, output_path=photo_path, message="S3 HTTP 200")


def _upload_and_download(photo_path: Path, input_path: Path, settings, root_dir: Path, logger) -> NuvolResult:
    _, upload_payload = _upload_to_s3(photo_path, settings, logger)
    s3_key = _find_string(upload_payload, {"s3Key", "key", "Key"})
    endpoint = str(getattr(settings, "watermark_endpoint", "") or "").strip()
    if not endpoint or not s3_key:
        message = "Uploaded OK, but watermark/download skipped because s3Key or watermark endpoint is missing"
        logger.warning("Nuvol %s: %s", photo_path, message)
        return NuvolResult("uploaded_no_download", uploaded=True, output_path=photo_path, message=message)

    print(f"NUVOL watermark {photo_path.name} {str(getattr(settings, 'username', '') or '')}", flush=True)
    watermark_response = _post_json(
        endpoint,
        {"s3Key": s3_key, "bucket": PHOTO_BUCKET},
        timeout=_timeout(settings),
    )
    watermark_payload = _json_or_text(watermark_response)
    logger.info("Nuvol watermark OK: %s", _short_response(watermark_response))

    download_url = _find_download_url(watermark_payload)
    if not download_url:
        logger.info("Nuvol watermark did not return URL; requesting signed view URL for %s", s3_key)
        download_url = _get_backend_view_url(s3_key, settings)

    download_dir = Path(getattr(settings, "download_dir", None) or (root_dir / "nuvol_downloads"))
    relative_folder = _relative_parent(input_path, root_dir / "input")
    target_dir = download_dir / relative_folder if relative_folder else download_dir
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = _unique_path(target_dir / photo_path.name)

    print(f"NUVOL downloading {photo_path.name} {str(getattr(settings, 'username', '') or '')}", flush=True)
    data = _download_bytes_with_retry(download_url, timeout=_timeout(settings), attempts=5, delay=1.5)
    data = _copy_jpeg_exif_bytes(photo_path.read_bytes(), data)
    target_path.write_bytes(data)
    _copy_timestamps(photo_path, target_path)
    _mark_backend_downloaded(s3_key, settings, logger)
    logger.info("Nuvol download OK: %s", target_path)
    print(f"NUVOL downloaded {photo_path.name} {str(getattr(settings, 'username', '') or '')}", flush=True)
    return NuvolResult("downloaded", uploaded=True, downloaded=True, output_path=photo_path, download_path=target_path)

def _post_json(endpoint: str, payload: dict[str, Any], timeout: float) -> bytes:
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"Nuvol HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Nuvol connection error: {exc.reason}") from exc


def _find_presigned_url(payload: Any) -> str | None:
    names = {"presignedUrl", "presignedURL", "presigned_url", "uploadUrl", "uploadURL", "signedUrl", "signedURL", "url"}
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        for value in payload.values():
            found = _find_presigned_url(value)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_presigned_url(item)
            if found:
                return found
    return None


def _find_string(payload: Any, names: set[str]) -> str | None:
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value:
                return value
        for value in payload.values():
            found = _find_string(value, names)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_string(item, names)
            if found:
                return found
    return None

def _put_file(url: str, file_path: Path, mime: str, timeout: float) -> int:
    file_bytes = file_path.read_bytes()
    req = request.Request(
        url,
        data=file_bytes,
        headers={"Content-Type": mime, "Content-Length": str(len(file_bytes))},
        method="PUT",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            resp.read()
            return int(resp.status)
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"S3 upload HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"S3 upload connection error: {exc.reason}") from exc
def _post_multipart(endpoint: str, fields: dict[str, str], file_path: Path, timeout: float) -> bytes:
    boundary = "----MaskeradeNuvol" + uuid.uuid4().hex
    body = bytearray()
    for name, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.extend(str(value).encode("utf-8"))
        body.extend(b"\r\n")

    mime = mimetypes.guess_type(file_path.name)[0] or "image/jpeg"
    file_bytes = file_path.read_bytes()
    body.extend(f"--{boundary}\r\n".encode())
    body.extend(
        f'Content-Disposition: form-data; name="{IMAGE_FIELD_NAME}"; filename="{file_path.name}"\r\n'.encode()
    )
    body.extend(f"Content-Type: {mime}\r\n\r\n".encode())
    body.extend(file_bytes)
    body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())

    req = request.Request(
        endpoint,
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"Nuvol HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"Nuvol connection error: {exc.reason}") from exc


def _download_bytes(url: str, timeout: float) -> bytes:
    req = request.Request(url, headers={"User-Agent": "MaskeradeNuvol/1.0"})
    with request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def _download_bytes_with_retry(url: str, timeout: float, attempts: int, delay: float) -> bytes:
    last_error: Exception | None = None
    for attempt in range(1, max(1, attempts) + 1):
        try:
            data = _download_bytes(url, timeout=timeout)
            if data:
                return data
            last_error = RuntimeError("empty download")
        except Exception as exc:
            last_error = exc
        if attempt < attempts:
            time.sleep(delay)
    raise RuntimeError(f"Nuvol download failed after {attempts} attempts: {last_error}")


def _api_endpoint(settings) -> str:
    return str(getattr(settings, "api_endpoint", "") or "https://z1r3s9gz67.execute-api.eu-west-3.amazonaws.com/prod").rstrip("/")


def _get_backend_view_url(s3_key: str, settings) -> str:
    base = _api_endpoint(settings)
    response = _post_json(
        f"{base}/view",
        {"s3Key": s3_key, "bucket": PHOTO_BUCKET},
        timeout=_timeout(settings),
    )
    payload = _json_or_text(response)
    url = _find_download_url(payload)
    if not url:
        raise RuntimeError(f"Nuvol view did not return a signed URL for {s3_key}: {payload}")
    return url


def _mark_backend_downloaded(s3_key: str, settings, logger) -> None:
    if _mark_dynamo_downloaded(s3_key, settings, logger):
        return

    logger.info("Nuvol Desktop login not configured; skipping global downloaded state for %s", s3_key)


def _mark_dynamo_downloaded(s3_key: str, settings, logger) -> bool:
    credentials = _get_desktop_aws_credentials(settings, logger)
    if not credentials:
        return False

    try:
        now = datetime.now(timezone.utc)
        code = (s3_key.split("/")[-1] or s3_key).rsplit(".", 1)[0]
        item = {
            "parkId": {"S": _normalize_park_id(getattr(settings, "park", ""))},
            "eventTimestamp": {"S": f"{now.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]}Z#{uuid.uuid4().hex[:8].upper()}"},
            "type": {"S": "photo_downloaded"},
            "eventType": {"S": "photo_downloaded"},
            "date": {"S": now.strftime("%Y-%m-%d")},
            "userId": {"S": str(getattr(settings, "auth_username", "") or "maskerade")},
            "s3Key": {"S": str(s3_key)},
            "code": {"S": code},
        }
        _aws_signed_json(
            service="dynamodb",
            endpoint=f"https://dynamodb.{AWS_REGION}.amazonaws.com/",
            target="DynamoDB_20120810.PutItem",
            payload={"TableName": PHOTO_EVENTS_TABLE, "Item": item},
            credentials=credentials,
            timeout=_timeout(settings),
        )
        logger.info("Nuvol marked downloaded in DynamoDB: %s", s3_key)
        return True
    except Exception as exc:
        logger.warning("Nuvol could not mark downloaded in DynamoDB for %s: %s", s3_key, exc)
        return False


def _get_desktop_aws_credentials(settings, logger) -> dict[str, str] | None:
    username = str(getattr(settings, "auth_username", "") or os.environ.get("NUVOL_DESKTOP_USERNAME", "")).strip()
    password = str(getattr(settings, "auth_password", "") or os.environ.get("NUVOL_DESKTOP_PASSWORD", ""))
    if not username or not password:
        return None

    cache_key = username
    cached = _AUTH_CACHE.get(cache_key)
    if cached and float(cached.get("expires_at", 0)) > time.time() + 300:
        return cached["credentials"]

    auth_payload = _aws_json_unsigned(
        endpoint=f"https://cognito-idp.{AWS_REGION}.amazonaws.com/",
        target="AWSCognitoIdentityProviderService.InitiateAuth",
        payload={
            "AuthFlow": "USER_PASSWORD_AUTH",
            "ClientId": COGNITO_CLIENT_ID,
            "AuthParameters": {"USERNAME": username, "PASSWORD": password},
        },
        timeout=_timeout(settings),
    )
    auth_result = auth_payload.get("AuthenticationResult") if isinstance(auth_payload, dict) else None
    id_token = auth_result.get("IdToken") if isinstance(auth_result, dict) else None
    if not id_token:
        raise RuntimeError(f"Cognito login did not return IdToken: {auth_payload}")

    logins_key = f"cognito-idp.{AWS_REGION}.amazonaws.com/{COGNITO_USER_POOL_ID}"
    identity_payload = _aws_json_unsigned(
        endpoint=f"https://cognito-identity.{AWS_REGION}.amazonaws.com/",
        target="AWSCognitoIdentityService.GetId",
        payload={"IdentityPoolId": COGNITO_IDENTITY_POOL_ID, "Logins": {logins_key: id_token}},
        timeout=_timeout(settings),
    )
    identity_id = identity_payload.get("IdentityId") if isinstance(identity_payload, dict) else None
    if not identity_id:
        raise RuntimeError(f"Cognito identity did not return IdentityId: {identity_payload}")

    creds_payload = _aws_json_unsigned(
        endpoint=f"https://cognito-identity.{AWS_REGION}.amazonaws.com/",
        target="AWSCognitoIdentityService.GetCredentialsForIdentity",
        payload={"IdentityId": identity_id, "Logins": {logins_key: id_token}},
        timeout=_timeout(settings),
    )
    raw = creds_payload.get("Credentials") if isinstance(creds_payload, dict) else None
    if not isinstance(raw, dict):
        raise RuntimeError(f"Cognito identity did not return credentials: {creds_payload}")

    credentials = {
        "access_key": raw.get("AccessKeyId") or "",
        "secret_key": raw.get("SecretKey") or "",
        "session_token": raw.get("SessionToken") or "",
    }
    if not credentials["access_key"] or not credentials["secret_key"] or not credentials["session_token"]:
        raise RuntimeError("Cognito returned incomplete AWS credentials")

    expires_at = _credential_expiry_epoch(raw.get("Expiration"))
    _AUTH_CACHE[cache_key] = {"credentials": credentials, "expires_at": expires_at}
    logger.info("Nuvol Desktop Cognito login OK for %s", username)
    return credentials


def _aws_json_unsigned(endpoint: str, target: str, payload: dict[str, Any], timeout: float) -> Any:
    data = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    req = request.Request(
        endpoint,
        data=data,
        headers={"Content-Type": "application/x-amz-json-1.1", "X-Amz-Target": target},
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return _json_or_text(resp.read())
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"AWS HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"AWS connection error: {exc.reason}") from exc


def _aws_signed_json(
    service: str,
    endpoint: str,
    target: str,
    payload: dict[str, Any],
    credentials: dict[str, str],
    timeout: float,
) -> Any:
    data = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    parsed = parse.urlparse(endpoint)
    host = parsed.netloc
    path = parsed.path or "/"
    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")
    payload_hash = hashlib.sha256(data).hexdigest()
    headers = {
        "content-type": "application/x-amz-json-1.0",
        "host": host,
        "x-amz-date": amz_date,
        "x-amz-security-token": credentials["session_token"],
        "x-amz-target": target,
    }
    signed_headers = ";".join(sorted(headers))
    canonical_headers = "".join(f"{key}:{headers[key]}\n" for key in sorted(headers))
    canonical_request = f"POST\n{path}\n\n{canonical_headers}\n{signed_headers}\n{payload_hash}"
    credential_scope = f"{date_stamp}/{AWS_REGION}/{service}/aws4_request"
    string_to_sign = (
        "AWS4-HMAC-SHA256\n"
        f"{amz_date}\n"
        f"{credential_scope}\n"
        f"{hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()}"
    )
    signing_key = _aws_signature_key(credentials["secret_key"], date_stamp, AWS_REGION, service)
    signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()
    auth = (
        "AWS4-HMAC-SHA256 "
        f"Credential={credentials['access_key']}/{credential_scope}, "
        f"SignedHeaders={signed_headers}, "
        f"Signature={signature}"
    )
    req = request.Request(
        endpoint,
        data=data,
        headers={
            "Authorization": auth,
            "Content-Type": headers["content-type"],
            "Host": host,
            "X-Amz-Date": amz_date,
            "X-Amz-Security-Token": credentials["session_token"],
            "X-Amz-Target": target,
        },
        method="POST",
    )
    try:
        with request.urlopen(req, timeout=timeout) as resp:
            return _json_or_text(resp.read())
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:800]
        raise RuntimeError(f"AWS signed HTTP {exc.code}: {detail}") from exc
    except error.URLError as exc:
        raise RuntimeError(f"AWS signed connection error: {exc.reason}") from exc


def _aws_signature_key(secret_key: str, date_stamp: str, region: str, service: str) -> bytes:
    key = ("AWS4" + secret_key).encode("utf-8")
    for value in (date_stamp, region, service, "aws4_request"):
        key = hmac.new(key, value.encode("utf-8"), hashlib.sha256).digest()
    return key


def _credential_expiry_epoch(value: Any) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        except Exception:
            return time.time() + 3300
    return time.time() + 3300


def _normalize_park_id(value: Any) -> str:
    return str(value or "").strip().lower()


def _json_or_text(data: bytes) -> Any:
    text = data.decode("utf-8", errors="replace")
    try:
        return json.loads(text)
    except Exception:
        return text


def _find_download_url(payload: Any) -> str | None:
    names = {
        "downloadUrl", "downloadURL", "download_url", "viewUrl", "viewURL", "view_url", "url", "signedUrl", "signedURL",
        "presignedUrl", "presignedURL", "resultUrl", "resultURL", "imageUrl", "imageURL",
    }
    if isinstance(payload, dict):
        for key, value in payload.items():
            if key in names and isinstance(value, str) and value.startswith(("http://", "https://")):
                return value
        for value in payload.values():
            found = _find_download_url(value)
            if found:
                return found
    elif isinstance(payload, list):
        for item in payload:
            found = _find_download_url(item)
            if found:
                return found
    elif isinstance(payload, str) and payload.startswith(("http://", "https://")):
        return payload
    return None


def _short_response(data: bytes) -> str:
    return data.decode("utf-8", errors="replace")[:500]


def _timeout(settings) -> float:
    return max(10.0, float(getattr(settings, "timeout_seconds", 90.0) or 90.0))


def _processed_list_path(root_dir: Path) -> Path:
    path = Path(root_dir) / "config" / "nuvol_processed_list.tsv"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _processed_key(path: Path) -> str:
    stat = path.stat()
    return f"{path.name}\t{stat.st_size}"


class _ProcessedList:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.items = set()
        with _PROCESSED_LIST_LOCK:
            if path.exists():
                self.items = {line.strip() for line in path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip()}

    def contains(self, key: str) -> bool:
        return key in self.items

    def add(self, key: str) -> None:
        with _PROCESSED_LIST_LOCK:
            if self.path.exists():
                self.items = {line.strip() for line in self.path.read_text(encoding="utf-8", errors="ignore").splitlines() if line.strip()}
            if key in self.items:
                return
            with self.path.open("a", encoding="utf-8") as f:
                f.write(key + "\n")
            self.items.add(key)


def _relative_parent(path: Path, root: Path) -> Path | None:
    try:
        relative = path.parent.resolve().relative_to(root.resolve())
        if str(relative) == ".":
            return None
        return relative
    except Exception:
        return None


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    suffix = path.suffix
    parent = path.parent
    for index in range(1, 10000):
        candidate = parent / f"{stem}-{index}{suffix}"
        if not candidate.exists():
            return candidate
    return parent / f"{stem}-{int(time.time())}{suffix}"


def _copy_timestamps(source: Path, target: Path) -> None:
    try:
        stat = source.stat()
        os.utime(target, (stat.st_atime, stat.st_mtime))
    except Exception:
        pass


def _copy_jpeg_exif_bytes(source: bytes, target: bytes) -> bytes:
    exif = _extract_exif_segment(source)
    if not exif or not target.startswith(b"\xff\xd8"):
        return target
    cleaned = _remove_exif_segments(target)
    return cleaned[:2] + exif + cleaned[2:]


def _extract_exif_segment(data: bytes) -> bytes | None:
    if not data.startswith(b"\xff\xd8"):
        return None
    offset = 2
    while offset + 4 <= len(data) and data[offset] == 0xFF:
        marker = data[offset + 1]
        if marker in {0xDA, 0xD9}:
            break
        length = int.from_bytes(data[offset + 2:offset + 4], "big")
        segment = data[offset:offset + 2 + length]
        if marker == 0xE1 and segment[4:10] == b"Exif\x00\x00":
            return segment
        offset += 2 + length
    return None


def _remove_exif_segments(data: bytes) -> bytes:
    if not data.startswith(b"\xff\xd8"):
        return data
    chunks = [data[:2]]
    offset = 2
    while offset + 4 <= len(data) and data[offset] == 0xFF:
        marker = data[offset + 1]
        if marker in {0xDA, 0xD9}:
            chunks.append(data[offset:])
            return b"".join(chunks)
        length = int.from_bytes(data[offset + 2:offset + 4], "big")
        segment = data[offset:offset + 2 + length]
        if not (marker == 0xE1 and segment[4:10] == b"Exif\x00\x00"):
            chunks.append(segment)
        offset += 2 + length
    chunks.append(data[offset:])
    return b"".join(chunks)


