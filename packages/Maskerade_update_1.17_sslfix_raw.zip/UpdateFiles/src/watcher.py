from __future__ import annotations

import logging
import time
from pathlib import Path

from .config import SUPPORTED_IMAGE_EXTENSIONS, load_settings
from .image_utils import list_images
from .processor import PhotoProcessor, ProcessingBusyError


class WatchService:
    def __init__(self, processor: PhotoProcessor, logger: logging.Logger) -> None:
        self.processor = processor
        self.logger = logger
        self._stability: dict[Path, tuple[tuple[int, int], float]] = {}
        self._seen: set[Path] = set()
        self._tree_signature: tuple[tuple[str, int, int], ...] | None = None
        self._tree_stable_since: float | None = None
        self._waiting_for_tree_log = False
        self._busy_path: Path | None = None
        self._busy_next_log_at = 0.0

    def run(self, process_existing: bool = True) -> None:
        self.processor.ensure_ready()
        self.logger.info("Hotfolder input: %s", self.processor.park.input_dir)

        if process_existing:
            self.logger.info("Hotfolder will process existing JPG files recursively")
        else:
            self._mark_existing_seen()

        # Polling is deliberately used on Windows because folders often arrive
        # through copy/sync operations in bursts. A full-tree stability check is
        # more reliable than reacting to individual filesystem events.
        self._run_polling()

    def _run_watchdog(self) -> None:
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        service = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.src_path)
                service._note_event(path, event.is_directory)

            def on_moved(self, event) -> None:  # type: ignore[no-untyped-def]
                path = Path(event.dest_path)
                service._note_event(path, event.is_directory)

        observer = Observer()
        observer.schedule(Handler(), str(self.processor.park.input_dir), recursive=True)
        observer.start()
        self.logger.info("Watching %s recursively", self.processor.park.input_dir)

        try:
            while True:
                self._process_new_files()
                time.sleep(self.processor.settings.processing.watch_poll_interval_seconds)
        except KeyboardInterrupt:
            self.logger.info("Stopping watcher")
        finally:
            observer.stop()
            observer.join()

    def _run_polling(self) -> None:
        interval = self.processor.settings.processing.watch_poll_interval_seconds
        self.logger.info(
            "Polling %s every %.1fs",
            self.processor.park.input_dir,
            interval,
        )
        try:
            while True:
                self._process_new_files()
                time.sleep(interval)
        except KeyboardInterrupt:
            self.logger.info("Stopping polling watcher")

    def _mark_existing_seen(self) -> None:
        self._seen.update(list_images(self.processor.park.input_dir))

    def _note_event(self, path: Path, is_directory: bool) -> None:
        if is_directory:
            self.logger.info("Detected new folder: %s", path)
            return
        if path.suffix.lower() in SUPPORTED_IMAGE_EXTENSIONS:
            self.logger.info("Detected new file: %s", path)

    def _process_new_files(self) -> None:
        self._reload_processor_settings()
        current_images = list_images(self.processor.park.input_dir)
        self._seen.intersection_update(current_images)
        candidates = [
            path
            for path in current_images
            if path not in self._seen
        ]
        if not candidates:
            self._stability.clear()
            self._tree_signature = None
            self._tree_stable_since = None
            self._waiting_for_tree_log = False
            self._reset_busy_state()
            self.processor.poll_nuvol()
            self.processor.cleanup_empty_input_dirs()
            return

        if not self._is_tree_ready(candidates):
            return

        handled_any = False
        completed_all = True
        for path in candidates:
            if path in self._seen:
                continue
            if not self._handle_candidate(path):
                completed_all = False
                break
            handled_any = True

        active = set(candidates)
        for path in list(self._stability):
            if path not in active:
                self._stability.pop(path, None)

        self.processor.cleanup_empty_input_dirs()
        self.processor.poll_nuvol()
        if handled_any and completed_all:
            self.logger.info("Hotfolder batch complete")

    def _is_tree_ready(self, candidates: list[Path]) -> bool:
        signature_items: list[tuple[str, int, int]] = []
        input_dir = self.processor.park.input_dir

        for path in candidates:
            try:
                stat = path.stat()
            except FileNotFoundError:
                self._stability.pop(path, None)
                continue

            if stat.st_size <= 0:
                self._mark_tree_unstable()
                self._log_waiting_once()
                return False

            try:
                relative = path.relative_to(input_dir).as_posix().lower()
            except ValueError:
                relative = str(path).lower()
            signature_items.append((relative, stat.st_size, int(stat.st_mtime_ns)))

        if not signature_items:
            return False

        signature = tuple(signature_items)
        now = time.monotonic()
        if signature != self._tree_signature:
            self._tree_signature = signature
            self._tree_stable_since = now
            self._log_waiting_once()
            return False

        stable_since = self._tree_stable_since or now
        interval = max(0.5, self.processor.settings.file_stability.interval_seconds)
        checks = max(1, self.processor.settings.file_stability.stable_checks)
        required_seconds = interval * checks

        if (now - stable_since) < required_seconds:
            self._log_waiting_once()
            return False

        self._waiting_for_tree_log = False
        return True

    def _mark_tree_unstable(self) -> None:
        self._tree_signature = None
        self._tree_stable_since = None

    def _log_waiting_once(self) -> None:
        if self._waiting_for_tree_log:
            return
        self.logger.info("Hotfolder waiting until IN and subfolders stop changing")
        self._waiting_for_tree_log = True

    def _is_ready(self, path: Path) -> bool:
        try:
            stat = path.stat()
        except FileNotFoundError:
            self._stability.pop(path, None)
            return False

        if stat.st_size <= 0:
            return False

        signature = (stat.st_size, int(stat.st_mtime_ns))
        now = time.monotonic()
        previous = self._stability.get(path)

        if previous is None:
            self._stability[path] = (signature, now)
            return False

        previous_signature, stable_since = previous
        if signature != previous_signature:
            self._stability[path] = (signature, now)
            return False

        interval = max(0.5, self.processor.settings.file_stability.interval_seconds)
        checks = max(1, self.processor.settings.file_stability.stable_checks)
        required_seconds = interval * checks

        return (now - stable_since) >= required_seconds

    def _handle_candidate(self, path: Path) -> bool:
        if not path.exists():
            self.logger.warning("Hotfolder skipped disappeared file: %s", path)
            self._stability.pop(path, None)
            return True

        if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
            self._seen.add(path)
            return True

        try:
            self._reload_processor_settings()
            result = self.processor.process_file(path, wait_for_stability=False)
            if result.status in {"processed", "skipped"}:
                self._seen.add(path)
                self._stability.pop(path, None)
            elif result.status == "failed":
                self._seen.add(path)
                self._stability.pop(path, None)
            self._reset_busy_state(path)
            return True
        except ProcessingBusyError:
            self._log_busy_retry(path)
            return False

    def _reload_processor_settings(self) -> None:
        try:
            settings = load_settings(self.processor.settings.config_path)
        except Exception as exc:
            self.logger.warning(
                "Hotfolder could not reload settings; keeping previous config: %s",
                exc,
            )
            return
        park_name = self.processor.park.name
        if park_name not in settings.parks:
            park_name = next(iter(settings.parks))
        self.processor.update_settings(settings, settings.get_park(park_name))

    def _log_busy_retry(self, path: Path) -> None:
        now = time.monotonic()
        if self._busy_path != path:
            self._busy_path = path
            self._busy_next_log_at = 0.0

        if now < self._busy_next_log_at:
            return

        self.logger.warning(
            "Hotfolder ocupado: hay otro proceso activo. Esperando turno para %s",
            path,
        )
        self._busy_next_log_at = now + 15.0

    def _reset_busy_state(self, path: Path | None = None) -> None:
        if path is not None and self._busy_path is not None and self._busy_path != path:
            return
        self._busy_path = None
        self._busy_next_log_at = 0.0

    def _handle_directory(self, path: Path) -> None:
        if not path.exists() or not path.is_dir():
            return
        for image_path in list_images(path):
            self._handle_candidate(image_path)
